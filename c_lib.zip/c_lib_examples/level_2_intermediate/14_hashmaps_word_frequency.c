/*
 * ============================================================================
 * c_lib_examples - Level 2 (Intermediate) - Example 14 of 30
 * File: level_2_intermediate/14_hashmaps_word_frequency.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   `Cl_Map_Str_I64` (Swiss-style H2 control bytes + dense contiguous arrays),
 *   byte-content string hashing, update/lookup/delete, dense iteration, and
 *   sorting results into a `Cl_DA`.
 *
 * WHY USE Cl_Map'S DENSE + H2 ARCHITECTURE:
 *   - 7-bit H2 tags in the control array reject ~99.2% of hash collisions
 *     with a single byte comparison before ever touching `keys[]`.
 *   - Storing `keys[]` and `values[]` densely in `0 .. len - 1` makes
 *     `CL_MAP_FOR_EACH` a flat, cache-friendly sequential scan (zero empty
 *     buckets skipped!).
 *   - `CL_MAP_INIT_STR` hashes string BYTES (`cl_hash_fnv1a64`), NOT pointer
 *     addresses, so two `Cl_Str` slices pointing to different buffers with
 *     identical text match as the same key.
 *
 * WHEN TO USE:
 *   - Counting/grouping, symbol tables, caches, deduplication, inverted indexes.
 *
 * ADVANTAGES:
 *   + Typed `V *` lookup (`CL_MAP_GET`), O(1) amortized put/get/delete.
 *   + One shared engine in `cl_map.c` keeps binary size tiny.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - `CL_MAP_DELETE` uses swap-remove on dense arrays, so iteration order
 *     changes after deletion (extract to `Cl_DA` and sort for stable display).
 *   - Keys are NOT auto-cloned: ensure key strings outlive the map (e.g., via
 *     a backing `Cl_Arena` as shown below).
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

typedef struct Word_Freq {
    Cl_Str word;
    cl_i64 count;
} Word_Freq;

CL_DA_DEFINE(DA_Word_Freq, Word_Freq);

static int cmp_freq_desc(const void *a, const void *b) {
    const Word_Freq *wa = (const Word_Freq *)a;
    const Word_Freq *wb = (const Word_Freq *)b;
    if (wa->count != wb->count) {
        return (wb->count > wa->count) - (wb->count < wa->count);
    }
    return cl_str_cmp(wa->word, wb->word);
}

int main(void) {
    printf("=== Example 14: HashMap Word Frequency Counter ===\n\n");

    Cl_Tracking_Allocator tr;
    cl_tracking_init(&tr, cl_heap_allocator());
    CL_DEFER_TRACKING(tr);
    Cl_Allocator alloc = cl_tracking_allocator(&tr);

    /* Backing arena owns normalized lowercase key strings (freed in O(1)) */
    Cl_Arena key_arena;
    CL_ENSURE(cl_arena_init_alloc(&key_arena, CL_KB(8), alloc));
    CL_DEFER_ARENA(key_arena);
    Cl_Allocator ka = cl_arena_allocator(&key_arena);

    Cl_Map_Str_I64 counts = {0};
    CL_MAP_INIT_STR(&counts, alloc);
    CL_DEFER_MAP(counts);

    Cl_Str prose = CL_STR(
        "Arenas make memory simple. Slices make buffers safe. "
        "Simple and safe memory makes C99 joyful like Odin!"
    );

    Cl_Str cur = prose;
    for (;;) {
        Cl_Str tok;
        CL_OPT_OR_BREAK(tok, cl_str_fields_iter(&cur));
        tok = cl_str_trim_cutset(tok, CL_STR(".,!?"));
        if (tok.len == 0) continue;

        Cl_Str key = cl_str_to_lower(tok, ka);
        cl_i64 *slot = CL_MAP_GET(&counts, key);
        if (slot != NULL) {
            *slot += 1;
        } else {
            CL_MAP_PUT(&counts, key, 1);
        }
    }

    /* Demonstrate deletion of a stop-word before ranking */
    (void)CL_MAP_DELETE(&counts, CL_STR("and"));

    DA_Word_Freq ranked = {0};
    CL_DA_INIT_CAP(&ranked, alloc, CL_MAP_LEN(&counts));
    CL_DEFER_DA(ranked);

    CL_MAP_FOR_EACH(i, &counts) {
        CL_DA_PUSH(&ranked, ((Word_Freq){ counts.keys[i], counts.values[i] }));
    }
    CL_DA_SORT(&ranked, cmp_freq_desc);

    printf("Top words (excluding 'and'):\n");
    for (cl_isize i = 0; i < CL_MIN(ranked.len, (cl_isize)8); i++) {
        Word_Freq wf = CL_DA_AT(&ranked, i);
        printf("  %-10.*s : %lld\n", CL_STR_ARG(wf.word), (CL_LL)wf.count);
    }

    cl_ctx_thread_shutdown();
    return 0;
}
