/*
 * ============================================================================
 * c_lib_examples - Level 2 (Intermediate) - Example 12 of 30
 * File: level_2_intermediate/12_context_and_dual_scratch_arenas.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Thread-local `Cl_Context` stack (`cl_ctx_push`/`pop`, `CL_DEFER_CTX_PUSH`),
 *   Odin-style `context.temp_allocator`, `cl_tprintf()`, and conflict-free
 *   dual scratch arenas (`cl_scratch_begin(&dst_alloc, 1)`).
 *
 * WHY THIS PATTERN IS ODIN'S SUPERPOWER:
 *   - Instead of threading `(Allocator a, Allocator tmp, Logger log)` through
 *     15 layers of function calls, you push a scoped `Cl_Context` once at the
 *     subsystem boundary and every callee inherits it automatically.
 *   - Dual scratch arenas solve a subtle bug: if function `F(dst_alloc)` uses
 *     scratch memory AND the caller passes `cl_ctx_temp_allocator()` as
 *     `dst_alloc`, a single scratch arena would rewind/corrupt the caller's
 *     return value! `cl_scratch_begin(&dst_alloc, 1)` automatically picks the
 *     OTHER thread-local scratch arena so aliasing is impossible.
 *
 * WHEN TO USE:
 *   - Push `Cl_Context` per subsystem, per test, or per worker thread.
 *   - Use `cl_scratch_begin(&dst_alloc, 1)` inside EVERY reusable function
 *     that builds an output in `dst_alloc` while needing internal scratch RAM.
 *
 * ADVANTAGES:
 *   + Clean function signatures with explicit, inspectable overrides.
 *   + Zero aliasing bugs even when callers pass `temp_allocator` as destination.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Relies on thread-local state (`__thread`), so remember to call
 *     `cl_ctx_temp_reset()` at frame/request boundaries and
 *     `cl_ctx_thread_shutdown()` before exiting long-lived worker threads.
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

/*
 * Reusable helper: normalizes comma-separated tokens into sorted uppercase,
 * allocating intermediate buffers in a conflict-free scratch arena and
 * placing ONLY the final result inside `dst_alloc`.
 */
static Cl_Str sort_and_format_tags(Cl_Str raw_csv, Cl_Allocator dst_alloc) {
    Cl_Scratch scratch = cl_scratch_begin(&dst_alloc, 1);
    CL_DEFER_SCRATCH(scratch);

    Cl_DA_Str tags = {0};
    CL_DA_INIT(&tags, scratch.allocator);

    Cl_Str cursor = raw_csv;
    for (;;) {
        Cl_Str tok;
        CL_OPT_OR_BREAK(tok, cl_str_split_iter(&cursor, CL_STR(",")));
        tok = cl_str_trim_space(tok);
        if (tok.len > 0) {
            CL_DA_PUSH(&tags, cl_str_to_upper(tok, scratch.allocator));
        }
    }
    CL_DA_SORT(&tags, cl_cmp_str);

    /* Only this final joined string lives in dst_alloc! */
    return cl_str_join(CL_DA_AS_SLICE(Cl_Slice_Str, &tags), CL_STR(" | "), dst_alloc);
}

int main(void) {
    printf("=== Example 12: Thread-Local Context & Dual Scratch Arenas ===\n\n");

    /* 1. Demonstrate passing temp_allocator as destination (conflict-free!) */
    Cl_Str raw = CL_STR("  zebra, alpha , mango , banana  ");
    Cl_Str out = sort_and_format_tags(raw, cl_ctx_temp_allocator());
    Cl_Str msg = cl_tprintf("Sorted tags (in temp_allocator): " CL_STR_FMT, CL_STR_ARG(out));
    printf("  " CL_STR_FMT "\n", CL_STR_ARG(msg));
    cl_ctx_temp_reset();

    /* 2. Scoped context override: swap default allocator to a stack arena */
    cl_u8 local_mem[CL_KB(4)];
    Cl_Arena local_arena;
    cl_arena_init_buffer(&local_arena, local_mem, (cl_isize)sizeof(local_mem));
    CL_DEFER_ARENA(local_arena);

    {
        Cl_Context sub = {0}; /* Zero fields automatically inherit from parent! */
        sub.allocator  = cl_arena_allocator(&local_arena);
        sub.user_index = 77;
        CL_DEFER_CTX_PUSH(sub);

        /* Notice: zero-initialized Cl_DA_I32 picks up local_arena automatically! */
        Cl_DA_I32 nums = {0};
        for (cl_i32 i = 0; i < 16; i++) {
            CL_DA_PUSH(&nums, i * 10);
        }
        printf("  Inside scoped ctx (user_index=%lld): arena used=%lld B, nums[15]=%d\n",
               (CL_LL)cl_ctx_current()->user_index,
               (CL_LL)cl_arena_used(&local_arena),
               CL_DA_AT(&nums, 15));
    }
    /* Outside scope: original heap allocator and user_index=0 are restored! */
    printf("  After  scoped ctx (user_index=%lld): restored default allocator.\n",
           (CL_LL)cl_ctx_current()->user_index);

    cl_ctx_thread_shutdown();
    return 0;
}
