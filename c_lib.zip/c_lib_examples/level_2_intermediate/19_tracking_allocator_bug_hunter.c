/*
 * ============================================================================
 * c_lib_examples - Level 2 (Intermediate) - Example 19 of 30
 * File: level_2_intermediate/19_tracking_allocator_bug_hunter.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Finding memory leaks, double frees, bad/wild/interior pointer frees,
 *   buffer underflow/overflow (16-byte front & back 0xFD redzones), uninit
 *   poisoning (0xCD), and live pointer validation using `Cl_Tracking_Allocator`.
 *
 * WHY USE Cl_Tracking_Allocator:
 *   - Runs in plain C99 binaries with ZERO external tools (no Valgrind needed)
 *     and wraps ANY `Cl_Allocator` (heap, arena, pool).
 *   - Reports exact `file:line (func)` for every leak, double free (both
 *     original alloc AND first free site!), and redzone breach.
 *   - Intercepts invalid frees safely without corrupting the underlying heap.
 *
 * WHEN TO USE:
 *   - Wrap `cl_heap_allocator()` during development and inside every unit test.
 *   - Set `tracker.panic_on_error = true` in CI so the very first bad pointer
 *     or redzone breach halts immediately under GDB.
 *   - Pair with `PROFILE=sanitize` (`-fsanitize=address,undefined`) for
 *     per-instruction shadow-memory checking.
 *
 * ADVANTAGES:
 *   + Pinpoints exact source lines for leaks and double-frees.
 *   + Live pointer query API (`cl_tracking_validate_ptr`) catches dangling
 *     or out-of-bounds pointers before passing them to C APIs.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Adds 32+ bytes of guard padding per allocation + hash-table/mutex
 *     bookkeeping -> remove wrapper in release builds for bare-metal speed.
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

int main(void) {
    printf("=== Example 19: Tracking Allocator Memory Bug Hunter ===\n\n");

    Cl_Tracking_Allocator tracker;
    cl_tracking_init(&tracker, cl_heap_allocator());
    CL_DEFER_TRACKING(tracker);
    tracker.panic_on_error = false; /* Keep running so we can inspect all bugs */
    Cl_Allocator alloc = cl_tracking_allocator(&tracker);

    /* 1. Non-zeroed allocation is poisoned with 0xCD in tracking mode */
    cl_u8 *uninit = (cl_u8 *)cl_alloc_non_zeroed(alloc, 32);
    printf("Non-zeroed poison byte check: 0x%02X (expected 0x%02X)\n",
           (unsigned)uninit[0], (unsigned)CL_MEM_POISON_ALLOC_UNINIT);
    cl_free(alloc, uninit, 32);

    /* 2. Deliberate leak (we inspect it in the report, then free at end) */
    cl_u8 *leaked = (cl_u8 *)cl_alloc(alloc, 128);

    /* 3. Double free (safely intercepted!) */
    cl_u8 *df = (cl_u8 *)cl_alloc(alloc, 64);
    cl_free(alloc, df, 64);
    cl_free(alloc, df, 64);

    /* 4. Unknown (stack) pointer & interior pointer bad frees */
    int stack_var = 9;
    cl_free(alloc, &stack_var, (cl_isize)sizeof(stack_var));

    cl_u8 *live = (cl_u8 *)cl_alloc(alloc, 96);
    cl_free(alloc, live + 16, 80);

    /* 5. Front underflow & back overflow into 16-byte 0xFD redzones */
    live[-1] = 0x11u;
    live[96] = 0x22u;
    (void)cl_tracking_check_integrity(&tracker, CL_HERE);
    live[-1] = CL_MEM_POISON_REDZONE;
    live[96] = CL_MEM_POISON_REDZONE;

    /* 6. Live pointer validation */
    printf("\nPointer validation:\n");
    printf("  live (96 B)       : %s\n", cl_ptr_status_name(cl_tracking_validate_ptr(&tracker, live, 96)));
    printf("  live (97 B)       : %s\n", cl_ptr_status_name(cl_tracking_validate_ptr(&tracker, live, 97)));
    printf("  df (after free)   : %s\n", cl_ptr_status_name(cl_tracking_validate_ptr(&tracker, df, 1)));
    printf("  &stack_var        : %s\n", cl_ptr_status_name(cl_tracking_validate_ptr(&tracker, &stack_var, 4)));

    cl_free(alloc, live, 96);
    cl_tracking_print_report(&tracker, stdout);

    /* Clean up demonstrated leak so ASan/LSan exits cleanly */
    cl_free(alloc, leaked, 128);
    cl_ctx_thread_shutdown();
    return 0;
}
