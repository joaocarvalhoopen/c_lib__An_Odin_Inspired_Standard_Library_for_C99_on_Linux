/*
 * ============================================================================
 * c_lib_examples - Level 2 (Intermediate) - Example 16 of 30
 * File: level_2_intermediate/16_string_builder_dynamic_and_fixed.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   `Cl_String_Builder` (modeled after Odin's `core:strings.Builder`) in BOTH
 *   dynamic growing mode (`cl_sb_init_cap`) and zero-heap fixed-buffer mode
 *   (`cl_sb_init_buffer`), plus `cl_aprintf`, `cl_tprintf`, and `cl_bprintf`.
 *
 * WHY USE Cl_String_Builder INSTEAD OF REPEATED `strcat` / `snprintf`:
 *   - Repeated `strcat` is O(n^2) because every call rescans from byte 0.
 *   - `Cl_String_Builder` tracks `len` and `cap`, giving O(1) amortized
 *     appends, typed writers (`i64`, `u64`, `hex`, `f64`, `bool`, `rune`,
 *     `c64`, `c128`, `fmt`, `repeat`), and O(1) `cl_sb_to_str()` views.
 *
 * WHEN TO USE DYNAMIC vs FIXED MODE:
 *   - Dynamic mode: generating JSON, Markdown, SQL, HTML, or reports whose
 *     final length is unbounded.
 *   - Fixed-buffer mode (`cl_sb_init_buffer`): building small bounded messages
 *     on the stack without touching the heap (check `sb.truncated` afterward).
 *
 * ADVANTAGES:
 *   + Clean, composable writers with zero O(n^2) concatenation traps.
 *   + `cl_sb_to_cstr(&sb)` ensures NUL termination on demand without changing
 *     `sb.len`.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Append-oriented: if you need in-place insert/erase/find-and-replace in
 *     a fixed NUL-terminated buffer, use `Cl_Str_Buf` (see Example 17).
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

int main(void) {
    printf("=== Example 16: Cl_String_Builder (Dynamic & Fixed Modes) ===\n\n");

    /* Part A: Dynamic growing mode generating structured JSON */
    Cl_String_Builder sb = {0};
    cl_sb_init_cap(&sb, cl_ctx_allocator(), 64);
    CL_DEFER_SB(sb);

    cl_sb_write_cstr(&sb, "{\n  \"project\": \"c_lib\",\n  \"version\": ");
    cl_sb_write_fmt(&sb, "\"%d.%d.%d\"", CL_VERSION_MAJOR, CL_VERSION_MINOR, CL_VERSION_PATCH);
    cl_sb_write_cstr(&sb, ",\n  \"impedance\": \"");
    cl_sb_write_c128(&sb, cl_c128_make(50.0, -12.5), 2);
    cl_sb_write_cstr(&sb, "\",\n  \"symbol\": \"");
    cl_sb_write_rune(&sb, 0x03A9); /* Greek capital Omega */
    cl_sb_write_cstr(&sb, "\",\n  \"flags\": ");
    cl_sb_write_hex(&sb, 0xA5F0u, true);
    cl_sb_write_cstr(&sb, ",\n  \"ok\": ");
    cl_sb_write_bool(&sb, true);
    cl_sb_write_cstr(&sb, "\n}\n");

    printf("[Dynamic JSON output (len=%lld, cap=%lld)]:\n%s\n",
           (CL_LL)sb.len, (CL_LL)sb.cap, cl_sb_to_cstr(&sb));

    /* Part B: Fixed-buffer mode (ZERO heap allocations!) */
    char stack_mem[24];
    Cl_String_Builder fixed;
    cl_sb_init_buffer(&fixed, stack_mem, (cl_isize)sizeof(stack_mem));
    cl_sb_write_cstr(&fixed, "ID=");
    cl_sb_write_i64(&fixed, 123456);
    cl_sb_write_cstr(&fixed, " [payload_too_long_for_24_bytes]");

    printf("[Fixed-buffer mode]: \"%s\" (truncated=%s)\n",
           cl_sb_to_cstr(&fixed), fixed.truncated ? "true" : "false");

    /* Part C: One-liner formatting helpers */
    char bbuf[48];
    Cl_Str bstr = cl_bprintf(bbuf, (cl_isize)sizeof(bbuf), "stack=%d", 7);
    Cl_Str tstr = cl_tprintf("temp=" CL_STR_FMT " + pi=%.2f", CL_STR_ARG(bstr), CL_PI_F64);
    printf("[Formatting helpers]: " CL_STR_FMT "\n", CL_STR_ARG(tstr));

    cl_ctx_temp_reset();
    cl_ctx_thread_shutdown();
    return 0;
}
