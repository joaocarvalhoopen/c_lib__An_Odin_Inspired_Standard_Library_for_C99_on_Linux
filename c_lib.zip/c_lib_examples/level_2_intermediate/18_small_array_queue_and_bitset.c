/*
 * ============================================================================
 * c_lib_examples - Level 2 (Intermediate) - Example 18 of 30
 * File: level_2_intermediate/18_small_array_queue_and_bitset.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Three Odin-inspired specialized containers in `cl_array.h`:
 *     1. `CL_SMALL_ARRAY_DEFINE`: stack-allocated dynamic-length array (0 heap).
 *     2. `CL_QUEUE_DEFINE`: O(1) circular ring-buffer FIFO/deque (BFS traversal).
 *     3. `Cl_Bit_Set`: compact 64-bit word bitset with popcount and set ops.
 *
 * WHY USE THESE INSTEAD OF ALWAYS REACHING FOR `Cl_DA` OR `Cl_Map`:
 *   - Small bounded collections (e.g., max 8 neighbors per node) waste heap
 *     allocations in a `Cl_DA`; `CL_SMALL_ARRAY_DEFINE` stays 100% on stack!
 *   - Removing from the front of a `Cl_DA` is O(n); a circular `Cl_Queue`
 *     pushes/pops both ends in O(1)!
 *   - Tracking visited IDs `0..N-1` in a `Cl_Map` costs ~32 bytes/entry;
 *     `Cl_Bit_Set` costs 1 BIT per ID (256x smaller!) and fits in L1 cache!
 *
 * WHEN TO USE:
 *   - `Small_Array`: small known upper bound (<= 64 elements).
 *   - `Queue`: BFS, job queues, sliding windows, producer-consumer buffers.
 *   - `Bit_Set`: graph visited masks, ECS component masks, permission flags.
 *
 * ADVANTAGES:
 *   + Dramatic cache-locality and allocation reductions vs generic containers.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - `Small_Array` refuses pushes once full (`CL_SA_PUSH` returns `false`).
 *   - `Cl_Bit_Set` is ideal for dense integer IDs `0..N-1`, not sparse 64-bit IDs.
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

/* Each graph vertex has at most 4 outgoing edges -> zero-heap Small_Array! */
CL_SMALL_ARRAY_DEFINE(Adj_List, cl_i32, 4);

int main(void) {
    printf("=== Example 18: Small Array, Circular Ring Queue & BitSet (Graph BFS) ===\n\n");

    Cl_Allocator alloc = cl_ctx_allocator();

    /* Build a small 6-node directed graph entirely on the stack */
    Adj_List graph[6] = {0};
    CL_SA_PUSH(&graph[0], 1); CL_SA_PUSH(&graph[0], 2);
    CL_SA_PUSH(&graph[1], 3); CL_SA_PUSH(&graph[1], 4);
    CL_SA_PUSH(&graph[2], 4);
    CL_SA_PUSH(&graph[3], 5);
    CL_SA_PUSH(&graph[4], 5);

    /* BitSet tracks visited vertices (1 bit per vertex!) */
    Cl_Bit_Set visited;
    CL_ENSURE(cl_bitset_init(&visited, 6, alloc));

    /* Circular ring queue drives O(1) Breadth-First Search */
    Cl_Queue_I64 q = {0};
    CL_QUEUE_INIT(&q, alloc);

    CL_QUEUE_PUSH_BACK(&q, 0);
    cl_bitset_set(&visited, 0);

    printf("BFS visitation order starting at node 0: ");
    cl_i64 node = 0;
    while (CL_QUEUE_POP_FRONT_SAFE(&q, &node)) {
        printf("%lld ", (CL_LL)node);
        Adj_List *adj = &graph[node];
        for (cl_isize i = 0; i < adj->len; i++) {
            cl_i32 nxt = CL_SA_AT(adj, i);
            if (!cl_bitset_test(&visited, nxt)) {
                cl_bitset_set(&visited, nxt);
                CL_QUEUE_PUSH_BACK(&q, nxt);
            }
        }
    }
    printf("\nReachable nodes count (popcount): %lld / 6\n\n",
           (CL_LL)cl_bitset_count_ones(&visited));

    /* Set algebra with Cl_Bit_Set: permissions intersection & union */
    Cl_Bit_Set role_a, role_b;
    CL_ENSURE(cl_bitset_init(&role_a, 16, alloc));
    CL_ENSURE(cl_bitset_init(&role_b, 16, alloc));
    cl_bitset_set(&role_a, 1); cl_bitset_set(&role_a, 3); cl_bitset_set(&role_a, 7);
    cl_bitset_set(&role_b, 3); cl_bitset_set(&role_b, 7); cl_bitset_set(&role_b, 12);

    cl_bitset_intersect_in_place(&role_a, &role_b);
    printf("Common permission bits (3 and 7): count=%lld, bit3=%d, bit7=%d, bit1=%d\n",
           (CL_LL)cl_bitset_count_ones(&role_a),
           cl_bitset_test(&role_a, 3),
           cl_bitset_test(&role_a, 7),
           cl_bitset_test(&role_a, 1));

    CL_QUEUE_FREE(&q);
    cl_bitset_destroy(&visited);
    cl_bitset_destroy(&role_a);
    cl_bitset_destroy(&role_b);
    cl_ctx_thread_shutdown();
    return 0;
}
