/*
 * ============================================================================
 * c_lib_examples - Level 2 (Intermediate) - Example 17 of 30
 * File: level_2_intermediate/17_strbuf_inplace_buffer_editing.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Mutable, fixed-capacity, ALWAYS NUL-terminated, zero-heap String Buffer
 *   (`Cl_Str_Buf`) with in-place manipulation (`insert`, `erase`,
 *   `replace_in_place`, `trim_space_in_place`, `to_upper/lower`, `reverse`,
 *   `pad_left/right`, `append_fmt`).
 *
 * WHY USE Cl_Str_Buf INSTEAD OF `char buf[N]` + `strncpy`/`strncat`:
 *   - Standard C `strncpy` does NOT guarantee NUL termination on truncation
 *     and wastes time zero-filling the tail; `strncat` has confusing size args.
 *   - `Cl_Str_Buf` guarantees `data[len] == '\0'` after EVERY mutation,
 *     tracks `truncated`, enforces bounds checks in debug mode, and performs
 *     rich in-place edits with ZERO heap allocations!
 *
 * WHEN TO USE Cl_Str_Buf vs Cl_String_Builder:
 *   - `Cl_Str_Buf`: editing fixed-size paths, HTTP/serial headers, telemetry
 *     strings, or real-time audio/embedded buffers where heap allocation is
 *     forbidden and in-place insert/erase/replace is needed.
 *   - `Cl_String_Builder`: append-only generation of unbounded text.
 *
 * ADVANTAGES:
 *   + Zero heap allocations, zero `free()` / `defer` needed.
 *   + Safe truncation flag prevents silent buffer overflows.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Fixed maximum capacity (`cap - 1` chars); never grows dynamically.
 *   - In-place insert/erase/replace shift trailing bytes in O(n).
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

int main(void) {
    printf("=== Example 17: Cl_Str_Buf In-Place String Buffer Manipulation ===\n\n");

    char storage[128];
    Cl_Str_Buf buf = CL_STRBUF_FROM_ARRAY(storage);

    /* Step-by-step in-place path normalization (0 heap allocations!) */
    cl_strbuf_set(&buf, CL_STR("   /srv//app//TEMP_report.txt   "));
    printf("  1. Initial       : '%s'\n", cl_strbuf_as_cstr(&buf));

    cl_strbuf_trim_space_in_place(&buf);
    printf("  2. Trim space    : '%s'\n", cl_strbuf_as_cstr(&buf));

    cl_strbuf_replace_in_place(&buf, CL_STR("//"), CL_STR("/"));
    printf("  3. Clean slashes : '%s'\n", cl_strbuf_as_cstr(&buf));

    cl_strbuf_replace_in_place(&buf, CL_STR("TEMP_"), CL_STR("final_"));
    printf("  4. Replace token : '%s'\n", cl_strbuf_as_cstr(&buf));

    cl_strbuf_insert(&buf, 0, CL_STR("/mnt/backup"));
    printf("  5. Insert prefix : '%s'\n", cl_strbuf_as_cstr(&buf));

    cl_strbuf_erase(&buf, buf.len - 4, 4); /* Remove ".txt" */
    cl_strbuf_append_fmt(&buf, "_%04d.csv", 2026);
    printf("  6. Swap ext+year : '%s' (len=%lld, rem=%lld)\n\n",
           cl_strbuf_as_cstr(&buf), (CL_LL)buf.len, (CL_LL)cl_strbuf_remaining(&buf));

    /* In-place padding, case conversion, and reverse */
    char badge_mem[32];
    Cl_Str_Buf badge = CL_STRBUF_FROM_ARRAY(badge_mem);
    cl_strbuf_set(&badge, CL_STR("node7"));
    cl_strbuf_to_upper_in_place(&badge);
    cl_strbuf_pad_left_in_place(&badge, 10, '_');
    cl_strbuf_pad_right_in_place(&badge, 14, '_');
    printf("  Padded badge     : '%s'\n", cl_strbuf_as_cstr(&badge));

    cl_strbuf_set(&badge, CL_STR("ABCDEF"));
    cl_strbuf_reverse_in_place(&badge);
    printf("  Reversed in-place: '%s'\n", cl_strbuf_as_cstr(&badge));

    /* Overflow safety on tiny buffer */
    char tiny_mem[8];
    Cl_Str_Buf tiny = CL_STRBUF_FROM_ARRAY(tiny_mem);
    bool fit = cl_strbuf_set(&tiny, CL_STR("TooLongStringFor8Bytes"));
    printf("  Tiny buf fit=%s  : '%s' (truncated=%s)\n",
           fit ? "true" : "false", cl_strbuf_as_cstr(&tiny), tiny.truncated ? "true" : "false");

    return 0;
}
