/*
 * ============================================================================
 * c_lib_examples - Level 2 (Intermediate) - Example 20 of 30
 * File: level_2_intermediate/20_endianness_and_binary_file_packets.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Portable binary serialization using explicit endianness helpers
 *   (`cl_write_u16/32/64_be/le`, `cl_read_u16/32/64_be/le`), IEEE-754 float
 *   and `complex64` wire encoding, and whole-file binary I/O
 *   (`cl_os_write_entire_file` / `cl_os_read_entire_file`).
 *
 * WHY NEVER WRITE RAW C STRUCTS DIRECTLY TO DISK OR NETWORK:
 *   - Raw `fwrite(&my_struct, sizeof(my_struct), 1, fp)` leaks compiler
 *     padding bytes, breaks across little-endian vs big-endian CPUs, and
 *     breaks on strict-alignment architectures when reading unaligned streams.
 *   - `cl_write_u32_be` / `cl_read_u32_be` produce a 100% deterministic,
 *     alignment-safe, endian-explicit binary format on every CPU!
 *
 * WHEN TO USE:
 *   - Network protocols (big-endian / network byte order).
 *   - Compact binary file formats, IQ RF captures, telemetry logs, game saves.
 *
 * ADVANTAGES:
 *   + Zero alignment UB (reads/writes byte-by-byte; GCC optimizes to single
 *     `bswap` + `mov` instructions at `-O2`!).
 *   + Combines cleanly with `Cl_Bytes` slices and whole-file read/write.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Requires writing explicit encode/decode routines per packet version
 *     (which is actually a benefit for backward-compatible file formats!).
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

#define PACKET_MAGIC 0x434C4942u /* "CLIB" */
#define PACKET_BYTES 26          /* 4 + 2 + 8 + 4 + 8 = 26 packed bytes */

typedef struct Telemetry_Packet {
    cl_u32 magic;
    cl_u16 sensor_id;
    cl_u64 seq_no;
    cl_f32 battery_v;
    cl_c64 iq_reading;
} Telemetry_Packet;

static void encode_packet_be(const Telemetry_Packet *pkt, cl_u8 out[PACKET_BYTES]) {
    cl_u32 batt_bits = 0, iq_re = 0, iq_im = 0;
    cl_f32 re = cl_c64_real(pkt->iq_reading);
    cl_f32 im = cl_c64_imag(pkt->iq_reading);
    cl_mem_copy(&batt_bits, &pkt->battery_v, 4);
    cl_mem_copy(&iq_re, &re, 4);
    cl_mem_copy(&iq_im, &im, 4);

    cl_write_u32_be(out + 0,  pkt->magic);
    cl_write_u16_be(out + 4,  pkt->sensor_id);
    cl_write_u64_be(out + 6,  pkt->seq_no);
    cl_write_u32_be(out + 14, batt_bits);
    cl_write_u32_be(out + 18, iq_re);
    cl_write_u32_be(out + 22, iq_im);
}

static bool decode_packet_be(Cl_Bytes wire, Telemetry_Packet *out) {
    if (wire.len < PACKET_BYTES) {
        return false;
    }
    cl_u32 magic = cl_read_u32_be(wire.data + 0);
    if (magic != PACKET_MAGIC) {
        return false;
    }
    cl_u32 batt_bits = cl_read_u32_be(wire.data + 14);
    cl_u32 iq_re     = cl_read_u32_be(wire.data + 18);
    cl_u32 iq_im     = cl_read_u32_be(wire.data + 22);
    cl_f32 batt = 0.0f, re = 0.0f, im = 0.0f;
    cl_mem_copy(&batt, &batt_bits, 4);
    cl_mem_copy(&re, &iq_re, 4);
    cl_mem_copy(&im, &iq_im, 4);

    out->magic      = magic;
    out->sensor_id  = cl_read_u16_be(wire.data + 4);
    out->seq_no     = cl_read_u64_be(wire.data + 6);
    out->battery_v  = batt;
    out->iq_reading = cl_c64_make(re, im);
    return true;
}

int main(void) {
    printf("=== Example 20: Explicit Endianness & Binary File Packets ===\n\n");

    Cl_Allocator alloc = cl_ctx_allocator();
    Cl_Str bin_path = CL_STR("/tmp/c_lib_ex20_packet.bin");

    Telemetry_Packet tx = {
        PACKET_MAGIC,
        409u,
        9876543210ull,
        3.72f,
        cl_c64_make(0.8660f, -0.5000f)
    };

    cl_u8 wire[PACKET_BYTES];
    encode_packet_be(&tx, wire);
    CL_ENSURE(cl_os_write_entire_file(bin_path, CL_SLICE_FROM_ARRAY(Cl_Bytes, wire)) == CL_ERR_NONE);

    Cl_Res_Bytes loaded = cl_os_read_entire_file(bin_path, alloc);
    CL_ENSURE(loaded.err == CL_ERR_NONE);

    Telemetry_Packet rx = {0};
    CL_ENSURE(decode_packet_be(loaded.value, &rx));

    printf("Decoded %lld-byte big-endian binary packet:\n", (CL_LL)loaded.value.len);
    printf("  magic      : 0x%08X\n", (unsigned)rx.magic);
    printf("  sensor_id  : %u\n", (unsigned)rx.sensor_id);
    printf("  seq_no     : %llu\n", (CL_ULL)rx.seq_no);
    printf("  battery_v  : %.2f V\n", (double)rx.battery_v);
    printf("  iq_reading : %.4f %+.4fi\n",
           (double)cl_c64_real(rx.iq_reading), (double)cl_c64_imag(rx.iq_reading));

    CL_SLICE_FREE(alloc, loaded.value);
    (void)cl_os_remove_file(bin_path);
    cl_ctx_thread_shutdown();
    return 0;
}
