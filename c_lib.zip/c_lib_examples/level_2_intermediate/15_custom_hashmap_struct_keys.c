/*
 * ============================================================================
 * c_lib_examples - Level 2 (Intermediate) - Example 15 of 30
 * File: level_2_intermediate/15_custom_hashmap_struct_keys.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Custom `CL_MAP_DEFINE` hash maps with:
 *     1. Packed POD struct keys (`Tile_Coord { x, y }`) using built-in
 *        bytewise hashing (`CL_MAP_INIT_POD`).
 *     2. Custom hash & equality callbacks (ASCII case-insensitive HTTP header
 *        lookup where `"Content-Type"` == `"content-type"`!).
 *
 * WHY CUSTOM HASH & EQUALITY CALLBACKS MATTER:
 *   - Real systems often map 2D/3D grid coordinates, composite IDs, or
 *     case-insensitive protocol keys (HTTP headers, DNS hostnames, SQL names)
 *     without allocating normalized temporary strings on every lookup.
 *
 * WHEN TO USE POD KEYS vs CUSTOM CALLBACKS:
 *   - Use `CL_MAP_INIT_POD` ONLY when your struct has NO uninitialized padding
 *     bytes (or is always zero-initialized before setting fields!).
 *   - Write custom `Cl_Hash_Proc` + `Cl_Eq_Proc` whenever a struct contains
 *     pointers, `Cl_Str`, floating-point `-0.0`, padding bytes, or custom
 *     equivalence rules (such as case-insensitivity).
 *
 * ADVANTAGES:
 *   + Zero allocations on case-insensitive lookups (hash lowercase on the fly).
 *   + Completely type-safe `V *` returns for any custom key/value types.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Struct padding trap: hashing raw struct bytes with uninitialized
 *     padding produces non-deterministic misses -> verify with `CL_STATIC_ASSERT`
 *     or write an explicit field-by-field hash callback.
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

/* 1. Zero-padding POD key for a sparse 2D tile grid */
typedef struct Tile_Coord {
    cl_i32 x;
    cl_i32 y;
} Tile_Coord;

CL_STATIC_ASSERT(sizeof(Tile_Coord) == 8, tile_coord_has_no_padding);
CL_MAP_DEFINE(Map_Tile_Name, Tile_Coord, Cl_Str);

/* 2. Case-insensitive Cl_Str hasher + comparator for HTTP headers */
static cl_u64 hash_str_fold(const void *key, cl_isize key_size) {
    CL_UNUSED_VAR(key_size);
    const Cl_Str *s = (const Cl_Str *)key;
    cl_u64 h = 14695981039346656037ull;
    for (cl_isize i = 0; i < s->len; i++) {
        cl_u8 c = s->data[i];
        if (c >= 'A' && c <= 'Z') c = (cl_u8)(c + ('a' - 'A'));
        h ^= (cl_u64)c;
        h *= 1099511628211ull;
    }
    return h;
}

static bool eq_str_fold(const void *a, const void *b, cl_isize key_size) {
    CL_UNUSED_VAR(key_size);
    return cl_str_eq_fold(*(const Cl_Str *)a, *(const Cl_Str *)b);
}

int main(void) {
    printf("=== Example 15: Custom HashMaps (Struct Keys & Case-Insensitive Keys) ===\n\n");

    Cl_Allocator alloc = cl_ctx_allocator();

    /* Part A: Sparse 2D tile grid keyed by Tile_Coord */
    Map_Tile_Name world = {0};
    CL_MAP_INIT_POD(&world, alloc);
    CL_DEFER_MAP(world);

    CL_MAP_PUT(&world, ((Tile_Coord){ 0, 0 }),    CL_STR("Origin Plaza"));
    CL_MAP_PUT(&world, ((Tile_Coord){ 10, -4 }),  CL_STR("Copper Mine"));
    CL_MAP_PUT(&world, ((Tile_Coord){ -7, 22 }),  CL_STR("Watchtower"));

    Cl_Str tile = CL_MAP_GET_OR(&world, ((Tile_Coord){ 10, -4 }), CL_STR("Wilderness"));
    Cl_Str empty = CL_MAP_GET_OR(&world, ((Tile_Coord){ 99, 99 }), CL_STR("Wilderness"));
    printf("[Sparse Grid]\n");
    printf("  (10, -4) -> " CL_STR_FMT "\n", CL_STR_ARG(tile));
    printf("  (99, 99) -> " CL_STR_FMT "\n\n", CL_STR_ARG(empty));

    /* Part B: Case-insensitive HTTP header map (zero allocs on lookup!) */
    Cl_Map_Str_Str headers = {0};
    CL_MAP_INIT(&headers, alloc, hash_str_fold, eq_str_fold);
    CL_DEFER_MAP(headers);

    CL_MAP_PUT(&headers, CL_STR("Content-Type"),  CL_STR("application/json"));
    CL_MAP_PUT(&headers, CL_STR("Cache-Control"), CL_STR("no-store"));

    Cl_Str *ct = CL_MAP_GET(&headers, CL_STR("content-type"));
    Cl_Str *cc = CL_MAP_GET(&headers, CL_STR("CACHE-CONTROL"));
    printf("[Case-Insensitive HTTP Headers]\n");
    printf("  lookup 'content-type'  -> " CL_STR_FMT "\n", CL_STR_ARG(*ct));
    printf("  lookup 'CACHE-CONTROL' -> " CL_STR_FMT "\n", CL_STR_ARG(*cc));

    cl_ctx_thread_shutdown();
    return 0;
}
