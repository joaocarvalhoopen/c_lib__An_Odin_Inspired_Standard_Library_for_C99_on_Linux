/*
 * ============================================================================
 * c_lib_examples - Level 2 (Intermediate) - Example 13 of 30
 * File: level_2_intermediate/13_dynamic_arrays_in_depth.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Odin-style dynamic arrays (`CL_DA_DEFINE`, `[dynamic]T`): custom struct
 *   types, `{0}` zero-init, `PUSH`, `APPEND_SLICE`, `INJECT_AT`,
 *   `ORDERED_REMOVE` vs O(1) `UNORDERED_REMOVE`, `RESERVE`, `RESIZE`,
 *   `SHRINK`, sorting, and zero-copy `CL_DA_AS_SLICE`.
 *
 * WHY EXPLICIT `{ data, len, cap, allocator }` STRUCTS INSTEAD OF HIDDEN HEADERS:
 *   - Unlike stb-style hidden negative-offset headers (`arr[-1]`), explicit
 *     structs match Odin's `Raw_Dynamic_Array` directly: `{0}` is valid,
 *     GDB displays `len`/`cap`/`data` cleanly, custom alignment works without
 *     header-padding bugs, and each array remembers its own `Cl_Allocator`.
 *
 * WHEN TO USE ORDERED vs UNORDERED REMOVE:
 *   - `CL_DA_ORDERED_REMOVE(da, idx)`: O(n) `memmove` shift — use when element
 *     order matters (UI lists, timeline keyframes, sorted arrays).
 *   - `CL_DA_UNORDERED_REMOVE(da, idx)`: O(1) swap-with-last — use for active
 *     bullet/particle pools or sets where order is irrelevant!
 *
 * ADVANTAGES:
 *   + Single shared growth engine (`cl_da_reserve_raw`) -> zero code bloat.
 *   + Bounds-checked `CL_DA_AT` and `CL_DA_POP` in dev builds.
 *   + O(1) zero-copy conversion to any slice-accepting function.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Growing reallocates and invalidates raw pointers to elements (store
 *     indices instead of pointers across `CL_DA_PUSH`, or pre-`CL_DA_RESERVE`).
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

typedef struct Task {
    cl_i32 id;
    cl_i32 priority;
    Cl_Str label;
} Task;

CL_SLICE_DEFINE(Slice_Task, Task);
CL_DA_DEFINE(DA_Task, Task);

static int cmp_task_priority(const void *a, const void *b) {
    const Task *ta = (const Task *)a;
    const Task *tb = (const Task *)b;
    return (ta->priority > tb->priority) - (ta->priority < tb->priority);
}

static void print_tasks(const char *heading, Slice_Task s) {
    printf("  %s (len=%lld):\n", heading, (CL_LL)s.len);
    CL_SLICE_FOR_EACH(i, s) {
        Task t = CL_SLICE_AT(s, i);
        printf("    [%lld] id=%d prio=%d label=" CL_STR_FMT "\n",
               (CL_LL)i, (int)t.id, (int)t.priority, CL_STR_ARG(t.label));
    }
}

int main(void) {
    printf("=== Example 13: Dynamic Arrays In Depth ===\n\n");

    Cl_Tracking_Allocator tr;
    cl_tracking_init(&tr, cl_heap_allocator());
    CL_DEFER_TRACKING(tr);
    Cl_Allocator alloc = cl_tracking_allocator(&tr);

    DA_Task tasks = {0};
    CL_DA_INIT_CAP(&tasks, alloc, 4);
    CL_DEFER_DA(tasks);

    /* Push & append from a slice */
    Task initial[] = {
        { 1, 30, CL_STR("Write docs") },
        { 2, 10, CL_STR("Fix bug") },
        { 3, 20, CL_STR("Run sanitizer") }
    };
    CL_DA_APPEND_SLICE(&tasks, CL_SLICE_FROM_ARRAY(Slice_Task, initial));
    CL_DA_INJECT_AT(&tasks, 1, ((Task){ 4, 5, CL_STR("Hotfix crash") }));
    print_tasks("After APPEND_SLICE + INJECT_AT(1)", CL_DA_AS_SLICE(Slice_Task, &tasks));

    /* Sort by ascending priority */
    CL_DA_SORT(&tasks, cmp_task_priority);
    print_tasks("After CL_DA_SORT (by priority)", CL_DA_AS_SLICE(Slice_Task, &tasks));

    /* Ordered remove preserves sorted order (O(n)) */
    CL_DA_ORDERED_REMOVE(&tasks, 0);
    print_tasks("After ORDERED_REMOVE(0) [order preserved]", CL_DA_AS_SLICE(Slice_Task, &tasks));

    /* Unordered remove swaps with last in O(1) */
    CL_DA_UNORDERED_REMOVE(&tasks, 0);
    print_tasks("After UNORDERED_REMOVE(0) [O(1) swap-last]", CL_DA_AS_SLICE(Slice_Task, &tasks));

    /* Shrink capacity down to exact length */
    CL_DA_SHRINK(&tasks);
    printf("  After CL_DA_SHRINK: len=%lld, cap=%lld\n",
           (CL_LL)tasks.len, (CL_LL)tasks.cap);

    cl_ctx_thread_shutdown();
    return 0;
}
