/*
 * ============================================================================
 * c_lib_examples - Level 2 (Intermediate) - Example 11 of 30
 * File: level_2_intermediate/11_linear_arena_and_temp_checkpoints.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Fixed-capacity linear bump allocator (`Cl_Arena`), stack-backed zero-heap
 *   arenas, O(1) in-place resize of the top allocation, nested checkpoints
 *   (`Cl_Arena_Temp`), bulk O(1) reset, and peak memory accounting.
 *
 * WHY USE Cl_Arena INSTEAD OF REPEATED `malloc`/`free`:
 *   - Most short-lived allocations share a clear phase boundary (one HTTP
 *     request, one simulation frame, one parser pass).
 *   - Bump allocation costs a few CPU instructions (align + offset += size),
 *     keeps related objects adjacent in L1/L2 cache, and frees thousands of
 *     objects in O(1) with zero fragmentation.
 *
 * WHEN TO USE:
 *   - Stack-backed `cl_arena_init_buffer`: fast local scratch spaces (<= 64 KiB).
 *   - Heap-backed `cl_arena_init_alloc`: medium bounded per-request arenas.
 *   - `cl_arena_temp_begin`/`end`: nested sub-scopes whose scratch data must
 *     be discarded without losing earlier allocations in the same arena.
 *
 * ADVANTAGES:
 *   + O(1) alloc, O(1) top-block resize, O(1) rewind, O(1) full reset.
 *   + Under ASan (`PROFILE=sanitize`), unused and rewound arena regions are
 *     explicitly poisoned so use-after-rewind crashes immediately!
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Individual `cl_free()` calls are no-ops (cannot reclaim middle holes).
 *   - Fixed capacity: returns `NULL` when full (use `Cl_Virtual_Arena` when
 *     maximum size is unknown upfront).
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

int main(void) {
    printf("=== Example 11: Linear Arena, In-Place Resize & Checkpoints ===\n\n");

    /* 1. Stack-backed linear arena: ZERO heap allocations or OS syscalls! */
    cl_u8 stack_buf[CL_KB(16)];
    Cl_Arena arena;
    cl_arena_init_buffer(&arena, stack_buf, (cl_isize)sizeof(stack_buf));
    CL_DEFER_ARENA(arena);
    Cl_Allocator aa = cl_arena_allocator(&arena);

    /* Allocate a persistent-for-this-phase header */
    Cl_Str title = cl_aprintf(aa, "Batch #1");
    printf("After title alloc      : used=%lld B, remaining=%lld B\n",
           (CL_LL)cl_arena_used(&arena), (CL_LL)cl_arena_remaining(&arena));

    /* 2. O(1) in-place resize of the most recent allocation (pointer stays identical!) */
    cl_i64 *series = cl_make_array(aa, cl_i64, 4);
    series[0] = 10; series[3] = 40;
    cl_i64 *grown = (cl_i64 *)cl_resize(aa, series, 4 * (cl_isize)sizeof(cl_i64), 16 * (cl_isize)sizeof(cl_i64));
    printf("In-place top resize    : same_ptr=%s, series[3]=%lld, series[15]=%lld\n",
           (grown == series) ? "true" : "false", (CL_LL)grown[3], (CL_LL)grown[15]);

    /* 3. Nested checkpoint / rewind (LIFO) */
    cl_isize before_temp = cl_arena_used(&arena);
    {
        Cl_Arena_Temp cp1 = cl_arena_temp_begin(&arena);
        CL_DEFER_TEMP(cp1);

        cl_f64 *scratch_a = cl_make_array(aa, cl_f64, 200);
        scratch_a[0] = 99.5;
        printf("Inside checkpoint 1    : used=%lld B\n", (CL_LL)cl_arena_used(&arena));

        {
            Cl_Arena_Temp cp2 = cl_arena_temp_begin(&arena);
            CL_DEFER_TEMP(cp2);

            cl_u8 *scratch_b = (cl_u8 *)cl_alloc(aa, CL_KB(4));
            scratch_b[0] = 1;
            printf("Inside checkpoint 2    : used=%lld B\n", (CL_LL)cl_arena_used(&arena));
        }
        printf("After  checkpoint 2    : used=%lld B (scratch_a[0]=%.1f intact!)\n",
               (CL_LL)cl_arena_used(&arena), scratch_a[0]);
    }
    printf("After  checkpoint 1    : used=%lld B (expected %lld B, title='" CL_STR_FMT "')\n",
           (CL_LL)cl_arena_used(&arena), (CL_LL)before_temp, CL_STR_ARG(title));

    /* 4. O(1) full reset & peak high-water mark */
    cl_arena_reset(&arena);
    printf("After cl_arena_reset   : used=%lld B, peak_used=%lld / %lld B\n",
           (CL_LL)cl_arena_used(&arena), (CL_LL)arena.peak_used, (CL_LL)arena.cap);

    return 0;
}
