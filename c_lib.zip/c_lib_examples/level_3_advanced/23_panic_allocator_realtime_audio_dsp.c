/*
 * ============================================================================
 * c_lib_examples - Level 3 (Advanced) - Example 23 of 30
 * File: level_3_advanced/23_panic_allocator_realtime_audio_dsp.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Enforcing hard real-time zero-allocation discipline using
 *   `cl_panic_allocator()` installed in `Cl_Context`, while running a
 *   `complex64` IQ single-pole low-pass filter (`y[n] = alpha*x[n] + (1-alpha)*y[n-1]`)
 *   and zero-heap `Cl_Str_Buf` telemetry inside the real-time callback.
 *
 * WHY USE cl_panic_allocator() ON REAL-TIME HOT PATHS:
 *   - In Linux audio callbacks (JACK/PipeWire/ALSA), SDR IQ pipelines, and
 *     robotics control loops, calling `malloc()` can acquire global locks or
 *     trigger page faults, causing audible dropouts or missed deadlines.
 *   - By pushing `ctx.allocator = cl_panic_allocator()` and
 *     `ctx.temp_allocator = cl_panic_allocator()` around the callback, ANY
 *     accidental allocation (even deep inside a helper function!) traps
 *     immediately during testing!
 *
 * WHEN TO USE:
 *   - Audio DSP callbacks, ISR-like tight control loops, lock-free packet
 *     processors, and inner render loops after warm-up pre-allocation.
 *
 * ADVANTAGES:
 *   + Mathematically verifies zero hidden allocations at runtime.
 *   + Pairs naturally with pre-allocated `Cl_Slice_C64` + stack `Cl_Str_Buf`.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Any forgotten dynamic call (like `cl_tprintf` or growing a `Cl_DA` past
 *     pre-reserved capacity) intentionally aborts the process -> pre-allocate
 *     all buffers outside the real-time scope!
 * ============================================================================
 */

#define CL_SHORT_NAMES
#include "cl/cl.h"
#include <stdio.h>

typedef struct Iq_Lowpass_State {
    complex64 prev_y;
    f32       alpha; /* Smoothing factor in (0, 1] */
} Iq_Lowpass_State;

/*
 * Real-time DSP callback: guaranteed ZERO heap/arena allocations!
 * Formula (plain-text ASCII): y[n] = alpha * x[n] + (1 - alpha) * y[n - 1]
 */
static void realtime_dsp_callback(
    Iq_Lowpass_State *st,
    Cl_Slice_C64 in_iq,
    Cl_Slice_C64 out_iq,
    Cl_Str_Buf *telemetry_out
) {
    CL_ENSURE(in_iq.len == out_iq.len);

    /* Enforce hard no-alloc guarantee for this entire callback subtree! */
    Context rt_ctx = {0};
    rt_ctx.allocator      = cl_panic_allocator();
    rt_ctx.temp_allocator = cl_panic_allocator();
    CL_DEFER_CTX_PUSH(rt_ctx);

    f32 one_minus = 1.0f - st->alpha;
    f32 peak_mag2 = 0.0f;

    CL_SLICE_FOR_EACH(n, in_iq) {
        complex64 x = CL_SLICE_AT(in_iq, n);
        complex64 y = st->alpha * x + one_minus * st->prev_y;
        st->prev_y = y;
        CL_SLICE_AT(out_iq, n) = y;

        f32 m2 = cl_c64_abs2(y);
        if (m2 > peak_mag2) {
            peak_mag2 = m2;
        }
    }

    /* Format status strictly into stack Cl_Str_Buf (zero heap allocations!) */
    cl_strbuf_clear(telemetry_out);
    cl_strbuf_append_fmt(telemetry_out, "processed=%lld IQ samples, peak_power=%.4f",
                         (CL_LL)in_iq.len, (double)peak_mag2);
}

int main(void) {
    printf("=== Example 23: Panic Allocator Real-Time Audio/IQ DSP Guard ===\n\n");

    /* Pre-allocate DSP buffers ONCE during startup (outside RT scope) */
    Allocator startup_alloc = cl_ctx_allocator();
    Cl_Slice_C64 in_buf  = CL_SLICE_MAKE(Cl_Slice_C64, startup_alloc, 128);
    Cl_Slice_C64 out_buf = CL_SLICE_MAKE(Cl_Slice_C64, startup_alloc, 128);

    CL_SLICE_FOR_EACH(n, in_buf) {
        /* Step impulse + alternating high-frequency ripple */
        f32 ripple = (n % 2 == 0) ? 0.5f : -0.5f;
        CL_SLICE_AT(in_buf, n) = cl_c64_make(1.0f + ripple, 0.25f - ripple * 0.5f);
    }

    Iq_Lowpass_State filter = { cl_c64_make(0.0f, 0.0f), 0.15f };
    char telem_mem[128];
    Cl_Str_Buf telem = CL_STRBUF_FROM_ARRAY(telem_mem);

    /* Execute 3 consecutive real-time blocks under cl_panic_allocator() */
    for (int blk = 1; blk <= 3; blk++) {
        realtime_dsp_callback(&filter, in_buf, out_buf, &telem);
        complex64 last = CL_SLICE_LAST(out_buf);
        printf("  Block %d: %s | tail=(%.4f %+.4fi)\n",
               blk, cl_strbuf_as_cstr(&telem),
               (double)cl_c64_real(last), (double)cl_c64_imag(last));
    }
    printf("\nAll 3 real-time DSP blocks ran with provably ZERO allocations!\n");

    CL_SLICE_FREE(startup_alloc, in_buf);
    CL_SLICE_FREE(startup_alloc, out_buf);
    cl_ctx_thread_shutdown();
    return 0;
}
