/*
 * ============================================================================
 * c_lib_examples - Level 3 (Advanced) - Example 26 of 30
 * File: level_3_advanced/26_quaternions_3d_orientation_tracker.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   3D rigid-body orientation using `Cl_Quat128` (`quaternion128`) and
 *   `Cl_Quat256` (`quaternion256`): axis-angle construction, rotation
 *   composition (`q_total = q_pitch * q_yaw`), rotating 3D vectors via
 *   `v' = q * v * conj(q)`, and smooth spherical linear interpolation (SLERP).
 *
 * Plain-Text ASCII Math Formulas:
 *   Quaternion:       q = w + x*i + y*j + z*k  (unit norm: x^2 + y^2 + z^2 + w^2 = 1)
 *   Pure 3D vector:   p = 0 + vx*i + vy*j + vz*k
 *   Vector rotation:  p' = q * p * conj(q)
 *   SLERP(a, b, t):   constant-angular-velocity interpolation for t in [0, 1]
 *
 * WHY USE QUATERNIONS INSTEAD OF EULER ANGLES OR 3x3 MATRICES:
 *   - Euler angles (yaw/pitch/roll) suffer from gimbal lock and ugly
 *     non-uniform interpolation paths.
 *   - 3x3 matrices need 9 floats (36/72 bytes) and expensive Gram-Schmidt
 *     re-orthogonalization; unit quaternions need only 4 floats (16/32 bytes),
 *     compose cleanly, re-normalize cheaply, and SLERP smoothly!
 *
 * WHEN TO USE Cl_Quat128 vs Cl_Quat256:
 *   - `Cl_Quat128` (f32, 16 bytes): games, skeletal animation, real-time 3D.
 *   - `Cl_Quat256` (f64, 32 bytes): aerospace IMU/AHRS fusion, robotics, CAD.
 *
 * ADVANTAGES:
 *   + Gimbal-lock free, compact, and constant-speed SLERP interpolation.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Less intuitive for human UI input -> expose Euler degrees in UI/config,
 *     then convert immediately to quaternions internally!
 * ============================================================================
 */

#define CL_SHORT_NAMES
#include "cl/cl.h"
#include <stdio.h>

typedef struct Vec3 {
    f64 x, y, z;
} Vec3;

/* Rotate 3D vector `v` by unit quaternion `q`: p' = q * (v, 0) * conj(q) */
static Vec3 quat256_rotate_vec3(Quat256 q, Vec3 v) {
    Quat256 p  = cl_quat256_make(v.x, v.y, v.z, 0.0);
    Quat256 r  = cl_quat256_mul(cl_quat256_mul(q, p), cl_quat256_conj(q));
    return (Vec3){ r.x, r.y, r.z };
}

int main(void) {
    printf("=== Example 26: Quaternions 3D Orientation & SLERP Tracker ===\n\n");

    /* 1. Start facing +X (1, 0, 0), rotate +90 deg around Z -> should point +Y (0, 1, 0) */
    Quat256 q_yaw90 = cl_quat256_from_axis_angle(0.0, 0.0, 1.0, CL_PI_F64 * 0.5);
    Vec3 forward = { 1.0, 0.0, 0.0 };
    Vec3 rotated = quat256_rotate_vec3(q_yaw90, forward);
    printf("Rotate (1, 0, 0) by +90 deg about Z -> (%.4f, %.4f, %.4f)\n",
           rotated.x, rotated.y, rotated.z);

    /* 2. Compose yaw (+90 deg about Z) then pitch (+90 deg about X) */
    Quat256 q_pitch90 = cl_quat256_from_axis_angle(1.0, 0.0, 0.0, CL_PI_F64 * 0.5);
    Quat256 q_target  = cl_quat256_normalize(cl_quat256_mul(q_pitch90, q_yaw90));
    Vec3 final_dir    = quat256_rotate_vec3(q_target, forward);
    printf("After +90 deg Z then +90 deg X     -> (%.4f, %.4f, %.4f) |norm|=%.12f\n\n",
           final_dir.x, final_dir.y, final_dir.z, cl_quat256_len(q_target));

    /* 3. Smooth SLERP drone camera transition from identity to q_yaw90 in 5 steps */
    printf("SLERP trajectory (identity -> +90 deg Z):\n");
    Quat256 q_start = cl_quat256_identity();
    for (int step = 0; step <= 4; step++) {
        f64 t = (f64)step / 4.0;
        Quat256 qt = cl_quat256_slerp(q_start, q_yaw90, t);
        Vec3 dir = quat256_rotate_vec3(qt, forward);
        printf("  t=%.2f : dir=(%+.4f, %+.4f, %+.4f)  |q|=%.6f\n",
               t, dir.x, dir.y, dir.z, cl_quat256_len(qt));
    }

    return 0;
}
