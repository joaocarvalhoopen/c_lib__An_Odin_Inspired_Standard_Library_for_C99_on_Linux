/*
 * ============================================================================
 * c_lib_examples - Level 3 (Advanced) - Example 28 of 30
 * File: level_3_advanced/28_csv_table_query_engine.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   In-memory CSV analytics engine uniting whole-file read/write, Arena
 *   memory, zero-copy `cl_str_split_lines_iter` + `cl_str_split_iter`,
 *   typed `Cl_DA` rows, `Cl_Map_Str_F64` group-by aggregation, sorting,
 *   and `Cl_String_Builder` Markdown report export.
 *
 * WHY THIS DATA-ORIENTED PIPELINE IS SO FAST:
 *   - 1 file read (`cl_os_read_entire_file_str`), 0 per-cell string copies
 *     (every string column points directly into the CSV file buffer!),
 *     1 contiguous `Cl_DA` array of flat structs, and 1 arena reset at the end!
 *
 * WHEN TO USE:
 *   - ETL scripts, benchmark result aggregators, financial/sensor CSV reports.
 *
 * ADVANTAGES:
 *   + Cache-friendly flat struct arrays + O(1) HashMap group-by aggregation.
 *   + Exports clean report back to filesystem in one `cl_os_write_entire_file_str`.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Simple unquoted CSV splitting (for RFC 4180 quoted commas `a,"b,c",d`,
 *     write a small quote-aware state machine on top of `Cl_Str`).
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

typedef struct Sale_Row {
    Cl_Str region;
    Cl_Str product;
    cl_i64 units;
    cl_f64 unit_price;
} Sale_Row;

CL_DA_DEFINE(DA_Sale_Row, Sale_Row);

typedef struct Region_Total {
    Cl_Str region;
    cl_f64 revenue;
} Region_Total;

CL_DA_DEFINE(DA_Region_Total, Region_Total);

static int cmp_region_rev_desc(const void *a, const void *b) {
    const Region_Total *ra = (const Region_Total *)a;
    const Region_Total *rb = (const Region_Total *)b;
    return (rb->revenue > ra->revenue) - (rb->revenue < ra->revenue);
}

int main(void) {
    printf("=== Example 28: In-Memory CSV Table Query & Aggregation Engine ===\n\n");

    Cl_Arena arena;
    CL_ENSURE(cl_arena_init_alloc(&arena, CL_KB(64), cl_ctx_allocator()));
    CL_DEFER_ARENA(arena);
    Cl_Allocator aa = cl_arena_allocator(&arena);

    Cl_Str csv_path = CL_STR("/tmp/c_lib_ex28_sales.csv");
    Cl_Str csv_data = CL_STR(
        "region,product,units,unit_price\n"
        "EU,WidgetA,12,19.50\n"
        "US,WidgetB,30,12.00\n"
        "EU,WidgetB,20,12.00\n"
        "APAC,WidgetA,18,19.50\n"
        "US,WidgetA,15,19.50\n"
        "APAC,WidgetC,9,45.00\n"
    );
    CL_ENSURE(cl_os_write_entire_file_str(csv_path, csv_data) == CL_ERR_NONE);

    /* Load whole CSV into arena */
    Cl_Res_Str file_res = cl_os_read_entire_file_str(csv_path, aa);
    CL_ENSURE(file_res.err == CL_ERR_NONE);

    DA_Sale_Row rows = {0};
    CL_DA_INIT(&rows, aa);

    Cl_Str cursor = file_res.value;
    /* Skip header row */
    (void)cl_str_split_lines_iter(&cursor);

    for (;;) {
        Cl_Str line;
        CL_OPT_OR_BREAK(line, cl_str_split_lines_iter(&cursor));
        if (line.len == 0) continue;

        Cl_Str c = line;
        Cl_Opt_Str r = cl_str_split_iter(&c, CL_STR(","));
        Cl_Opt_Str p = cl_str_split_iter(&c, CL_STR(","));
        Cl_Opt_Str u = cl_str_split_iter(&c, CL_STR(","));
        Cl_Opt_Str pr = cl_str_split_iter(&c, CL_STR(","));
        if (!r.ok || !p.ok || !u.ok || !pr.ok) continue;

        Cl_Opt_I64 units = cl_str_parse_i64(u.value, 10);
        Cl_Opt_F64 price = cl_str_parse_f64(pr.value);
        if (!units.ok || !price.ok) continue;

        CL_DA_PUSH(&rows, ((Sale_Row){ r.value, p.value, units.value, price.value }));
    }

    /* GROUP BY region -> SUM(units * unit_price) */
    Cl_Map_Str_F64 by_region = {0};
    CL_MAP_INIT_STR(&by_region, aa);
    CL_DA_FOR_EACH(i, &rows) {
        Sale_Row row = CL_DA_AT(&rows, i);
        cl_f64 rev = (cl_f64)row.units * row.unit_price;
        cl_f64 *acc = CL_MAP_GET(&by_region, row.region);
        if (acc) *acc += rev;
        else CL_MAP_PUT(&by_region, row.region, rev);
    }

    /* Sort aggregated regions by revenue descending */
    DA_Region_Total summary = {0};
    CL_DA_INIT_CAP(&summary, aa, CL_MAP_LEN(&by_region));
    CL_MAP_FOR_EACH(i, &by_region) {
        CL_DA_PUSH(&summary, ((Region_Total){ by_region.keys[i], by_region.values[i] }));
    }
    CL_DA_SORT(&summary, cmp_region_rev_desc);

    /* Render Markdown report via Cl_String_Builder */
    Cl_String_Builder report = {0};
    cl_sb_init(&report, aa);
    cl_sb_write_fmt(&report, "Processed %lld CSV rows (arena used: %lld bytes)\n\n",
                    (CL_LL)rows.len, (CL_LL)cl_arena_used(&arena));
    cl_sb_write_cstr(&report, "| Region | Total Revenue |\n|--------|--------------:|\n");
    CL_DA_FOR_EACH(i, &summary) {
        Region_Total rt = CL_DA_AT(&summary, i);
        cl_sb_write_fmt(&report, "| %-6.*s | $%12.2f |\n", CL_STR_ARG(rt.region), rt.revenue);
    }

    printf("%s", cl_sb_to_cstr(&report));

    (void)cl_os_remove_file(csv_path);
    cl_ctx_thread_shutdown();
    return 0;
}
