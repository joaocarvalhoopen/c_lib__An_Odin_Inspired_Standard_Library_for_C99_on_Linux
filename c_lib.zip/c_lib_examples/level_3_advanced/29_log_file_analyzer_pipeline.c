/*
 * ============================================================================
 * c_lib_examples - Level 3 (Advanced) - Example 29 of 30
 * File: level_3_advanced/29_log_file_analyzer_pipeline.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   End-to-end Linux CLI log-file analyzer pipeline uniting whole-file I/O,
 *   multiple return values (`CL_OR_RETURN_ERR`), zero-copy parsing,
 *   custom `Cl_Map` struct aggregation, `Cl_DA` sorting, `Cl_String_Builder`,
 *   `Cl_Multi_Logger` (console + file), `CL_DEFER_*`, and
 *   `Cl_Tracking_Allocator` proving zero memory leaks.
 *
 * WHY THIS ARCHITECTURE SCALES CLEANLY:
 *   - Reading the file once lets every endpoint key stay a zero-copy `Cl_Str`
 *     slice into the loaded buffer.
 *   - Every resource attaches to `CL_DEFER_*` right at creation, making the
 *     pipeline resilient to any future early error return.
 *
 * ADVANTAGES:
 *   + Single-pass O(file_size) parsing + explicit typed error handling.
 *   + Full runtime leak & redzone verification built directly into main().
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Loads the full log file into RAM; switch to chunked reads for multi-GB
 *     logs that exceed available memory.
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

typedef struct Endpoint_Stats {
    cl_i64 count;
    cl_i64 errors;
    cl_f64 total_ms;
    cl_f64 max_ms;
} Endpoint_Stats;

CL_MAP_DEFINE(Map_Endpoint_Stats, Cl_Str, Endpoint_Stats);

typedef struct Endpoint_Row {
    Cl_Str         endpoint;
    Endpoint_Stats stats;
} Endpoint_Row;

CL_DA_DEFINE(DA_Endpoint_Row, Endpoint_Row);

static int cmp_row_avg_desc(const void *a, const void *b) {
    const Endpoint_Row *ra = (const Endpoint_Row *)a;
    const Endpoint_Row *rb = (const Endpoint_Row *)b;
    cl_f64 avg_a = ra->stats.total_ms / (cl_f64)ra->stats.count;
    cl_f64 avg_b = rb->stats.total_ms / (cl_f64)rb->stats.count;
    return (avg_b > avg_a) - (avg_b < avg_a);
}

static CL_NODISCARD Cl_Error analyze_log_file(Cl_Str path, Cl_Allocator alloc) {
    Cl_Str file_text;
    CL_OR_RETURN_ERR(file_text, cl_os_read_entire_file_str(path, alloc));
    void *file_slot = (void *)(cl_uintptr)file_text.data;
    CL_DEFER_FREE_SLOT(alloc, file_slot, file_text.len);

    Map_Endpoint_Stats stats_map = {0};
    CL_MAP_INIT_STR(&stats_map, alloc);
    CL_DEFER_MAP(stats_map);

    Cl_Str cursor = file_text;
    cl_i64 line_no = 0, malformed = 0;

    for (;;) {
        Cl_Str line;
        CL_OPT_OR_BREAK(line, cl_str_split_lines_iter(&cursor));
        line_no += 1;
        line = cl_str_trim_space(line);
        if (line.len == 0 || cl_str_has_prefix(line, CL_STR("#"))) continue;

        Cl_Str rest = line;
        Cl_Opt_Str lvl = cl_str_fields_iter(&rest);
        Cl_Opt_Str ep  = cl_str_fields_iter(&rest);
        Cl_Opt_Str st  = cl_str_fields_iter(&rest);
        Cl_Opt_Str ms  = cl_str_fields_iter(&rest);
        if (!lvl.ok || !ep.ok || !st.ok || !ms.ok) {
            CL_LOG_WARN("Line %lld malformed: " CL_STR_FMT, (CL_LL)line_no, CL_STR_ARG(line));
            malformed += 1;
            continue;
        }

        Cl_Str_Cut st_kv = cl_str_cut(st.value, CL_STR("="));
        Cl_Str_Cut ms_kv = cl_str_cut(ms.value, CL_STR("="));
        Cl_Opt_I64 code  = cl_str_parse_i64(st_kv.after, 10);
        Cl_Opt_F64 lat   = cl_str_parse_f64(ms_kv.after);
        if (!st_kv.found || !ms_kv.found || !code.ok || !lat.ok) {
            malformed += 1;
            continue;
        }

        Endpoint_Stats *s = CL_MAP_GET(&stats_map, ep.value);
        if (s == NULL) {
            Endpoint_Stats init = { 1, (code.value >= 500) ? 1 : 0, lat.value, lat.value };
            CL_MAP_PUT(&stats_map, ep.value, init);
        } else {
            s->count    += 1;
            s->errors   += (code.value >= 500) ? 1 : 0;
            s->total_ms += lat.value;
            if (lat.value > s->max_ms) s->max_ms = lat.value;
        }
    }

    DA_Endpoint_Row rows = {0};
    CL_DA_INIT_CAP(&rows, alloc, CL_MAP_LEN(&stats_map));
    CL_DEFER_DA(rows);

    CL_MAP_FOR_EACH(i, &stats_map) {
        CL_DA_PUSH(&rows, ((Endpoint_Row){ stats_map.keys[i], stats_map.values[i] }));
    }
    CL_DA_SORT(&rows, cmp_row_avg_desc);

    Cl_String_Builder sb = {0};
    cl_sb_init(&sb, alloc);
    CL_DEFER_SB(sb);

    cl_sb_write_fmt(&sb, "\nParsed %lld lines (%lld malformed), %lld endpoints:\n",
                    (CL_LL)line_no, (CL_LL)malformed, (CL_LL)rows.len);
    cl_sb_write_cstr(&sb, "  Endpoint       | Reqs | 5xx | Avg (ms) | Max (ms)\n");
    cl_sb_write_cstr(&sb, "  ---------------+------+-----+----------+---------\n");
    CL_DA_FOR_EACH(i, &rows) {
        Endpoint_Row r = CL_DA_AT(&rows, i);
        cl_sb_write_fmt(&sb, "  %-14.*s | %4lld | %3lld | %8.2f | %7.2f\n",
                        CL_STR_ARG(r.endpoint), (CL_LL)r.stats.count,
                        (CL_LL)r.stats.errors,
                        r.stats.total_ms / (cl_f64)r.stats.count, r.stats.max_ms);
    }

    CL_LOG_INFO("Log analysis complete." CL_STR_FMT, CL_STR_ARG(cl_sb_to_str(&sb)));
    return CL_ERR_NONE;
}

int main(void) {
    printf("=== Example 29: Production Log File Analyzer Pipeline ===\n\n");

    Cl_Tracking_Allocator tracker;
    cl_tracking_init(&tracker, cl_heap_allocator());
    CL_DEFER_TRACKING(tracker);
    Cl_Allocator alloc = cl_tracking_allocator(&tracker);

    Cl_Str audit_path = CL_STR("/tmp/c_lib_ex29_audit.log");
    FILE *audit_fp = fopen("/tmp/c_lib_ex29_audit.log", "w");
    CL_ENSURE(audit_fp != NULL);
    CL_DEFER_FILE(audit_fp);

    Cl_Multi_Logger ml;
    cl_multi_logger_init(&ml);
    cl_multi_logger_add(&ml, cl_console_logger(CL_LOG_LEVEL_INFO, CL_LOG_OPT_LEVEL | CL_LOG_OPT_AUTO_COLOR));
    cl_multi_logger_add(&ml, cl_file_logger(audit_fp, CL_LOG_LEVEL_WARN, CL_LOG_OPT_LEVEL));

    Cl_Context ctx = cl_ctx_default();
    ctx.allocator = alloc;
    ctx.logger    = cl_multi_logger(&ml, CL_LOG_LEVEL_DEBUG);
    CL_DEFER_CTX_PUSH(ctx);

    Cl_Str sample_path = CL_STR("/tmp/c_lib_ex29_access.log");
    Cl_Str sample_log = CL_STR(
        "# Access log\n"
        "INFO  /api/users   status=200 ms=12.4\n"
        "INFO  /api/orders  status=200 ms=45.8\n"
        "ERROR /api/orders  status=503 ms=210.5\n"
        "WARN  corrupted_line\n"
        "INFO  /api/search  status=200 ms=78.3\n"
        "ERROR /api/search  status=500 ms=154.0\n"
        "INFO  /api/health  status=200 ms=1.1\n"
    );
    CL_ENSURE(cl_os_write_entire_file_str(sample_path, sample_log) == CL_ERR_NONE);
    CL_ENSURE(analyze_log_file(sample_path, alloc) == CL_ERR_NONE);

    (void)cl_os_remove_file(sample_path);
    fclose(audit_fp);
    audit_fp = NULL;
    (void)cl_os_remove_file(audit_path);

    CL_ENSURE(cl_tracking_is_clean(&tracker));
    printf("Tracking verification: %lld allocs, %lld frees, 0 leaks (peak %lld B).\n",
           (CL_LL)tracker.total_alloc_count, (CL_LL)tracker.total_free_count,
           (CL_LL)tracker.peak_bytes);
    cl_ctx_thread_shutdown();
    return 0;
}
