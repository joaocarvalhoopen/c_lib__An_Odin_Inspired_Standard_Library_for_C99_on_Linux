/*
 * ============================================================================
 * c_lib_examples - Level 3 (Advanced) - Example 25 of 30
 * File: level_3_advanced/25_complex_mandelbrot_ascii_renderer.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Mandelbrot fractal ASCII renderer demonstrating native `complex128`
 *   iteration (`z = z*z + c`), `cl_c128_abs2(z) > 4.0` (avoiding expensive
 *   `sqrt` in the inner loop!), `Cl_String_Builder`, and whole-file output.
 *
 * Plain-Text ASCII Escape-Time Formula:
 *   Starting at z_0 = 0 + 0*i:
 *     z_{n+1} = z_n^2 + c
 *   Point `c` escapes if |z_n|^2 = Re(z_n)^2 + Im(z_n)^2 > 4.0
 *
 * WHY USE cl_c128_abs2() INSTEAD OF cl_c128_abs() IN INNER LOOPS:
 *   - `cl_c128_abs(z)` calls `cabs()` which computes `hypot(re, im)` (square
 *     root + overflow scaling).
 *   - Comparing `cl_c128_abs2(z) > 4.0` is mathematically identical to
 *     `|z| > 2.0` while using only 2 multiplies + 1 add!
 *
 * WHEN TO USE:
 *   - Any iterative complex dynamical system (Mandelbrot/Julia sets, Newton
 *     root basins, pole-zero stability checks).
 *
 * ADVANTAGES:
 *   + Inner loop reads directly like textbook mathematics (`z = z * z + c`).
 *   + Entire ASCII frame is built in ONE `Cl_String_Builder` buffer (fast!).
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Native C99 `z * z` includes IEEE-754 NaN/Inf recovery checks unless
 *     compiled with `-fcx-limited-range` / `-ffast-math` in release builds.
 * ============================================================================
 */

#define CL_SHORT_NAMES
#include "cl/cl.h"
#include <stdio.h>

static isize mandelbrot_iters(complex128 c, isize max_iter) {
    complex128 z = cl_c128_make(0.0, 0.0);
    for (isize iter = 0; iter < max_iter; iter++) {
        if (cl_c128_abs2(z) > 4.0) {
            return iter;
        }
        z = z * z + c;
    }
    return max_iter;
}

int main(void) {
    printf("=== Example 25: Complex128 Mandelbrot ASCII Renderer ===\n\n");

    const isize width = 64, height = 22, max_iter = 48;
    Str palette = STR(" .:-=+*#%@");

    String_Builder sb = {0};
    cl_sb_init_cap(&sb, cl_ctx_allocator(), (width + 1) * height);
    CL_DEFER_SB(sb);

    Stopwatch sw = {0};
    cl_stopwatch_start(&sw);

    for (isize row = 0; row < height; row++) {
        f64 im = 1.15 - (2.30 * (f64)row) / (f64)(height - 1);
        for (isize col = 0; col < width; col++) {
            f64 re = -2.1 + (2.9 * (f64)col) / (f64)(width - 1);
            isize it = mandelbrot_iters(cl_c128_make(re, im), max_iter);
            isize idx = (it == max_iter)
                            ? (palette.len - 1)
                            : ((it * (palette.len - 1)) / max_iter);
            cl_sb_write_byte(&sb, cl_str_at(palette, idx));
        }
        cl_sb_write_byte(&sb, '\n');
    }

    cl_stopwatch_stop(&sw);

    /* Save rendered frame to disk in one whole-file call, then remove temp file */
    Str out_path = STR("/tmp/c_lib_ex25_mandelbrot.txt");
    CL_ENSURE(cl_os_write_entire_file_str(out_path, cl_sb_to_str(&sb)) == CL_ERR_NONE);
    (void)cl_os_remove_file(out_path);

    printf("%s\nRendered %lldx%lld complex128 fractal in %.3f ms.\n",
           cl_sb_to_cstr(&sb), (CL_LL)width, (CL_LL)height, cl_stopwatch_elapsed_ms(&sw));

    cl_ctx_thread_shutdown();
    return 0;
}
