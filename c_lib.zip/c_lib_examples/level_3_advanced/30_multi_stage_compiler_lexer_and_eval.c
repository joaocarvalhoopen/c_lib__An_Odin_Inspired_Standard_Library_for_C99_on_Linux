/*
 * ============================================================================
 * c_lib_examples - Level 3 (Advanced) - Example 30 of 30
 * File: level_3_advanced/30_multi_stage_compiler_lexer_and_eval.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Capstone mini-compiler: a complex-number expression lexer + recursive-
 *   descent parser & evaluator supporting `+`, `-`, `*`, `/`, unary `-`,
 *   parentheses, imaginary literals (`3i`, `2.5i`), and named variables
 *   stored in a `Cl_Map_Str_C128` symbol table!
 *
 * Architecture Showcased (Everything in `c_lib` Working Together):
 *   - `Cl_Arena` owns all lexed tokens (O(1) teardown via `CL_DEFER_ARENA`).
 *   - `Cl_DA` stores the token stream (`DA_Token`) with bounds-checked access.
 *   - `Cl_Map_Str_C128` stores complex128 variables (`z1`, `gain`, `pi`).
 *   - `CL_RES_DEFINE(Res_C128, cl_c128, Cl_Error)` + `CL_OR_RETURN` propagates
 *     syntax/math errors cleanly without `setjmp` or global error flags.
 *   - `Cl_String_Builder` formats results cleanly as `a + bi`.
 *   - `Cl_Tracking_Allocator` proves 0 leaked bytes across the entire run.
 *
 * WHY ARENAS + SLICES + MULTIPLE RETURNS SHINE IN COMPILERS & INTERPRETERS:
 *   - Token lexemes are zero-copy `Cl_Str` slices into the source string.
 *   - Every AST / token allocation lives in one phase arena, eliminating
 *     recursive tree destructors and memory leaks on syntax errors!
 *
 * ADVANTAGES:
 *   + Clean grammar with exact operator precedence and complex128 evaluation.
 *   + Zero leaks even when parsing malformed expressions (e.g. `"(3 + * 4"`).
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Recursive descent uses the C call stack -> for untrusted deeply nested
 *     inputs (`((((...))))`), add a max recursion depth guard!
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

typedef enum Tok_Kind {
    TOK_EOF = 0,
    TOK_NUMBER,
    TOK_IMAG,
    TOK_IDENT,
    TOK_PLUS,
    TOK_MINUS,
    TOK_STAR,
    TOK_SLASH,
    TOK_LPAREN,
    TOK_RPAREN
} Tok_Kind;

typedef struct Token {
    Tok_Kind kind;
    Cl_Str   lexeme;
    cl_f64   num_val;
} Token;

CL_DA_DEFINE(DA_Token, Token);
CL_RES_DEFINE(Res_C128, cl_c128, Cl_Error);

static bool is_alpha(cl_u8 c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
}

static bool is_digit(cl_u8 c) {
    return c >= '0' && c <= '9';
}

/* Stage 1: Lexer -> emits zero-copy tokens into `out` (allocated in Arena) */
static Cl_Error lex_expression(Cl_Str src, DA_Token *out) {
    cl_isize i = 0;
    while (i < src.len) {
        cl_u8 c = cl_str_at(src, i);
        if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
            i += 1;
            continue;
        }
        if (c == '+') { CL_DA_PUSH(out, ((Token){ TOK_PLUS,   cl_str_slice(src, i, i + 1), 0.0 })); i += 1; continue; }
        if (c == '-') { CL_DA_PUSH(out, ((Token){ TOK_MINUS,  cl_str_slice(src, i, i + 1), 0.0 })); i += 1; continue; }
        if (c == '*') { CL_DA_PUSH(out, ((Token){ TOK_STAR,   cl_str_slice(src, i, i + 1), 0.0 })); i += 1; continue; }
        if (c == '/') { CL_DA_PUSH(out, ((Token){ TOK_SLASH,  cl_str_slice(src, i, i + 1), 0.0 })); i += 1; continue; }
        if (c == '(') { CL_DA_PUSH(out, ((Token){ TOK_LPAREN, cl_str_slice(src, i, i + 1), 0.0 })); i += 1; continue; }
        if (c == ')') { CL_DA_PUSH(out, ((Token){ TOK_RPAREN, cl_str_slice(src, i, i + 1), 0.0 })); i += 1; continue; }

        if (is_digit(c) || c == '.') {
            cl_isize start = i;
            while (i < src.len && (is_digit(cl_str_at(src, i)) || cl_str_at(src, i) == '.')) {
                i += 1;
            }
            Cl_Str num_lex = cl_str_slice(src, start, i);
            Cl_Opt_F64 parsed = cl_str_parse_f64(num_lex);
            if (!parsed.ok) return CL_ERR_PARSE_FAILED;

            bool is_imag = (i < src.len && cl_str_at(src, i) == 'i');
            if (is_imag) i += 1;
            CL_DA_PUSH(out, ((Token){ is_imag ? TOK_IMAG : TOK_NUMBER, cl_str_slice(src, start, i), parsed.value }));
            continue;
        }

        if (is_alpha(c)) {
            cl_isize start = i;
            while (i < src.len && (is_alpha(cl_str_at(src, i)) || is_digit(cl_str_at(src, i)))) {
                i += 1;
            }
            Cl_Str id = cl_str_slice(src, start, i);
            if (cl_str_eq(id, CL_STR("i"))) {
                CL_DA_PUSH(out, ((Token){ TOK_IMAG, id, 1.0 }));
            } else {
                CL_DA_PUSH(out, ((Token){ TOK_IDENT, id, 0.0 }));
            }
            continue;
        }
        return CL_ERR_PARSE_FAILED;
    }
    CL_DA_PUSH(out, ((Token){ TOK_EOF, CL_STR_EMPTY, 0.0 }));
    return CL_ERR_NONE;
}

/* Stage 2: Recursive-Descent Parser + Complex128 Evaluator */
typedef struct Parser {
    const DA_Token        *tokens;
    cl_isize               pos;
    const Cl_Map_Str_C128 *env;
} Parser;

static Token peek(const Parser *p) {
    return CL_DA_AT(p->tokens, p->pos);
}

static Res_C128 parse_expr(Parser *p);

static Res_C128 parse_primary(Parser *p) {
    Token t = peek(p);
    if (t.kind == TOK_MINUS) {
        p->pos += 1;
        cl_c128 v;
        CL_OR_RETURN(v, parse_primary(p), Res_C128);
        return CL_OK(Res_C128, -v);
    }
    if (t.kind == TOK_NUMBER) {
        p->pos += 1;
        return CL_OK(Res_C128, cl_c128_make(t.num_val, 0.0));
    }
    if (t.kind == TOK_IMAG) {
        p->pos += 1;
        return CL_OK(Res_C128, cl_c128_make(0.0, t.num_val));
    }
    if (t.kind == TOK_IDENT) {
        p->pos += 1;
        cl_c128 *found = CL_MAP_GET(p->env, t.lexeme);
        if (found == NULL) return CL_ERR(Res_C128, CL_ERR_NOT_FOUND);
        return CL_OK(Res_C128, *found);
    }
    if (t.kind == TOK_LPAREN) {
        p->pos += 1;
        cl_c128 inner;
        CL_OR_RETURN(inner, parse_expr(p), Res_C128);
        if (peek(p).kind != TOK_RPAREN) return CL_ERR(Res_C128, CL_ERR_PARSE_FAILED);
        p->pos += 1;
        return CL_OK(Res_C128, inner);
    }
    return CL_ERR(Res_C128, CL_ERR_PARSE_FAILED);
}

static Res_C128 parse_term(Parser *p) {
    cl_c128 lhs;
    CL_OR_RETURN(lhs, parse_primary(p), Res_C128);
    while (peek(p).kind == TOK_STAR || peek(p).kind == TOK_SLASH) {
        Tok_Kind op = peek(p).kind;
        p->pos += 1;
        cl_c128 rhs;
        CL_OR_RETURN(rhs, parse_primary(p), Res_C128);
        if (op == TOK_STAR) {
            lhs = lhs * rhs;
        } else {
            if (cl_c128_abs2(rhs) == 0.0) return CL_ERR(Res_C128, CL_ERR_INVALID_ARG);
            lhs = lhs / rhs;
        }
    }
    return CL_OK(Res_C128, lhs);
}

static Res_C128 parse_expr(Parser *p) {
    cl_c128 lhs;
    CL_OR_RETURN(lhs, parse_term(p), Res_C128);
    while (peek(p).kind == TOK_PLUS || peek(p).kind == TOK_MINUS) {
        Tok_Kind op = peek(p).kind;
        p->pos += 1;
        cl_c128 rhs;
        CL_OR_RETURN(rhs, parse_term(p), Res_C128);
        lhs = (op == TOK_PLUS) ? (lhs + rhs) : (lhs - rhs);
    }
    return CL_OK(Res_C128, lhs);
}

static Res_C128 eval_complex_expr(Cl_Str src, const Cl_Map_Str_C128 *env, Cl_Allocator backing) {
    /* Phase-scoped arena: ALL tokens vanish in O(1) at scope exit! */
    Cl_Arena phase_arena;
    if (!cl_arena_init_alloc(&phase_arena, CL_KB(8), backing)) {
        return CL_ERR(Res_C128, CL_ERR_OUT_OF_MEMORY);
    }
    CL_DEFER_ARENA(phase_arena);

    DA_Token tokens = {0};
    CL_DA_INIT(&tokens, cl_arena_allocator(&phase_arena));

    Cl_Error lerr = lex_expression(src, &tokens);
    if (lerr != CL_ERR_NONE) {
        return CL_ERR(Res_C128, lerr);
    }

    Parser parser = { &tokens, 0, env };
    cl_c128 val;
    CL_OR_RETURN(val, parse_expr(&parser), Res_C128);
    if (peek(&parser).kind != TOK_EOF) {
        return CL_ERR(Res_C128, CL_ERR_PARSE_FAILED);
    }
    return CL_OK(Res_C128, val);
}

int main(void) {
    printf("=== Example 30: Complex-Number Expression Lexer & Evaluator ===\n\n");

    Cl_Tracking_Allocator tr;
    cl_tracking_init(&tr, cl_heap_allocator());
    CL_DEFER_TRACKING(tr);
    Cl_Allocator alloc = cl_tracking_allocator(&tr);

    /* Populate symbol table with complex128 variables */
    Cl_Map_Str_C128 env = {0};
    CL_MAP_INIT_STR(&env, alloc);
    CL_DEFER_MAP(env);
    CL_MAP_PUT(&env, CL_STR("z1"),   cl_c128_make(3.0, 4.0));
    CL_MAP_PUT(&env, CL_STR("gain"), cl_c128_make(0.5, -0.5));

    Cl_Str tests[] = {
        CL_STR("(3 + 4i) * (1 - 2i)"),
        CL_STR("z1 * gain + 2.5i"),
        CL_STR("-(1 + i) * (1 + i)"),
        CL_STR("(10 + 5i) / (2 - i)"),
        CL_STR("z1 + unknown_var"),
        CL_STR("(3 + * 4)")
    };

    Cl_String_Builder sb = {0};
    cl_sb_init(&sb, alloc);
    CL_DEFER_SB(sb);

    for (cl_isize idx = 0; idx < CL_ARRAY_LEN(tests); idx++) {
        Res_C128 r = eval_complex_expr(tests[idx], &env, alloc);
        cl_sb_reset(&sb);
        if (r.err == CL_ERR_NONE) {
            cl_sb_write_c128(&sb, r.value, 3);
            printf("  %-24.*s  =>  %s\n", CL_STR_ARG(tests[idx]), cl_sb_to_cstr(&sb));
        } else {
            printf("  %-24.*s  =>  ERROR (%s)\n", CL_STR_ARG(tests[idx]), cl_error_name(r.err));
        }
    }

    /* Cleanly verify zero leaks even after malformed expressions */
    cl_ctx_thread_shutdown();
    return 0;
}
