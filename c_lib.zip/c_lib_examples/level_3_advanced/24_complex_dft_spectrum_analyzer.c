/*
 * ============================================================================
 * c_lib_examples - Level 3 (Advanced) - Example 24 of 30
 * File: level_3_advanced/24_complex_dft_spectrum_analyzer.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Discrete Fourier Transform (DFT) spectrum analyzer uniting `complex64`
 *   storage, `complex128` twiddle accumulation, typed slices,
 *   `Cl_Virtual_Arena`, `Cl_String_Builder`, Parseval energy verification,
 *   and `Cl_Tracking_Allocator`.
 *
 * Plain-Text ASCII DSP Formulas:
 *   Signal (N = 64, Fs = 64 Hz -> 1 Hz/bin):
 *     x[n] = 1.0*cos(2*pi*5*n/N) + 0.6*sin(2*pi*14*n/N) + 0.3*cos(2*pi*22*n/N)
 *   DFT:
 *     X[k] = sum_{n=0..N-1} x[n] * e^(-i * 2*pi*k*n / N)
 *   Single-sided amplitude (0 < k < N/2):
 *     A[k] = (2 / N) * |X[k]|
 *   Parseval's Energy Theorem:
 *     sum |x[n]|^2 == (1 / N) * sum |X[k]|^2
 *
 * WHY MIX complex64 STORAGE WITH complex128 ACCUMULATION:
 *   - `complex64` halves RAM/cache bandwidth for large sample buffers.
 *   - Widening to `complex128` (`cl_c64_to_c128`) during accumulation prevents
 *     summation rounding error across many bins.
 *
 * ADVANTAGES:
 *   + Expressive infix complex arithmetic with C99 `_Complex` + FFTW-identical
 *     interleaved layout.
 *   + Bounds-checked slice accesses catch indexing bugs in dev builds.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Direct DFT is O(N^2); for N >= 1024 switch to an O(N log N) radix-2 FFT
 *     operating directly on the exact same `Cl_Slice_C64` / `Cl_Slice_C128`.
 * ============================================================================
 */

#define CL_SHORT_NAMES
#include "cl/cl.h"
#include <math.h>
#include <stdio.h>

static Cl_Error compute_dft(Cl_Slice_C64 input, Cl_Slice_C128 output) {
    if (input.len <= 0 || input.len != output.len) {
        return CL_ERR_INVALID_ARG;
    }
    isize N = input.len;
    f64 w0 = CL_TAU_F64 / (f64)N;

    for (isize k = 0; k < N; k++) {
        complex128 acc = cl_c128_make(0.0, 0.0);
        for (isize n = 0; n < N; n++) {
            complex128 twiddle = cl_c128_exp(cl_c128_make(0.0, -w0 * (f64)k * (f64)n));
            acc += cl_c64_to_c128(CL_SLICE_AT(input, n)) * twiddle;
        }
        CL_SLICE_AT(output, k) = acc;
    }
    return CL_ERR_NONE;
}

int main(void) {
    printf("=== Example 24: Complex64/Complex128 DFT Spectrum Analyzer ===\n\n");

    Virtual_Arena va;
    CL_ENSURE(cl_varena_init(&va, CL_MB(4), CL_KB(64)));
    CL_DEFER_VARENA(va);
    Allocator dsp_alloc = cl_varena_allocator(&va);

    const isize N = 64;
    const f64 Fs  = 64.0;

    Cl_Slice_C64  samples  = CL_SLICE_MAKE(Cl_Slice_C64,  dsp_alloc, N);
    Cl_Slice_C128 spectrum = CL_SLICE_MAKE(Cl_Slice_C128, dsp_alloc, N);

    f64 time_energy = 0.0;
    CL_SLICE_FOR_EACH(n, samples) {
        f64 t = (f64)n / Fs;
        f64 v = 1.0 * cos(CL_TAU_F64 * 5.0 * t)
              + 0.6 * sin(CL_TAU_F64 * 14.0 * t)
              + 0.3 * cos(CL_TAU_F64 * 22.0 * t);
        CL_SLICE_AT(samples, n) = cl_c64_make((f32)v, 0.0f);
        time_energy += (f64)cl_c64_abs2(CL_SLICE_AT(samples, n));
    }

    Stopwatch sw = {0};
    cl_stopwatch_start(&sw);
    CL_ENSURE(compute_dft(samples, spectrum) == CL_ERR_NONE);
    cl_stopwatch_stop(&sw);

    f64 freq_energy = 0.0;
    CL_SLICE_FOR_EACH(k, spectrum) {
        freq_energy += cl_c128_abs2(CL_SLICE_AT(spectrum, k));
    }
    freq_energy /= (f64)N;

    String_Builder sb = {0};
    CL_DEFER_SB(sb);
    cl_sb_write_fmt(&sb, "DFT (N=%lld, Fs=%.0f Hz) took %.3f ms | Parseval diff=%.2e\n\n",
                    (CL_LL)N, Fs, cl_stopwatch_elapsed_ms(&sw), fabs(time_energy - freq_energy));
    cl_sb_write_cstr(&sb, "  Freq (Hz) | Amp    | Phase (deg) | Spectrum\n");
    cl_sb_write_cstr(&sb, "  ----------+--------+-------------+--------------------------\n");

    for (isize k = 0; k <= N / 2; k++) {
        complex128 Xk = CL_SLICE_AT(spectrum, k);
        f64 scale = (k == 0 || k == N / 2) ? (1.0 / (f64)N) : (2.0 / (f64)N);
        f64 amp = scale * cl_c128_abs(Xk);
        if (amp > 0.05) {
            cl_sb_write_fmt(&sb, "  %6lld Hz | %6.3f | %+10.2f  | ",
                            (CL_LL)k, amp, cl_c128_arg(Xk) * (180.0 / CL_PI_F64));
            cl_sb_write_repeat(&sb, STR("#"), (isize)(amp * 24.0 + 0.5));
            cl_sb_write_byte(&sb, '\n');
        }
    }

    printf("%s", cl_sb_to_cstr(&sb));
    cl_ctx_thread_shutdown();
    return 0;
}
