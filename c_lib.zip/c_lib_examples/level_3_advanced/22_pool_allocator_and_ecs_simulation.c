/*
 * ============================================================================
 * c_lib_examples - Level 3 (Advanced) - Example 22 of 30
 * File: level_3_advanced/22_pool_allocator_and_ecs_simulation.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Multi-allocator game/simulation loop matching each object's lifetime to
 *   the ideal allocator:
 *     - `Cl_Virtual_Arena` -> persistent world/event log (pointer-stable)
 *     - `Cl_Pool`          -> O(1) fixed-size Entity spawn/despawn (0 frag)
 *     - `Cl_Bit_Set`       -> compact alive entity bitmask
 *     - `temp_allocator`   -> per-frame scratch lists & telemetry wiped in O(1)
 *     - `Cl_Stopwatch`     -> monotonic frame timing
 *
 * WHY MATCH ALLOCATORS TO LIFETIMES:
 *   - Throwing persistent world data, dynamic entities, and temporary frame
 *     strings into one global `malloc` heap creates fragmentation, unpredictable
 *     latency spikes, and leak-prone shutdown sequences.
 *   - Separating by lifetime gives O(1) spawn/despawn (`Cl_Pool`), O(1) frame
 *     cleanup (`cl_ctx_temp_reset`), and O(1) world teardown (`Cl_Virtual_Arena`).
 *
 * ADVANTAGES:
 *   + Zero heap fragmentation across thousands of simulation ticks.
 *   + Deterministic O(1) spawn and despawn with ASan poisoning on free slots.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - `Cl_Pool` has a fixed maximum slot count (`MAX_ENTITIES`); exceeding it
 *     requires either sizing conservatively or chaining multiple pools.
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

#define MAX_ENTITIES 64

typedef struct Entity {
    cl_i32 id;
    cl_f32 x, y;
    cl_f32 vx, vy;
    cl_f32 hp;
} Entity;

typedef struct Event_Node {
    Cl_Str             message;
    struct Event_Node *next;
} Event_Node;

int main(void) {
    printf("=== Example 22: Multi-Allocator ECS Simulation (Virtual Arena + Pool + Temp) ===\n\n");

    Cl_Stopwatch sw = {0};
    cl_stopwatch_start(&sw);

    Cl_Virtual_Arena world_va;
    CL_ENSURE(cl_varena_init(&world_va, CL_MB(32), CL_KB(64)));
    CL_DEFER_VARENA(world_va);
    Cl_Allocator world_alloc = cl_varena_allocator(&world_va);

    Cl_Pool entity_pool;
    CL_ENSURE(cl_pool_init_alloc(
        &entity_pool, MAX_ENTITIES, (cl_isize)sizeof(Entity), CL_ALIGNOF(Entity), world_alloc
    ));
    CL_DEFER_POOL(entity_pool);
    Cl_Allocator pool_alloc = cl_pool_allocator(&entity_pool);

    Cl_Bit_Set alive_mask;
    CL_ENSURE(cl_bitset_init(&alive_mask, MAX_ENTITIES, world_alloc));

    Entity *slots[MAX_ENTITIES] = {0};
    Event_Node *event_head = NULL, *event_tail = NULL;

    for (cl_i32 i = 0; i < 6; i++) {
        Entity *e = cl_new(pool_alloc, Entity);
        CL_ENSURE(e != NULL);
        e->id = i + 1;
        e->x  = (cl_f32)(i * 10);
        e->vx = 2.5f;
        e->vy = 1.0f;
        e->hp = 20.0f + (cl_f32)(i * 15);
        slots[i] = e;
        cl_bitset_set(&alive_mask, i);
    }

    for (int tick = 1; tick <= 5; tick++) {
        Cl_DA_I32 active_ids = {0};
        CL_DA_INIT(&active_ids, cl_ctx_temp_allocator());

        for (cl_isize i = 0; i < MAX_ENTITIES; i++) {
            if (!cl_bitset_test(&alive_mask, i)) continue;
            Entity *e = slots[i];
            e->x  += e->vx * 0.5f;
            e->y  += e->vy * 0.5f;
            e->hp -= 12.0f;
            CL_DA_PUSH(&active_ids, e->id);

            if (e->hp <= 0.0f) {
                Event_Node *ev = cl_new(world_alloc, Event_Node);
                ev->message = cl_aprintf(world_alloc, "Tick %d: Entity #%d expired at (%.1f, %.1f)",
                                         tick, (int)e->id, (double)e->x, (double)e->y);
                if (event_tail == NULL) event_head = event_tail = ev;
                else { event_tail->next = ev; event_tail = ev; }

                cl_delete(pool_alloc, e);
                slots[i] = NULL;
                cl_bitset_clear(&alive_mask, i);
            }
        }

        Cl_Str line = cl_tprintf("Tick %d: processed=%lld, alive=%lld, pool=%lld/%lld",
                                 tick, (CL_LL)active_ids.len,
                                 (CL_LL)cl_bitset_count_ones(&alive_mask),
                                 (CL_LL)entity_pool.used_count,
                                 (CL_LL)entity_pool.chunk_count);
        printf("  " CL_STR_FMT "\n", CL_STR_ARG(line));
        cl_ctx_temp_reset();
    }

    printf("\nPersistent World Event Log:\n");
    for (const Event_Node *cur = event_head; cur != NULL; cur = cur->next) {
        printf("  * " CL_STR_FMT "\n", CL_STR_ARG(cur->message));
    }

    cl_stopwatch_stop(&sw);
    printf("\nElapsed: %.3f ms (committed=%lld KiB, used=%lld B)\n",
           cl_stopwatch_elapsed_ms(&sw),
           (CL_LL)(world_va.committed / CL_KB(1)),
           (CL_LL)world_va.offset);

    cl_ctx_thread_shutdown();
    return 0;
}
