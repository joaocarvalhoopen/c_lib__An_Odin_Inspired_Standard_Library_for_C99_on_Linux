/*
 * ============================================================================
 * c_lib_examples - Level 3 (Advanced) - Example 27 of 30
 * File: level_3_advanced/27_ini_config_file_parser.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Zero-copy `.ini` configuration file loader combining whole-file I/O
 *   (`cl_os_write_entire_file_str` / `cl_os_read_entire_file_str`),
 *   `cl_str_split_lines_iter`, `cl_str_cut`, `Cl_Arena`, `Cl_Map_Str_Str`
 *   keyed by `"section.key"`, and typed config getters (`i64`, `f64`, `bool`,
 *   `complex128`).
 *
 * WHY THIS DESIGN IS IDIOMATIC IN ODIN & c_lib:
 *   - Reading the entire `.ini` file once into an arena means EVERY section
 *     name, key, and value is a zero-copy `Cl_Str` slice pointing directly
 *     into the loaded file buffer!
 *   - Only composite `"section.key"` map keys are formatted inside the arena,
 *     and tearing down the entire config takes ONE `cl_arena_destroy()`!
 *
 * WHEN TO USE:
 *   - Application config files, server settings, DSP/RF calibration profiles.
 *
 * ADVANTAGES:
 *   + ~60 lines of clean, leak-proof C99 with zero external JSON/YAML deps.
 *   + Typed getters with safe fallbacks via `CL_OR_ELSE`.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Minimal `.ini` grammar (no multi-line quoted escapes or nested arrays).
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

typedef struct Ini_Config {
    Cl_Arena       arena;
    Cl_Map_Str_Str entries; /* "section.key" -> raw value slice */
} Ini_Config;

static Cl_Error ini_load_file(Ini_Config *cfg, Cl_Str path, Cl_Allocator backing) {
    CL_ZERO_STRUCT(cfg);
    if (!cl_arena_init_alloc(&cfg->arena, CL_KB(64), backing)) {
        return CL_ERR_OUT_OF_MEMORY;
    }
    Cl_Allocator aa = cl_arena_allocator(&cfg->arena);

    Cl_Res_Str file_res = cl_os_read_entire_file_str(path, aa);
    if (file_res.err != CL_ERR_NONE) {
        cl_arena_destroy(&cfg->arena);
        return file_res.err;
    }

    CL_MAP_INIT_STR(&cfg->entries, aa);

    Cl_Str section = CL_STR("global");
    Cl_Str cursor  = file_res.value;
    for (;;) {
        Cl_Str line;
        CL_OPT_OR_BREAK(line, cl_str_split_lines_iter(&cursor));
        line = cl_str_trim_space(line);
        if (line.len == 0 || cl_str_has_prefix(line, CL_STR("#")) || cl_str_has_prefix(line, CL_STR(";"))) {
            continue;
        }
        if (cl_str_has_prefix(line, CL_STR("[")) && cl_str_has_suffix(line, CL_STR("]"))) {
            section = cl_str_trim_space(cl_str_slice(line, 1, line.len - 1));
            continue;
        }
        Cl_Str_Cut kv = cl_str_cut(line, CL_STR("="));
        if (!kv.found) continue;

        Cl_Str k = cl_str_trim_space(kv.before);
        Cl_Str v = cl_str_trim_space(kv.after);
        Cl_Str full_key = cl_aprintf(aa, CL_STR_FMT "." CL_STR_FMT, CL_STR_ARG(section), CL_STR_ARG(k));
        CL_MAP_PUT(&cfg->entries, full_key, v);
    }

    return CL_ERR_NONE;
}

static void ini_destroy(Ini_Config *cfg) {
    /* Everything (file text, map buckets, composite keys) lives in cfg->arena! */
    cl_arena_destroy(&cfg->arena);
    CL_ZERO_STRUCT(cfg);
}

static Cl_Opt_Str ini_get(const Ini_Config *cfg, Cl_Str full_key) {
    Cl_Str *p = CL_MAP_GET(&cfg->entries, full_key);
    return p ? CL_SOME(Cl_Opt_Str, *p) : CL_NONE(Cl_Opt_Str);
}

int main(void) {
    printf("=== Example 27: Zero-Copy INI Config File Parser ===\n\n");

    Cl_Tracking_Allocator tr;
    cl_tracking_init(&tr, cl_heap_allocator());
    CL_DEFER_TRACKING(tr);
    Cl_Allocator alloc = cl_tracking_allocator(&tr);

    Cl_Str ini_path = CL_STR("/tmp/c_lib_ex27_app.ini");
    Cl_Str sample = CL_STR(
        "# RF Receiver Configuration\n"
        "[server]\n"
        "host = 0.0.0.0\n"
        "port = 9090\n"
        "tls  = true\n"
        "\n"
        "[dsp]\n"
        "sample_rate = 48000.0\n"
        "calibration_gain = 0.985 - 0.172i\n"
    );
    CL_ENSURE(cl_os_write_entire_file_str(ini_path, sample) == CL_ERR_NONE);

    Ini_Config cfg;
    CL_ENSURE(ini_load_file(&cfg, ini_path, alloc) == CL_ERR_NONE);

    Cl_Str host = CL_OR_ELSE(ini_get(&cfg, CL_STR("server.host")), CL_STR("127.0.0.1"));
    cl_i64 port = CL_OR_ELSE(cl_str_parse_i64(CL_OR_ELSE(ini_get(&cfg, CL_STR("server.port")), CL_STR("")), 10), 8080);
    bool   tls  = CL_OR_ELSE(cl_str_parse_bool(CL_OR_ELSE(ini_get(&cfg, CL_STR("server.tls")), CL_STR(""))), false);
    cl_f64 sr   = CL_OR_ELSE(cl_str_parse_f64(CL_OR_ELSE(ini_get(&cfg, CL_STR("dsp.sample_rate")), CL_STR(""))), 44100.0);
    cl_c128 g   = CL_OR_ELSE(cl_str_parse_c128(CL_OR_ELSE(ini_get(&cfg, CL_STR("dsp.calibration_gain")), CL_STR(""))),
                             cl_c128_make(1.0, 0.0));

    printf("Loaded INI settings (%lld keys, arena used=%lld B):\n",
           (CL_LL)CL_MAP_LEN(&cfg.entries), (CL_LL)cl_arena_used(&cfg.arena));
    printf("  server.host          = " CL_STR_FMT "\n", CL_STR_ARG(host));
    printf("  server.port          = %lld\n", (CL_LL)port);
    printf("  server.tls           = %s\n", tls ? "true" : "false");
    printf("  dsp.sample_rate      = %.1f Hz\n", sr);
    printf("  dsp.calibration_gain = %.3f %+.3fi\n", cl_c128_real(g), cl_c128_imag(g));

    ini_destroy(&cfg);
    (void)cl_os_remove_file(ini_path);
    CL_ENSURE(cl_tracking_is_clean(&tr));
    cl_ctx_thread_shutdown();
    return 0;
}
