/*
 * ============================================================================
 * c_lib_examples - Level 3 (Advanced) - Example 21 of 30
 * File: level_3_advanced/21_virtual_arena_large_graph.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Linux `Cl_Virtual_Arena` (`mmap` reserve + on-demand `mprotect` commit +
 *   `madvise(MADV_DONTNEED)` physical page reclamation) used to build a
 *   pointer-linked graph across multiple commit chunks with guaranteed
 *   pointer stability.
 *
 * WHY USE Cl_Virtual_Arena FOR POINTER-HEAVY GRAPHS / ASTs / TREES:
 *   - Growing a `Cl_DA` with `realloc()` moves memory, invalidating every
 *     raw `Node *` pointer held by parent/child edges.
 *   - Fixed `Cl_Arena` never moves pointers, but fails if you underestimate
 *     the final node count.
 *   - `Cl_Virtual_Arena` reserves e.g. 256 MiB of virtual address space at
 *     ZERO physical RAM cost, commits 64 KiB OS pages lazily as needed, and
 *     NEVER moves the base address! Every `Node *` remains valid forever
 *     until `cl_varena_reset()` / `cl_varena_destroy()`.
 *
 * WHEN TO USE:
 *   - Compiler ASTs / IR graphs, scene graphs, spatial BVH/octrees, large
 *     parsing DOMs, or growing buffers needing stable interior pointers.
 *
 * ADVANTAGES:
 *   + 100% pointer stability across arbitrarily large growth.
 *   + Zero physical RAM paid for uncommitted reserved space.
 *   + Single O(1) `cl_varena_reset(&va, true)` releases ALL nodes AND hands
 *     physical pages back to the Linux kernel!
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Linux/POSIX virtual memory specific (4 KiB page granularity).
 *   - Cannot free an individual node in the middle (only bulk reset / rewind).
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

typedef struct Dag_Node {
    cl_i64           id;
    Cl_Str           name;
    struct Dag_Node *left;
    struct Dag_Node *right;
    cl_u8            payload[256]; /* Forces growth across multiple 64 KiB commits */
} Dag_Node;

static cl_i64 count_chain_nodes(const Dag_Node *head) {
    cl_i64 n = 0;
    for (const Dag_Node *cur = head; cur != NULL; cur = cur->left) {
        n += 1;
    }
    return n;
}

int main(void) {
    printf("=== Example 21: Virtual Arena Pointer-Stable Graph ===\n\n");

    /* Reserve 256 MiB virtual address space, commit in 64 KiB chunks */
    Cl_Virtual_Arena va;
    CL_ENSURE(cl_varena_init(&va, CL_MB(256), CL_KB(64)));
    CL_DEFER_VARENA(va);
    Cl_Allocator alloc = cl_varena_allocator(&va);

    printf("OS page size : %lld bytes\n", (CL_LL)va.page_size);
    printf("Initial      : reserved=%lld MiB, committed=%lld KiB\n",
           (CL_LL)(va.reserved / CL_MB(1)), (CL_LL)(va.committed / CL_KB(1)));

    /* Allocate 1000 linked nodes (~300 KiB -> crosses 5 OS commit chunks!) */
    Dag_Node *head = NULL;
    Dag_Node *first_node = NULL;
    for (cl_i64 i = 0; i < 1000; i++) {
        Dag_Node *node = cl_new(alloc, Dag_Node);
        CL_ENSURE(node != NULL);
        node->id   = i;
        node->name = cl_aprintf(alloc, "node_%lld", (CL_LL)i);
        node->left = head;
        if (first_node == NULL) {
            first_node = node;
        }
        head = node;
    }

    /* Notice: `first_node` pointer from chunk #1 is STILL 100% valid after chunk #5! */
    printf("After 1000 nodes: committed=%lld KiB, used=%lld bytes\n",
           (CL_LL)(va.committed / CL_KB(1)), (CL_LL)va.offset);
    printf("Pointer stability check: first_node->id=%lld, name='" CL_STR_FMT "', chain_len=%lld\n",
           (CL_LL)first_node->id, CL_STR_ARG(first_node->name), (CL_LL)count_chain_nodes(head));

    /* Reclaim physical RAM via madvise(MADV_DONTNEED) while keeping virtual map */
    cl_varena_reset(&va, true);
    printf("After reset(decommit=true): committed=%lld KiB, used=%lld bytes\n",
           (CL_LL)(va.committed / CL_KB(1)), (CL_LL)va.offset);

    return 0;
}
