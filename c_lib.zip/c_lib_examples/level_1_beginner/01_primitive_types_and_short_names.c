/*
 * ============================================================================
 * c_lib_examples - Level 1 (Beginner) - Example 01 of 30
 * File: level_1_beginner/01_primitive_types_and_short_names.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Odin-style explicit fixed-width scalar types (`i8..i64`, `u8..u64`,
 *   `isize`, `usize`, `f32`, `f64`, `b32`, `rune`), opt-in `CL_SHORT_NAMES`,
 *   pure C99 `CL_STATIC_ASSERT`, byte size units (`KB`, `MB`), and
 *   single-evaluation `CL_MIN` / `CL_MAX` / `CL_CLAMP` / `CL_SWAP`.
 *
 * WHY USE EXPLICIT TYPES AND SIGNED SIZES:
 *   - Standard C's `int`, `long`, and `unsigned long` vary in width across
 *     platforms and ABIs. Fixed-width names (`i32`, `u64`, `f64`) document
 *     exact memory layout and range right in the type signature.
 *   - Using signed `isize` (`ptrdiff_t`) for lengths and indices prevents
 *     notorious C unsigned underflow bugs (such as `size_t i = n - 1` wrapping
 *     to 18446744073709551615 when `n == 0`).
 *
 * WHEN TO USE:
 *   - Use `cl_*` prefixed names in public headers to avoid namespace clashes.
 *   - Enable `#define CL_SHORT_NAMES` in `.c` application files when you want
 *     concise Odin-style readability (`u8`, `i64`, `f64`, `complex128`, `Str`).
 *
 * ADVANTAGES:
 *   + Self-documenting struct layouts and portable integer ranges.
 *   + `CL_MIN`/`CL_MAX`/`CL_CLAMP` evaluate arguments ONCE on GCC/Clang
 *     (preventing double-evaluation macro bugs like `CL_MAX(a++, b)`).
 *   + `CL_STATIC_ASSERT` catches struct-layout regressions at compile time.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - `CL_SHORT_NAMES` introduces short identifiers (`i32`, `u8`, `Str`) that
 *     could collide with legacy third-party headers if included before them.
 *   - `isize` halves maximum addressable size compared to `usize`, which is
 *     harmless on 64-bit Linux (2^63 - 1 bytes is 8 exabytes).
 * ============================================================================
 */

#define CL_SHORT_NAMES
#include "cl/cl.h"
#include <stdio.h>

typedef struct Sensor_Frame {
    u64 timestamp_ns;
    f32 temperature_c;
    b32 valid;
} Sensor_Frame;

/* Pure C99 compile-time layout guarantee */
CL_STATIC_ASSERT(sizeof(Sensor_Frame) == 16, sensor_frame_is_16_bytes);

static i32 next_counter(i32 *state) {
    *state += 1;
    return *state;
}

int main(void) {
    printf("=== Example 01: Primitive Types & Short Names ===\n\n");

    /* Signed reverse loop is 100% safe even when len == 0! */
    isize empty_len = 0;
    isize visited = 0;
    for (isize i = empty_len - 1; i >= 0; i--) {
        visited += 1;
    }
    printf("Signed reverse loop on len=0 visited %lld elements (no unsigned underflow!).\n",
           (CL_LL)visited);

    /* Exact sizes and byte units */
    printf("sizeof(Sensor_Frame) = %zu bytes\n", sizeof(Sensor_Frame));
    printf("Buffer presets       : 4 KB = %lld B, 2 MB = %lld B\n",
           (CL_LL)KB(4), (CL_LL)MB(2));

    /* Single-evaluation CL_MAX / CL_CLAMP / CL_SWAP */
    i32 counter = 10;
    i32 biggest = CL_MAX(next_counter(&counter), 5); /* Calls next_counter ONCE! */
    printf("Single-eval CL_MAX   : result=%d, counter=%d (expected 11)\n", biggest, counter);

    f64 clamped = CL_CLAMP(142.5, 0.0, 100.0);
    printf("Clamped percentage   : %.1f%%\n", clamped);

    i64 a = 100, b = 999;
    CL_SWAP(a, b);
    printf("After CL_SWAP        : a=%lld, b=%lld\n", (CL_LL)a, (CL_LL)b);

    return 0;
}
