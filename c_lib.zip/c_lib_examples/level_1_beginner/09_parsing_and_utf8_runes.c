/*
 * ============================================================================
 * c_lib_examples - Level 1 (Beginner) - Example 09 of 30
 * File: level_1_beginner/09_parsing_and_utf8_runes.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Strict numeric/boolean/complex parsing (`cl_str_parse_*`) and strict
 *   RFC 3629 UTF-8 rune decoding, encoding, validation, and rune-safe reversal.
 *
 * WHY USE c_lib PARSERS INSTEAD OF `atoi`/`strtol`/`strtod`:
 *   - `atoi("abc")` silently returns `0` with no error reporting!
 *   - `strtol` requires NUL-terminated strings, manual `errno = 0`, and
 *     checking `*endptr == '\0'`.
 *   - `cl_str_parse_i64/u64/f64/bool/c64/c128` work directly on `Cl_Str`
 *     views, support Odin-style underscores (`1_000_000`) and base prefixes
 *     (`0x`, `0b`, `0o`), reject trailing garbage and integer overflows, and
 *     return `CL_NODISCARD` `Cl_Opt_*` values.
 *
 * WHEN TO USE UTF-8 RUNES:
 *   - Use `cl_utf8_valid()` at system boundaries to reject malformed or
 *     overlong/surrogate byte sequences.
 *   - Use `cl_utf8_next()` whenever counting user-visible code points or
 *     manipulating multi-byte text (never reverse UTF-8 byte-by-byte!).
 *
 * ADVANTAGES:
 *   + Strict error handling with zero silent `0` fallbacks.
 *   + Supports complex64/complex128 formats like `"3 - 4i"` and `"(3, 4)"`.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Rune count counts Unicode scalar values, not extended grapheme clusters
 *     (combining accents / ZWJ emoji sequences remain multiple runes).
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

int main(void) {
    printf("=== Example 09: Strict Parsing & UTF-8 Runes ===\n\n");

    /* 1. Strict integer, float, bool, and complex parsers */
    Cl_Opt_I64 dec = cl_str_parse_i64(CL_STR("-1_250_000"), 10);
    Cl_Opt_I64 hex = cl_str_parse_i64(CL_STR("0xDEAD"), 0);
    Cl_Opt_I64 bin = cl_str_parse_i64(CL_STR("0b101101"), 0);
    Cl_Opt_I64 bad = cl_str_parse_i64(CL_STR("42xyz"), 10);
    Cl_Opt_F64 flt = cl_str_parse_f64(CL_STR("6.022e23"));
    Cl_Opt_Bool b  = cl_str_parse_bool(CL_STR("yes"));
    Cl_Opt_C128 z1 = cl_str_parse_c128(CL_STR("3.5 - 2.25i"));
    Cl_Opt_C64  z2 = cl_str_parse_c64(CL_STR("(1.5, -0.5)"));

    printf("Parsed values:\n");
    printf("  dec = %lld (ok=%d)\n", (CL_LL)dec.value, dec.ok);
    printf("  hex = %lld (ok=%d)\n", (CL_LL)hex.value, hex.ok);
    printf("  bin = %lld (ok=%d)\n", (CL_LL)bin.value, bin.ok);
    printf("  bad = ok=%d (rejected trailing garbage 'xyz')\n", bad.ok);
    printf("  flt = %.3e (ok=%d)\n", flt.value, flt.ok);
    printf("  b   = %s (ok=%d)\n", b.value ? "true" : "false", b.ok);
    printf("  z1  = %.2f + %.2fi (ok=%d)\n", cl_c128_real(z1.value), cl_c128_imag(z1.value), z1.ok);
    printf("  z2  = %.2f + %.2fi (ok=%d)\n\n",
           (double)cl_c64_real(z2.value), (double)cl_c64_imag(z2.value), z2.ok);

    /* 2. UTF-8 multi-byte decoding (1, 2, 3, and 4-byte runes) */
    const cl_u8 utf8_sample[] = {
        'O', 'l', 0xC3u, 0xA1u, ' ',            /* "Ola" with a-acute (U+00E1) */
        0xE2u, 0x82u, 0xACu, ' ',               /* Euro sign (U+20AC) */
        0xF0u, 0x9Fu, 0x9Au, 0x80u              /* Rocket (U+1F680) */
    };
    Cl_Str text = cl_str_from_parts(utf8_sample, (cl_isize)sizeof(utf8_sample));
    printf("UTF-8 string : " CL_STR_FMT " (bytes=%lld, runes=%lld, valid=%s)\n",
           CL_STR_ARG(text),
           (CL_LL)text.len,
           (CL_LL)cl_utf8_rune_count(text),
           cl_utf8_valid(text) ? "true" : "false");

    cl_isize off = 0;
    printf("Code points  : ");
    while (off < text.len) {
        Cl_Utf8_Decode d = cl_utf8_next(text, &off);
        printf("U+%04X ", (unsigned)d.codepoint);
    }
    printf("\n");

    /* Rune-safe reversal preserves every multi-byte character intact */
    Cl_Str rev = cl_str_reverse_utf8(text, cl_ctx_temp_allocator());
    printf("Reversed     : " CL_STR_FMT " (valid=%s)\n",
           CL_STR_ARG(rev), cl_utf8_valid(rev) ? "true" : "false");

    /* Security check: invalid overlong sequence rejected cleanly */
    const cl_u8 overlong_slash[2] = { 0xC0u, 0xAFu };
    printf("Overlong 0xC0 0xAF valid? %s\n",
           cl_utf8_valid(cl_str_from_parts(overlong_slash, 2)) ? "true" : "false");

    cl_ctx_temp_reset();
    cl_ctx_thread_shutdown();
    return 0;
}
