/*
 * ============================================================================
 * c_lib_examples - Level 1 (Beginner) - Example 05 of 30
 * File: level_1_beginner/05_multiple_return_values_and_errors.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Odin-style multiple return values (`CL_OPT_DEFINE`, `CL_RES_DEFINE`,
 *   `CL_PAIR_DEFINE`, `CL_TUPLE3_DEFINE`) and ergonomic error propagation
 *   (`CL_OR_RETURN`, `CL_OPT_OR_RETURN`, `CL_OR_ELSE`, `CL_OPT_OR_BREAK`).
 *
 * WHY USE STRUCT-VALUE MULTIPLE RETURNS:
 *   - Eliminates ambiguous error sentinels (`-1`, `0`, `NULL`) and out-pointer
 *     boilerplate (`bool parse(const char *s, int *out_val)`).
 *   - On x86_64 Linux SysV ABI, structs <= 16 bytes return directly in CPU
 *     registers (RAX + RDX), matching Odin's zero-cost multiple returns.
 *   - `CL_NODISCARD` warns at compile time if a caller forgets to check errors.
 *
 * WHEN TO USE:
 *   - Use `CL_OPT_DEFINE` (`{ value, ok }`) when absence has a single obvious
 *     meaning (map lookup, string parse, optional config key).
 *   - Use `CL_RES_DEFINE` (`{ value, err }`) when the caller needs to know WHY
 *     an operation failed (I/O, validation, protocol decoding).
 *   - Use `CL_PAIR_DEFINE` / `CL_TUPLE3_DEFINE` for multi-output math/parsing.
 *
 * ADVANTAGES:
 *   + Clean linear control flow with `CL_OR_RETURN` (no pyramid of doom).
 *   + Impossible to confuse a valid value (like `0` or `-1`) with failure.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Each unique `(T, E)` combination needs a 1-line `CL_RES_DEFINE` typedef.
 *   - Returning very large structs (> 64 bytes) by value copies via hidden
 *     caller stack slot (for huge structs, return pointer or populate out-arg).
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

typedef struct User_Port_Range {
    cl_i64 start_port;
    cl_i64 end_port;
} User_Port_Range;

CL_RES_DEFINE(Res_Port_Range, User_Port_Range, Cl_Error);
CL_TUPLE3_DEFINE(Stats_Triple, cl_i64, cl_i64, cl_f64); /* min, max, avg */

static CL_NODISCARD Cl_Res_I64 parse_valid_port(Cl_Str text) {
    Cl_Opt_I64 p = cl_str_parse_i64(text, 10);
    if (!p.ok) {
        return CL_ERR(Cl_Res_I64, CL_ERR_PARSE_FAILED);
    }
    if (p.value < 1 || p.value > 65535) {
        return CL_ERR(Cl_Res_I64, CL_ERR_OUT_OF_BOUNDS);
    }
    return CL_OK(Cl_Res_I64, p.value);
}

static CL_NODISCARD Res_Port_Range parse_port_range(Cl_Str spec) {
    Cl_Str_Cut parts = cl_str_cut(spec, CL_STR("-"));
    if (!parts.found) {
        return CL_ERR(Res_Port_Range, CL_ERR_PARSE_FAILED);
    }

    cl_i64 lo = 0, hi = 0;
    CL_OR_RETURN(lo, parse_valid_port(parts.before), Res_Port_Range);
    CL_OR_RETURN(hi, parse_valid_port(parts.after),  Res_Port_Range);

    if (lo > hi) {
        return CL_ERR(Res_Port_Range, CL_ERR_INVALID_ARG);
    }
    return CL_OK(Res_Port_Range, ((User_Port_Range){ lo, hi }));
}

static Stats_Triple compute_stats(Cl_Slice_I64 vals) {
    CL_ENSURE(vals.len > 0);
    cl_i64 lo = CL_SLICE_AT(vals, 0);
    cl_i64 hi = lo;
    cl_i64 sum = 0;
    CL_SLICE_FOR_EACH(i, vals) {
        cl_i64 v = CL_SLICE_AT(vals, i);
        if (v < lo) lo = v;
        if (v > hi) hi = v;
        sum += v;
    }
    return (Stats_Triple){ lo, hi, (cl_f64)sum / (cl_f64)vals.len };
}

int main(void) {
    printf("=== Example 05: Multiple Return Values & Error Propagation ===\n\n");

    Cl_Str cases[] = { CL_STR("8000-8080"), CL_STR("9000-8000"), CL_STR("80-99999"), CL_STR("oops") };
    for (cl_isize i = 0; i < CL_ARRAY_LEN(cases); i++) {
        Res_Port_Range r = parse_port_range(cases[i]);
        if (r.err == CL_ERR_NONE) {
            printf("  '" CL_STR_FMT "' -> OK [%lld .. %lld]\n",
                   CL_STR_ARG(cases[i]), (CL_LL)r.value.start_port, (CL_LL)r.value.end_port);
        } else {
            printf("  '" CL_STR_FMT "' -> ERROR (%s)\n",
                   CL_STR_ARG(cases[i]), cl_error_name(r.err));
        }
    }

    /* Inline default fallback using CL_OR_ELSE */
    cl_i64 timeout_ms = CL_OR_ELSE(cl_str_parse_i64(CL_STR("bad_num"), 10), 5000);
    printf("\nFallback timeout via CL_OR_ELSE : %lld ms\n", (CL_LL)timeout_ms);

    /* 3-value tuple return */
    cl_i64 data[] = { 10, 40, 20, 90, 40 };
    Stats_Triple st = compute_stats(CL_SLICE_FROM_ARRAY(Cl_Slice_I64, data));
    printf("Triple return (min, max, avg)   : (%lld, %lld, %.1f)\n",
           (CL_LL)st.first, (CL_LL)st.second, st.third);

    return 0;
}
