/*
 * ============================================================================
 * c_lib_examples - Level 1 (Beginner) - Example 07 of 30
 * File: level_1_beginner/07_complex64_and_complex128_basics.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   First-class `complex64` (`cl_c64`) and `complex128` (`cl_c128`) types
 *   using native ISO C99 `_Complex` arithmetic, polar form, transcendental
 *   functions, binary layout compatibility, and an AC RLC circuit solver.
 *
 * Plain-Text ASCII Formulas:
 *   Angular frequency: omega = 2 * pi * f
 *   Impedance:         Z = R + i * (omega * L - 1 / (omega * C))
 *   Phasor current:    I = V / Z
 *   Apparent power:    S = V * conj(I) = P + i * Q
 *   Euler identity:    e^(i * pi) + 1 = 0
 *
 * WHY USE NATIVE C99 _Complex (`cl_c64` / `cl_c128`):
 *   - Supports natural infix operators (`+`, `-`, `*`, `/`) without verbose
 *     `c128_mul(a, c128_add(b, c))` nesting.
 *   - Guaranteed by C99 6.2.5p13 to have exact `float[2]` / `double[2]` layout
 *     for zero-copy interop with Odin `complex64`/`complex128`, FFTW, and BLAS.
 *   - Public headers never expose `<complex.h>`'s colliding `I` macro.
 *
 * WHEN TO USE complex64 vs complex128:
 *   - `complex64` (8 bytes): large SDR IQ streams, audio/image FFTs, GPU data.
 *   - `complex128` (16 bytes): circuit solvers, control systems, numerical ODEs.
 *
 * ADVANTAGES:
 *   + Clean math expressions and built-in parsing (`cl_str_parse_c64/c128`)
 *     and formatting (`cl_sb_write_c64/c128`).
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Transcendental functions require linking `-lm`.
 *   - Strict IEEE-754 complex division handles NaN/Inf edge cases conservatively
 *     (slightly slower than manual algebra in branchless SIMD inner loops).
 * ============================================================================
 */

#define CL_SHORT_NAMES
#include "cl/cl.h"
#include <stdio.h>

int main(void) {
    printf("=== Example 07: complex64 & complex128 Basics ===\n\n");

    /* 1. Series RLC AC circuit (complex128) */
    f64 R = 50.0, L = 0.010, C = 100e-6, f = 100.0;
    f64 omega = CL_TAU_F64 * f;
    complex128 Z = cl_c128_make(R, omega * L - 1.0 / (omega * C));
    complex128 V = cl_c128_from_polar(120.0, 0.0);
    complex128 I_cur = V / Z;
    complex128 S_pwr = V * cl_c128_conj(I_cur);

    String_Builder sb = {0};
    CL_DEFER_SB(sb);

    cl_sb_write_cstr(&sb, "Impedance Z = ");
    cl_sb_write_c128(&sb, Z, 3);
    cl_sb_write_cstr(&sb, " Ohms\nCurrent   I = ");
    cl_sb_write_c128(&sb, I_cur, 4);
    cl_sb_write_fmt(&sb, " A  (|I|=%.4f A, phase=%.2f deg)\n",
                    cl_c128_abs(I_cur), cl_c128_arg(I_cur) * (180.0 / CL_PI_F64));
    cl_sb_write_fmt(&sb, "Power     S = %.2f W (real) + %.2f VAR (reactive)\n",
                    cl_c128_real(S_pwr), cl_c128_imag(S_pwr));
    printf("%s\n", cl_sb_to_cstr(&sb));

    /* 2. Euler's identity: e^(i*pi) + 1 = 0 */
    complex128 euler = cl_c128_exp(cl_c128_make(0.0, CL_PI_F64)) + cl_c128_make(1.0, 0.0);
    printf("Euler |e^(i*pi) + 1| = %.3e\n", cl_c128_abs(euler));

    /* 3. complex64 IQ rotation and binary float[2] layout verification */
    complex64 iq  = cl_c64_make(1.0f, 0.0f);
    complex64 rot = cl_c64_from_polar(1.0f, CL_PI_F32 / 4.0f); /* 45 deg */
    complex64 out = iq * rot;
    f32 raw_pair[2];
    cl_mem_copy(raw_pair, &out, (isize)sizeof(raw_pair));
    printf("complex64 rotated 45 deg -> float[2] = { %.4f, %.4f }\n",
           (double)raw_pair[0], (double)raw_pair[1]);

    cl_ctx_thread_shutdown();
    return 0;
}
