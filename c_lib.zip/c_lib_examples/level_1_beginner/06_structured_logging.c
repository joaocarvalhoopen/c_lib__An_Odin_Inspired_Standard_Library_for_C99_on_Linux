/*
 * ============================================================================
 * c_lib_examples - Level 1 (Beginner) - Example 06 of 30
 * File: level_1_beginner/06_structured_logging.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Structured pluggable logging (`Cl_Logger`, `CL_LOG_DEBUG..FATAL`, console
 *   auto-color via `isatty`, file logger, `Cl_Multi_Logger` fan-out, and
 *   scoped silencing via `cl_nil_logger()`).
 *
 * WHY USE Cl_Logger INSTEAD OF `printf`/`fprintf(stderr, ...)`:
 *   - Library code logs via `CL_LOG_*` without hardcoding where output goes.
 *   - Applications plug in console, file, multi-sink, or custom loggers via
 *     thread-local `Cl_Context`, with timestamps, severity tags, `file:line`,
 *     thread-safety (`pthread_mutex_t`), and compile-time stripping via
 *     `CL_LOG_MIN_LEVEL`.
 *
 * WHEN TO USE:
 *   - Console logger (`CL_LOG_OPT_AUTO_COLOR`): interactive CLI tools.
 *   - Multi-logger (console + file): services and daemons needing live output
 *     plus persistent warning/error audit files.
 *   - Nil logger (`cl_nil_logger()`): unit tests or noisy third-party steps.
 *
 * ADVANTAGES:
 *   + Zero heap allocations for log lines under 1024 bytes.
 *   + Compile-time stripping (`-DCL_LOG_MIN_LEVEL=2`) eliminates debug logs
 *     with zero runtime overhead in release binaries.
 *   + Thread-safe output prevents interleaved lines across worker threads.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Synchronous I/O (`fprintf` + `fflush`): for ultra-high-frequency logging
 *     (>100k msgs/sec), implement a custom async ring-buffer `Cl_Log_Proc`.
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

int main(void) {
    printf("=== Example 06: Structured Pluggable Logging ===\n\n");

    Cl_Str audit_path = CL_STR("/tmp/c_lib_ex06_audit.log");
    FILE *fp = fopen("/tmp/c_lib_ex06_audit.log", "w");
    CL_ENSURE(fp != NULL);
    CL_DEFER_FILE(fp);

    /* Fan-out logger: INFO+ to console, WARN+ to audit file */
    Cl_Multi_Logger ml;
    cl_multi_logger_init(&ml);
    cl_multi_logger_add(&ml, cl_console_logger(CL_LOG_LEVEL_INFO, CL_LOG_DEFAULT_OPTIONS));
    cl_multi_logger_add(&ml, cl_file_logger(fp, CL_LOG_LEVEL_WARN,
                                            CL_LOG_OPT_LEVEL | CL_LOG_OPT_SHORT_FILE | CL_LOG_OPT_FUNC));

    Cl_Context ctx = cl_ctx_default();
    ctx.logger = cl_multi_logger(&ml, CL_LOG_LEVEL_DEBUG);
    CL_DEFER_CTX_PUSH(ctx);

    CL_LOG_DEBUG("Debug trace (filtered out by both sinks; stripped in release)");
    CL_LOG_INFO("Service initialized (workers=%d, bounds_check=%d)", 4, CL_BOUNDS_CHECK);
    CL_LOG_WARN("Cache miss rate elevated: %.1f%%", 24.5);
    CL_LOG_ERROR("Retrying upstream request #%d", 3);

    /* Temporarily silence logs inside a sub-scope */
    {
        Cl_Context quiet = {0};
        quiet.logger = cl_nil_logger();
        CL_DEFER_CTX_PUSH(quiet);
        CL_LOG_ERROR("Suppressed inside quiet scope!");
    }
    CL_LOG_INFO("Multi-logger automatically restored.");

    /* Inspect what reached the audit file using whole-file read */
    fclose(fp);
    fp = NULL; /* Prevent double close in CL_DEFER_FILE */

    Cl_Res_Str audit = cl_os_read_entire_file_str(audit_path, cl_ctx_temp_allocator());
    if (audit.err == CL_ERR_NONE) {
        printf("\nAudit file contents (WARN+ only):\n" CL_STR_FMT, CL_STR_ARG(audit.value));
    }
    (void)cl_os_remove_file(audit_path);

    cl_ctx_temp_reset();
    cl_ctx_thread_shutdown();
    return 0;
}
