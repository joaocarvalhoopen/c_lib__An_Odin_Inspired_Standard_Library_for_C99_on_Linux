/*
 * ============================================================================
 * c_lib_examples - Level 1 (Beginner) - Example 04 of 30
 * File: level_1_beginner/04_defer_three_tiers.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   All three tiers of `defer` in `c_lib`:
 *     - Tier 1 (Recommended Linux Default): `CL_DEFER_*` via GCC/Clang
 *       `__attribute__((cleanup))` (LIFO, early-return safe, no exec stack).
 *     - Tier 2 (Pure ISO C99 Blocks): `CL_DEFER_LOOP`, `CL_WITH_TEMP`.
 *     - Tier 3 (Pure ISO C99 Stack): `Cl_Defer_Stack` (early-return safe).
 *
 * WHY USE DEFER INSTEAD OF `goto cleanup`:
 *   - Acquiring a resource and writing its cleanup 100 lines later under
 *     nested `goto` labels frequently causes leaks when new early returns
 *     are added during maintenance.
 *   - Putting cleanup right below acquisition guarantees resources are
 *     released in reverse (LIFO) order on every exit path.
 *
 * WHEN TO USE EACH TIER:
 *   - Tier 1 (`CL_DEFER_FREE`, `CL_DEFER_ARENA`, `CL_DEFER_FILE`, `CL_DEFER_FN`):
 *     Default for all Linux GCC/Clang code.
 *   - Tier 2 (`CL_DEFER_LOOP`, `CL_WITH_TEMP`):
 *     Small self-contained scopes with NO `return`/`break`/`goto` inside
 *     (use `continue` if you need an early exit out of a Tier 2 block!).
 *   - Tier 3 (`Cl_Defer_Stack`):
 *     If porting to a strict ISO C99 compiler lacking `__attribute__((cleanup))`.
 *
 * ADVANTAGES:
 *   + Tier 1 has zero runtime overhead and works identically on GCC & Clang.
 *   + Avoids GCC nested functions (which break Clang and risk executable stacks).
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Tier 1 is a GNU/Clang extension (guarded safely by `CL_HAVE_CLEANUP`).
 *   - Tier 2 skips cleanup if you mistakenly `return` or `break` out of it.
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

static void log_cleanup(void *arg) {
    printf("    [defer] releasing: %s\n", (const char *)arg);
}

static int tier1_early_return_demo(bool fail_halfway, Cl_Allocator alloc) {
    void *buf_a = cl_alloc(alloc, 128);
    CL_DEFER_FREE(alloc, buf_a, 128);
    CL_DEFER_FN(log_cleanup, "Resource A");

    if (fail_halfway) {
        printf("  Returning early before acquiring Resource B...\n");
        return -1; /* Automatically frees buf_a and runs Resource A cleanup! */
    }

    void *buf_b = cl_alloc(alloc, 256);
    CL_DEFER_FREE(alloc, buf_b, 256);
    CL_DEFER_FN(log_cleanup, "Resource B");
    return 0;
}

static int tier3_pure_c99_demo(bool fail_halfway) {
    Cl_Defer_Stack ds;
    cl_defer_stack_init(&ds);

    cl_defer_stack_push(&ds, log_cleanup, "Pure-C99 Resource 1");
    if (fail_halfway) {
        CL_DEFER_STACK_RETURN(&ds, -1);
    }
    cl_defer_stack_push(&ds, log_cleanup, "Pure-C99 Resource 2");
    CL_DEFER_STACK_RETURN(&ds, 0);
}

int main(void) {
    printf("=== Example 04: Three Tiers of Defer in C99 ===\n\n");

    Cl_Tracking_Allocator tr;
    cl_tracking_init(&tr, cl_heap_allocator());
    CL_DEFER_TRACKING(tr);
    Cl_Allocator alloc = cl_tracking_allocator(&tr);

    printf("[Tier 1: Early Return]\n");
    (void)tier1_early_return_demo(true, alloc);

    printf("\n[Tier 1: Normal Exit (strict LIFO: B then A)]\n");
    (void)tier1_early_return_demo(false, alloc);

    printf("\n[Tier 2: Pure ISO C99 Structured Block (continue exits safely)]\n");
    CL_DEFER_LOOP(printf("    [begin] entering lock scope\n"),
                  printf("    [end]   exiting lock scope\n")) {
        printf("    working inside scope...\n");
        continue; /* Safe early exit that STILL runs the end expression! */
    }

    printf("\n[Tier 3: Pure ISO C99 Early-Return Defer Stack]\n");
    (void)tier3_pure_c99_demo(false);

    CL_ENSURE(cl_tracking_is_clean(&tr));
    printf("\nVerified 0 leaked bytes across all defer tiers.\n");
    cl_ctx_thread_shutdown();
    return 0;
}
