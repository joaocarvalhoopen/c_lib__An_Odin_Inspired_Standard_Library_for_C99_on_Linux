/*
 * ============================================================================
 * c_lib_examples - Level 1 (Beginner) - Example 10 of 30
 * File: level_1_beginner/10_whole_file_read_write_and_time.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Whole-file Linux filesystem I/O (`cl_os_read_entire_file`,
 *   `cl_os_read_entire_file_str`, `cl_os_write_entire_file_str`,
 *   `cl_os_write_entire_file_atomic`, reading `/proc/version`), environment
 *   lookups (`cl_os_env_get`), and monotonic timing (`Cl_Stopwatch`).
 *
 * WHY READ & WRITE WHOLE FILES AT ONCE:
 *   - 90% of configuration, source, JSON, CSV, and asset files fit comfortably
 *     in RAM. Reading an entire file into a single contiguous buffer in ONE
 *     call makes parsing vastly simpler (every parsed token is a zero-copy
 *     `Cl_Str` view into that buffer!) and avoids fragile partial `fgets()`
 *     line-buffer truncation bugs.
 *   - `cl_os_write_entire_file_atomic()` writes to a temp file, calls
 *     `fsync()`, and atomically `rename()`s it into place so crashes mid-write
 *     never corrupt existing config/state files.
 *
 * WHEN TO USE:
 *   - Regular files under ~100 MiB and Linux virtual files (`/proc/version`).
 *   - Use `cl_os_write_entire_file_atomic()` for critical state/config files.
 *
 * ADVANTAGES:
 *   + Single allocation for regular files (sized directly via `fstat`).
 *   + Automatic chunked fallback for Linux `/proc` files where `st_size == 0`.
 *   + Typed `Cl_Res_Bytes` / `Cl_Res_Str` returns (never silent `NULL`).
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Not intended for multi-gigabyte streaming logs or infinite pipes (use
 *     POSIX `open`/`read`/`write` or `mmap` for streaming huge datasets).
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

int main(void) {
    printf("=== Example 10: Whole-File Read/Write & Monotonic Stopwatch ===\n\n");

    Cl_Tracking_Allocator tr;
    cl_tracking_init(&tr, cl_heap_allocator());
    CL_DEFER_TRACKING(tr);
    Cl_Allocator alloc = cl_tracking_allocator(&tr);

    Cl_Stopwatch sw = {0};
    cl_stopwatch_start(&sw);

    /* 1. Write an entire text file at once */
    Cl_Str path = CL_STR("/tmp/c_lib_ex10_demo.txt");
    Cl_Str body = CL_STR("Whole-file I/O in c_lib!\nZero partial fgets bugs.\n");
    CL_ENSURE(cl_os_write_entire_file_str(path, body) == CL_ERR_NONE);

    /* 2. Read the entire file back in one call */
    Cl_Res_Str loaded = cl_os_read_entire_file_str(path, alloc);
    CL_ENSURE(loaded.err == CL_ERR_NONE);
    printf("Read %lld bytes from " CL_STR_FMT ":\n" CL_STR_FMT "\n",
           (CL_LL)loaded.value.len, CL_STR_ARG(path), CL_STR_ARG(loaded.value));
    cl_str_free(loaded.value, alloc);

    /* 3. Crash-safe atomic replacement (write temp + fsync + rename) */
    Cl_Str updated = CL_STR("Atomically replaced content (fsync + rename).\n");
    Cl_Bytes updated_bytes = { (cl_u8 *)(cl_uintptr)updated.data, updated.len };
    CL_ENSURE(cl_os_write_entire_file_atomic(path, updated_bytes) == CL_ERR_NONE);

    Cl_Res_Str reloaded = cl_os_read_entire_file_str(path, alloc);
    CL_ENSURE(reloaded.err == CL_ERR_NONE);
    printf("After atomic write: " CL_STR_FMT, CL_STR_ARG(reloaded.value));
    cl_str_free(reloaded.value, alloc);
    (void)cl_os_remove_file(path);

    /* 4. Read a Linux virtual /proc file (st_size == 0 handled automatically!) */
    if (cl_os_file_exists(CL_STR("/proc/version"))) {
        Cl_Res_Str ver = cl_os_read_entire_file_str(CL_STR("/proc/version"), alloc);
        if (ver.err == CL_ERR_NONE) {
            Cl_Str first_line = cl_str_trim_space(ver.value);
            if (first_line.len > 64) {
                first_line = cl_str_slice(first_line, 0, 64);
            }
            printf("Linux /proc/version : " CL_STR_FMT "...\n", CL_STR_ARG(first_line));
            cl_str_free(ver.value, alloc);
        }
    }

    /* 5. Environment variable lookup */
    Cl_Str user = CL_OR_ELSE(cl_os_env_get(CL_STR("USER")), CL_STR("<unset>"));
    cl_stopwatch_stop(&sw);
    printf("USER env            : " CL_STR_FMT "\n", CL_STR_ARG(user));
    printf("Total elapsed time  : %.3f ms\n", cl_stopwatch_elapsed_ms(&sw));

    CL_ENSURE(cl_tracking_is_clean(&tr));
    cl_ctx_thread_shutdown();
    return 0;
}
