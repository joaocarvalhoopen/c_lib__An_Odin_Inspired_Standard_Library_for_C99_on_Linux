/*
 * ============================================================================
 * c_lib_examples - Level 1 (Beginner) - Example 03 of 30
 * File: level_1_beginner/03_slices_and_bounds_checking.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Typed slices (`Cl_Slice_*`, `CL_SLICE_DEFINE`), zero-copy sub-slicing
 *   (`CL_SLICE_SUB`), sorting, binary search, reversing, cloning, and
 *   toggleable development-time bounds checking (`CL_BOUNDS_CHECK`).
 *
 * WHY USE SLICES INSTEAD OF `(T *ptr, size_t len)`:
 *   - Bundling pointer + length into one value prevents mismatches where the
 *     wrong length is paired with a pointer or lost across function calls.
 *   - `CL_SLICE_AT(s, i)` and `CL_SLICE_SUB(s, lo, hi)` validate indices in
 *     debug builds (`-DCL_BOUNDS_CHECK=1`, using GCC `__builtin_expect` +
 *     `__builtin_trap`) and compile away to ZERO instructions in release
 *     builds (`-DCL_BOUNDS_CHECK=0`).
 *
 * WHEN TO USE:
 *   - Prefer slices as function parameters whenever a function reads or
 *     mutates a contiguous sequence of elements (regardless of whether the
 *     backing memory is a C array, arena, dynamic array, or heap slice).
 *
 * ADVANTAGES:
 *   + Works uniformly on stack arrays, heap buffers, and dynamic array views.
 *   + O(1) sub-slicing (`s[lo:hi]`) with zero copying.
 *   + Catches off-by-one and negative-index bugs immediately during testing.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Slices do NOT own memory and cannot grow (use `Cl_DA_*` when growth
 *     is needed, then pass `CL_DA_AS_SLICE(...)` to slice-accepting functions).
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

static void print_i32_slice(const char *label, Cl_Slice_I32 s) {
    printf("  %-18s [len=%lld]: ", label, (CL_LL)s.len);
    CL_SLICE_FOR_EACH(i, s) {
        printf("%d ", CL_SLICE_AT(s, i));
    }
    printf("\n");
}

int main(void) {
    printf("=== Example 03: Slices & Toggleable Bounds Checking ===\n\n");
    printf("Compile-time CL_BOUNDS_CHECK = %d\n\n", CL_BOUNDS_CHECK);

    cl_i32 raw[] = { 42, 15, 88, 7, 63, 29, 91, 34 };
    Cl_Slice_I32 nums = CL_SLICE_FROM_ARRAY(Cl_Slice_I32, raw);
    print_i32_slice("Original", nums);

    /* Zero-copy sub-slice nums[2:6] -> { 88, 7, 63, 29 } */
    Cl_Slice_I32 window = CL_SLICE_SUB(nums, 2, 6);
    print_i32_slice("Sub-slice [2:6]", window);

    /* Mutating a sub-slice modifies the backing array directly */
    CL_SLICE_AT(window, 0) = 50;
    print_i32_slice("After window[0]=50", nums);

    /* Sort, binary search, and reverse in place */
    CL_SLICE_SORT(nums, cl_cmp_i32);
    print_i32_slice("Sorted ascending", nums);

    cl_i32 target = 63;
    cl_isize idx = CL_SLICE_BSEARCH(nums, &target, cl_cmp_i32);
    printf("  Binary search 63   : found at index %lld\n", (CL_LL)idx);

    CL_SLICE_REVERSE(nums);
    print_i32_slice("Reversed", nums);

    /* Allocate a heap clone, verify equality, fill, and release */
    Cl_Allocator alloc = cl_ctx_allocator();
    Cl_Slice_I32 copy = CL_SLICE_CLONE(Cl_Slice_I32, alloc, nums);
    CL_ENSURE(CL_SLICE_EQUAL(nums, copy));
    CL_SLICE_FILL(copy, 9);
    print_i32_slice("Filled clone", copy);
    CL_SLICE_FREE(alloc, copy);

    cl_ctx_thread_shutdown();
    return 0;
}
