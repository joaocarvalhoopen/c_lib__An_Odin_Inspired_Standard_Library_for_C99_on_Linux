/*
 * ============================================================================
 * c_lib_examples - Level 1 (Beginner) - Example 08 of 30
 * File: level_1_beginner/08_string_manipulation_and_iterators.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Odin-style string manipulation (`core:strings`): zero-allocation views
 *   (`cut`, `trim_*`, `has_prefix/suffix`, `count`, `index`, `split_iter`,
 *   `split_lines_iter`, `fields_iter`) and allocating transformations
 *   (`split`, `join`, `repeat`, `replace_all`, `to_upper`, `pad_left`).
 *
 * WHY SEPARATE ZERO-ALLOCATION ITERATORS FROM ALLOCATING TRANSFORMS:
 *   - Most parsing tasks only need to inspect tokens without creating new
 *     strings. `cl_str_split_iter` / `cl_str_fields_iter` / `cl_str_cut` do
 *     ZERO heap allocations and mutate only a 16-byte cursor struct on stack.
 *   - When you genuinely need a new string (`join`, `replace_all`, `to_upper`),
 *     passing an explicit `Cl_Allocator` lets you route it to an Arena or
 *     temp allocator so cleanup stays O(1).
 *
 * WHEN TO USE:
 *   - Prefer `cl_str_cut` + `split_iter` for parsing URLs, headers, CSV, logs.
 *   - Use `cl_str_replace_all` / `cl_str_join` with `cl_ctx_temp_allocator()`
 *     for transient display strings, or an owned allocator for persistent data.
 *
 * ADVANTAGES:
 *   + Eliminates destructive `strtok()` (which mutates input & isn't reentrant).
 *   + Composable pipeline style identical to Odin's `core:strings`.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - `cl_str_to_upper`/`cl_str_to_lower` are ASCII-focused (full Unicode
 *     locale case-folding requires ICU/Unicode tables outside a tiny C99 lib).
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>

int main(void) {
    printf("=== Example 08: String Manipulation & Zero-Alloc Iterators ===\n\n");

    /* 1. Zero-allocation URL/query parsing using cl_str_cut + trim_prefix */
    Cl_Str url = CL_STR("https://api.example.com/v1/items?sort=price&limit=25");
    Cl_Str no_scheme = cl_str_trim_prefix(url, CL_STR("https://"));
    Cl_Str_Cut host_rest = cl_str_cut(no_scheme, CL_STR("/"));
    Cl_Str_Cut path_query = cl_str_cut(host_rest.after, CL_STR("?"));

    printf("Host  : " CL_STR_FMT "\n", CL_STR_ARG(host_rest.before));
    printf("Path  : /" CL_STR_FMT "\n", CL_STR_ARG(path_query.before));
    printf("Query parameters (zero heap allocations):\n");

    Cl_Str q = path_query.after;
    for (;;) {
        Cl_Str pair;
        CL_OPT_OR_BREAK(pair, cl_str_split_iter(&q, CL_STR("&")));
        Cl_Str_Cut kv = cl_str_cut(pair, CL_STR("="));
        printf("  " CL_STR_FMT " = " CL_STR_FMT "\n", CL_STR_ARG(kv.before), CL_STR_ARG(kv.after));
    }

    /* 2. Zero-alloc whitespace field tokenization */
    Cl_Str line = CL_STR("   alpha\t\tbeta   gamma  ");
    printf("\nFields: ");
    for (;;) {
        Cl_Str tok;
        CL_OPT_OR_BREAK(tok, cl_str_fields_iter(&line));
        printf("[" CL_STR_FMT "] ", CL_STR_ARG(tok));
    }
    printf("\n");

    /* 3. Allocating transformations routed into temp_allocator (0 manual frees!) */
    Cl_Allocator tmp = cl_ctx_temp_allocator();
    Cl_Slice_Str parts = cl_str_split(CL_STR("red,green,blue"), CL_STR(","), tmp);
    Cl_Str joined   = cl_str_join(parts, CL_STR(" | "), tmp);
    Cl_Str replaced = cl_str_replace_all(joined, CL_STR("green"), CL_STR("emerald"), tmp);
    Cl_Str upper    = cl_str_to_upper(replaced, tmp);
    Cl_Str banner   = cl_str_repeat(CL_STR("-="), 12, tmp);
    Cl_Str padded   = cl_str_pad_left(CL_STR("42"), 6, '0', tmp);

    printf("\nTransformed (temp_allocator):\n");
    printf("  " CL_STR_FMT "\n", CL_STR_ARG(banner));
    printf("  Upper  : " CL_STR_FMT "\n", CL_STR_ARG(upper));
    printf("  Padded : " CL_STR_FMT "\n", CL_STR_ARG(padded));

    cl_ctx_temp_reset();
    cl_ctx_thread_shutdown();
    return 0;
}
