/*
 * ============================================================================
 * c_lib_examples - Level 1 (Beginner) - Example 02 of 30
 * File: level_1_beginner/02_strings_basics_and_cstr_interop.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Topic:
 *   Odin-style length-prefixed strings (`Cl_Str`), compile-time `CL_STR()`,
 *   safe formatting (`CL_STR_FMT`/`CL_STR_ARG`), embedded NUL bytes, and all
 *   three conversion strategies to standard C NUL-terminated strings (`char *`).
 *
 * WHY USE Cl_Str INSTEAD OF `const char *`:
 *   - `strlen()` is O(n) and cannot represent binary/embedded-NUL text.
 *   - Substring extraction in raw C requires copying or mutating the buffer
 *     with `'\0'`. `Cl_Str` carries `{ data, len }`, making length and
 *     substrings O(1) and zero-copy.
 *
 * WHEN TO USE EACH C-STRING CONVERSION:
 *   1. `cl_str_to_cstr_buf(s, stack_buf, cap)` -> Best when max size is small
 *      and bounded (e.g., file paths < 256 bytes): ZERO heap allocations.
 *   2. `cl_str_to_cstr_temp(s)` -> Best for one-shot POSIX/libc calls
 *      (`fopen`, `getenv`, `system`): O(1) scratch alloc, wiped on reset.
 *   3. `cl_str_to_cstr(s, alloc)` -> Best when the C string must outlive the
 *      current scope (caller frees with `cl_cstr_free(cs, s.len, alloc)`).
 *
 * ADVANTAGES:
 *   + O(1) length, O(1) zero-copy slicing, safe embedded NULs.
 *   + Explicit ownership: you always know whether a C string lives on the
 *     stack, temp arena, or heap.
 *
 * DISADVANTAGES / TRADE-OFFS:
 *   - Never pass `s.data` directly to `printf("%s", ...)` because `Cl_Str`
 *     views are not guaranteed NUL-terminated. Always use `CL_STR_FMT`.
 * ============================================================================
 */

#include "cl/cl.h"
#include <stdio.h>
#include <string.h>

int main(void) {
    printf("=== Example 02: Strings Basics & C-String Interop ===\n\n");

    Cl_Tracking_Allocator tracker;
    cl_tracking_init(&tracker, cl_heap_allocator());
    CL_DEFER_TRACKING(tracker);
    Cl_Allocator alloc = cl_tracking_allocator(&tracker);

    /* 1. Compile-time string literal (length computed by sizeof at compile time) */
    Cl_Str full = CL_STR("Odin-style strings in C99");
    Cl_Str sub  = cl_str_slice(full, 0, 10); /* Zero-copy view: "Odin-style" */

    printf("Full : '" CL_STR_FMT "' (len=%lld)\n", CL_STR_ARG(full), (CL_LL)full.len);
    printf("Sub  : '" CL_STR_FMT "' (len=%lld)\n\n", CL_STR_ARG(sub), (CL_LL)sub.len);

    /* 2. Conversion A: Zero-allocation fixed stack buffer */
    char stack_buf[16];
    Cl_CStr_Buf_Res bres = cl_str_to_cstr_buf(sub, stack_buf, CL_ARRAY_LEN(stack_buf));
    printf("[A] Stack buffer : \"%s\" (written=%lld, truncated=%s)\n",
           stack_buf, (CL_LL)bres.written, bres.truncated ? "yes" : "no");

    /* 3. Conversion B: Temp allocator (no manual free needed!) */
    char *temp_cs = cl_str_to_cstr_temp(full);
    printf("[B] Temp cstring : \"%s\" (strlen=%zu)\n", temp_cs, strlen(temp_cs));
    cl_ctx_temp_reset();

    /* 4. Conversion C: Long-lived owned C string via explicit allocator */
    char *owned_cs = cl_str_to_cstr(sub, alloc);
    printf("[C] Owned cstr   : \"%s\"\n", owned_cs);
    cl_cstr_free(owned_cs, sub.len, alloc);

    /* 5. Embedded NUL safety: Cl_Str preserves full length past '\0' */
    const cl_u8 raw_bytes[7] = { 'A', 'B', '\0', 'C', 'D', '\0', 'E' };
    Cl_Str binary_str = cl_str_from_parts(raw_bytes, 7);
    printf("\nBinary Cl_Str len = %lld (byte[0]=%c, byte[2]=0x%02X, byte[6]=%c)\n",
           (CL_LL)binary_str.len,
           (char)cl_str_at(binary_str, 0),
           (unsigned)cl_str_at(binary_str, 2),
           (char)cl_str_at(binary_str, 6));

    CL_ENSURE(cl_tracking_is_clean(&tracker));
    cl_ctx_thread_shutdown();
    return 0;
}
