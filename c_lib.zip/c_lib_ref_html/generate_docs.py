#!/usr/bin/env python3
"""
===============================================================================
c_lib_ref_html - Zero-Dependency Odin-Style HTML Reference Documentation Generator
File: generate_docs.py
License: MIT Open Source License (see LICENSE file)
SPDX-License-Identifier: MIT
Copyright (c) 2026 Joao Carvalho

Purpose:
  Parses every C99 header (.h) and implementation (.c) file in `../c_lib`,
  extracts all structs, enums, typedefs, macros, and functions (including
  macro-generated slices, dynamic arrays, hash maps, optionals, and results)
  along with their complete English descriptions, parameters, data types,
  units, and return values, and also indexes all 30 progressive examples in
  `../c_lib_examples`.

Outputs:
  - index.html      : Interactive Odin-inspired reference documentation with:
                        * Top-bar API fuzzy search (structs/enums/typedefs/macros/funcs)
                        * Dedicated Examples section (#examples) with its own
                          separate fuzzy search across all 30 examples (title,
                          topic, pros/cons docs, and referenced c_lib APIs)
                        * Quick links to every one of the 30 examples (in the
                          sidebar, on the overview page, on #examples, and as
                          related-example chips on each module page)
                        * Easy navigation for (.h + .c) pairs vs single .h files
                        * Dark Mode & Light Mode toggle
  - src/*.html      : Dark-mode (default) syntax-highlighted C99 viewers for
                      every .h and .c file with exact #L<line> anchors and
                      1-click .h <-> .c switching.
  - examples/*.html : Dark-mode (default) syntax-highlighted C99 viewers for
                      every one of the 30 examples with Prev/Next navigation.

Dependencies:
  Python 3 standard library ONLY (zero external packages, zero CDNs, works
  100% offline via file:// or any local HTTP server).

Usage:
  python3 c_lib_ref_html/generate_docs.py
  # or from repository root:
  make docs
===============================================================================
"""

import argparse
import datetime
import html
import json
import re
from pathlib import Path


# -----------------------------------------------------------------------------
# Logical Module Grouping (Modeled After pkg.odin-lang.org Categories)
# -----------------------------------------------------------------------------

MODULE_GROUPS = [
    ("Core & Types", [
        "cl", "cl_config", "cl_types", "cl_complex", "cl_short",
    ]),
    ("Safety, Defer & Control Flow", [
        "cl_assert", "cl_defer", "cl_result",
    ]),
    ("Memory & Allocators", [
        "cl_mem", "cl_alloc", "cl_arena", "cl_virtual_arena",
        "cl_pool", "cl_tracking_alloc", "cl_context",
    ]),
    ("Containers", [
        "cl_slice", "cl_array", "cl_hash", "cl_map",
    ]),
    ("Strings & UTF-8", [
        "cl_utf8", "cl_string", "cl_string_builder", "cl_strbuf",
    ]),
    ("Logging & Linux OS", [
        "cl_log", "cl_os",
    ]),
]

EXAMPLE_LEVEL_META = {
    "level_1_beginner":     ("Level 1: Beginner",     "beginner",     1),
    "level_2_intermediate": ("Level 2: Intermediate", "intermediate", 2),
    "level_3_advanced":     ("Level 3: Advanced",     "advanced",     3),
}


# -----------------------------------------------------------------------------
# Zero-Dependency C99 Syntax Highlighter
# -----------------------------------------------------------------------------

C99_KEYWORDS = {
    "auto", "break", "case", "const", "continue", "default", "do", "else",
    "enum", "extern", "for", "goto", "if", "inline", "register", "restrict",
    "return", "sizeof", "static", "struct", "switch", "typedef", "union",
    "volatile", "while", "_Bool", "_Complex", "_Imaginary", "bool", "true",
    "false", "NULL", "__extension__", "__attribute__", "__typeof__",
    "__alignof__", "__thread",
}

C99_BUILTIN_TYPES = {
    "void", "char", "short", "int", "long", "float", "double", "signed",
    "unsigned", "size_t", "ssize_t", "ptrdiff_t", "uintptr_t", "intptr_t",
    "int8_t", "int16_t", "int32_t", "int64_t", "uint8_t", "uint16_t",
    "uint32_t", "uint64_t", "FILE", "va_list", "time_t", "pid_t",
    "pthread_mutex_t",
    "cl_i8", "cl_i16", "cl_i32", "cl_i64",
    "cl_u8", "cl_u16", "cl_u32", "cl_u64",
    "cl_isize", "cl_usize", "cl_uintptr",
    "cl_f32", "cl_f64", "cl_b8", "cl_b32",
    "cl_byte", "cl_rune", "cl_rawptr",
    "cl_c64", "cl_c128",
    "i8", "i16", "i32", "i64", "u8", "u16", "u32", "u64",
    "isize", "usize", "uintptr", "f32", "f64", "b8", "b32",
    "byte", "rune", "rawptr", "c64", "c128", "complex64", "complex128",
}

TOKEN_RE = re.compile(
    r"(?P<block_com>/\*[\s\S]*?\*/)"
    r"|(?P<line_com>//[^\n]*)"
    r"|(?P<string>\"(?:\\.|[^\"\\\n])*\")"
    r"|(?P<char>'(?:\\.|[^'\\\n])*')"
    r"|(?P<preproc>^[ \t]*#[ \t]*[a-zA-Z_]\w*)"
    r"|(?P<num>\b(?:0[xX][0-9a-fA-F]+[uUlL]*|0[bB][01]+[uUlL]*|[0-9]+(?:\.[0-9]*)?(?:[eE][+-]?[0-9]+)?[fFlLuU]*)\b)"
    r"|(?P<ident>\b[A-Za-z_][A-Za-z0-9_]*\b)",
    re.MULTILINE,
)


def classify_ident(word, next_non_ws):
    if word in C99_KEYWORDS:
        return "tok-kw"
    if word in C99_BUILTIN_TYPES or re.match(r"^Cl_[A-Z]", word):
        return "tok-type"
    if (len(word) >= 2 and word.isupper() and "_" in word) or word.startswith("CL_"):
        return "tok-macro"
    if next_non_ws == "(":
        return "tok-fn"
    return None


def highlight_c_code(code):
    """Return syntax-highlighted HTML for a C99 code snippet."""
    out = []
    pos = 0
    n = len(code)
    for m in TOKEN_RE.finditer(code):
        if m.start() > pos:
            out.append(html.escape(code[pos:m.start()]))
        kind = m.lastgroup
        text = m.group(0)
        esc = html.escape(text)
        if kind in ("block_com", "line_com"):
            out.append(f'<span class="tok-com">{esc}</span>')
        elif kind in ("string", "char"):
            out.append(f'<span class="tok-str">{esc}</span>')
        elif kind == "preproc":
            out.append(f'<span class="tok-pp">{esc}</span>')
        elif kind == "num":
            out.append(f'<span class="tok-num">{esc}</span>')
        elif kind == "ident":
            j = m.end()
            while j < n and code[j] in " \t":
                j += 1
            nxt = code[j] if j < n else ""
            cls = classify_ident(text, nxt)
            if cls:
                out.append(f'<span class="{cls}">{esc}</span>')
            else:
                out.append(esc)
        else:
            out.append(esc)
        pos = m.end()
    if pos < n:
        out.append(html.escape(code[pos:]))
    return "".join(out)


def highlight_c_lines(code):
    """
    Syntax-highlight a full C99 source file and return a list of HTML strings
    (one per physical line) with balanced <span> tags across multi-line comments.
    """
    per_line = [[]]
    pos = 0
    n = len(code)

    def push_text(raw_text, css_class=None):
        parts = raw_text.split("\n")
        for idx, part in enumerate(parts):
            if idx > 0:
                per_line.append([])
            if part:
                esc = html.escape(part)
                if css_class:
                    per_line[-1].append(f'<span class="{css_class}">{esc}</span>')
                else:
                    per_line[-1].append(esc)

    for m in TOKEN_RE.finditer(code):
        if m.start() > pos:
            push_text(code[pos:m.start()], None)
        kind = m.lastgroup
        text = m.group(0)
        if kind in ("block_com", "line_com"):
            push_text(text, "tok-com")
        elif kind in ("string", "char"):
            push_text(text, "tok-str")
        elif kind == "preproc":
            push_text(text, "tok-pp")
        elif kind == "num":
            push_text(text, "tok-num")
        elif kind == "ident":
            j = m.end()
            while j < n and code[j] in " \t":
                j += 1
            nxt = code[j] if j < n else ""
            push_text(text, classify_ident(text, nxt))
        else:
            push_text(text, None)
        pos = m.end()

    if pos < n:
        push_text(code[pos:], None)

    return ["".join(chunks) for chunks in per_line]


# -----------------------------------------------------------------------------
# Pure-Python C99 Header, Source, and Example Parser
# -----------------------------------------------------------------------------

def clean_doc_comment(raw):
    """Strip /* */, //, leading '*', and decorative separator bars from a comment."""
    if not raw:
        return ""
    text = raw.strip()
    if text.startswith("/*"):
        text = text[2:]
        if text.endswith("*/"):
            text = text[:-2]
        cleaned_lines = []
        for ln in text.splitlines():
            s = ln.strip()
            if s.startswith("*"):
                s = s[1:]
                if s.startswith(" "):
                    s = s[1:]
            if re.match(r"^[=\-~*]{6,}$", s.strip()):
                continue
            cleaned_lines.append(s.rstrip())
        return "\n".join(cleaned_lines).strip()
    if text.startswith("//"):
        lines = []
        for ln in text.splitlines():
            s = ln.strip()
            if s.startswith("//"):
                s = s[2:].lstrip()
            lines.append(s)
        return "\n".join(lines).strip()
    return text


def extract_file_doc(source):
    """Extract the top-of-file documentation block comment."""
    m = re.match(r"\s*/\*([\s\S]*?)\*/", source)
    if not m:
        return ""
    lines = []
    for ln in m.group(1).splitlines():
        s = ln.strip()
        if s.startswith("*"):
            s = s[1:]
            if s.startswith(" "):
                s = s[1:]
        if re.match(r"^[=\-]{6,}$", s.strip()):
            continue
        if re.match(r"^(c_lib - |c_lib_examples - |File:\s*)", s.strip()):
            continue
        lines.append(s.rstrip())
    return "\n".join(lines).strip()


def extract_inline_comment(line):
    m = re.search(r"/\*(.*?)\*/\s*$", line)
    if m:
        return m.group(1).strip()
    m = re.search(r"//(.*)$", line)
    if m:
        return m.group(1).strip()
    return ""


def strip_comments_preserving_lines(text):
    def repl(m):
        if m.group(0).startswith(("\"", "'")):
            return m.group(0)
        return re.sub(r"[^\n]", " ", m.group(0))
    return re.sub(
        r"\"(?:\\.|[^\"\\\n])*\"|'(?:\\.|[^'\\\n])*'|/\*[\s\S]*?\*/|//[^\n]*",
        repl,
        text,
    )


def find_c_implementations(c_source):
    """Scan a `.c` file for non-static function definitions -> { name: line_no }."""
    impls = {}
    cleaned = strip_comments_preserving_lines(c_source)
    lines = cleaned.splitlines()
    n = len(lines)
    depth = 0
    i = 0

    while i < n:
        line = lines[i]
        stripped = line.strip()

        if depth == 0 and stripped and not stripped.startswith("#"):
            if not re.match(r"^(static|typedef|enum|struct|union)\b", stripped):
                start_line = i + 1
                buf = [line]
                j = i
                found_brace = False
                while j < n:
                    if "{" in lines[j]:
                        found_brace = True
                        break
                    if ";" in lines[j]:
                        break
                    j += 1
                    if j < n:
                        buf.append(lines[j])
                if found_brace:
                    header = " ".join(x.strip() for x in buf)
                    before_brace = header.split("{", 1)[0].strip()
                    before_brace_clean = re.sub(r"\bCL_PRINTF_LIKE\s*\([^)]*\)", "", before_brace)
                    m = re.search(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(", before_brace_clean)
                    if m:
                        fn_name = m.group(1)
                        if fn_name not in C99_KEYWORDS and not fn_name.startswith("CL_"):
                            impls.setdefault(fn_name, start_line)

        depth += line.count("{") - line.count("}")
        if depth < 0:
            depth = 0
        i += 1

    return impls


def expand_generator_macro(line, line_no, doc):
    """Detect CL_SLICE_DEFINE / CL_DA_DEFINE / CL_MAP_DEFINE / CL_OPT_DEFINE / CL_RES_DEFINE."""
    m = re.match(r"^(CL_(?:SLICE|DA|MAP|QUEUE|OPT|RES|PAIR|TUPLE3)_DEFINE)\s*\(([^)]+)\)\s*;", line.strip())
    if not m:
        return None
    macro_name = m.group(1)
    args = [a.strip() for a in m.group(2).split(",")]
    if not args:
        return None
    type_name = args[0]

    if macro_name == "CL_SLICE_DEFINE" and len(args) == 2:
        T = args[1]
        sig = f"typedef struct {type_name} {{\n    {T} *data;\n    cl_isize len;\n}} {type_name};"
        auto_doc = f"Pre-defined typed slice of `{T}` (length in elements; generated via `{macro_name}({type_name}, {T})`)."
    elif macro_name == "CL_DA_DEFINE" and len(args) == 2:
        T = args[1]
        sig = (f"typedef struct {type_name} {{\n    {T} *data;\n    cl_isize len;\n"
               f"    cl_isize cap;\n    Cl_Allocator allocator;\n}} {type_name};")
        auto_doc = f"Pre-defined dynamic array of `{T}` (`len` and `cap` in elements; generated via `{macro_name}`)."
    elif macro_name == "CL_QUEUE_DEFINE" and len(args) == 2:
        T = args[1]
        sig = (f"typedef struct {type_name} {{\n    {T} *data;\n    cl_isize head;\n"
               f"    cl_isize len;\n    cl_isize cap;\n    Cl_Allocator allocator;\n}} {type_name};")
        auto_doc = f"Pre-defined circular ring queue of `{T}` (`head`, `len`, `cap` in elements; generated via `{macro_name}`)."
    elif macro_name == "CL_MAP_DEFINE" and len(args) == 3:
        K, V = args[1], args[2]
        sig = (f"typedef struct {type_name} {{\n    Cl_Map_Header hdr;\n"
               f"    {K} *keys;\n    {V} *values;\n}} {type_name};")
        auto_doc = f"Pre-defined HashMap mapping `{K}` -> `{V}` (generated via `{macro_name}`)."
    elif macro_name == "CL_OPT_DEFINE" and len(args) == 2:
        T = args[1]
        sig = f"typedef struct {type_name} {{\n    {T} value;\n    bool ok;\n}} {type_name};"
        auto_doc = f"Pre-defined optional return struct `({T}, bool)` (generated via `{macro_name}`)."
    elif macro_name == "CL_RES_DEFINE" and len(args) == 3:
        T, E = args[1], args[2]
        sig = f"typedef struct {type_name} {{\n    {T} value;\n    {E} err;\n}} {type_name};"
        auto_doc = f"Pre-defined result return struct `({T}, {E})` where `err == 0` means success (generated via `{macro_name}`)."
    else:
        sig = line.strip()
        auto_doc = f"Generated via `{macro_name}`."

    final_doc = (doc + "\n\n" + auto_doc).strip() if doc else auto_doc
    return {
        "name": type_name,
        "kind": "struct",
        "line": line_no,
        "signature": sig,
        "doc": final_doc,
        "generated_by": macro_name,
    }


def parse_header(h_path, c_impls):
    """Parse a C99 header file into (file_doc, includes, symbols)."""
    source = h_path.read_text(encoding="utf-8")
    lines = source.splitlines()
    n = len(lines)

    file_doc = extract_file_doc(source)
    guard_name = None
    includes = []
    symbols = []
    seen_keys = set()

    def add_symbol(sym):
        key = (sym["kind"], sym["name"])
        if key in seen_keys:
            return
        seen_keys.add(key)
        if sym["kind"] == "func" and sym["name"] in c_impls:
            sym["impl_line"] = c_impls[sym["name"]]
        symbols.append(sym)

    i = 0
    while i < n and not lines[i].strip():
        i += 1
    if i < n and lines[i].strip().startswith("/*"):
        while i < n and "*/" not in lines[i]:
            i += 1
        i += 1

    pending_doc = ""
    pending_doc_end = -10

    while i < n:
        raw = lines[i]
        stripped = raw.strip()

        if not stripped:
            if i - pending_doc_end > 2:
                pending_doc = ""
            i += 1
            continue

        if stripped.startswith("/*"):
            buf = [raw]
            while "*/" not in lines[i] and i + 1 < n:
                i += 1
                buf.append(lines[i])
            pending_doc = clean_doc_comment("\n".join(buf))
            pending_doc_end = i
            i += 1
            continue

        if stripped.startswith("//"):
            buf = [raw]
            while i + 1 < n and lines[i + 1].strip().startswith("//"):
                i += 1
                buf.append(lines[i])
            pending_doc = clean_doc_comment("\n".join(buf))
            pending_doc_end = i
            i += 1
            continue

        m_ifndef = re.match(r"^#\s*ifndef\s+([A-Z0-9_]+_H)\b", stripped)
        if m_ifndef and guard_name is None:
            guard_name = m_ifndef.group(1)
            pending_doc = ""
            i += 1
            continue

        m_inc = re.match(r'^#\s*include\s+"([^"]+\.h)"', stripped)
        if m_inc:
            inc_name = Path(m_inc.group(1)).stem
            if inc_name not in includes:
                includes.append(inc_name)
            pending_doc = ""
            i += 1
            continue

        m_undef = re.match(r"^#\s*undef\s+([A-Za-z_][A-Za-z0-9_]*)\b", stripped)
        if m_undef:
            uname = m_undef.group(1)
            key = ("macro", uname)
            if key in seen_keys:
                seen_keys.remove(key)
                symbols = [s for s in symbols if not (s["kind"] == "macro" and s["name"] == uname)]
            i += 1
            continue

        m_def = re.match(r"^#\s*define\s+([A-Za-z_][A-Za-z0-9_]*)(\([^)]*\))?(.*)", stripped)
        if m_def:
            start_line = i + 1
            name = m_def.group(1)
            raw_lines = [raw.rstrip()]
            while raw_lines[-1].endswith("\\") and i + 1 < n:
                i += 1
                raw_lines.append(lines[i].rstrip())
            if name != guard_name and not name.endswith("_IMPL"):
                inline_doc = extract_inline_comment(raw_lines[0]) if len(raw_lines) == 1 else ""
                doc = pending_doc or inline_doc
                sig_lines = [ln.lstrip() if idx == 0 else ln for idx, ln in enumerate(raw_lines)]
                add_symbol({
                    "name": name,
                    "kind": "macro",
                    "line": start_line,
                    "signature": "\n".join(sig_lines),
                    "doc": doc,
                })
            pending_doc = ""
            i += 1
            continue

        if stripped.startswith("#"):
            if re.match(r"^#\s*(include|endif|undef)\b", stripped):
                pending_doc = ""
            i += 1
            continue

        if stripped.startswith("CL_STATIC_ASSERT"):
            while ";" not in lines[i] and i + 1 < n:
                i += 1
            pending_doc = ""
            i += 1
            continue

        gen_sym = expand_generator_macro(stripped, i + 1, pending_doc)
        if gen_sym is not None:
            add_symbol(gen_sym)
            pending_doc = ""
            i += 1
            continue

        if re.match(r"^(?:typedef\s+)?(?:struct|union)\b", stripped) and "(" not in stripped and ("{" in stripped or not stripped.endswith(";")):
            start_line = i + 1
            block = [raw.rstrip()]
            brace_depth = raw.count("{") - raw.count("}")
            while (brace_depth > 0 or ";" not in lines[i]) and i + 1 < n:
                i += 1
                block.append(lines[i].rstrip())
                brace_depth += lines[i].count("{") - lines[i].count("}")
            full_decl = "\n".join(block)
            m_td = re.search(r"\}\s*([A-Za-z_][A-Za-z0-9_]*)\s*;", full_decl)
            m_tag = re.search(r"\b(?:struct|union)\s+([A-Za-z_][A-Za-z0-9_]*)", full_decl)
            name = m_td.group(1) if m_td else (m_tag.group(1) if m_tag else "anonymous_struct")
            add_symbol({
                "name": name,
                "kind": "struct",
                "line": start_line,
                "signature": full_decl,
                "doc": pending_doc,
            })
            pending_doc = ""
            i += 1
            continue

        if re.match(r"^(?:typedef\s+)?enum\b", stripped):
            start_line = i + 1
            block = [raw.rstrip()]
            brace_depth = raw.count("{") - raw.count("}")
            while (brace_depth > 0 or ";" not in lines[i]) and i + 1 < n:
                i += 1
                block.append(lines[i].rstrip())
                brace_depth += lines[i].count("{") - lines[i].count("}")
            full_decl = "\n".join(block)
            m_td = re.search(r"\}\s*([A-Za-z_][A-Za-z0-9_]*)\s*;", full_decl)
            if m_td:
                name = m_td.group(1)
            else:
                m_first = re.search(r"\{\s*([A-Za-z_][A-Za-z0-9_]*)", full_decl)
                first_c = m_first.group(1) if m_first else "constants"
                prefix = "_".join(first_c.split("_")[:3])
                name = f"{prefix}_*"
            add_symbol({
                "name": name,
                "kind": "enum",
                "line": start_line,
                "signature": full_decl,
                "doc": pending_doc,
            })
            pending_doc = ""
            i += 1
            continue

        if stripped.startswith("typedef "):
            start_line = i + 1
            block = [raw.rstrip()]
            while ";" not in lines[i] and i + 1 < n:
                i += 1
                block.append(lines[i].rstrip())
            full_decl = "\n".join(block)
            no_com = strip_comments_preserving_lines(full_decl)
            m_fp = re.search(r"\(\s*\*\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)", no_com)
            if m_fp:
                name = m_fp.group(1)
            else:
                m_al = re.search(r"([A-Za-z_][A-Za-z0-9_]*)\s*;", no_com)
                name = m_al.group(1) if m_al else "typedef"
            inline_doc = extract_inline_comment(block[0]) if len(block) == 1 else ""
            add_symbol({
                "name": name,
                "kind": "typedef",
                "line": start_line,
                "signature": full_decl,
                "doc": pending_doc or inline_doc,
            })
            pending_doc = ""
            i += 1
            continue

        start_line = i + 1
        sig_buf = [raw.rstrip()]
        j = i
        is_inline_def = False
        found_semi = False
        while j < n:
            no_c = strip_comments_preserving_lines(lines[j])
            if "{" in no_c:
                is_inline_def = True
                break
            if ";" in no_c:
                found_semi = True
                break
            j += 1
            if j < n:
                sig_buf.append(lines[j].rstrip())

        if is_inline_def:
            header_text = "\n".join(sig_buf)
            sig_only = header_text.split("{", 1)[0].rstrip() + ";"
            brace_depth = lines[j].count("{") - lines[j].count("}")
            while brace_depth > 0 and j + 1 < n:
                j += 1
                brace_depth += lines[j].count("{") - lines[j].count("}")

            clean_sig = re.sub(r"\bCL_PRINTF_LIKE\s*\([^)]*\)", "", strip_comments_preserving_lines(sig_only))
            m_fn = re.search(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(", clean_sig)
            if m_fn:
                fn_name = m_fn.group(1)
                is_internal_defer = fn_name.startswith(("cl_defer_run_", "cl_da_defer_", "cl_map_defer_"))
                if not is_internal_defer and fn_name not in C99_KEYWORDS:
                    add_symbol({
                        "name": fn_name,
                        "kind": "func",
                        "is_inline": True,
                        "line": start_line,
                        "signature": sig_only,
                        "doc": pending_doc,
                    })
            pending_doc = ""
            i = j + 1
            continue

        if found_semi:
            full_decl = "\n".join(sig_buf)
            clean_sig = re.sub(r"\bCL_PRINTF_LIKE\s*\([^)]*\)", "", strip_comments_preserving_lines(full_decl))
            m_fn = re.search(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(", clean_sig)
            if m_fn and "(" in clean_sig and ")" in clean_sig:
                fn_name = m_fn.group(1)
                if fn_name not in C99_KEYWORDS:
                    inline_doc = extract_inline_comment(sig_buf[0]) if len(sig_buf) == 1 else ""
                    add_symbol({
                        "name": fn_name,
                        "kind": "func",
                        "is_inline": False,
                        "line": start_line,
                        "signature": full_decl,
                        "doc": pending_doc or inline_doc,
                    })
            pending_doc = ""
            i = j + 1
            continue

        pending_doc = ""
        i += 1

    return file_doc, includes, symbols


def build_summary(file_doc, key_prefix="purpose:"):
    """Extract a crisp 1-2 sentence summary from a file header doc block."""
    if not file_doc:
        return ""
    lines = file_doc.splitlines()
    collecting = False
    buf = []
    for ln in lines:
        s = ln.strip()
        if s.lower().startswith(key_prefix):
            collecting = True
            rest = s[len(key_prefix):].strip()
            if rest:
                buf.append(rest)
            continue
        if collecting:
            if not s:
                break
            if buf and re.match(r"^[A-Z][A-Za-z0-9 _/-]{1,30}:$", s):
                break
            buf.append(s)
    if buf:
        return " ".join(buf)
    for ln in lines:
        s = ln.strip()
        if s and not re.match(r"^(License:|SPDX-License-Identifier:|Copyright\b)", s, re.I):
            return s
    return ""


def parse_examples(examples_dir, sym_to_mod, sym_to_id):
    """
    Scan `../c_lib_examples/level_*/*.c`, extract documentation, title, level,
    and referenced `c_lib` symbols/modules for each of the 30 examples.
    """
    examples = []
    if not examples_dir.exists():
        return examples

    c_files = sorted(examples_dir.glob("level_*/*.c"), key=lambda p: p.name)
    ident_re = re.compile(r"\b(?:cl_[a-z0-9_]+|Cl_[A-Za-z0-9_]+|CL_[A-Z0-9_]+)\b")

    for ex_path in c_files:
        level_dir = ex_path.parent.name
        level_title, level_key, level_num = EXAMPLE_LEVEL_META.get(
            level_dir, (level_dir, "other", 9)
        )
        source = ex_path.read_text(encoding="utf-8")
        doc = extract_file_doc(source)
        topic = build_summary(doc, "topic:")

        # Derive readable title from filename "07_complex64_and_complex128_basics.c"
        stem = ex_path.stem
        m_num = re.match(r"^(\d+)_(.+)$", stem)
        num_str = m_num.group(1) if m_num else "00"
        raw_slug = m_num.group(2) if m_num else stem
        pretty_words = []
        acronym_map = {
            "cstr": "C-String", "utf8": "UTF-8", "ini": "INI", "csv": "CSV",
            "dft": "DFT", "dsp": "DSP", "ecs": "ECS", "ascii": "ASCII",
            "3d": "3D", "c64": "complex64", "c128": "complex128",
            "strbuf": "Cl_Str_Buf", "bitset": "BitSet",
        }
        for w in raw_slug.split("_"):
            pretty_words.append(acronym_map.get(w.lower(), w.capitalize()))
        title = " ".join(pretty_words)

        # Find referenced c_lib symbols & modules in the code body
        code_no_comments = strip_comments_preserving_lines(source)
        found_syms = []
        seen_syms = set()
        used_mods = set()
        for m in ident_re.finditer(code_no_comments):
            ident = m.group(0)
            if ident in sym_to_mod and ident not in seen_syms:
                seen_syms.add(ident)
                mod = sym_to_mod[ident]
                used_mods.add(mod)
                found_syms.append({
                    "name": ident,
                    "mod": mod,
                    "sym_id": sym_to_id[ident],
                })

        examples.append({
            "num": num_str,
            "id": stem,
            "file": ex_path.name,
            "rel_path": f"{level_dir}/{ex_path.name}",
            "html": f"examples/{ex_path.name}.html",
            "level_dir": level_dir,
            "level_title": level_title,
            "level_key": level_key,
            "level_num": level_num,
            "title": title,
            "topic": topic,
            "doc": doc,
            "lines": len(source.splitlines()),
            "modules": sorted(used_mods),
            "symbols": found_syms[:24],
            "all_symbol_names": sorted(seen_syms),
            "path": ex_path,
        })

    return examples


# -----------------------------------------------------------------------------
# Dark-Mode Syntax-Highlighted C99 Viewer Pages (for src/*.html & examples/*.html)
# -----------------------------------------------------------------------------

SOURCE_PAGE_CSS = """
:root {
    --bg: #0d121d;
    --bg-bar: #131a2a;
    --bg-hover: #182236;
    --bg-hl: rgba(56, 130, 212, 0.24);
    --hl-border: #4ea1ff;
    --border: #232f46;
    --text: #dce6f5;
    --text-muted: #7f91ad;
    --ln-color: #536480;
    --accent: #5aa2f8;
    --accent-bg: rgba(90, 162, 248, 0.14);
    --tok-kw: #f47067;
    --tok-type: #4fd1a5;
    --tok-fn: #6cb6ff;
    --tok-macro: #f0b458;
    --tok-str: #96d0ff;
    --tok-num: #d2a8ff;
    --tok-pp: #d2a8ff;
    --tok-com: #7688a6;
}
html[data-theme="light"] {
    --bg: #f8fafd;
    --bg-bar: #ffffff;
    --bg-hover: #eef3fa;
    --bg-hl: rgba(29, 91, 184, 0.14);
    --hl-border: #1d5bb8;
    --border: #d5dfec;
    --text: #1c2536;
    --text-muted: #5b6c84;
    --ln-color: #8b9bb4;
    --accent: #1d5bb8;
    --accent-bg: rgba(29, 91, 184, 0.10);
    --tok-kw: #cf222e;
    --tok-type: #0f766e;
    --tok-fn: #1d5bb8;
    --tok-macro: #9a5b00;
    --tok-str: #0a3069;
    --tok-num: #7c3aed;
    --tok-pp: #7c3aed;
    --tok-com: #6e7f98;
}
* { box-sizing: border-box; }
html, body {
    margin: 0; padding: 0;
    background: var(--bg); color: var(--text);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
}
.topbar {
    position: sticky; top: 0; z-index: 50;
    display: flex; align-items: center; justify-content: space-between; gap: 12px;
    padding: 10px 20px;
    background: var(--bg-bar); border-bottom: 1px solid var(--border);
    flex-wrap: wrap;
}
.topbar-left { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
.topbar-right { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.brand-link {
    color: var(--accent); text-decoration: none; font-weight: 700;
    font-size: 14px; padding: 5px 10px; border-radius: 6px;
    background: var(--accent-bg);
}
.brand-link:hover { filter: brightness(1.15); }
.file-title {
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    font-size: 15px; font-weight: 700; color: var(--text);
}
.file-meta { font-size: 12px; color: var(--text-muted); }
.pill-btn {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 5px 11px; border-radius: 6px;
    border: 1px solid var(--border); background: transparent;
    color: var(--text); text-decoration: none; font-size: 12.5px; font-weight: 600;
    cursor: pointer;
}
.pill-btn:hover { background: var(--bg-hover); border-color: var(--accent); color: var(--accent); }
.code-wrap { padding: 12px 0 60px; overflow-x: auto; }
.code-table {
    width: 100%; border-collapse: collapse;
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace;
    font-size: 13.5px; line-height: 1.55;
}
.code-row { scroll-margin-top: 76px; }
.code-row:hover { background: var(--bg-hover); }
.code-row.target-line { background: var(--bg-hl); }
.code-row.target-line .ln {
    border-left: 3px solid var(--hl-border);
    color: var(--accent); font-weight: 700;
}
.ln {
    width: 1%; min-width: 56px; padding: 0 14px 0 12px;
    text-align: right; user-select: none; vertical-align: top;
    color: var(--ln-color); border-left: 3px solid transparent;
}
.ln a { color: inherit; text-decoration: none; display: block; }
.ln a:hover { color: var(--accent); }
.lc { padding: 0 20px 0 10px; white-space: pre; }
.tok-kw { color: var(--tok-kw); font-weight: 600; }
.tok-type { color: var(--tok-type); }
.tok-fn { color: var(--tok-fn); }
.tok-macro { color: var(--tok-macro); }
.tok-str { color: var(--tok-str); }
.tok-num { color: var(--tok-num); }
.tok-pp { color: var(--tok-pp); font-weight: 600; }
.tok-com { color: var(--tok-com); font-style: italic; }
"""


def render_code_viewer_html(file_path, rel_display, back_href, back_label, nav_buttons_html=""):
    """Generate a dark-mode-default syntax-highlighted HTML source viewer page."""
    source = file_path.read_text(encoding="utf-8")
    hl_lines = highlight_c_lines(source)
    total_lines = len(hl_lines)

    rows = []
    for idx, line_html in enumerate(hl_lines, start=1):
        rows.append(
            f'<tr class="code-row" id="L{idx}">'
            f'<td class="ln"><a href="#L{idx}">{idx}</a></td>'
            f'<td class="lc">{line_html if line_html else " "}</td>'
            f'</tr>'
        )
    table_body = "\n".join(rows)

    return f"""<!DOCTYPE html>
<!-- License: MIT Open Source License (SPDX-License-Identifier: MIT) -->
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{html.escape(file_path.name)} — c_lib C99 Source</title>
<style>{SOURCE_PAGE_CSS}</style>
</head>
<body>
<header class="topbar">
  <div class="topbar-left">
    <a class="brand-link" href="{html.escape(back_href)}">&larr; {html.escape(back_label)}</a>
    <span class="file-title">{html.escape(rel_display)}</span>
    <span class="file-meta">{total_lines} lines &middot; C99 &middot; MIT License</span>
  </div>
  <div class="topbar-right">
    {nav_buttons_html}
    <a class="pill-btn" href="../index.html#overview">API Reference</a>
    <a class="pill-btn" href="../index.html#examples">All 30 Examples</a>
    <button class="pill-btn" id="themeBtn" type="button">Theme: Dark</button>
  </div>
</header>
<main class="code-wrap">
  <table class="code-table"><tbody>
{table_body}
  </tbody></table>
</main>
<script>
(function() {{
  var root = document.documentElement;
  var btn = document.getElementById("themeBtn");
  function applyTheme(t) {{
    root.setAttribute("data-theme", t);
    btn.textContent = (t === "dark") ? "Theme: Dark" : "Theme: Light";
  }}
  applyTheme("dark");
  btn.addEventListener("click", function() {{
    applyTheme(root.getAttribute("data-theme") === "dark" ? "light" : "dark");
  }});

  function highlightHash() {{
    var prev = document.querySelectorAll(".target-line");
    for (var i = 0; i < prev.length; i++) prev[i].classList.remove("target-line");
    if (location.hash && /^#L\\d+$/.test(location.hash)) {{
      var row = document.getElementById(location.hash.slice(1));
      if (row) {{
        row.classList.add("target-line");
        row.scrollIntoView({{ block: "center", behavior: "instant" }});
      }}
    }}
  }}
  window.addEventListener("hashchange", highlightHash);
  highlightHash();
}})();
</script>
</body>
</html>
"""


# -----------------------------------------------------------------------------
# Main Odin-Style Documentation UI (index.html)
# -----------------------------------------------------------------------------

MAIN_CSS = """
:root {
    --bg: #0f1522;
    --bg-sidebar: #131a2b;
    --bg-surface: #172033;
    --bg-code: #0b101b;
    --bg-hover: #1d2942;
    --border: #24314a;
    --border-strong: #324466;
    --text: #e2eaf6;
    --text-soft: #b2c2db;
    --text-muted: #7c8fad;
    --accent: #4ea1ff;
    --accent-hover: #79b8ff;
    --accent-bg: rgba(78, 161, 255, 0.14);
    --badge-pair-bg: rgba(79, 209, 165, 0.14);
    --badge-pair-fg: #4fd1a5;
    --badge-hdr-bg: rgba(210, 168, 255, 0.14);
    --badge-hdr-fg: #d2a8ff;
    --lvl-beg-bg: rgba(79, 209, 165, 0.15);
    --lvl-beg-fg: #4fd1a5;
    --lvl-int-bg: rgba(240, 180, 88, 0.16);
    --lvl-int-fg: #f0b458;
    --lvl-adv-bg: rgba(244, 112, 103, 0.16);
    --lvl-adv-fg: #f47067;
    --kind-struct-bg: rgba(79, 209, 165, 0.15);
    --kind-struct-fg: #4fd1a5;
    --kind-enum-bg: rgba(210, 168, 255, 0.15);
    --kind-enum-fg: #d2a8ff;
    --kind-typedef-bg: rgba(121, 184, 255, 0.15);
    --kind-typedef-fg: #79b8ff;
    --kind-macro-bg: rgba(240, 180, 88, 0.16);
    --kind-macro-fg: #f0b458;
    --kind-func-bg: rgba(78, 161, 255, 0.16);
    --kind-func-fg: #6cb6ff;
    --mark-bg: rgba(240, 180, 88, 0.28);
    --mark-fg: #ffd58a;
    --shadow: 0 14px 36px rgba(0, 0, 0, 0.48);
    --tok-kw: #f47067;
    --tok-type: #4fd1a5;
    --tok-fn: #6cb6ff;
    --tok-macro: #f0b458;
    --tok-str: #96d0ff;
    --tok-num: #d2a8ff;
    --tok-pp: #d2a8ff;
    --tok-com: #7688a6;
}
html[data-theme="light"] {
    --bg: #f6f8fc;
    --bg-sidebar: #eef2f8;
    --bg-surface: #ffffff;
    --bg-code: #f1f5fb;
    --bg-hover: #e5edf8;
    --border: #d5dfed;
    --border-strong: #b6c6dd;
    --text: #192334;
    --text-soft: #3a4962;
    --text-muted: #62738f;
    --accent: #1d5bb8;
    --accent-hover: #14448e;
    --accent-bg: rgba(29, 91, 184, 0.10);
    --badge-pair-bg: rgba(15, 118, 110, 0.11);
    --badge-pair-fg: #0f766e;
    --badge-hdr-bg: rgba(109, 40, 217, 0.10);
    --badge-hdr-fg: #6d28d9;
    --lvl-beg-bg: rgba(15, 118, 110, 0.11);
    --lvl-beg-fg: #0f766e;
    --lvl-int-bg: rgba(180, 83, 9, 0.11);
    --lvl-int-fg: #9a5000;
    --lvl-adv-bg: rgba(185, 28, 28, 0.10);
    --lvl-adv-fg: #b91c1c;
    --kind-struct-bg: rgba(15, 118, 110, 0.11);
    --kind-struct-fg: #0f766e;
    --kind-enum-bg: rgba(109, 40, 217, 0.10);
    --kind-enum-fg: #6d28d9;
    --kind-typedef-bg: rgba(29, 91, 184, 0.10);
    --kind-typedef-fg: #1d5bb8;
    --kind-macro-bg: rgba(180, 83, 9, 0.11);
    --kind-macro-fg: #9a5000;
    --kind-func-bg: rgba(29, 91, 184, 0.11);
    --kind-func-fg: #1d5bb8;
    --mark-bg: rgba(245, 158, 11, 0.25);
    --mark-fg: #78350f;
    --shadow: 0 12px 32px rgba(20, 35, 65, 0.14);
    --tok-kw: #cf222e;
    --tok-type: #0f766e;
    --tok-fn: #1d5bb8;
    --tok-macro: #9a5b00;
    --tok-str: #0a3069;
    --tok-num: #7c3aed;
    --tok-pp: #7c3aed;
    --tok-com: #6c7d96;
}
* { box-sizing: border-box; }
html, body {
    margin: 0; padding: 0; min-height: 100%;
    background: var(--bg); color: var(--text);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, sans-serif;
    line-height: 1.55;
}
a { color: var(--accent); text-decoration: none; }
a:hover { color: var(--accent-hover); text-decoration: underline; }
code, pre {
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace;
}

/* Sticky Odin-style top navbar */
.navbar {
    position: sticky; top: 0; z-index: 100;
    height: 60px; padding: 0 18px;
    background: var(--bg-sidebar);
    border-bottom: 1px solid var(--border);
    display: flex; align-items: center; gap: 14px;
}
.brand {
    display: flex; align-items: center; gap: 9px;
    color: var(--text); font-weight: 800; font-size: 18px;
    text-decoration: none; white-space: nowrap;
}
.brand:hover { text-decoration: none; }
.brand-mark {
    display: inline-flex; align-items: center; justify-content: center;
    width: 30px; height: 30px; border-radius: 7px;
    background: linear-gradient(135deg, #2b6cb0, #4ea1ff);
    color: #fff; font-weight: 900; font-size: 15px;
    font-family: ui-monospace, monospace;
}
.brand-ver {
    font-size: 11px; font-weight: 700; padding: 2px 7px; border-radius: 999px;
    background: var(--accent-bg); color: var(--accent);
}
.nav-links { display: flex; align-items: center; gap: 4px; }
.nav-link {
    padding: 6px 11px; border-radius: 7px;
    color: var(--text-soft); font-size: 13px; font-weight: 600;
    text-decoration: none; white-space: nowrap;
}
.nav-link:hover { background: var(--bg-hover); color: var(--text); text-decoration: none; }
.nav-link.active { background: var(--accent-bg); color: var(--accent); }

/* Prominent top API fuzzy search */
.search-box {
    position: relative; flex: 1; max-width: 560px; margin: 0 auto;
}
.search-input-wrap { position: relative; display: flex; align-items: center; }
.search-icon {
    position: absolute; left: 12px; color: var(--text-muted);
    font-size: 14px; pointer-events: none;
}
.search-input {
    width: 100%; height: 38px; padding: 0 74px 0 36px;
    border-radius: 8px; border: 1px solid var(--border-strong);
    background: var(--bg-surface); color: var(--text);
    font-size: 13.5px; outline: none;
    transition: border-color 0.15s, box-shadow 0.15s;
}
.search-input:focus {
    border-color: var(--accent);
    box-shadow: 0 0 0 3px var(--accent-bg);
}
.search-kbd {
    position: absolute; right: 10px;
    font-size: 11px; color: var(--text-muted);
    border: 1px solid var(--border); border-radius: 4px;
    padding: 1px 6px; background: var(--bg); pointer-events: none;
}
.search-dropdown {
    display: none; position: absolute; top: 44px; left: 0; right: 0;
    max-height: 460px; overflow-y: auto;
    background: var(--bg-surface); border: 1px solid var(--border-strong);
    border-radius: 10px; box-shadow: var(--shadow); z-index: 200;
}
.search-dropdown.open { display: block; }
.search-header-bar {
    display: flex; align-items: center; justify-content: space-between;
    padding: 8px 12px; font-size: 11.5px; color: var(--text-muted);
    border-bottom: 1px solid var(--border); background: var(--bg-sidebar);
}
.search-item {
    display: flex; align-items: center; justify-content: space-between; gap: 10px;
    padding: 9px 14px; cursor: pointer;
    border-bottom: 1px solid var(--border);
    text-decoration: none; color: var(--text);
}
.search-item:last-child { border-bottom: none; }
.search-item:hover, .search-item.active { background: var(--bg-hover); text-decoration: none; }
.search-item-main { display: flex; align-items: center; gap: 9px; min-width: 0; }
.search-item-name {
    font-family: ui-monospace, monospace; font-size: 13.5px; font-weight: 600;
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
mark {
    background: var(--mark-bg); color: var(--mark-fg);
    border-radius: 2px; padding: 0 1px;
}
.search-item-meta {
    display: flex; align-items: center; gap: 8px; flex-shrink: 0;
    font-size: 11.5px; color: var(--text-muted);
    font-family: ui-monospace, monospace;
}
.search-empty { padding: 20px; text-align: center; color: var(--text-muted); font-size: 13.5px; }

.nav-actions { display: flex; align-items: center; gap: 8px; }
.icon-btn {
    height: 36px; padding: 0 12px; border-radius: 8px;
    border: 1px solid var(--border); background: var(--bg-surface);
    color: var(--text); font-size: 13px; font-weight: 600;
    cursor: pointer; display: inline-flex; align-items: center; gap: 6px;
    white-space: nowrap;
}
.icon-btn:hover { border-color: var(--accent); color: var(--accent); }
.menu-btn { display: none; }

/* Main 3-pane layout */
.layout {
    display: grid;
    grid-template-columns: 280px minmax(0, 1fr) 230px;
    min-height: calc(100vh - 60px);
}
.sidebar {
    position: sticky; top: 60px; height: calc(100vh - 60px);
    overflow-y: auto; padding: 12px 12px 44px;
    background: var(--bg-sidebar); border-right: 1px solid var(--border);
}
.sidebar-primary-tabs {
    display: grid; grid-template-columns: 1fr 1fr; gap: 4px;
    margin-bottom: 10px; padding: 3px; border-radius: 8px;
    background: var(--bg); border: 1px solid var(--border);
}
.side-primary-tab {
    padding: 5px 6px; border-radius: 6px; border: none;
    background: transparent; color: var(--text-muted);
    font-size: 12px; font-weight: 700; cursor: pointer;
}
.side-primary-tab:hover { color: var(--text); }
.side-primary-tab.active { background: var(--accent); color: #fff; }
.sidebar-filter {
    width: 100%; height: 32px; padding: 0 10px; margin-bottom: 8px;
    border-radius: 6px; border: 1px solid var(--border);
    background: var(--bg-surface); color: var(--text); font-size: 12.5px;
    outline: none;
}
.sidebar-filter:focus { border-color: var(--accent); }
.sidebar-tabs {
    display: grid; grid-template-columns: repeat(3, 1fr); gap: 4px;
    margin-bottom: 12px;
}
.side-tab {
    padding: 4px 6px; border-radius: 6px;
    border: 1px solid var(--border); background: var(--bg-surface);
    color: var(--text-muted); font-size: 11px; font-weight: 700;
    cursor: pointer; text-align: center;
    font-family: ui-monospace, monospace;
}
.side-tab:hover { border-color: var(--accent); color: var(--accent); }
.side-tab.active { background: var(--accent); border-color: var(--accent); color: #fff; }
.nav-group { margin-bottom: 14px; }
.nav-group-title {
    font-size: 11px; font-weight: 700; text-transform: uppercase;
    letter-spacing: 0.08em; color: var(--text-muted);
    padding: 4px 8px; margin-bottom: 2px;
}
.nav-mod {
    display: flex; align-items: center; justify-content: space-between; gap: 6px;
    padding: 6px 9px; border-radius: 6px; margin-bottom: 2px;
    color: var(--text-soft); font-size: 13px; font-weight: 500;
    font-family: ui-monospace, monospace; text-decoration: none;
}
.nav-mod:hover { background: var(--bg-hover); color: var(--text); text-decoration: none; }
.nav-mod.active { background: var(--accent-bg); color: var(--accent); font-weight: 700; }
.nav-ex-label {
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 12.5px;
}
.nav-ex-num {
    font-family: ui-monospace, monospace; font-weight: 700;
    color: var(--accent); margin-right: 5px;
}
.file-badge {
    font-size: 10px; font-weight: 700; padding: 1px 6px; border-radius: 999px;
    font-family: ui-monospace, monospace; white-space: nowrap; flex-shrink: 0;
}
.file-badge.pair { background: var(--badge-pair-bg); color: var(--badge-pair-fg); }
.file-badge.hdr  { background: var(--badge-hdr-bg);  color: var(--badge-hdr-fg); }
.lvl-badge {
    font-size: 10px; font-weight: 800; padding: 2px 7px; border-radius: 999px;
    text-transform: uppercase; letter-spacing: 0.04em; white-space: nowrap;
}
.lvl-beginner     { background: var(--lvl-beg-bg); color: var(--lvl-beg-fg); }
.lvl-intermediate { background: var(--lvl-int-bg); color: var(--lvl-int-fg); }
.lvl-advanced     { background: var(--lvl-adv-bg); color: var(--lvl-adv-fg); }

/* Content pane */
.content { padding: 28px 36px 80px; max-width: 980px; width: 100%; }
.right-toc {
    position: sticky; top: 60px; height: calc(100vh - 60px);
    overflow-y: auto; padding: 24px 16px 40px;
    border-left: 1px solid var(--border); font-size: 12.5px;
}
.toc-heading {
    font-size: 11px; font-weight: 700; text-transform: uppercase;
    letter-spacing: 0.08em; color: var(--text-muted); margin-bottom: 8px;
}
.toc-link {
    display: block; padding: 3px 6px; border-radius: 4px;
    color: var(--text-muted); text-decoration: none;
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.toc-link:hover { color: var(--accent); background: var(--bg-hover); text-decoration: none; }
.toc-link.sec { color: var(--text-soft); font-weight: 700; margin-top: 8px; }
.toc-link.sym { padding-left: 14px; font-family: ui-monospace, monospace; font-size: 11.5px; }

/* Hero & Overview */
.hero {
    padding: 24px 26px; border-radius: 12px; margin-bottom: 24px;
    background: var(--bg-surface); border: 1px solid var(--border);
}
.hero h1 { margin: 0 0 8px; font-size: 28px; letter-spacing: -0.02em; }
.hero p { margin: 0 0 16px; color: var(--text-soft); font-size: 14.5px; }
.stats-row { display: flex; flex-wrap: wrap; gap: 10px; align-items: center; }
.stat-pill {
    padding: 6px 12px; border-radius: 8px;
    background: var(--bg); border: 1px solid var(--border);
    font-size: 12.5px; color: var(--text-soft);
}
.stat-pill strong { color: var(--accent); font-family: ui-monospace, monospace; }
.hero-cta {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 6px 14px; border-radius: 8px;
    background: var(--accent); color: #fff; font-weight: 700; font-size: 13px;
}
.hero-cta:hover { color: #fff; filter: brightness(1.1); text-decoration: none; }

.group-section { margin-bottom: 26px; }
.group-section h2 {
    font-size: 16px; font-weight: 700; margin: 0 0 12px;
    padding-bottom: 6px; border-bottom: 1px solid var(--border);
    color: var(--text); display: flex; align-items: center; justify-content: space-between;
}
.mod-grid {
    display: grid; grid-template-columns: repeat(auto-fill, minmax(265px, 1fr));
    gap: 12px;
}
.mod-card {
    display: flex; flex-direction: column; gap: 8px;
    padding: 14px 16px; border-radius: 10px;
    background: var(--bg-surface); border: 1px solid var(--border);
    transition: border-color 0.15s, transform 0.12s;
}
.mod-card:hover { border-color: var(--accent); transform: translateY(-1px); }
.mod-card-top { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.mod-card-name {
    font-family: ui-monospace, monospace; font-size: 15px; font-weight: 700;
    color: var(--accent);
}
.mod-card-desc {
    font-size: 12.5px; color: var(--text-soft);
    display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
    overflow: hidden; min-height: 36px;
}
.mod-card-foot {
    display: flex; align-items: center; justify-content: space-between; gap: 8px;
    font-size: 11.5px; color: var(--text-muted); margin-top: auto;
    padding-top: 6px; border-top: 1px solid var(--border);
}
.src-mini-links { display: flex; gap: 8px; }
.src-mini-links a { font-family: ui-monospace, monospace; font-size: 11.5px; }

/* Quick 30-Example Compact Strip on Overview */
.ex-quick-grid {
    display: grid; grid-template-columns: repeat(auto-fill, minmax(275px, 1fr));
    gap: 8px;
}
.ex-quick-link {
    display: flex; align-items: center; justify-content: space-between; gap: 8px;
    padding: 8px 12px; border-radius: 8px;
    background: var(--bg-surface); border: 1px solid var(--border);
    color: var(--text); font-size: 12.5px; font-weight: 600;
}
.ex-quick-link:hover { border-color: var(--accent); background: var(--bg-hover); text-decoration: none; }
.ex-quick-left { display: flex; align-items: center; gap: 8px; min-width: 0; }
.ex-quick-title { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

/* Dedicated Examples Browser Page (#examples) */
.ex-search-panel {
    padding: 18px 20px; border-radius: 12px; margin-bottom: 22px;
    background: var(--bg-surface); border: 1px solid var(--border);
}
.ex-search-input {
    width: 100%; height: 42px; padding: 0 14px; margin-bottom: 12px;
    border-radius: 8px; border: 1px solid var(--border-strong);
    background: var(--bg); color: var(--text); font-size: 14px; outline: none;
}
.ex-search-input:focus {
    border-color: var(--accent);
    box-shadow: 0 0 0 3px var(--accent-bg);
}
.ex-card {
    margin-bottom: 14px; border-radius: 10px; overflow: hidden;
    background: var(--bg-surface); border: 1px solid var(--border);
}
.ex-card-head {
    display: flex; align-items: center; justify-content: space-between;
    gap: 12px; flex-wrap: wrap;
    padding: 12px 16px; background: var(--bg-sidebar);
    border-bottom: 1px solid var(--border);
}
.ex-card-title-wrap { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.ex-num {
    font-family: ui-monospace, monospace; font-size: 13px; font-weight: 800;
    padding: 2px 8px; border-radius: 6px;
    background: var(--accent-bg); color: var(--accent);
}
.ex-title { font-size: 15.5px; font-weight: 700; color: var(--text); }
.ex-card-body { padding: 13px 16px; }
.ex-topic { margin: 0 0 10px; font-size: 13.5px; color: var(--text-soft); }
.ex-tags { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 10px; }
.ex-sym-chip {
    padding: 2px 7px; border-radius: 5px;
    background: var(--bg); border: 1px solid var(--border);
    font-family: ui-monospace, monospace; font-size: 11.5px; color: var(--text-soft);
}
.ex-sym-chip:hover { border-color: var(--accent); color: var(--accent); text-decoration: none; }
.ex-details {
    margin-top: 8px; border-top: 1px dashed var(--border); padding-top: 8px;
}
.ex-details summary {
    cursor: pointer; font-size: 12.5px; font-weight: 600; color: var(--accent);
    user-select: none;
}
.ex-details-body {
    margin-top: 8px; padding: 12px 14px; border-radius: 8px;
    background: var(--bg-code); border: 1px solid var(--border);
    white-space: pre-wrap; font-size: 12.5px; color: var(--text-soft);
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
}

/* Module Reference Page */
.mod-header {
    display: flex; align-items: flex-start; justify-content: space-between;
    gap: 16px; flex-wrap: wrap; margin-bottom: 16px;
    padding-bottom: 16px; border-bottom: 1px solid var(--border);
}
.mod-title { margin: 0; font-size: 26px; font-family: ui-monospace, monospace; }
.mod-title .pkg-prefix { color: var(--text-muted); font-weight: 400; }
.mod-files { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
.src-btn {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 6px 12px; border-radius: 7px;
    border: 1px solid var(--border-strong); background: var(--bg-surface);
    color: var(--text); font-family: ui-monospace, monospace; font-size: 12.5px;
    font-weight: 600; text-decoration: none;
}
.src-btn:hover { border-color: var(--accent); color: var(--accent); text-decoration: none; background: var(--accent-bg); }
.src-btn.primary { background: var(--accent); border-color: var(--accent); color: #fff; }
.src-btn.primary:hover { filter: brightness(1.1); color: #fff; background: var(--accent); }
.mod-doc {
    padding: 16px 18px; border-radius: 10px; margin-bottom: 16px;
    background: var(--bg-surface); border: 1px solid var(--border);
    white-space: pre-wrap; font-size: 13.5px; color: var(--text-soft);
}
.includes-bar {
    display: flex; flex-wrap: wrap; align-items: center; gap: 6px;
    margin-bottom: 14px; font-size: 12px; color: var(--text-muted);
}
.inc-chip {
    padding: 2px 8px; border-radius: 5px;
    background: var(--bg-surface); border: 1px solid var(--border);
    font-family: ui-monospace, monospace; font-size: 11.5px; color: var(--accent);
}
.inc-chip:hover { border-color: var(--accent); background: var(--accent-bg); text-decoration: none; }

.filter-bar { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 18px; }
.filter-pill {
    padding: 5px 12px; border-radius: 999px;
    border: 1px solid var(--border); background: var(--bg-surface);
    color: var(--text-soft); font-size: 12.5px; font-weight: 600; cursor: pointer;
}
.filter-pill:hover { border-color: var(--accent); color: var(--accent); }
.filter-pill.active { background: var(--accent); border-color: var(--accent); color: #fff; }

.index-box {
    padding: 14px 18px; border-radius: 10px; margin-bottom: 24px;
    background: var(--bg-surface); border: 1px solid var(--border);
}
.index-box h3 {
    margin: 0 0 10px; font-size: 12.5px; color: var(--text-muted);
    text-transform: uppercase; letter-spacing: 0.06em;
}
.index-chips { display: flex; flex-wrap: wrap; gap: 6px; }
.index-chip {
    display: inline-flex; align-items: center; gap: 5px;
    padding: 3px 8px; border-radius: 5px;
    background: var(--bg); border: 1px solid var(--border);
    font-family: ui-monospace, monospace; font-size: 12px; color: var(--text-soft);
}
.index-chip:hover { border-color: var(--accent); color: var(--accent); text-decoration: none; }

/* Symbol sections & cards */
.sec-title {
    margin: 28px 0 14px; font-size: 19px; font-weight: 700;
    padding-bottom: 6px; border-bottom: 2px solid var(--border);
    display: flex; align-items: center; gap: 10px;
}
.sec-count {
    font-size: 12px; font-family: ui-monospace, monospace;
    padding: 1px 8px; border-radius: 999px;
    background: var(--bg-surface); color: var(--text-muted);
    border: 1px solid var(--border);
}
.sym-card {
    margin-bottom: 16px; border-radius: 10px; overflow: hidden;
    background: var(--bg-surface); border: 1px solid var(--border);
    scroll-margin-top: 76px;
}
.sym-card.flash { border-color: var(--accent); box-shadow: 0 0 0 3px var(--accent-bg); }
.sym-head {
    display: flex; align-items: center; justify-content: space-between;
    gap: 12px; flex-wrap: wrap;
    padding: 10px 14px; background: var(--bg-sidebar);
    border-bottom: 1px solid var(--border);
}
.sym-left { display: flex; align-items: center; gap: 9px; min-width: 0; flex-wrap: wrap; }
.kind-badge {
    font-size: 10.5px; font-weight: 800; text-transform: uppercase;
    letter-spacing: 0.05em; padding: 2px 7px; border-radius: 5px;
    font-family: ui-monospace, monospace;
}
.kind-struct  { background: var(--kind-struct-bg);  color: var(--kind-struct-fg); }
.kind-enum    { background: var(--kind-enum-bg);    color: var(--kind-enum-fg); }
.kind-typedef { background: var(--kind-typedef-bg); color: var(--kind-typedef-fg); }
.kind-macro   { background: var(--kind-macro-bg);   color: var(--kind-macro-fg); }
.kind-func    { background: var(--kind-func-bg);    color: var(--kind-func-fg); }
.sym-name {
    font-family: ui-monospace, monospace; font-size: 15px; font-weight: 700;
    color: var(--text);
}
.sym-subbadge {
    font-size: 10.5px; padding: 1px 6px; border-radius: 4px;
    background: var(--bg); color: var(--text-muted); border: 1px solid var(--border);
    font-family: ui-monospace, monospace;
}
.sym-links { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.src-jump {
    display: inline-flex; align-items: center; gap: 4px;
    padding: 3px 9px; border-radius: 5px;
    font-family: ui-monospace, monospace; font-size: 11.5px; font-weight: 600;
    background: var(--bg); border: 1px solid var(--border); color: var(--accent);
}
.src-jump:hover { border-color: var(--accent); background: var(--accent-bg); text-decoration: none; }
.src-jump.impl { color: var(--badge-pair-fg); }
.src-jump.impl:hover { border-color: var(--badge-pair-fg); background: var(--badge-pair-bg); }
.sym-code {
    margin: 0; padding: 12px 16px; overflow-x: auto;
    background: var(--bg-code); font-size: 13px; line-height: 1.5;
    border-bottom: 1px solid var(--border);
}
.sym-code:last-child { border-bottom: none; }
.sym-doc {
    padding: 12px 16px; font-size: 13.5px; color: var(--text-soft);
    white-space: pre-wrap; line-height: 1.6;
}
.sym-doc code {
    font-size: 12.5px; padding: 1px 5px; border-radius: 4px;
    background: var(--bg-code); color: var(--text); border: 1px solid var(--border);
}
.doc-sec-hdr {
    display: inline-block; font-weight: 700; color: var(--text);
    font-size: 12px; text-transform: uppercase; letter-spacing: 0.05em;
}

.tok-kw { color: var(--tok-kw); font-weight: 600; }
.tok-type { color: var(--tok-type); }
.tok-fn { color: var(--tok-fn); }
.tok-macro { color: var(--tok-macro); }
.tok-str { color: var(--tok-str); }
.tok-num { color: var(--tok-num); }
.tok-pp { color: var(--tok-pp); font-weight: 600; }
.tok-com { color: var(--tok-com); font-style: italic; }

@media (max-width: 1160px) {
    .layout { grid-template-columns: 260px minmax(0, 1fr); }
    .right-toc { display: none; }
}
@media (max-width: 820px) {
    .layout { grid-template-columns: 1fr; }
    .menu-btn { display: inline-flex; }
    .nav-links { display: none; }
    .sidebar {
        display: none; position: fixed; left: 0; top: 60px; bottom: 0;
        width: 290px; z-index: 150; box-shadow: var(--shadow);
    }
    .sidebar.open { display: block; }
    .content { padding: 18px 16px 60px; }
}
"""

MAIN_JS = r"""
(function() {
  var DATA = window.CLIB_DOCS;
  var root = document.documentElement;
  var sidebarEl = document.getElementById("sidebar");
  var navTreeEl = document.getElementById("navTree");
  var contentEl = document.getElementById("content");
  var rightTocEl = document.getElementById("rightToc");
  var themeBtn = document.getElementById("themeBtn");
  var menuBtn = document.getElementById("menuBtn");
  var sideFilter = document.getElementById("sidebarFilter");
  var sideFileTabs = document.getElementById("sidebarFileTabs");
  var navLinkApi = document.getElementById("navLinkApi");
  var navLinkEx  = document.getElementById("navLinkEx");

  var searchInput = document.getElementById("searchInput");
  var searchDrop  = document.getElementById("searchDropdown");

  /* Theme persistence (Dark Mode default) */
  function setTheme(t) {
    root.setAttribute("data-theme", t);
    try { localStorage.setItem("clib_docs_theme", t); } catch (e) {}
    themeBtn.textContent = (t === "dark") ? "Light Mode" : "Dark Mode";
  }
  var savedTheme = "dark";
  try {
    var st = localStorage.getItem("clib_docs_theme");
    if (st === "light" || st === "dark") savedTheme = st;
  } catch (e) {}
  setTheme(savedTheme);
  themeBtn.addEventListener("click", function() {
    setTheme(root.getAttribute("data-theme") === "dark" ? "light" : "dark");
  });

  if (menuBtn) {
    menuBtn.addEventListener("click", function() {
      sidebarEl.classList.toggle("open");
    });
  }

  /* Index modules and related examples per module */
  var modByName = {};
  var modExamples = {};
  var searchItems = [];
  for (var mIdx = 0; mIdx < DATA.modules.length; mIdx++) {
    var mod = DATA.modules[mIdx];
    modByName[mod.name] = mod;
    modExamples[mod.name] = [];
    searchItems.push({
      kind: "module",
      name: mod.name,
      mod: mod.name,
      fileLabel: mod.has_c ? (mod.h_file + " + " + mod.c_file) : mod.h_file,
      line: 1,
      srcHref: mod.h_html,
      hash: "#mod/" + encodeURIComponent(mod.name),
      doc: mod.summary || ""
    });
    for (var sIdx = 0; sIdx < mod.symbols.length; sIdx++) {
      var sym = mod.symbols[sIdx];
      searchItems.push({
        kind: sym.kind,
        name: sym.name,
        mod: mod.name,
        fileLabel: mod.h_file + ":" + sym.line,
        line: sym.line,
        srcHref: mod.h_html + "#L" + sym.line,
        hash: "#sym/" + encodeURIComponent(mod.name) + "/" + encodeURIComponent(sym.id),
        doc: sym.doc || ""
      });
    }
  }
  for (var eIdx = 0; eIdx < DATA.examples.length; eIdx++) {
    var ex = DATA.examples[eIdx];
    for (var em = 0; em < ex.modules.length; em++) {
      var mn = ex.modules[em];
      if (modExamples[mn]) modExamples[mn].push(ex);
    }
  }

  function escHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  /* Render rich English doc comments: backtick code + bold Parameters/Returns/Fields headings */
  function formatDocHtml(rawDoc) {
    if (!rawDoc) return "";
    var lines = rawDoc.split("\n");
    var out = [];
    for (var i = 0; i < lines.length; i++) {
      var ln = escHtml(lines[i]);
      ln = ln.replace(/`([^`]+)`/g, "<code>$1</code>");
      ln = ln.replace(/^(\s*)(License|SPDX-License-Identifier|Function|Struct|Macro|Enum|Typedef|Description|Summary|Parameters|Parameter|Params|Returns|Return|Fields|Field|Members|Values|Note|Notes|Units|Preconditions|Usage|Purpose|Formula|Formulas|Behavior|Complexity|Safety|Thread Safety|Example|Examples):/,
                      '$1<span class="doc-sec-hdr">$2:</span>');
      out.push(ln);
    }
    return out.join("\n");
  }

  /* Fuzzy Search Engine */
  function fuzzyMatch(query, target) {
    var q = query.toLowerCase();
    var t = target.toLowerCase();
    var qi = 0, score = 0, streak = 0;
    var positions = [];
    for (var ti = 0; ti < t.length && qi < q.length; ti++) {
      if (t[ti] === q[qi]) {
        positions.push(ti);
        var bonus = 10;
        if (ti === 0) bonus += 24;
        else if (t[ti - 1] === "_" || t[ti - 1] === "." || t[ti - 1] === "-" || t[ti - 1] === " ") bonus += 16;
        else if (target[ti] >= "A" && target[ti] <= "Z" && target[ti - 1] >= "a" && target[ti - 1] <= "z") bonus += 14;
        streak += 1;
        bonus += streak * 5;
        score += bonus;
        qi += 1;
      } else {
        streak = 0;
      }
    }
    if (qi !== q.length) return null;
    if (t === q) score += 200;
    else if (t.indexOf(q) === 0) score += 90;
    else if (t.indexOf(q) !== -1) score += 45;
    score -= (t.length - q.length) * 0.35;
    return { score: score, positions: positions };
  }

  function renderHighlighted(text, positions) {
    if (!positions || positions.length === 0) return escHtml(text);
    var posSet = {};
    for (var i = 0; i < positions.length; i++) posSet[positions[i]] = true;
    var out = "", inMark = false;
    for (var j = 0; j < text.length; j++) {
      var hit = !!posSet[j];
      if (hit && !inMark) { out += "<mark>"; inMark = true; }
      else if (!hit && inMark) { out += "</mark>"; inMark = false; }
      out += escHtml(text[j]);
    }
    if (inMark) out += "</mark>";
    return out;
  }

  /* Sidebar primary switcher: Modules (25) vs Examples (30) */
  var sidePane = "modules";
  var sideMode = "all";
  var currentModName = null;
  var currentView = "overview";

  var sidePrimaryBtns = document.querySelectorAll(".side-primary-tab");
  for (var pIdx = 0; pIdx < sidePrimaryBtns.length; pIdx++) {
    sidePrimaryBtns[pIdx].addEventListener("click", function() {
      sidePane = this.getAttribute("data-pane");
      syncSidebarTabs();
      renderSidebar();
    });
  }
  var sideTabBtns = document.querySelectorAll(".side-tab");
  for (var stIdx = 0; stIdx < sideTabBtns.length; stIdx++) {
    sideTabBtns[stIdx].addEventListener("click", function() {
      sideMode = this.getAttribute("data-mode");
      for (var k = 0; k < sideTabBtns.length; k++) {
        sideTabBtns[k].classList.toggle("active", sideTabBtns[k] === this);
      }
      renderSidebar();
    });
  }
  function syncSidebarTabs() {
    for (var i = 0; i < sidePrimaryBtns.length; i++) {
      sidePrimaryBtns[i].classList.toggle("active", sidePrimaryBtns[i].getAttribute("data-pane") === sidePane);
    }
    sideFileTabs.style.display = (sidePane === "modules") ? "grid" : "none";
    sideFilter.placeholder = (sidePane === "modules") ? "Filter modules..." : "Quick filter 30 examples...";
  }

  function renderSidebar() {
    var q = (sideFilter.value || "").trim().toLowerCase();
    var parts = [];
    if (sidePane === "modules") {
      parts.push(
        '<a class="nav-mod' + (currentView === "overview" ? " active" : "") + '" href="#overview">' +
        '<span>Overview</span><span class="file-badge hdr">' + DATA.modules.length + ' mods</span></a>'
      );
      parts.push(
        '<a class="nav-mod' + (currentView === "examples" ? " active" : "") + '" href="#examples">' +
        '<span>Examples Browser</span><span class="file-badge pair">' + DATA.examples.length + ' files</span></a>'
      );
      for (var g = 0; g < DATA.groups.length; g++) {
        var grp = DATA.groups[g];
        var rows = [];
        for (var i = 0; i < grp.modules.length; i++) {
          var mn = grp.modules[i];
          var m = modByName[mn];
          if (!m) continue;
          if (sideMode === "pair" && !m.has_c) continue;
          if (sideMode === "hdr" && m.has_c) continue;
          if (q && mn.toLowerCase().indexOf(q) === -1 && (m.summary || "").toLowerCase().indexOf(q) === -1) continue;
          var cls = (currentView === "mod" && mn === currentModName) ? " active" : "";
          var badge = m.has_c
            ? '<span class="file-badge pair">.h + .c</span>'
            : '<span class="file-badge hdr">.h</span>';
          rows.push(
            '<a class="nav-mod' + cls + '" href="#mod/' + encodeURIComponent(mn) + '">' +
            '<span>' + escHtml(mn) + '</span>' + badge + '</a>'
          );
        }
        if (rows.length > 0) {
          parts.push('<div class="nav-group"><div class="nav-group-title">' + escHtml(grp.title) + '</div>' + rows.join("") + '</div>');
        }
      }
    } else {
      parts.push(
        '<a class="nav-mod' + (currentView === "examples" ? " active" : "") + '" href="#examples">' +
        '<span>Search All 30 Examples</span><span class="file-badge pair">search</span></a>'
      );
      var levels = [
        { key: "beginner",     title: "Level 1: Beginner (01-10)" },
        { key: "intermediate", title: "Level 2: Intermediate (11-20)" },
        { key: "advanced",     title: "Level 3: Advanced (21-30)" }
      ];
      for (var li = 0; li < levels.length; li++) {
        var lv = levels[li];
        var exRows = [];
        for (var ei = 0; ei < DATA.examples.length; ei++) {
          var ex = DATA.examples[ei];
          if (ex.level_key !== lv.key) continue;
          var hay = (ex.num + " " + ex.title + " " + ex.file + " " + ex.topic + " " + ex.modules.join(" ")).toLowerCase();
          if (q && hay.indexOf(q) === -1) continue;
          exRows.push(
            '<a class="nav-mod" href="' + ex.html + '" target="_blank" title="Open ' + escHtml(ex.rel_path) + ' in dark-mode C99 viewer">' +
            '<span class="nav-ex-label"><span class="nav-ex-num">' + escHtml(ex.num) + '</span>' + escHtml(ex.title) + '</span>' +
            '<span style="color:var(--text-muted);font-size:11px">&#8599;</span></a>'
          );
        }
        if (exRows.length > 0) {
          parts.push('<div class="nav-group"><div class="nav-group-title">' + escHtml(lv.title) + '</div>' + exRows.join("") + '</div>');
        }
      }
    }
    navTreeEl.innerHTML = parts.join("");
  }

  sideFilter.addEventListener("input", renderSidebar);

  /* Top-Bar API Fuzzy Search */
  var activeSearchIdx = 0;
  var currentSearchResults = [];

  function runSearch(rawQuery) {
    var q = rawQuery.trim();
    if (!q) {
      searchDrop.classList.remove("open");
      currentSearchResults = [];
      return;
    }
    var kindFilter = null;
    var colon = q.indexOf(":");
    if (colon > 0) {
      var cand = q.slice(0, colon).toLowerCase();
      if (cand === "struct" || cand === "enum" || cand === "typedef" || cand === "macro" || cand === "func" || cand === "module") {
        kindFilter = cand;
        q = q.slice(colon + 1).trim();
      }
    }

    var hits = [];
    for (var i = 0; i < searchItems.length; i++) {
      var it = searchItems[i];
      if (kindFilter && it.kind !== kindFilter) continue;
      if (!q) {
        hits.push({ item: it, score: 1, positions: [] });
        continue;
      }
      var res = fuzzyMatch(q, it.name);
      if (res) {
        hits.push({ item: it, score: res.score, positions: res.positions });
      } else if (it.doc && it.doc.toLowerCase().indexOf(q.toLowerCase()) !== -1) {
        hits.push({ item: it, score: 5, positions: [] });
      }
    }
    hits.sort(function(a, b) {
      if (b.score !== a.score) return b.score - a.score;
      return a.item.name.localeCompare(b.item.name);
    });

    currentSearchResults = hits.slice(0, 40);
    activeSearchIdx = 0;

    if (currentSearchResults.length === 0) {
      searchDrop.innerHTML = '<div class="search-empty">No API matches for "' + escHtml(rawQuery) + '". Try prefixes like <code>struct:</code>, <code>macro:</code>, or <code>func:</code>.</div>';
      searchDrop.classList.add("open");
      return;
    }

    var htmlParts = [
      '<div class="search-header-bar">' +
      '<span>' + hits.length + ' API match' + (hits.length === 1 ? "" : "es") + '</span>' +
      '<span>Enter: docs &middot; Shift+Enter: source &middot; Esc: close</span></div>'
    ];
    for (var r = 0; r < currentSearchResults.length; r++) {
      var h = currentSearchResults[r];
      var itm = h.item;
      var kcls = itm.kind === "module" ? "kind-typedef" : ("kind-" + itm.kind);
      htmlParts.push(
        '<a class="search-item' + (r === 0 ? " active" : "") + '" data-idx="' + r + '" href="' + itm.hash + '">' +
        '<div class="search-item-main">' +
        '<span class="kind-badge ' + kcls + '">' + escHtml(itm.kind) + '</span>' +
        '<span class="search-item-name">' + renderHighlighted(itm.name, h.positions) + '</span>' +
        '</div>' +
        '<div class="search-item-meta"><span>' + escHtml(itm.fileLabel) + '</span></div>' +
        '</a>'
      );
    }
    searchDrop.innerHTML = htmlParts.join("");
    searchDrop.classList.add("open");
  }

  function updateSearchActive() {
    var nodes = searchDrop.querySelectorAll(".search-item");
    for (var i = 0; i < nodes.length; i++) {
      nodes[i].classList.toggle("active", i === activeSearchIdx);
    }
    if (nodes[activeSearchIdx]) nodes[activeSearchIdx].scrollIntoView({ block: "nearest" });
  }

  searchInput.addEventListener("input", function() { runSearch(searchInput.value); });
  searchInput.addEventListener("focus", function() { if (searchInput.value.trim()) runSearch(searchInput.value); });
  searchInput.addEventListener("keydown", function(e) {
    if (!searchDrop.classList.contains("open")) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      if (currentSearchResults.length > 0) {
        activeSearchIdx = (activeSearchIdx + 1) % currentSearchResults.length;
        updateSearchActive();
      }
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      if (currentSearchResults.length > 0) {
        activeSearchIdx = (activeSearchIdx - 1 + currentSearchResults.length) % currentSearchResults.length;
        updateSearchActive();
      }
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (currentSearchResults[activeSearchIdx]) {
        var target = currentSearchResults[activeSearchIdx].item;
        searchDrop.classList.remove("open");
        if (e.shiftKey) window.open(target.srcHref, "_blank");
        else location.hash = target.hash;
      }
    } else if (e.key === "Escape") {
      searchDrop.classList.remove("open");
      searchInput.blur();
    }
  });
  searchDrop.addEventListener("click", function(e) {
    if (e.target.closest(".search-item")) searchDrop.classList.remove("open");
  });
  document.addEventListener("click", function(e) {
    if (!e.target.closest(".search-box")) searchDrop.classList.remove("open");
  });
  document.addEventListener("keydown", function(e) {
    var tag = (document.activeElement && document.activeElement.tagName || "").toLowerCase();
    if ((e.key === "/" && tag !== "input" && tag !== "textarea") || ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k")) {
      e.preventDefault();
      searchInput.focus();
      searchInput.select();
    }
  });

  /* Overview Page (Modules Directory + Quick Links to All 30 Examples) */
  function renderOverview() {
    var t = DATA.totals;
    var out = [];
    out.push(
      '<section class="hero">' +
      '<h1>c_lib API Reference</h1>' +
      '<p>Odin-inspired ISO C99 standard library for Linux, licensed under the <strong>MIT Open Source License</strong> (<code>SPDX-License-Identifier: MIT</code>). Explore all <strong>' + t.modules + '</strong> modules (<code>.h + .c</code> pairs and single <code>.h</code> headers), fuzzy-search every struct, enum, typedef, macro, and function from the top bar, or browse and search all <strong>' + DATA.examples.length + '</strong> progressive examples.</p>' +
      '<div class="stats-row">' +
      '<div class="stat-pill"><strong>MIT</strong> Open Source License</div>' +
      '<div class="stat-pill"><strong>' + t.modules + '</strong> Modules (' + t.paired + ' .h+.c, ' + t.header_only + ' .h)</div>' +
      '<div class="stat-pill"><strong>' + t.structs + '</strong> Structs</div>' +
      '<div class="stat-pill"><strong>' + t.enums + '</strong> Enums</div>' +
      '<div class="stat-pill"><strong>' + t.typedefs + '</strong> Typedefs</div>' +
      '<div class="stat-pill"><strong>' + t.macros + '</strong> Macros</div>' +
      '<div class="stat-pill"><strong>' + t.funcs + '</strong> Functions</div>' +
      '<a class="hero-cta" href="#examples">Browse &amp; Search 30 Examples &rarr;</a>' +
      '</div></section>'
    );

    var tocParts = ['<div class="toc-heading">Overview</div>'];
    for (var g = 0; g < DATA.groups.length; g++) {
      var grp = DATA.groups[g];
      var gid = "grp-" + g;
      tocParts.push('<a class="toc-link sec" href="javascript:void(0)" data-scroll="' + gid + '">' + escHtml(grp.title) + '</a>');
      out.push('<section class="group-section" id="' + gid + '"><h2><span>' + escHtml(grp.title) + '</span></h2><div class="mod-grid">');
      for (var i = 0; i < grp.modules.length; i++) {
        var m = modByName[grp.modules[i]];
        if (!m) continue;
        var badge = m.has_c
          ? '<span class="file-badge pair">.h + .c</span>'
          : '<span class="file-badge hdr">.h only</span>';
        var srcLinks = '<a href="' + m.h_html + '" target="_blank">' + escHtml(m.h_file) + '</a>';
        if (m.has_c) srcLinks += '<a href="' + m.c_html + '" target="_blank">' + escHtml(m.c_file) + '</a>';
        out.push(
          '<div class="mod-card">' +
          '<div class="mod-card-top">' +
          '<a class="mod-card-name" href="#mod/' + encodeURIComponent(m.name) + '">' + escHtml(m.name) + '</a>' +
          badge + '</div>' +
          '<div class="mod-card-desc">' + escHtml(m.summary || "Header module.") + '</div>' +
          '<div class="mod-card-foot">' +
          '<span>' + m.symbols.length + ' symbols</span>' +
          '<span class="src-mini-links">' + srcLinks + '</span>' +
          '</div></div>'
        );
      }
      out.push('</div></section>');
    }

    /* Quick Links to All 30 Examples right on Overview too! */
    tocParts.push('<a class="toc-link sec" href="javascript:void(0)" data-scroll="quick-examples">30 Examples Quick Links</a>');
    out.push(
      '<section class="group-section" id="quick-examples">' +
      '<h2><span>Quick Links: All 30 Examples</span><a style="font-size:13px" href="#examples">Open Dedicated Examples Search &rarr;</a></h2>' +
      '<div class="ex-quick-grid">'
    );
    for (var ei = 0; ei < DATA.examples.length; ei++) {
      var ex = DATA.examples[ei];
      out.push(
        '<a class="ex-quick-link" href="' + ex.html + '" target="_blank" title="' + escHtml(ex.topic) + '">' +
        '<span class="ex-quick-left"><span class="ex-num">' + escHtml(ex.num) + '</span>' +
        '<span class="ex-quick-title">' + escHtml(ex.title) + '</span></span>' +
        '<span class="lvl-badge lvl-' + ex.level_key + '">' + escHtml(ex.level_key.slice(0, 3)) + '</span>' +
        '</a>'
      );
    }
    out.push('</div></section>');

    contentEl.innerHTML = out.join("");
    rightTocEl.innerHTML = tocParts.join("");
    bindTocScroll();
  }

  /* Dedicated Examples Browser & Separate Examples Search Page (#examples) */
  var exQuery = "";
  var exLevelFilter = "all";

  function renderExamplesPage() {
    var out = [];
    out.push(
      '<div class="mod-header">' +
      '<div><h1 class="mod-title"><span class="pkg-prefix">c_lib/</span>examples <span class="file-badge pair">' + DATA.examples.length + ' runnable C99 examples</span></h1></div>' +
      '<div class="mod-files"><a class="src-btn" href="#overview">&larr; Back to API Reference</a></div>' +
      '</div>'
    );
    out.push(
      '<div class="ex-search-panel">' +
      '<input id="exSearchInput" class="ex-search-input" type="search" ' +
      'value="' + escHtml(exQuery) + '" ' +
      'placeholder="Search 30 examples by title, topic, concept, or c_lib API (e.g. dft, arena, defer, tracking, map, quaternion, csv, panic)...">' +
      '<div class="filter-bar" style="margin-bottom:0">' +
      '<button type="button" class="filter-pill ex-lvl-pill' + (exLevelFilter === "all" ? " active" : "") + '" data-lvl="all">All (30)</button>' +
      '<button type="button" class="filter-pill ex-lvl-pill' + (exLevelFilter === "beginner" ? " active" : "") + '" data-lvl="beginner">Level 1: Beginner (10)</button>' +
      '<button type="button" class="filter-pill ex-lvl-pill' + (exLevelFilter === "intermediate" ? " active" : "") + '" data-lvl="intermediate">Level 2: Intermediate (10)</button>' +
      '<button type="button" class="filter-pill ex-lvl-pill' + (exLevelFilter === "advanced" ? " active" : "") + '" data-lvl="advanced">Level 3: Advanced (10)</button>' +
      '</div></div>'
    );
    out.push('<div id="exResultsContainer"></div>');
    contentEl.innerHTML = out.join("");

    var exInput = document.getElementById("exSearchInput");
    exInput.addEventListener("input", function() {
      exQuery = exInput.value;
      renderExamplesResults();
    });
    var lvlBtns = contentEl.querySelectorAll(".ex-lvl-pill");
    for (var i = 0; i < lvlBtns.length; i++) {
      lvlBtns[i].addEventListener("click", function() {
        exLevelFilter = this.getAttribute("data-lvl");
        for (var j = 0; j < lvlBtns.length; j++) {
          lvlBtns[j].classList.toggle("active", lvlBtns[j] === this);
        }
        renderExamplesResults();
      });
    }
    renderExamplesResults();
  }

  function renderExamplesResults() {
    var container = document.getElementById("exResultsContainer");
    if (!container) return;
    var q = (exQuery || "").trim();
    var qLow = q.toLowerCase();

    var matches = [];
    for (var i = 0; i < DATA.examples.length; i++) {
      var ex = DATA.examples[i];
      if (exLevelFilter !== "all" && ex.level_key !== exLevelFilter) continue;
      if (!q) {
        matches.push({ ex: ex, score: 0, titlePos: [] });
        continue;
      }
      var tokens = q.split(/\s+/).filter(Boolean);
      var totalScore = 0;
      var allMatched = true;
      var titlePosMap = {};
      var fullLow = (ex.num + " " + ex.title + " " + ex.file + " " + ex.level_title + " " +
                     ex.topic + " " + ex.doc + " " + ex.modules.join(" ") + " " +
                     ex.all_symbol_names.join(" ")).toLowerCase();

      for (var ti = 0; ti < tokens.length; ti++) {
        var tok = tokens[ti];
        var tokLow = tok.toLowerCase();
        var tokBest = -1;
        var mTitle = fuzzyMatch(tok, ex.title);
        if (mTitle) {
          tokBest = Math.max(tokBest, mTitle.score + 50);
          for (var pi = 0; pi < mTitle.positions.length; pi++) titlePosMap[mTitle.positions[pi]] = true;
        }
        var mFile = fuzzyMatch(tok, ex.file);
        if (mFile) tokBest = Math.max(tokBest, mFile.score + 30);
        if (ex.topic.toLowerCase().indexOf(tokLow) !== -1) tokBest = Math.max(tokBest, 45);
        if (ex.doc.toLowerCase().indexOf(tokLow) !== -1) tokBest = Math.max(tokBest, 25);
        for (var s = 0; s < ex.all_symbol_names.length; s++) {
          var ms = fuzzyMatch(tok, ex.all_symbol_names[s]);
          if (ms) { tokBest = Math.max(tokBest, ms.score + 20); break; }
        }
        if (tokBest < 0 && fullLow.indexOf(tokLow) !== -1) tokBest = 15;
        if (tokBest < 0) { allMatched = false; break; }
        totalScore += tokBest;
      }
      if (allMatched) {
        var titlePos = [];
        for (var kPos in titlePosMap) {
          if (Object.prototype.hasOwnProperty.call(titlePosMap, kPos)) titlePos.push(parseInt(kPos, 10));
        }
        matches.push({ ex: ex, score: totalScore, titlePos: titlePos });
      }
    }
    if (q) {
      matches.sort(function(a, b) { return b.score - a.score; });
    }

    var tocParts = ['<div class="toc-heading">Examples (' + matches.length + ')</div>'];
    if (matches.length === 0) {
      container.innerHTML = '<div class="search-empty">No examples matched "' + escHtml(q) + '".</div>';
      rightTocEl.innerHTML = tocParts.join("");
      return;
    }

    var cards = ['<p style="color:var(--text-muted);font-size:13px;margin:0 0 14px">Showing <strong>' + matches.length + '</strong> of ' + DATA.examples.length + ' examples. Click <strong>Open Code</strong> to inspect the full C99 source in dark mode.</p>'];
    for (var k = 0; k < matches.length; k++) {
      var exm = matches[k].ex;
      var cardId = "ex-card-" + exm.num;
      tocParts.push('<a class="toc-link sym" href="javascript:void(0)" data-scroll="' + cardId + '">' + escHtml(exm.num + " " + exm.title) + '</a>');

      var symChips = [];
      for (var si = 0; si < exm.symbols.length; si++) {
        var sy = exm.symbols[si];
        symChips.push(
          '<a class="ex-sym-chip" href="#sym/' + encodeURIComponent(sy.mod) + '/' + encodeURIComponent(sy.sym_id) + '">' +
          escHtml(sy.name) + '</a>'
        );
      }

      cards.push(
        '<article class="ex-card" id="' + cardId + '">' +
        '<div class="ex-card-head">' +
        '<div class="ex-card-title-wrap">' +
        '<span class="ex-num">#' + escHtml(exm.num) + '</span>' +
        '<span class="ex-title">' + renderHighlighted(exm.title, matches[k].titlePos) + '</span>' +
        '<span class="lvl-badge lvl-' + exm.level_key + '">' + escHtml(exm.level_title) + '</span>' +
        '</div>' +
        '<div class="sym-links">' +
        '<a class="src-btn primary" href="' + exm.html + '" target="_blank">Open Code (' + exm.lines + ' lines) &#8599;</a>' +
        '</div>' +
        '</div>' +
        '<div class="ex-card-body">' +
        '<p class="ex-topic">' + escHtml(exm.topic || exm.rel_path) + '</p>' +
        (symChips.length ? '<div class="ex-tags">' + symChips.join("") + '</div>' : '') +
        '<details class="ex-details"><summary>Read full rationale (Why, When, Advantages &amp; Disadvantages)</summary>' +
        '<div class="ex-details-body">' + escHtml(exm.doc) + '</div></details>' +
        '</div></article>'
      );
    }
    container.innerHTML = cards.join("");
    rightTocEl.innerHTML = tocParts.join("");
    bindTocScroll();
  }

  /* Individual Module Reference Page */
  var activeKindFilter = "all";
  var SECTION_ORDER = [
    { kind: "struct",  title: "Structs & Types" },
    { kind: "enum",    title: "Enums" },
    { kind: "typedef", title: "Typedefs" },
    { kind: "macro",   title: "Macros & Constants" },
    { kind: "func",    title: "Functions" }
  ];

  function renderModule(mod, focusSymId) {
    var filesHtml = '<a class="src-btn" href="' + mod.h_html + '" target="_blank">View ' + escHtml(mod.h_file) + ' &#8599;</a>';
    if (mod.has_c) {
      filesHtml += '<a class="src-btn" href="' + mod.c_html + '" target="_blank">View ' + escHtml(mod.c_file) + ' &#8599;</a>';
    }
    var pairBadge = mod.has_c
      ? '<span class="file-badge pair">.h + .c pair</span>'
      : '<span class="file-badge hdr">header-only .h</span>';

    var counts = { all: mod.symbols.length, struct: 0, enum: 0, typedef: 0, macro: 0, func: 0 };
    for (var i = 0; i < mod.symbols.length; i++) counts[mod.symbols[i].kind] = (counts[mod.symbols[i].kind] || 0) + 1;

    var out = [];
    out.push(
      '<div class="mod-header">' +
      '<div><h1 class="mod-title"><span class="pkg-prefix">c_lib/</span>' + escHtml(mod.name) + ' ' + pairBadge + '</h1></div>' +
      '<div class="mod-files">' + filesHtml + '</div>' +
      '</div>'
    );

    if (mod.doc) {
      out.push('<div class="mod-doc">' + formatDocHtml(mod.doc) + '</div>');
    }

    if (mod.includes && mod.includes.length > 0) {
      var incChips = [];
      for (var ic = 0; ic < mod.includes.length; ic++) {
        var iname = mod.includes[ic];
        if (modByName[iname]) {
          incChips.push('<a class="inc-chip" href="#mod/' + encodeURIComponent(iname) + '">' + escHtml(iname + ".h") + '</a>');
        }
      }
      if (incChips.length > 0) {
        out.push('<div class="includes-bar"><span>Includes:</span>' + incChips.join("") + '</div>');
      }
    }

    /* Related examples quick links for this module */
    var relEx = modExamples[mod.name] || [];
    if (relEx.length > 0) {
      var exChips = [];
      for (var re = 0; re < relEx.length; re++) {
        var rx = relEx[re];
        exChips.push(
          '<a class="inc-chip" href="' + rx.html + '" target="_blank" title="' + escHtml(rx.topic) + '">' +
          '#' + escHtml(rx.num) + ' ' + escHtml(rx.title) + ' &#8599;</a>'
        );
      }
      out.push('<div class="includes-bar"><span>Used in Examples:</span>' + exChips.join("") + '</div>');
    }

    var pills = [
      { k: "all",     label: "All (" + counts.all + ")" },
      { k: "struct",  label: "Structs (" + counts.struct + ")" },
      { k: "enum",    label: "Enums (" + counts.enum + ")" },
      { k: "typedef", label: "Typedefs (" + counts.typedef + ")" },
      { k: "macro",   label: "Macros (" + counts.macro + ")" },
      { k: "func",    label: "Functions (" + counts.func + ")" }
    ];
    out.push('<div class="filter-bar">');
    for (var p = 0; p < pills.length; p++) {
      if (pills[p].k !== "all" && counts[pills[p].k] === 0) continue;
      out.push(
        '<button type="button" class="filter-pill' + (activeKindFilter === pills[p].k ? " active" : "") +
        '" data-kind="' + pills[p].k + '">' + pills[p].label + '</button>'
      );
    }
    out.push('</div>');

    var visibleSyms = mod.symbols.filter(function(s) {
      return activeKindFilter === "all" || s.kind === activeKindFilter;
    });
    if (visibleSyms.length > 0) {
      out.push('<div class="index-box"><h3>Index</h3><div class="index-chips">');
      for (var ix = 0; ix < visibleSyms.length; ix++) {
        var vs = visibleSyms[ix];
        out.push(
          '<a class="index-chip" href="#sym/' + encodeURIComponent(mod.name) + '/' + encodeURIComponent(vs.id) + '">' +
          '<span class="kind-badge kind-' + vs.kind + '">' + vs.kind[0] + '</span>' +
          escHtml(vs.name) + '</a>'
        );
      }
      out.push('</div></div>');
    }

    var tocParts = ['<div class="toc-heading">On This Page</div>'];
    for (var si = 0; si < SECTION_ORDER.length; si++) {
      var sec = SECTION_ORDER[si];
      if (activeKindFilter !== "all" && activeKindFilter !== sec.kind) continue;
      var items = mod.symbols.filter(function(s) { return s.kind === sec.kind; });
      if (items.length === 0) continue;

      var secId = "sec-" + sec.kind;
      tocParts.push('<a class="toc-link sec" href="javascript:void(0)" data-scroll="' + secId + '">' + escHtml(sec.title) + ' (' + items.length + ')</a>');
      out.push('<h2 class="sec-title" id="' + secId + '">' + escHtml(sec.title) + ' <span class="sec-count">' + items.length + '</span></h2>');

      for (var k = 0; k < items.length; k++) {
        var sym = items[k];
        tocParts.push(
          '<a class="toc-link sym" href="#sym/' + encodeURIComponent(mod.name) + '/' + encodeURIComponent(sym.id) + '">' +
          escHtml(sym.name) + '</a>'
        );
        var subBadge = "";
        if (sym.is_inline) subBadge = '<span class="sym-subbadge">static inline</span>';
        else if (sym.generated_by) subBadge = '<span class="sym-subbadge">' + escHtml(sym.generated_by) + '</span>';

        var srcLinks =
          '<a class="src-jump" href="' + mod.h_html + '#L' + sym.line + '" target="_blank" title="Open header declaration in dark-mode C99 viewer">' +
          escHtml(mod.h_file) + ':' + sym.line + ' &#8599;</a>';
        if (sym.impl_line && mod.has_c) {
          srcLinks +=
            '<a class="src-jump impl" href="' + mod.c_html + '#L' + sym.impl_line + '" target="_blank" title="Open .c implementation in dark-mode C99 viewer">' +
            'impl ' + escHtml(mod.c_file) + ':' + sym.impl_line + ' &#8599;</a>';
        }

        out.push(
          '<article class="sym-card" id="card-' + escHtml(sym.id) + '">' +
          '<div class="sym-head">' +
          '<div class="sym-left">' +
          '<span class="kind-badge kind-' + sym.kind + '">' + escHtml(sym.kind) + '</span>' +
          '<a class="sym-name" href="#sym/' + encodeURIComponent(mod.name) + '/' + encodeURIComponent(sym.id) + '">' + escHtml(sym.name) + '</a>' +
          subBadge +
          '</div>' +
          '<div class="sym-links">' + srcLinks + '</div>' +
          '</div>' +
          '<pre class="sym-code"><code>' + sym.sig_html + '</code></pre>' +
          (sym.doc ? '<div class="sym-doc">' + formatDocHtml(sym.doc) + '</div>' : '') +
          '</article>'
        );
      }
    }

    contentEl.innerHTML = out.join("");
    rightTocEl.innerHTML = tocParts.join("");
    bindTocScroll();

    var pillBtns = contentEl.querySelectorAll(".filter-pill");
    for (var b = 0; b < pillBtns.length; b++) {
      pillBtns[b].addEventListener("click", function() {
        activeKindFilter = this.getAttribute("data-kind");
        renderModule(mod, null);
      });
    }

    if (focusSymId) {
      var card = document.getElementById("card-" + focusSymId);
      if (card) {
        card.classList.add("flash");
        card.scrollIntoView({ behavior: "smooth", block: "start" });
        setTimeout(function() { card.classList.remove("flash"); }, 1800);
      }
    }
  }

  function bindTocScroll() {
    var links = rightTocEl.querySelectorAll("[data-scroll]");
    for (var i = 0; i < links.length; i++) {
      links[i].addEventListener("click", function() {
        var el = document.getElementById(this.getAttribute("data-scroll"));
        if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    }
  }

  function syncNavLinks() {
    if (navLinkApi) navLinkApi.classList.toggle("active", currentView !== "examples");
    if (navLinkEx)  navLinkEx.classList.toggle("active", currentView === "examples");
  }

  /* Hash Router (#overview, #examples, #mod/<name>, #sym/<mod>/<symId>) */
  function route() {
    sidebarEl.classList.remove("open");
    var hash = location.hash || "#overview";
    if (hash === "#examples" || hash.indexOf("#examples/") === 0) {
      currentView = "examples";
      currentModName = null;
      sidePane = "examples";
      syncSidebarTabs();
      syncNavLinks();
      renderSidebar();
      renderExamplesPage();
      window.scrollTo({ top: 0, behavior: "instant" });
      return;
    }
    if (hash.indexOf("#sym/") === 0) {
      var parts = hash.slice(5).split("/");
      var mName = decodeURIComponent(parts[0] || "");
      var symId = decodeURIComponent(parts.slice(1).join("/") || "");
      var mod = modByName[mName];
      if (mod) {
        var needFull = (currentView !== "mod" || currentModName !== mName || activeKindFilter !== "all");
        currentView = "mod";
        currentModName = mName;
        activeKindFilter = "all";
        sidePane = "modules";
        syncSidebarTabs();
        syncNavLinks();
        renderSidebar();
        if (needFull) {
          renderModule(mod, symId);
        } else {
          var card = document.getElementById("card-" + symId);
          if (card) {
            card.classList.add("flash");
            card.scrollIntoView({ behavior: "smooth", block: "start" });
            setTimeout(function() { card.classList.remove("flash"); }, 1800);
          }
        }
        return;
      }
    } else if (hash.indexOf("#mod/") === 0) {
      var mName2 = decodeURIComponent(hash.slice(5));
      var mod2 = modByName[mName2];
      if (mod2) {
        currentView = "mod";
        currentModName = mName2;
        activeKindFilter = "all";
        sidePane = "modules";
        syncSidebarTabs();
        syncNavLinks();
        renderSidebar();
        renderModule(mod2, null);
        window.scrollTo({ top: 0, behavior: "instant" });
        return;
      }
    }
    currentView = "overview";
    currentModName = null;
    syncSidebarTabs();
    syncNavLinks();
    renderSidebar();
    renderOverview();
    window.scrollTo({ top: 0, behavior: "instant" });
  }

  window.addEventListener("hashchange", route);
  route();
})();
"""


def generate_docs(clib_dir, examples_dir, out_dir):
    inc_dir = clib_dir / "include" / "cl"
    src_dir = clib_dir / "src"
    out_src_dir = out_dir / "src"
    out_ex_dir = out_dir / "examples"
    out_src_dir.mkdir(parents=True, exist_ok=True)
    out_ex_dir.mkdir(parents=True, exist_ok=True)

    headers = sorted(inc_dir.glob("*.h"), key=lambda p: p.name)
    modules_data = []
    sym_to_mod = {}
    sym_to_id = {}
    totals = {
        "modules": 0, "paired": 0, "header_only": 0,
        "structs": 0, "enums": 0, "typedefs": 0, "macros": 0, "funcs": 0,
        "examples": 0,
    }

    for h_path in headers:
        mod_name = h_path.stem
        c_path = src_dir / f"{mod_name}.c"
        has_c = c_path.exists()

        c_impls = {}
        if has_c:
            c_impls = find_c_implementations(c_path.read_text(encoding="utf-8"))

        file_doc, includes, symbols = parse_header(h_path, c_impls)

        h_html_name = f"{h_path.name}.html"
        c_html_name = f"{c_path.name}.html" if has_c else None

        h_peer_btn = (
            f'<a class="pill-btn" href="{html.escape(c_html_name)}">Switch to {html.escape(c_path.name)}</a>'
            if has_c else ""
        )
        (out_src_dir / h_html_name).write_text(
            render_code_viewer_html(
                h_path,
                f"c_lib/include/cl/{h_path.name}",
                f"../index.html#mod/{mod_name}",
                f"{mod_name} docs",
                nav_buttons_html=h_peer_btn,
            ),
            encoding="utf-8",
        )

        if has_c:
            c_peer_btn = f'<a class="pill-btn" href="{html.escape(h_html_name)}">Switch to {html.escape(h_path.name)}</a>'
            (out_src_dir / c_html_name).write_text(
                render_code_viewer_html(
                    c_path,
                    f"c_lib/src/{c_path.name}",
                    f"../index.html#mod/{mod_name}",
                    f"{mod_name} docs",
                    nav_buttons_html=c_peer_btn,
                ),
                encoding="utf-8",
            )

        id_counter = {}
        enriched_syms = []
        for sym in symbols:
            base_id = re.sub(r"[^A-Za-z0-9_]", "_", f"{sym['kind']}_{sym['name']}")
            cnt = id_counter.get(base_id, 0)
            id_counter[base_id] = cnt + 1
            sym_id = base_id if cnt == 0 else f"{base_id}_{cnt}"

            # Map symbol name -> owning module/id for example cross-linking
            if sym["name"] not in sym_to_mod:
                sym_to_mod[sym["name"]] = mod_name
                sym_to_id[sym["name"]] = sym_id

            sym_entry = {
                "id": sym_id,
                "name": sym["name"],
                "kind": sym["kind"],
                "line": sym["line"],
                "sig_html": highlight_c_code(sym["signature"]),
                "doc": sym["doc"],
            }
            if sym.get("is_inline"):
                sym_entry["is_inline"] = True
            if sym.get("generated_by"):
                sym_entry["generated_by"] = sym["generated_by"]
            if sym.get("impl_line"):
                sym_entry["impl_line"] = sym["impl_line"]
            enriched_syms.append(sym_entry)

            if sym["kind"] == "struct":
                totals["structs"] += 1
            elif sym["kind"] == "enum":
                totals["enums"] += 1
            elif sym["kind"] == "typedef":
                totals["typedefs"] += 1
            elif sym["kind"] == "macro":
                totals["macros"] += 1
            elif sym["kind"] == "func":
                totals["funcs"] += 1

        totals["modules"] += 1
        if has_c:
            totals["paired"] += 1
        else:
            totals["header_only"] += 1

        modules_data.append({
            "name": mod_name,
            "h_file": h_path.name,
            "c_file": c_path.name if has_c else None,
            "has_c": has_c,
            "h_html": f"src/{h_html_name}",
            "c_html": f"src/{c_html_name}" if has_c else None,
            "includes": includes,
            "doc": file_doc,
            "summary": build_summary(file_doc, "purpose:"),
            "symbols": enriched_syms,
        })

    # Parse all 30 examples and render dark-mode syntax-highlighted example viewers
    examples_raw = parse_examples(examples_dir, sym_to_mod, sym_to_id)
    examples_data = []
    for idx, ex in enumerate(examples_raw):
        nav_btns = []
        if idx > 0:
            prev_ex = examples_raw[idx - 1]
            nav_btns.append(f'<a class="pill-btn" href="{html.escape(prev_ex["file"] + ".html")}">&larr; #{prev_ex["num"]}</a>')
        if idx + 1 < len(examples_raw):
            next_ex = examples_raw[idx + 1]
            nav_btns.append(f'<a class="pill-btn" href="{html.escape(next_ex["file"] + ".html")}">#{next_ex["num"]} &rarr;</a>')

        (out_ex_dir / f"{ex['file']}.html").write_text(
            render_code_viewer_html(
                ex["path"],
                f"c_lib_examples/{ex['rel_path']}",
                "../index.html#examples",
                "Examples Browser",
                nav_buttons_html="".join(nav_btns),
            ),
            encoding="utf-8",
        )

        ex_clean = {k: v for k, v in ex.items() if k != "path"}
        examples_data.append(ex_clean)
    totals["examples"] = len(examples_data)

    # Ordered module groups
    known_mods = {m["name"] for m in modules_data}
    assigned = set()
    groups_out = []
    for title, names in MODULE_GROUPS:
        present = [nm for nm in names if nm in known_mods]
        if present:
            groups_out.append({"title": title, "modules": present})
            assigned.update(present)
    leftover = sorted(known_mods - assigned)
    if leftover:
        groups_out.append({"title": "Other Modules", "modules": leftover})

    payload = {
        "generated_at": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        "totals": totals,
        "groups": groups_out,
        "modules": modules_data,
        "examples": examples_data,
    }
    safe_json = json.dumps(payload, ensure_ascii=True).replace("</", "<\\/")

    index_html = f"""<!DOCTYPE html>
<!-- License: MIT Open Source License (SPDX-License-Identifier: MIT) -->
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>c_lib — C99 Reference Documentation &amp; 30 Examples</title>
<style>{MAIN_CSS}</style>
</head>
<body>
<header class="navbar">
  <button class="icon-btn menu-btn" id="menuBtn" type="button" aria-label="Toggle Sidebar">&#9776;</button>
  <a class="brand" href="#overview">
    <span class="brand-mark">cl</span>
    <span>c_lib</span>
    <span class="brand-ver">C99 / MIT</span>
  </a>

  <nav class="nav-links">
    <a id="navLinkApi" class="nav-link active" href="#overview">API Reference</a>
    <a id="navLinkEx" class="nav-link" href="#examples">Examples ({totals['examples']})</a>
  </nav>

  <div class="search-box">
    <div class="search-input-wrap">
      <span class="search-icon">&#128269;</span>
      <input id="searchInput" class="search-input" type="search"
             placeholder="Fuzzy search API structs, macros, functions... (try: c128, arena, macro:defer)"
             autocomplete="off" spellcheck="false">
      <span class="search-kbd">/ or Ctrl+K</span>
    </div>
    <div id="searchDropdown" class="search-dropdown"></div>
  </div>

  <div class="nav-actions">
    <button id="themeBtn" class="icon-btn" type="button">Light Mode</button>
  </div>
</header>

<div class="layout">
  <aside id="sidebar" class="sidebar">
    <div class="sidebar-primary-tabs" role="tablist" aria-label="Browse Modules or Examples">
      <button type="button" class="side-primary-tab active" data-pane="modules">Modules ({totals['modules']})</button>
      <button type="button" class="side-primary-tab" data-pane="examples">Examples ({totals['examples']})</button>
    </div>
    <input id="sidebarFilter" class="sidebar-filter" type="search" placeholder="Filter modules...">
    <div id="sidebarFileTabs" class="sidebar-tabs" role="tablist" aria-label="Filter by module file type">
      <button type="button" class="side-tab active" data-mode="all">All</button>
      <button type="button" class="side-tab" data-mode="pair">.h + .c</button>
      <button type="button" class="side-tab" data-mode="hdr">.h only</button>
    </div>
    <nav id="navTree"></nav>
  </aside>
  <main id="content" class="content"></main>
  <aside id="rightToc" class="right-toc"></aside>
</div>

<script>window.CLIB_DOCS = {safe_json};</script>
<script>{MAIN_JS}</script>
</body>
</html>
"""

    (out_dir / "index.html").write_text(index_html, encoding="utf-8")
    return totals


def main():
    script_dir = Path(__file__).resolve().parent
    default_clib = script_dir.parent / "c_lib"
    default_examples = script_dir.parent / "c_lib_examples"

    parser = argparse.ArgumentParser(
        description="Generate Odin-style HTML reference docs, 30-example browser, and dark-mode C99 source viewers for c_lib."
    )
    parser.add_argument("--clib-dir", type=Path, default=default_clib)
    parser.add_argument("--examples-dir", type=Path, default=default_examples)
    parser.add_argument("--out-dir", type=Path, default=script_dir)
    args = parser.parse_args()

    totals = generate_docs(args.clib_dir, args.examples_dir, args.out_dir)
    print(
        f"Generated c_lib HTML reference in {args.out_dir}:\n"
        f"  Modules  : {totals['modules']} ({totals['paired']} .h+.c pairs, {totals['header_only']} .h only)\n"
        f"  Structs  : {totals['structs']}\n"
        f"  Enums    : {totals['enums']}\n"
        f"  Typedefs : {totals['typedefs']}\n"
        f"  Macros   : {totals['macros']}\n"
        f"  Functions: {totals['funcs']}\n"
        f"  Examples : {totals['examples']} (dark-mode viewers in examples/)\n"
        f"Open {args.out_dir / 'index.html'} in your browser."
    )


if __name__ == "__main__":
    main()
