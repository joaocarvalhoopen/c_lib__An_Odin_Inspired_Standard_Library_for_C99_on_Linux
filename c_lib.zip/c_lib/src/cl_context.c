/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_context.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Implementation of the thread-local Cl_Context stack and conflict-free
 *   dual virtual-memory scratch arenas.
 * ============================================================================
 */

#include "cl/cl_context.h"

#if CL_COMPILER_GNU_COMPAT
    /*
     * Storage-class qualifier declaring a file-scoped thread-local variable
     * using GNU __thread (wrapped in CL_EXTENSION for strict -Wpedantic).
     */
    #define CL_TLS CL_EXTENSION static __thread
#else
    /*
     * Fallback storage-class qualifier (plain static) for compilers without
     * GNU __thread thread-local storage support.
     */
    #define CL_TLS static
#endif

CL_TLS Cl_Context       cl_tls_ctx_stack[CL_CONTEXT_STACK_MAX];
CL_TLS cl_isize         cl_tls_ctx_depth = 0;
CL_TLS bool             cl_tls_ctx_initialized = false;
CL_TLS Cl_Virtual_Arena cl_tls_scratch[2];
CL_TLS bool             cl_tls_scratch_ready = false;

/*
 * Lazily initializes the calling thread's two conflict-free scratch virtual
 * arenas (each reserving 8 MiB virtual space with 64 KiB commit chunks).
 * Asserts via CL_ENSURE that both mmap reservations succeed.
 */
static void cl_tls_ensure_scratch(void) {
    if (!cl_tls_scratch_ready) {
        bool ok0 = cl_varena_init(&cl_tls_scratch[0], CL_MB(8), CL_KB(64));
        bool ok1 = cl_varena_init(&cl_tls_scratch[1], CL_MB(8), CL_KB(64));
        CL_ENSURE(ok0 && ok1);
        cl_tls_scratch_ready = true;
    }
}

/*
 * Synchronizes global/subsystem active logger and assertion callback state
 * with the fields of the given active Cl_Context.
 *
 * Parameters:
 *   ctx (const Cl_Context *) - Active context whose logger and assert_proc are applied.
 */
static void cl_tls_sync_subsystems(const Cl_Context *ctx) {
    cl_log_set_active(ctx->logger);
    cl_assert_set_proc(ctx->assert_proc ? ctx->assert_proc : cl_default_assert_proc);
}

/*
 * Builds a default Cl_Context for the calling thread using cl_heap_allocator(),
 * scratch virtual arena 0 as temp_allocator, the default debug console logger,
 * and cl_default_assert_proc.
 *
 * Returns:
 *   (Cl_Context) Populated default context struct.
 */
Cl_Context cl_ctx_default(void) {
    cl_tls_ensure_scratch();
    Cl_Context ctx;
    ctx.allocator      = cl_heap_allocator();
    ctx.temp_allocator = cl_varena_allocator(&cl_tls_scratch[0]);
    ctx.logger         = cl_console_logger(CL_LOG_LEVEL_DEBUG, CL_LOG_DEFAULT_OPTIONS);
    ctx.assert_proc    = cl_default_assert_proc;
    ctx.user_ptr       = NULL;
    ctx.user_index     = 0;
    return ctx;
}

/*
 * Lazily initializes the calling thread's context stack with a single root
 * default context frame and synchronizes logger and assert subsystems.
 */
static void cl_tls_ensure_ctx(void) {
    if (!cl_tls_ctx_initialized) {
        cl_tls_ctx_stack[0]   = cl_ctx_default();
        cl_tls_ctx_depth      = 1;
        cl_tls_ctx_initialized = true;
        cl_tls_sync_subsystems(&cl_tls_ctx_stack[0]);
    }
}

/*
 * Returns a mutable pointer to the top Cl_Context on the calling thread's
 * context stack after ensuring lazy initialization.
 *
 * Returns:
 *   (Cl_Context *) Non-NULL pointer to the active thread-local context.
 */
Cl_Context *cl_ctx_current(void) {
    cl_tls_ensure_ctx();
    return &cl_tls_ctx_stack[cl_tls_ctx_depth - 1];
}

/*
 * Pushes ctx onto the thread-local context stack, inheriting any unset
 * allocator, temp_allocator, logger, or assert_proc from the previous top
 * frame, and synchronizes active subsystems.
 *
 * Parameters:
 *   ctx (Cl_Context) - New context frame to push onto the thread-local stack.
 *
 * Returns:
 *   (bool) true on success; false if cl_tls_ctx_depth >= CL_CONTEXT_STACK_MAX.
 */
bool cl_ctx_push(Cl_Context ctx) {
    cl_tls_ensure_ctx();
    if (cl_tls_ctx_depth >= CL_CONTEXT_STACK_MAX) {
        return false;
    }
    const Cl_Context *prev = &cl_tls_ctx_stack[cl_tls_ctx_depth - 1];
    /* Fill any zeroed fields by inheriting from the previous context */
    if (!cl_allocator_is_valid(ctx.allocator)) {
        ctx.allocator = prev->allocator;
    }
    if (!cl_allocator_is_valid(ctx.temp_allocator)) {
        ctx.temp_allocator = prev->temp_allocator;
    }
    if (ctx.logger.proc == NULL) {
        ctx.logger = prev->logger;
    }
    if (ctx.assert_proc == NULL) {
        ctx.assert_proc = prev->assert_proc;
    }
    cl_tls_ctx_stack[cl_tls_ctx_depth++] = ctx;
    cl_tls_sync_subsystems(&cl_tls_ctx_stack[cl_tls_ctx_depth - 1]);
    return true;
}

/*
 * Pops the top frame from the thread-local context stack (preserving the root
 * frame when depth == 1) and resynchronizes logger and assert subsystems.
 */
void cl_ctx_pop(void) {
    cl_tls_ensure_ctx();
    if (cl_tls_ctx_depth > 1) {
        cl_tls_ctx_depth -= 1;
        cl_tls_sync_subsystems(&cl_tls_ctx_stack[cl_tls_ctx_depth - 1]);
    }
}

/*
 * Retrieves the general-purpose allocator from the active thread-local context.
 *
 * Returns:
 *   (Cl_Allocator) Current context's allocator handle.
 */
Cl_Allocator cl_ctx_allocator(void) {
    return cl_ctx_current()->allocator;
}

/*
 * Retrieves the temporary/scratch allocator from the active thread-local context.
 *
 * Returns:
 *   (Cl_Allocator) Current context's temp_allocator handle.
 */
Cl_Allocator cl_ctx_temp_allocator(void) {
    return cl_ctx_current()->temp_allocator;
}

/*
 * Retrieves the structured logger from the active thread-local context.
 *
 * Returns:
 *   (Cl_Logger) Current context's logger handle.
 */
Cl_Logger cl_ctx_logger(void) {
    return cl_ctx_current()->logger;
}

/*
 * Resets the calling thread's current temp_allocator in O(1) by issuing
 * cl_free_all() on it.
 */
void cl_ctx_temp_reset(void) {
    cl_tls_ensure_ctx();
    cl_free_all(cl_ctx_current()->temp_allocator);
}

/*
 * Selects whichever of the calling thread's two TLS scratch virtual arenas
 * does not match any allocator's data pointer in conflicts, begins a
 * Cl_VArena_Temp checkpoint on it, and returns a Cl_Scratch handle.
 *
 * Parameters:
 *   conflicts      (const Cl_Allocator *) - Array of allocators to avoid aliasing (may be NULL).
 *   conflict_count (cl_isize)             - Number of elements in conflicts (element count).
 *
 * Returns:
 *   (Cl_Scratch) Scoped scratch handle containing the checkpoint and allocator view.
 */
Cl_Scratch cl_scratch_begin(const Cl_Allocator *conflicts, cl_isize conflict_count) {
    cl_tls_ensure_scratch();

    cl_isize chosen = 0;
    for (cl_isize idx = 0; idx < 2; idx++) {
        bool collides = false;
        for (cl_isize c = 0; c < conflict_count; c++) {
            if (conflicts != NULL && conflicts[c].data == (void *)&cl_tls_scratch[idx]) {
                collides = true;
                break;
            }
        }
        if (!collides) {
            chosen = idx;
            break;
        }
    }

    Cl_Scratch s;
    s.temp      = cl_varena_temp_begin(&cl_tls_scratch[chosen]);
    s.allocator = cl_varena_allocator(&cl_tls_scratch[chosen]);
    return s;
}

/*
 * Rewinds the scratch virtual arena stored in scratch back to its saved
 * checkpoint in O(1).
 *
 * Parameters:
 *   scratch (Cl_Scratch) - Scratch handle returned by cl_scratch_begin().
 */
void cl_scratch_end(Cl_Scratch scratch) {
    cl_varena_temp_end(scratch.temp);
}

/*
 * Unmaps both TLS scratch virtual arenas for the calling thread and resets
 * thread-local initialization flags and context stack depth to 0.
 */
void cl_ctx_thread_shutdown(void) {
    if (cl_tls_scratch_ready) {
        cl_varena_destroy(&cl_tls_scratch[0]);
        cl_varena_destroy(&cl_tls_scratch[1]);
        cl_tls_scratch_ready = false;
    }
    cl_tls_ctx_initialized = false;
    cl_tls_ctx_depth = 0;
}
