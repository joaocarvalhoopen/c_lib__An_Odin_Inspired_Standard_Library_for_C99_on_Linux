/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_pool.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Implementation of Cl_Pool O(1) fixed-size block allocator with intrusive
 *   free list and AddressSanitizer poisoning of unused slots.
 * ============================================================================
 */

#include "cl/cl_pool.h"

/*
 * Rebuilds the intrusive singly-linked free list across all chunk_count slots
 * in reverse index order so allocations pop sequentially starting from slot 0,
 * resets used_count to 0, and poisons all free slots under AddressSanitizer.
 *
 * Parameters:
 *   pool (Cl_Pool *) - Initialized pool whose base, chunk_count, and chunk_size are valid.
 */
static void cl_pool_rebuild_freelist(Cl_Pool *pool) {
    /* Unpoison before linking intrusive free-list pointers */
    CL_ASAN_UNPOISON(pool->base, (cl_usize)(pool->chunk_count * pool->chunk_size));

    pool->free_head  = NULL;
    pool->used_count = 0;

    /* Link in reverse so allocations come out sequentially from slot 0 upward */
    for (cl_isize i = pool->chunk_count - 1; i >= 0; i--) {
        cl_u8 *slot = pool->base + (i * pool->chunk_size);
        Cl_Pool_Node *node = (Cl_Pool_Node *)slot;
        node->next = pool->free_head;
        pool->free_head = node;
    }

    /* Poison all unoccupied slots */
    CL_ASAN_POISON(pool->base, (cl_usize)(pool->chunk_count * pool->chunk_size));
}

/*
 * Initializes a Cl_Pool over a caller-owned buffer by aligning the start address,
 * computing the aligned chunk stride and slot count, and linking the free list.
 *
 * Parameters:
 *   pool        (Cl_Pool *) - Pool descriptor to initialize; must be non-NULL.
 *   buffer      (void *)    - Caller-provided backing buffer (NULL returns false).
 *   buffer_size (cl_isize)  - Total capacity of buffer in bytes (<= 0 returns false).
 *   chunk_size  (cl_isize)  - Requested chunk size in bytes (> 0).
 *   chunk_align (cl_isize)  - Power-of-two chunk alignment in bytes (<= 0 defaults to
 *                             CL_DEFAULT_ALIGNMENT; clamped up to sizeof(void *)).
 *
 * Returns:
 *   (bool) true if at least one chunk fits and initialization succeeded; false otherwise.
 */
bool cl_pool_init_buffer(
    Cl_Pool *pool,
    void *buffer,
    cl_isize buffer_size,
    cl_isize chunk_size,
    cl_isize chunk_align
) {
    CL_ENSURE(pool != NULL);
    CL_ZERO_STRUCT(pool);

    if (buffer == NULL || buffer_size <= 0 || chunk_size <= 0) {
        return false;
    }
    if (chunk_align <= 0) {
        chunk_align = CL_DEFAULT_ALIGNMENT;
    }
    if (chunk_align < (cl_isize)sizeof(void *)) {
        chunk_align = (cl_isize)sizeof(void *);
    }
    CL_ASSERT(cl_is_power_of_two(chunk_align));

    cl_uintptr raw_addr = (cl_uintptr)buffer;
    cl_isize pad = cl_align_padding(raw_addr, chunk_align);
    if (pad >= buffer_size) {
        return false;
    }

    cl_isize min_chunk = (chunk_size < (cl_isize)sizeof(Cl_Pool_Node))
                             ? (cl_isize)sizeof(Cl_Pool_Node)
                             : chunk_size;
    cl_isize aligned_chunk = cl_align_forward_isize(min_chunk, chunk_align);
    cl_isize usable = buffer_size - pad;
    cl_isize count = usable / aligned_chunk;
    if (count <= 0) {
        return false;
    }

    pool->base        = (cl_u8 *)buffer + pad;
    pool->cap_bytes   = count * aligned_chunk;
    pool->chunk_size  = aligned_chunk;
    pool->chunk_count = count;

    cl_pool_rebuild_freelist(pool);
    return true;
}

/*
 * Initializes a Cl_Pool by computing total_bytes = chunk_count * aligned_chunk
 * with overflow checking, allocating owned storage from backing, and building
 * the intrusive free list.
 *
 * Parameters:
 *   pool        (Cl_Pool *)    - Pool descriptor to initialize; must be non-NULL.
 *   chunk_count (cl_isize)     - Number of slots to allocate (chunk count; > 0).
 *   chunk_size  (cl_isize)     - Minimum payload size per chunk in bytes (> 0).
 *   chunk_align (cl_isize)     - Power-of-two chunk alignment in bytes (<= 0 defaults to
 *                                CL_DEFAULT_ALIGNMENT; clamped up to sizeof(void *)).
 *   backing     (Cl_Allocator) - Allocator used to allocate and later free the buffer.
 *
 * Returns:
 *   (bool) true on success; false if parameters are invalid, total size overflows, or OOM.
 */
bool cl_pool_init_alloc(
    Cl_Pool *pool,
    cl_isize chunk_count,
    cl_isize chunk_size,
    cl_isize chunk_align,
    Cl_Allocator backing
) {
    CL_ENSURE(pool != NULL);
    CL_ZERO_STRUCT(pool);

    if (chunk_count <= 0 || chunk_size <= 0) {
        return false;
    }
    if (chunk_align <= 0) {
        chunk_align = CL_DEFAULT_ALIGNMENT;
    }
    if (chunk_align < (cl_isize)sizeof(void *)) {
        chunk_align = (cl_isize)sizeof(void *);
    }
    CL_ASSERT(cl_is_power_of_two(chunk_align));

    cl_isize min_chunk = (chunk_size < (cl_isize)sizeof(Cl_Pool_Node))
                             ? (cl_isize)sizeof(Cl_Pool_Node)
                             : chunk_size;
    cl_isize aligned_chunk = cl_align_forward_isize(min_chunk, chunk_align);

    cl_isize total_bytes = 0;
    if (cl_mul_overflow_isize(chunk_count, aligned_chunk, &total_bytes)) {
        return false;
    }

    void *buf = cl_alloc_non_zeroed_aligned_loc(backing, total_bytes, chunk_align, CL_HERE);
    if (buf == NULL) {
        return false;
    }

    pool->base          = (cl_u8 *)buf;
    pool->cap_bytes     = total_bytes;
    pool->chunk_size    = aligned_chunk;
    pool->chunk_count   = chunk_count;
    pool->backing_alloc = backing;

    cl_pool_rebuild_freelist(pool);
    return true;
}

/*
 * Unpoisons the pool buffer under ASan, frees it through backing_alloc if
 * owned, and clears the Cl_Pool descriptor; safe no-op if pool is NULL.
 *
 * Parameters:
 *   pool (Cl_Pool *) - Pool to destroy (may be NULL).
 */
void cl_pool_destroy(Cl_Pool *pool) {
    if (pool == NULL) {
        return;
    }
    if (pool->base != NULL) {
        CL_ASAN_UNPOISON(pool->base, (cl_usize)pool->cap_bytes);
        if (cl_allocator_is_valid(pool->backing_alloc)) {
            cl_free_loc(pool->backing_alloc, pool->base, pool->cap_bytes, CL_HERE);
        }
    }
    CL_ZERO_STRUCT(pool);
}

/*
 * Reclaims every slot in the pool by rebuilding the intrusive free list in
 * O(chunk_count); safe no-op if pool is NULL or uninitialized.
 *
 * Parameters:
 *   pool (Cl_Pool *) - Pool to reset (may be NULL).
 */
void cl_pool_free_all(Cl_Pool *pool) {
    if (pool == NULL || pool->base == NULL) {
        return;
    }
    cl_pool_rebuild_freelist(pool);
}

/*
 * Internal O(1) slot allocation helper for Cl_Pool. Pops free_head, unpoisons
 * the slot under ASan, increments used_count, and either zeroes the chunk or
 * paints CL_MEM_POISON_ALLOC_UNINIT in debug builds.
 *
 * Parameters:
 *   pool   (Cl_Pool *) - Target pool (returns NULL if NULL or free_head is NULL).
 *   zeroed (bool)      - If true, zero-initialize chunk_size bytes; otherwise debug-fill 0xCD.
 *
 * Returns:
 *   (void *) Pointer to the allocated chunk, or NULL if pool is NULL or full.
 */
static void *cl_pool_alloc_internal(Cl_Pool *pool, bool zeroed) {
    if (pool == NULL || pool->free_head == NULL) {
        return NULL;
    }
    Cl_Pool_Node *node = pool->free_head;
    CL_ASAN_UNPOISON(node, (cl_usize)pool->chunk_size);
    pool->free_head = node->next;
    pool->used_count += 1;

    if (zeroed) {
        cl_mem_zero(node, pool->chunk_size);
    }
#ifndef NDEBUG
    else {
        cl_mem_set(node, CL_MEM_POISON_ALLOC_UNINIT, pool->chunk_size);
    }
#endif
    return (void *)node;
}

/*
 * Allocates one zero-initialized chunk from pool in O(1).
 *
 * Parameters:
 *   pool (Cl_Pool *) - Target pool (may be NULL).
 *
 * Returns:
 *   (void *) Pointer to a zero-initialized chunk of pool->chunk_size bytes, or NULL if full.
 */
void *cl_pool_alloc(Cl_Pool *pool) {
    return cl_pool_alloc_internal(pool, true);
}

/*
 * Releases a single chunk back onto pool->free_head in O(1), enforcing pool
 * bounds and chunk-boundary alignment via CL_ENSURE_MSG, scrubbing freed bytes
 * with 0xDD in debug builds, and poisoning the slot under ASan.
 *
 * Parameters:
 *   pool (Cl_Pool *) - Owning pool (safe no-op if NULL).
 *   ptr  (void *)    - Chunk pointer to return (safe no-op if NULL; must belong to pool
 *                      and satisfy ((ptr - base) % chunk_size) == 0).
 */
void cl_pool_free(Cl_Pool *pool, void *ptr) {
    if (pool == NULL || ptr == NULL) {
        return;
    }
    cl_u8 *p = (cl_u8 *)ptr;
    CL_ENSURE_MSG(
        p >= pool->base && p < (pool->base + pool->cap_bytes),
        "cl_pool_free: pointer %p is outside pool bounds [%p, %p)",
        (void *)p,
        (void *)pool->base,
        (void *)(pool->base + pool->cap_bytes)
    );
    CL_ENSURE_MSG(
        ((p - pool->base) % pool->chunk_size) == 0,
        "cl_pool_free: pointer %p is not aligned to chunk boundary (%lld bytes)",
        (void *)p,
        (long long)pool->chunk_size
    );

#ifndef NDEBUG
    cl_mem_set(p, CL_MEM_POISON_FREED, pool->chunk_size);
#endif
    Cl_Pool_Node *node = (Cl_Pool_Node *)p;
    node->next = pool->free_head;
    pool->free_head = node;
    if (pool->used_count > 0) {
        pool->used_count -= 1;
    }
    CL_ASAN_POISON(p, (cl_usize)pool->chunk_size);
}

/*
 * Cl_Alloc_Proc dispatch callback for Cl_Pool. Serves allocations up to
 * pool->chunk_size bytes, handles FREE and FREE_ALL, and allows in-place
 * RESIZE only while size <= pool->chunk_size.
 *
 * Parameters:
 *   allocator_data (void *)        - Pointer to the backing Cl_Pool struct.
 *   mode           (Cl_Alloc_Mode) - Requested allocator operation.
 *   size           (cl_isize)      - Requested allocation or resize byte size (bytes; must be <= chunk_size).
 *   alignment      (cl_isize)      - Ignored (all pool chunks use pool's fixed chunk_align).
 *   old_memory     (void *)        - Existing chunk pointer for FREE/RESIZE, or NULL.
 *   old_size       (cl_isize)      - Previous byte size used to zero growth tail during RESIZE.
 *   loc            (Cl_Source_Loc) - Unused caller source location.
 *
 * Returns:
 *   (void *) Pointer to allocated/resized chunk, or NULL on FREE, FREE_ALL,
 *            size > chunk_size, size <= 0, or pool exhaustion.
 */
static void *cl_pool_alloc_proc(
    void          *allocator_data,
    Cl_Alloc_Mode  mode,
    cl_isize       size,
    cl_isize       alignment,
    void          *old_memory,
    cl_isize       old_size,
    Cl_Source_Loc  loc
) {
    CL_UNUSED_VAR(alignment);
    CL_UNUSED_VAR(old_size);
    CL_UNUSED_VAR(loc);
    Cl_Pool *pool = (Cl_Pool *)allocator_data;

    switch (mode) {
        case CL_ALLOC_ALLOC:
            if (size <= 0 || size > pool->chunk_size) {
                return NULL;
            }
            return cl_pool_alloc_internal(pool, true);
        case CL_ALLOC_ALLOC_NON_ZEROED:
            if (size <= 0 || size > pool->chunk_size) {
                return NULL;
            }
            return cl_pool_alloc_internal(pool, false);
        case CL_ALLOC_FREE:
            cl_pool_free(pool, old_memory);
            return NULL;
        case CL_ALLOC_FREE_ALL:
            cl_pool_free_all(pool);
            return NULL;
        case CL_ALLOC_RESIZE:
        case CL_ALLOC_RESIZE_NON_ZEROED:
            if (old_memory == NULL) {
                if (size <= 0 || size > pool->chunk_size) {
                    return NULL;
                }
                return cl_pool_alloc_internal(pool, mode == CL_ALLOC_RESIZE);
            }
            if (size <= 0) {
                cl_pool_free(pool, old_memory);
                return NULL;
            }
            if (size <= pool->chunk_size) {
                if (mode == CL_ALLOC_RESIZE && size > old_size) {
                    cl_mem_zero((cl_u8 *)old_memory + old_size, size - old_size);
                }
                return old_memory;
            }
            return NULL; /* Cannot grow past fixed chunk_size */
    }
    return NULL;
}

/*
 * Wraps a Cl_Pool pointer into a polymorphic Cl_Allocator handle.
 *
 * Parameters:
 *   pool (Cl_Pool *) - Pool to wrap; must be non-NULL.
 *
 * Returns:
 *   (Cl_Allocator) Allocator handle with proc = cl_pool_alloc_proc and data = pool.
 */
Cl_Allocator cl_pool_allocator(Cl_Pool *pool) {
    CL_ENSURE(pool != NULL);
    return (Cl_Allocator){ cl_pool_alloc_proc, pool };
}
