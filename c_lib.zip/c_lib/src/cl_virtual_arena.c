/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_virtual_arena.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Linux mmap/mprotect/madvise implementation of Cl_Virtual_Arena with
 *   on-demand page commitment, pointer-stable growth, and ASan poisoning.
 * ============================================================================
 */

/*
 * Feature test macro exposing Linux/BSD extensions such as MAP_ANONYMOUS and
 * madvise()/MADV_DONTNEED in <sys/mman.h> under strict ISO C99 (-std=c99).
 */
#define _DEFAULT_SOURCE

/*
 * Feature test macro selecting POSIX.1-2008 interfaces such as sysconf() and
 * _SC_PAGESIZE in <unistd.h>.
 */
#define _POSIX_C_SOURCE 200809L

#include "cl/cl_virtual_arena.h"
#include <sys/mman.h>
#include <unistd.h>

/*
 * Queries the host operating system memory page size using sysconf(_SC_PAGESIZE).
 *
 * Returns:
 *   (cl_isize) OS page size in bytes, or 4096 bytes if sysconf returns <= 0.
 */
cl_isize cl_os_page_size(void) {
    long ps = sysconf(_SC_PAGESIZE);
    if (ps <= 0) {
        return 4096;
    }
    return (cl_isize)ps;
}

/*
 * Ensures that at least needed_end bytes from va->base are committed with
 * PROT_READ | PROT_WRITE permissions, growing va->committed in multiples of
 * va->commit_chunk (clamped to va->reserved) and poisoning newly committed
 * pages under AddressSanitizer.
 *
 * Parameters:
 *   va         (Cl_Virtual_Arena *) - Target virtual arena.
 *   needed_end (cl_isize)           - Required committed end offset from base in bytes.
 *
 * Returns:
 *   (bool) true if needed_end bytes are committed; false if needed_end > va->reserved
 *          or mprotect() fails.
 */
static bool cl_varena_ensure_committed(Cl_Virtual_Arena *va, cl_isize needed_end) {
    if (needed_end <= va->committed) {
        return true;
    }
    if (needed_end > va->reserved) {
        return false;
    }

    cl_isize delta = needed_end - va->committed;
    cl_isize chunks = (delta + va->commit_chunk - 1) / va->commit_chunk;
    cl_isize grow = chunks * va->commit_chunk;
    if (va->committed + grow > va->reserved) {
        grow = va->reserved - va->committed;
    }

    void *commit_addr = va->base + va->committed;
    if (mprotect(commit_addr, (cl_usize)grow, PROT_READ | PROT_WRITE) != 0) {
        return false;
    }

    CL_ASAN_POISON(commit_addr, (cl_usize)grow);
    va->committed += grow;
    return true;
}

/*
 * Internal O(1) bump allocation helper for Cl_Virtual_Arena. Aligns the bump
 * offset, commits additional pages on demand if needed, updates offset/prev_offset/
 * peak_used, unpoisons the region under ASan, and zeroes or debug-fills bytes.
 *
 * Parameters:
 *   va        (Cl_Virtual_Arena *) - Target virtual arena (returns NULL if NULL or unmapped).
 *   size      (cl_isize)           - Allocation length in bytes (<= 0 returns NULL).
 *   alignment (cl_isize)           - Power-of-two alignment in bytes (<= 0 defaults to CL_DEFAULT_ALIGNMENT).
 *   zeroed    (bool)               - If true, zero-initialize bytes; otherwise paint 0xCD in debug builds.
 *
 * Returns:
 *   (void *) Pointer to allocated virtual-arena memory, or NULL if size <= 0, reservation
 *            is exhausted, or page commitment fails.
 */
static void *cl_varena_alloc_internal(
    Cl_Virtual_Arena *va,
    cl_isize size,
    cl_isize alignment,
    bool zeroed
) {
    if (size <= 0 || va == NULL || va->base == NULL) {
        return NULL;
    }
    if (alignment <= 0) {
        alignment = CL_DEFAULT_ALIGNMENT;
    }
    CL_ASSERT(cl_is_power_of_two(alignment));

    cl_uintptr curr_addr = (cl_uintptr)(va->base + va->offset);
    cl_isize padding = cl_align_padding(curr_addr, alignment);
    cl_isize aligned_offset = va->offset + padding;

    if (aligned_offset < 0 || size > (va->reserved - aligned_offset)) {
        return NULL;
    }
    cl_isize end_offset = aligned_offset + size;
    if (!cl_varena_ensure_committed(va, end_offset)) {
        return NULL;
    }

    void *ptr = va->base + aligned_offset;
    va->prev_offset = aligned_offset;
    va->offset = end_offset;
    if (va->offset > va->peak_used) {
        va->peak_used = va->offset;
    }

    CL_ASAN_UNPOISON(ptr, (cl_usize)size);

    if (zeroed) {
        /* Fresh OS pages are already zero, but reused pages after reset may not be */
        cl_mem_zero(ptr, size);
    }
#ifndef NDEBUG
    else {
        cl_mem_set(ptr, CL_MEM_POISON_ALLOC_UNINIT, size);
    }
#endif

    return ptr;
}

/*
 * Internal resize helper for Cl_Virtual_Arena. Resizes in place in O(1) when
 * old_memory is the top allocation (committing pages on growth and poisoning
 * shrunk tail bytes), or falls back to allocating a fresh block and copying
 * min(old_size, new_size) bytes.
 *
 * Parameters:
 *   va         (Cl_Virtual_Arena *) - Target virtual arena.
 *   old_memory (void *)             - Existing pointer inside va, or NULL for a fresh allocation.
 *   old_size   (cl_isize)           - Prior allocation length in bytes.
 *   new_size   (cl_isize)           - Requested new length in bytes (<= 0 returns NULL).
 *   alignment  (cl_isize)           - Power-of-two alignment in bytes (<= 0 defaults to CL_DEFAULT_ALIGNMENT).
 *   zeroed     (bool)               - If true, zero-initialize newly grown bytes; otherwise paint 0xCD in debug.
 *
 * Returns:
 *   (void *) Pointer to the resized block, or NULL if new_size <= 0, reservation
 *            is exhausted, or page commitment fails.
 */
static void *cl_varena_resize_internal(
    Cl_Virtual_Arena *va,
    void *old_memory,
    cl_isize old_size,
    cl_isize new_size,
    cl_isize alignment,
    bool zeroed
) {
    if (old_memory == NULL) {
        return cl_varena_alloc_internal(va, new_size, alignment, zeroed);
    }
    if (new_size <= 0) {
        return NULL;
    }
    if (alignment <= 0) {
        alignment = CL_DEFAULT_ALIGNMENT;
    }

    cl_u8 *old_ptr = (cl_u8 *)old_memory;
    CL_ASSERT(old_ptr >= va->base && old_ptr < va->base + va->reserved);

    /* Fast path: resize top allocation in place */
    if (old_ptr == va->base + va->prev_offset) {
        if (new_size > (va->reserved - va->prev_offset)) {
            return NULL;
        }
        cl_isize prev_end = va->offset;
        cl_isize new_end  = va->prev_offset + new_size;
        if (!cl_varena_ensure_committed(va, new_end)) {
            return NULL;
        }
        va->offset = new_end;
        if (va->offset > va->peak_used) {
            va->peak_used = va->offset;
        }
        if (new_size > old_size) {
            cl_isize diff = new_size - old_size;
            CL_ASAN_UNPOISON(old_ptr + old_size, (cl_usize)diff);
            if (zeroed) {
                cl_mem_zero(old_ptr + old_size, diff);
            }
#ifndef NDEBUG
            else {
                cl_mem_set(old_ptr + old_size, CL_MEM_POISON_ALLOC_UNINIT, diff);
            }
#endif
        } else if (new_end < prev_end) {
            cl_isize shrink = prev_end - new_end;
#ifndef NDEBUG
            cl_mem_set(va->base + new_end, CL_MEM_POISON_FREED, shrink);
#endif
            CL_ASAN_POISON(va->base + new_end, (cl_usize)shrink);
        }
        return old_memory;
    }

    void *new_ptr = cl_varena_alloc_internal(va, new_size, alignment, zeroed);
    if (new_ptr == NULL) {
        return NULL;
    }
    cl_isize copy_len = (old_size < new_size) ? old_size : new_size;
    cl_mem_copy(new_ptr, old_memory, copy_len);
    return new_ptr;
}

/*
 * Cl_Alloc_Proc dispatch callback for Cl_Virtual_Arena. Dispatches ALLOC/RESIZE
 * to internal helpers, maps FREE_ALL to cl_varena_reset(va, false) (retaining
 * committed pages), and treats individual FREE as a no-op returning NULL.
 *
 * Parameters:
 *   allocator_data (void *)        - Pointer to the backing Cl_Virtual_Arena.
 *   mode           (Cl_Alloc_Mode) - Requested allocator operation.
 *   size           (cl_isize)      - Requested allocation or resize byte count (bytes).
 *   alignment      (cl_isize)      - Power-of-two alignment in bytes.
 *   old_memory     (void *)        - Existing pointer for RESIZE/FREE, or NULL.
 *   old_size       (cl_isize)      - Prior allocation length in bytes.
 *   loc            (Cl_Source_Loc) - Unused caller source location.
 *
 * Returns:
 *   (void *) Pointer to allocated/resized memory, or NULL on FREE, FREE_ALL, or failure.
 */
static void *cl_varena_alloc_proc(
    void          *allocator_data,
    Cl_Alloc_Mode  mode,
    cl_isize       size,
    cl_isize       alignment,
    void          *old_memory,
    cl_isize       old_size,
    Cl_Source_Loc  loc
) {
    CL_UNUSED_VAR(loc);
    Cl_Virtual_Arena *va = (Cl_Virtual_Arena *)allocator_data;

    switch (mode) {
        case CL_ALLOC_ALLOC:
            return cl_varena_alloc_internal(va, size, alignment, true);
        case CL_ALLOC_ALLOC_NON_ZEROED:
            return cl_varena_alloc_internal(va, size, alignment, false);
        case CL_ALLOC_FREE:
            return NULL;
        case CL_ALLOC_FREE_ALL:
            cl_varena_reset(va, false);
            return NULL;
        case CL_ALLOC_RESIZE:
            return cl_varena_resize_internal(va, old_memory, old_size, size, alignment, true);
        case CL_ALLOC_RESIZE_NON_ZEROED:
            return cl_varena_resize_internal(va, old_memory, old_size, size, alignment, false);
    }
    return NULL;
}

/*
 * Initializes a Cl_Virtual_Arena by reserving page-aligned virtual address
 * space with mmap(NULL, reserve_size, PROT_NONE, MAP_PRIVATE | MAP_ANONYMOUS).
 *
 * Parameters:
 *   va           (Cl_Virtual_Arena *) - Descriptor to initialize; must be non-NULL.
 *   reserve_size (cl_isize)           - Requested virtual reservation in bytes (<= 0 defaults to 64 MiB).
 *   commit_chunk (cl_isize)           - Requested commit step in bytes (<= 0 defaults to 64 KiB;
 *                                       rounded up to OS page size and clamped to reserve_size).
 *
 * Returns:
 *   (bool) true on success; false if mmap returns MAP_FAILED.
 */
bool cl_varena_init(Cl_Virtual_Arena *va, cl_isize reserve_size, cl_isize commit_chunk) {
    CL_ENSURE(va != NULL);
    CL_ZERO_STRUCT(va);

    cl_isize page = cl_os_page_size();
    if (reserve_size <= 0) {
        reserve_size = CL_MB(64);
    }
    if (commit_chunk <= 0) {
        commit_chunk = CL_KB(64);
    }

    reserve_size = cl_align_forward_isize(reserve_size, page);
    commit_chunk = cl_align_forward_isize(commit_chunk, page);
    if (commit_chunk > reserve_size) {
        commit_chunk = reserve_size;
    }

    void *mem = mmap(NULL, (cl_usize)reserve_size, PROT_NONE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (mem == MAP_FAILED) {
        return false;
    }

    va->base         = (cl_u8 *)mem;
    va->reserved     = reserve_size;
    va->committed    = 0;
    va->commit_chunk = commit_chunk;
    va->page_size    = page;
    return true;
}

/*
 * Unpoisons committed memory under ASan, unmaps the entire reserved address
 * range via munmap(), and zeroes the Cl_Virtual_Arena struct; safe no-op if NULL.
 *
 * Parameters:
 *   va (Cl_Virtual_Arena *) - Virtual arena to destroy (may be NULL).
 */
void cl_varena_destroy(Cl_Virtual_Arena *va) {
    if (va == NULL) {
        return;
    }
    if (va->base != NULL) {
        if (va->committed > 0) {
            CL_ASAN_UNPOISON(va->base, (cl_usize)va->committed);
        }
        munmap(va->base, (cl_usize)va->reserved);
    }
    CL_ZERO_STRUCT(va);
}

/*
 * Resets offset and prev_offset to 0 in O(1), either decommitting physical
 * pages via madvise(MADV_DONTNEED) + mprotect(PROT_NONE) or retaining committed
 * pages while scrubbing used bytes (debug) and poisoning committed space under ASan.
 *
 * Parameters:
 *   va             (Cl_Virtual_Arena *) - Virtual arena to reset (safe no-op if NULL or base is NULL).
 *   decommit_pages (bool)               - If true, advise OS to drop physical pages and set committed = 0;
 *                                         if false, retain committed pages for fast reuse.
 */
void cl_varena_reset(Cl_Virtual_Arena *va, bool decommit_pages) {
    if (va == NULL || va->base == NULL) {
        return;
    }
    if (va->committed > 0) {
        if (decommit_pages) {
            CL_ASAN_UNPOISON(va->base, (cl_usize)va->committed);
            (void)madvise(va->base, (cl_usize)va->committed, MADV_DONTNEED);
            (void)mprotect(va->base, (cl_usize)va->committed, PROT_NONE);
            va->committed = 0;
        } else {
#ifndef NDEBUG
            if (va->offset > 0) {
                CL_ASAN_UNPOISON(va->base, (cl_usize)va->offset);
                cl_mem_set(va->base, CL_MEM_POISON_FREED, va->offset);
            }
#endif
            CL_ASAN_POISON(va->base, (cl_usize)va->committed);
        }
    }
    va->offset = 0;
    va->prev_offset = 0;
}

/*
 * Wraps a Cl_Virtual_Arena pointer into a polymorphic Cl_Allocator handle.
 *
 * Parameters:
 *   va (Cl_Virtual_Arena *) - Virtual arena to wrap; must be non-NULL.
 *
 * Returns:
 *   (Cl_Allocator) Allocator handle with proc = cl_varena_alloc_proc and data = va.
 */
Cl_Allocator cl_varena_allocator(Cl_Virtual_Arena *va) {
    CL_ENSURE(va != NULL);
    return (Cl_Allocator){ cl_varena_alloc_proc, va };
}

/*
 * Captures the current offset and prev_offset of va into a Cl_VArena_Temp
 * checkpoint for later O(1) rewind.
 *
 * Parameters:
 *   va (Cl_Virtual_Arena *) - Virtual arena to checkpoint; must be non-NULL.
 *
 * Returns:
 *   (Cl_VArena_Temp) Saved checkpoint recording va, offset, and prev_offset.
 */
Cl_VArena_Temp cl_varena_temp_begin(Cl_Virtual_Arena *va) {
    CL_ENSURE(va != NULL);
    return (Cl_VArena_Temp){ va, va->offset, va->prev_offset };
}

/*
 * Rewinds a Cl_Virtual_Arena back to a saved checkpoint in O(1), scrubbing
 * rewound bytes with CL_MEM_POISON_FREED in debug builds and poisoning them
 * under AddressSanitizer.
 *
 * Parameters:
 *   temp (Cl_VArena_Temp) - Saved checkpoint from cl_varena_temp_begin()
 *                           (safe no-op if temp.arena is NULL).
 */
void cl_varena_temp_end(Cl_VArena_Temp temp) {
    if (temp.arena == NULL) {
        return;
    }
    Cl_Virtual_Arena *va = temp.arena;
    CL_ASSERT(va->offset >= temp.saved_offset);
    cl_isize rewound = va->offset - temp.saved_offset;
    if (rewound > 0) {
#ifndef NDEBUG
        CL_ASAN_UNPOISON(va->base + temp.saved_offset, (cl_usize)rewound);
        cl_mem_set(va->base + temp.saved_offset, CL_MEM_POISON_FREED, rewound);
#endif
        CL_ASAN_POISON(va->base + temp.saved_offset, (cl_usize)rewound);
    }
    va->offset = temp.saved_offset;
    va->prev_offset = temp.saved_prev_offset;
}
