/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_string_builder.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Implementation of Cl_String_Builder (dynamic and fixed-buffer modes),
 *   complex64/complex128 formatting, and cl_aprintf / cl_tprintf / cl_bprintf.
 * ============================================================================
 */

#include "cl/cl_string_builder.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

/*
 * Function: cl_sb_init
 * Purpose:
 *   Zero-initializes *sb in dynamic mode and records its allocator.
 * Parameters:
 *   sb (Cl_String_Builder *): Builder to initialize; must be non-NULL.
 *   alloc (Cl_Allocator): Allocator to bind (falls back to context if invalid).
 * Returns:
 *   void.
 */
void cl_sb_init(Cl_String_Builder *sb, Cl_Allocator alloc) {
    CL_ENSURE(sb != NULL);
    CL_ZERO_STRUCT(sb);
    sb->allocator = alloc;
}

/*
 * Function: cl_sb_init_cap
 * Purpose:
 *   Initializes *sb in dynamic mode and reserves at least initial_cap bytes.
 * Parameters:
 *   sb (Cl_String_Builder *): Builder to initialize; must be non-NULL.
 *   alloc (Cl_Allocator): Allocator to bind.
 *   initial_cap (cl_isize): Minimum initial capacity in bytes (<= 0 skips alloc).
 * Returns:
 *   bool: true on success; false if initial reservation fails.
 */
bool cl_sb_init_cap(Cl_String_Builder *sb, Cl_Allocator alloc, cl_isize initial_cap) {
    cl_sb_init(sb, alloc);
    if (initial_cap <= 0) {
        return true;
    }
    return cl_sb_reserve(sb, initial_cap);
}

/*
 * Function: cl_sb_init_buffer
 * Purpose:
 *   Initializes *sb in fixed-buffer mode backed by caller memory buf[cap].
 * Parameters:
 *   sb (Cl_String_Builder *): Builder to initialize; must be non-NULL.
 *   buf (void *): Caller-owned byte buffer, or NULL.
 *   cap (cl_isize): Capacity of buf in bytes (<= 0 sets cap = 0).
 * Returns:
 *   void.
 */
void cl_sb_init_buffer(Cl_String_Builder *sb, void *buf, cl_isize cap) {
    CL_ENSURE(sb != NULL);
    CL_ZERO_STRUCT(sb);
    sb->data         = (cl_u8 *)buf;
    sb->cap          = (buf != NULL && cap > 0) ? cap : 0;
    sb->fixed_buffer = true;
}

/*
 * Function: cl_sb_destroy
 * Purpose:
 *   Frees the dynamic backing buffer (if not in fixed-buffer mode) and zeroes
 *   all builder fields. Safe on NULL.
 * Parameters:
 *   sb (Cl_String_Builder *): Builder to destroy, or NULL.
 * Returns:
 *   void.
 */
void cl_sb_destroy(Cl_String_Builder *sb) {
    if (sb == NULL) {
        return;
    }
    if (!sb->fixed_buffer && sb->data != NULL) {
        cl_free_loc(cl_alloc_or_ctx(sb->allocator), sb->data, sb->cap, CL_HERE);
    }
    CL_ZERO_STRUCT(sb);
}

/*
 * Function: cl_sb_reset
 * Purpose:
 *   Clears builder length to 0 bytes and resets truncated to false without
 *   releasing the underlying buffer. Safe on NULL.
 * Parameters:
 *   sb (Cl_String_Builder *): Builder to reset, or NULL.
 * Returns:
 *   void.
 */
void cl_sb_reset(Cl_String_Builder *sb) {
    if (sb == NULL) {
        return;
    }
    sb->len       = 0;
    sb->truncated = false;
}

/*
 * Function: cl_sb_reserve
 * Purpose:
 *   Grows a dynamic builder's buffer (doubling from 64 bytes) so that
 *   sb->cap >= min_cap bytes. Fails without allocating in fixed-buffer mode.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   min_cap (cl_isize): Minimum required capacity in bytes.
 * Returns:
 *   bool: true if sb->cap >= min_cap after the call; false otherwise.
 */
bool cl_sb_reserve(Cl_String_Builder *sb, cl_isize min_cap) {
    CL_ENSURE(sb != NULL);
    if (min_cap <= sb->cap) {
        return true;
    }
    if (sb->fixed_buffer) {
        return false;
    }
    if (!cl_allocator_is_valid(sb->allocator)) {
        sb->allocator = cl_ctx_allocator();
    }

    cl_isize new_cap = (sb->cap > 0) ? sb->cap : 64;
    while (new_cap < min_cap) {
        if (new_cap > PTRDIFF_MAX / 2) {
            new_cap = min_cap;
            break;
        }
        new_cap *= 2;
    }

    cl_u8 *new_data = (cl_u8 *)cl_resize_non_zeroed_aligned_loc(
        sb->allocator, sb->data, sb->cap, new_cap, 1, CL_HERE
    );
    if (new_data == NULL) {
        return false;
    }
    sb->data = new_data;
    sb->cap  = new_cap;
    return true;
}

/*
 * Function: cl_sb_write_bytes
 * Purpose:
 *   Appends len bytes from data to sb, growing in dynamic mode or clamping to
 *   available space and setting sb->truncated in fixed-buffer mode.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   data (const void *): Source bytes, or NULL (returns 0).
 *   len (cl_isize): Number of bytes to write (<= 0 returns 0).
 * Returns:
 *   cl_isize: Actual number of bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_bytes(Cl_String_Builder *sb, const void *data, cl_isize len) {
    CL_ENSURE(sb != NULL);
    if (data == NULL || len <= 0) {
        return 0;
    }
    if (sb->fixed_buffer) {
        cl_isize avail = sb->cap - sb->len;
        if (avail <= 0) {
            sb->truncated = true;
            return 0;
        }
        cl_isize to_write = len;
        if (to_write > avail) {
            to_write = avail;
            sb->truncated = true;
        }
        cl_mem_copy(sb->data + sb->len, data, to_write);
        sb->len += to_write;
        return to_write;
    }

    if (!cl_sb_reserve(sb, sb->len + len)) {
        return 0;
    }
    cl_mem_copy(sb->data + sb->len, data, len);
    sb->len += len;
    return len;
}

/*
 * Function: cl_sb_write_byte
 * Purpose:
 *   Appends a single byte to sb.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   byte_val (cl_u8): Byte to append.
 * Returns:
 *   cl_isize: 1 (byte) on success, or 0 on failure/truncation.
 */
cl_isize cl_sb_write_byte(Cl_String_Builder *sb, cl_u8 byte_val) {
    return cl_sb_write_bytes(sb, &byte_val, 1);
}

/*
 * Function: cl_sb_write_str
 * Purpose:
 *   Appends all bytes of s to sb.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   s (Cl_Str): Source byte slice (length in bytes).
 * Returns:
 *   cl_isize: Number of bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_str(Cl_String_Builder *sb, Cl_Str s) {
    return cl_sb_write_bytes(sb, s.data, s.len);
}

/*
 * Function: cl_sb_write_cstr
 * Purpose:
 *   Appends a NUL-terminated C string (excluding NUL) to sb.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   cs (const char *): NUL-terminated C string, or NULL (returns 0).
 * Returns:
 *   cl_isize: Number of bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_cstr(Cl_String_Builder *sb, const char *cs) {
    if (cs == NULL) {
        return 0;
    }
    return cl_sb_write_bytes(sb, cs, (cl_isize)strlen(cs));
}

/*
 * Function: cl_sb_write_rune
 * Purpose:
 *   UTF-8 encodes Unicode code point r and appends the resulting 1..4 bytes
 *   to sb.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   r (cl_rune): Unicode scalar value (invalid runes encode as U+FFFD).
 * Returns:
 *   cl_isize: Number of UTF-8 bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_rune(Cl_String_Builder *sb, cl_rune r) {
    cl_u8 encoded[4];
    cl_isize n = cl_utf8_encode_rune(r, encoded);
    return cl_sb_write_bytes(sb, encoded, n);
}

/*
 * Function: cl_sb_write_repeat
 * Purpose:
 *   Appends s repeated count times, pre-reserving capacity in dynamic mode
 *   when s.len * count does not overflow.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   s (Cl_Str): Byte slice to repeat.
 *   count (cl_isize): Repetition count (<= 0 writes nothing).
 * Returns:
 *   cl_isize: Total bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_repeat(Cl_String_Builder *sb, Cl_Str s, cl_isize count) {
    if (s.len <= 0 || count <= 0) {
        return 0;
    }
    cl_isize total = 0;
    if (!sb->fixed_buffer) {
        cl_isize need = 0;
        if (!cl_mul_overflow_isize(s.len, count, &need)) {
            (void)cl_sb_reserve(sb, sb->len + need);
        }
    }
    for (cl_isize i = 0; i < count; i++) {
        cl_isize w = cl_sb_write_str(sb, s);
        total += w;
        if (w < s.len) {
            break;
        }
    }
    return total;
}

/*
 * Function: cl_sb_write_i64
 * Purpose:
 *   Formats signed 64-bit integer v in decimal and appends it to sb.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   v (cl_i64): Signed integer value.
 * Returns:
 *   cl_isize: Number of ASCII bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_i64(Cl_String_Builder *sb, cl_i64 v) {
    char buf[32];
    int n = snprintf(buf, sizeof(buf), "%lld", (long long)v);
    return (n > 0) ? cl_sb_write_bytes(sb, buf, (cl_isize)n) : 0;
}

/*
 * Function: cl_sb_write_u64
 * Purpose:
 *   Formats unsigned 64-bit integer v in decimal and appends it to sb.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   v (cl_u64): Unsigned integer value.
 * Returns:
 *   cl_isize: Number of ASCII bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_u64(Cl_String_Builder *sb, cl_u64 v) {
    char buf[32];
    int n = snprintf(buf, sizeof(buf), "%llu", (unsigned long long)v);
    return (n > 0) ? cl_sb_write_bytes(sb, buf, (cl_isize)n) : 0;
}

/*
 * Function: cl_sb_write_hex
 * Purpose:
 *   Formats unsigned 64-bit integer v as "0x..." hexadecimal and appends to sb.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   v (cl_u64): Unsigned integer value.
 *   uppercase (bool): True for uppercase hex digits, false for lowercase.
 * Returns:
 *   cl_isize: Number of ASCII bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_hex(Cl_String_Builder *sb, cl_u64 v, bool uppercase) {
    char buf[32];
    int n = snprintf(buf, sizeof(buf), uppercase ? "0x%llX" : "0x%llx", (unsigned long long)v);
    return (n > 0) ? cl_sb_write_bytes(sb, buf, (cl_isize)n) : 0;
}

/*
 * Function: cl_sb_write_f64
 * Purpose:
 *   Formats double-precision float v using "%.*f" (precision >= 0) or "%g"
 *   (precision < 0) and appends it to sb.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   v (cl_f64): Floating-point value.
 *   precision (int): Fractional decimal digits (>= 0), or < 0 for general "%g".
 * Returns:
 *   cl_isize: Number of ASCII bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_f64(Cl_String_Builder *sb, cl_f64 v, int precision) {
    char buf[64];
    int n;
    if (precision < 0) {
        n = snprintf(buf, sizeof(buf), "%g", v);
    } else {
        n = snprintf(buf, sizeof(buf), "%.*f", precision, v);
    }
    return (n > 0) ? cl_sb_write_bytes(sb, buf, (cl_isize)n) : 0;
}

/*
 * Function: cl_sb_write_bool
 * Purpose:
 *   Appends "true" if v is true or "false" if v is false to sb.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   v (bool): Boolean value.
 * Returns:
 *   cl_isize: Number of ASCII bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_bool(Cl_String_Builder *sb, bool v) {
    return cl_sb_write_str(sb, v ? CL_STR("true") : CL_STR("false"));
}

/*
 * Function: cl_sb_write_c64
 * Purpose:
 *   Promotes cl_c64 to cl_c128 and appends its formatted text to sb.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   z (cl_c64): Single-precision complex number.
 *   precision (int): Fractional decimal digits (>= 0), or < 0 for "%g".
 * Returns:
 *   cl_isize: Number of ASCII bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_c64(Cl_String_Builder *sb, cl_c64 z, int precision) {
    return cl_sb_write_c128(sb, cl_c64_to_c128(z), precision);
}

/*
 * Function: cl_sb_write_c128
 * Purpose:
 *   Formats a double-precision complex number as "re + imi" or "re - |im|i"
 *   and appends it to sb.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   z (cl_c128): Double-precision complex number.
 *   precision (int): Fractional decimal digits (>= 0), or < 0 for "%g".
 * Returns:
 *   cl_isize: Number of ASCII bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_c128(Cl_String_Builder *sb, cl_c128 z, int precision) {
    cl_f64 re = cl_c128_real(z);
    cl_f64 im = cl_c128_imag(z);
    char sign = (im < 0.0) ? '-' : '+';
    cl_f64 abs_im = fabs(im);

    char buf[128];
    int n;
    if (precision < 0) {
        n = snprintf(buf, sizeof(buf), "%g %c %gi", re, sign, abs_im);
    } else {
        n = snprintf(buf, sizeof(buf), "%.*f %c %.*fi", precision, re, sign, precision, abs_im);
    }
    return (n > 0) ? cl_sb_write_bytes(sb, buf, (cl_isize)n) : 0;
}

/*
 * Function: cl_sb_write_vfmt
 * Purpose:
 *   Formats printf-style text from a va_list and appends it to sb. In dynamic
 *   mode formats directly into reserved storage; in fixed-buffer mode uses a
 *   512-byte stack buffer or scratch arena to format before clamping.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   fmt (const char *): NUL-terminated printf format string (NULL returns 0).
 *   args (va_list): Variadic argument list matching fmt.
 * Returns:
 *   cl_isize: Number of bytes written to sb (>= 0, bytes).
 */
cl_isize cl_sb_write_vfmt(Cl_String_Builder *sb, const char *fmt, va_list args) {
    CL_ENSURE(sb != NULL);
    if (fmt == NULL) {
        return 0;
    }

    va_list copy;
    va_copy(copy, args);
    int needed = vsnprintf(NULL, 0, fmt, args);
    if (needed <= 0) {
        va_end(copy);
        return 0;
    }

    if (sb->fixed_buffer) {
        char stack_buf[512];
        if ((cl_isize)needed < (cl_isize)sizeof(stack_buf)) {
            vsnprintf(stack_buf, sizeof(stack_buf), fmt, copy);
            va_end(copy);
            return cl_sb_write_bytes(sb, stack_buf, (cl_isize)needed);
        }
        Cl_Scratch scratch = cl_scratch_begin(NULL, 0);
        char *tmp = (char *)cl_alloc_non_zeroed_aligned_loc(scratch.allocator, (cl_isize)needed + 1, 1, CL_HERE);
        cl_isize written = 0;
        if (tmp != NULL) {
            vsnprintf(tmp, (cl_usize)needed + 1u, fmt, copy);
            written = cl_sb_write_bytes(sb, tmp, (cl_isize)needed);
        }
        va_end(copy);
        cl_scratch_end(scratch);
        return written;
    }

    if (!cl_sb_reserve(sb, sb->len + (cl_isize)needed + 1)) {
        va_end(copy);
        return 0;
    }
    vsnprintf((char *)(sb->data + sb->len), (cl_usize)needed + 1u, fmt, copy);
    va_end(copy);
    sb->len += (cl_isize)needed;
    return (cl_isize)needed;
}

/*
 * Function: cl_sb_write_fmt
 * Purpose:
 *   Variadic wrapper around cl_sb_write_vfmt that appends formatted text to sb.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   fmt (const char *): NUL-terminated printf format string.
 *   ... (variadic): Arguments matching fmt.
 * Returns:
 *   cl_isize: Number of bytes written to sb (>= 0, bytes).
 */
cl_isize cl_sb_write_fmt(Cl_String_Builder *sb, const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    cl_isize w = cl_sb_write_vfmt(sb, fmt, args);
    va_end(args);
    return w;
}

/*
 * Function: cl_sb_pop_byte
 * Purpose:
 *   Removes the trailing byte from sb if sb is non-empty and optionally
 *   writes it to *out_byte.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder, or NULL.
 *   out_byte (cl_u8 *): Optional output pointer for the removed byte.
 * Returns:
 *   bool: true if a byte was popped; false if sb is NULL or empty.
 */
bool cl_sb_pop_byte(Cl_String_Builder *sb, cl_u8 *out_byte) {
    if (sb == NULL || sb->len <= 0) {
        return false;
    }
    sb->len -= 1;
    if (out_byte != NULL) {
        *out_byte = sb->data[sb->len];
    }
    return true;
}

/*
 * Function: cl_sb_truncate
 * Purpose:
 *   Truncates the builder's length to new_len bytes after bounds checking.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   new_len (cl_isize): Target length in bytes; must satisfy 0 <= new_len <= sb->len.
 * Returns:
 *   void.
 */
void cl_sb_truncate(Cl_String_Builder *sb, cl_isize new_len) {
    CL_ENSURE(sb != NULL);
    CL_BOUNDS_CHECK_RANGE(0, new_len, sb->len);
    sb->len = new_len;
}

/*
 * Function: cl_sb_to_str
 * Purpose:
 *   Returns a zero-copy Cl_Str view over the builder's current bytes.
 * Parameters:
 *   sb (const Cl_String_Builder *): Source builder, or NULL.
 * Returns:
 *   Cl_Str: Non-owning view of sb->len bytes, or CL_STR_EMPTY if empty/NULL.
 */
Cl_Str cl_sb_to_str(const Cl_String_Builder *sb) {
    if (sb == NULL || sb->len <= 0 || sb->data == NULL) {
        return CL_STR_EMPTY;
    }
    return (Cl_Str){ sb->data, sb->len };
}

/*
 * Function: cl_sb_to_cstr
 * Purpose:
 *   Ensures the builder's buffer is NUL-terminated at sb->data[sb->len]
 *   (growing by 1 byte in dynamic mode or clamping to cap - 1 in fixed-buffer
 *   mode) and returns it as a C string pointer.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder, or NULL.
 * Returns:
 *   const char *: Pointer to a NUL-terminated string, or "" if sb is NULL,
 *     empty/unallocated, or reservation fails.
 */
const char *cl_sb_to_cstr(Cl_String_Builder *sb) {
    if (sb == NULL) {
        return "";
    }
    if (sb->fixed_buffer) {
        if (sb->data == NULL || sb->cap <= 0) {
            return "";
        }
        if (sb->len >= sb->cap) {
            sb->len = sb->cap - 1;
            sb->truncated = true;
        }
        sb->data[sb->len] = '\0';
        return (const char *)sb->data;
    }
    if (sb->len == 0 && sb->data == NULL) {
        return "";
    }
    if (!cl_sb_reserve(sb, sb->len + 1)) {
        return "";
    }
    sb->data[sb->len] = '\0';
    return (const char *)sb->data;
}

/*
 * Function: cl_sb_clone_str
 * Purpose:
 *   Allocates an exact-length copy of the builder's current string from alloc.
 * Parameters:
 *   sb (const Cl_String_Builder *): Source builder, or NULL.
 *   alloc (Cl_Allocator): Allocator for the clone (falls back to context).
 * Returns:
 *   Cl_Str: Newly allocated Cl_Str copy, or CL_STR_EMPTY if empty or OOM.
 */
Cl_Str cl_sb_clone_str(const Cl_String_Builder *sb, Cl_Allocator alloc) {
    return cl_str_clone(cl_sb_to_str(sb), alloc);
}

/* ----------------------------------------------------------------------------
 * Formatting Helpers (cl_aprintf / cl_tprintf / cl_bprintf)
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_vaprintf
 * Purpose:
 *   Internal va_list implementation backing cl_aprintf and cl_tprintf.
 *   Formats into a stack buffer (< 512 bytes) or scratch buffer and copies
 *   exactly needed bytes into alloc so cl_str_free receives the exact size.
 * Parameters:
 *   alloc (Cl_Allocator): Allocator for the output bytes (falls back to context).
 *   fmt (const char *): NUL-terminated printf format string (NULL returns empty).
 *   args (va_list): Variadic arguments matching fmt.
 * Returns:
 *   Cl_Str: Newly allocated formatted string of needed bytes, or CL_STR_EMPTY.
 */
static Cl_Str cl_vaprintf(Cl_Allocator alloc, const char *fmt, va_list args) {
    if (fmt == NULL) {
        return CL_STR_EMPTY;
    }
    va_list copy;
    va_copy(copy, args);
    int needed = vsnprintf(NULL, 0, fmt, args);
    if (needed <= 0) {
        va_end(copy);
        return CL_STR_EMPTY;
    }

    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    /* Format into a temporary NUL-terminated buffer then copy exact `needed` bytes
       so cl_str_free(s, alloc) passes the exact allocation size! */
    char stack_buf[512];
    cl_u8 *dst = (cl_u8 *)cl_alloc_non_zeroed_aligned_loc(a, (cl_isize)needed, 1, CL_HERE);
    if (dst == NULL) {
        va_end(copy);
        return CL_STR_EMPTY;
    }

    if ((cl_isize)needed < (cl_isize)sizeof(stack_buf)) {
        vsnprintf(stack_buf, sizeof(stack_buf), fmt, copy);
        va_end(copy);
        cl_mem_copy(dst, stack_buf, (cl_isize)needed);
    } else {
        Cl_Scratch scratch = cl_scratch_begin(&a, 1);
        char *tmp = (char *)cl_alloc_non_zeroed_aligned_loc(scratch.allocator, (cl_isize)needed + 1, 1, CL_HERE);
        if (tmp != NULL) {
            vsnprintf(tmp, (cl_usize)needed + 1u, fmt, copy);
            cl_mem_copy(dst, tmp, (cl_isize)needed);
        }
        va_end(copy);
        cl_scratch_end(scratch);
    }

    return (Cl_Str){ dst, (cl_isize)needed };
}

/*
 * Function: cl_aprintf
 * Purpose:
 *   Formats a printf-style string into a newly allocated Cl_Str from alloc.
 * Parameters:
 *   alloc (Cl_Allocator): Allocator for output bytes (falls back to context).
 *   fmt (const char *): NUL-terminated printf format string.
 *   ... (variadic): Arguments matching fmt.
 * Returns:
 *   Cl_Str: Newly allocated formatted string, or CL_STR_EMPTY on error/OOM.
 */
Cl_Str cl_aprintf(Cl_Allocator alloc, const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    Cl_Str s = cl_vaprintf(alloc, fmt, args);
    va_end(args);
    return s;
}

/*
 * Function: cl_tprintf
 * Purpose:
 *   Formats a printf-style string into the thread-local temporary allocator.
 * Parameters:
 *   fmt (const char *): NUL-terminated printf format string.
 *   ... (variadic): Arguments matching fmt.
 * Returns:
 *   Cl_Str: Temp-allocated formatted string, or CL_STR_EMPTY on error/OOM.
 */
Cl_Str cl_tprintf(const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    Cl_Str s = cl_vaprintf(cl_ctx_temp_allocator(), fmt, args);
    va_end(args);
    return s;
}

/*
 * Function: cl_bprintf
 * Purpose:
 *   Formats a printf-style string into caller-owned buf[buf_cap] with
 *   guaranteed NUL termination and returns a non-owning view of written bytes.
 * Parameters:
 *   buf (char *): Destination buffer, or NULL.
 *   buf_cap (cl_isize): Total capacity of buf in bytes, including NUL.
 *   fmt (const char *): NUL-terminated printf format string, or NULL.
 *   ... (variadic): Arguments matching fmt.
 * Returns:
 *   Cl_Str: Non-owning view into buf (length <= buf_cap - 1 bytes), or
 *     CL_STR_EMPTY on invalid arguments, empty output, or formatting error.
 */
Cl_Str cl_bprintf(char *buf, cl_isize buf_cap, const char *fmt, ...) {
    if (buf == NULL || buf_cap <= 0 || fmt == NULL) {
        return CL_STR_EMPTY;
    }
    va_list args;
    va_start(args, fmt);
    int n = vsnprintf(buf, (cl_usize)buf_cap, fmt, args);
    va_end(args);
    if (n <= 0) {
        buf[0] = '\0';
        return CL_STR_EMPTY;
    }
    cl_isize actual = (n >= buf_cap) ? (buf_cap - 1) : (cl_isize)n;
    buf[actual] = '\0';
    return (Cl_Str){ (const cl_u8 *)buf, actual };
}
