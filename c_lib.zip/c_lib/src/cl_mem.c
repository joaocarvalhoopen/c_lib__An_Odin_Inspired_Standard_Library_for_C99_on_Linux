/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_mem.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Implementation of UBSan-safe memory primitives and bounded C-string
 *   copy/concatenation utilities.
 * ============================================================================
 */

#include "cl/cl_mem.h"
#include <string.h>

/*
 * Zero-initializes size bytes starting at dst via memset, returning early if
 * dst is NULL or size <= 0 to avoid C99/UBSan undefined behavior.
 *
 * Parameters:
 *   dst  (void *)   - Destination buffer pointer (may be NULL).
 *   size (cl_isize) - Number of bytes to clear (bytes; <= 0 is a no-op).
 */
void cl_mem_zero(void *dst, cl_isize size) {
    if (size <= 0 || dst == NULL) {
        return;
    }
    memset(dst, 0, (cl_usize)size);
}

/*
 * Fills size bytes starting at dst with byte_val via memset, returning early
 * if dst is NULL or size <= 0.
 *
 * Parameters:
 *   dst      (void *)   - Destination buffer pointer (may be NULL).
 *   byte_val (cl_u8)    - Byte pattern to write, in range 0x00..0xFF.
 *   size     (cl_isize) - Number of bytes to fill (bytes; <= 0 is a no-op).
 */
void cl_mem_set(void *dst, cl_u8 byte_val, cl_isize size) {
    if (size <= 0 || dst == NULL) {
        return;
    }
    memset(dst, (int)byte_val, (cl_usize)size);
}

/*
 * Copies size non-overlapping bytes from src to dst via memcpy, returning
 * early if size <= 0, dst is NULL, src is NULL, or dst == src.
 *
 * Parameters:
 *   dst  (void *)       - Destination buffer pointer (must not overlap src).
 *   src  (const void *) - Source buffer pointer (must not overlap dst).
 *   size (cl_isize)     - Number of bytes to copy (bytes; <= 0 is a no-op).
 */
void cl_mem_copy(void *dst, const void *src, cl_isize size) {
    if (size <= 0 || dst == NULL || src == NULL || dst == src) {
        return;
    }
    memcpy(dst, src, (cl_usize)size);
}

/*
 * Copies size possibly overlapping bytes from src to dst via memmove,
 * returning early if size <= 0, dst is NULL, src is NULL, or dst == src.
 *
 * Parameters:
 *   dst  (void *)       - Destination buffer pointer (may overlap src).
 *   src  (const void *) - Source buffer pointer (may overlap dst).
 *   size (cl_isize)     - Number of bytes to move (bytes; <= 0 is a no-op).
 */
void cl_mem_move(void *dst, const void *src, cl_isize size) {
    if (size <= 0 || dst == NULL || src == NULL || dst == src) {
        return;
    }
    memmove(dst, src, (cl_usize)size);
}

/*
 * Compares size bytes at a and b via memcmp, returning 0 immediately when
 * size <= 0 or a == b and asserting both pointers are non-NULL otherwise.
 *
 * Parameters:
 *   a    (const void *) - First memory buffer (non-NULL when size > 0 and a != b).
 *   b    (const void *) - Second memory buffer (non-NULL when size > 0 and a != b).
 *   size (cl_isize)     - Number of bytes to compare (bytes).
 *
 * Returns:
 *   (int) < 0 if a < b, 0 if equal (or size <= 0 or a == b), > 0 if a > b.
 */
int cl_mem_cmp(const void *a, const void *b, cl_isize size) {
    if (size <= 0 || a == b) {
        return 0;
    }
    CL_ASSERT(a != NULL && b != NULL);
    return memcmp(a, b, (cl_usize)size);
}

/*
 * Checks byte-for-byte equality of two memory regions by delegating to
 * cl_mem_cmp().
 *
 * Parameters:
 *   a    (const void *) - First memory buffer (non-NULL when size > 0 and a != b).
 *   b    (const void *) - Second memory buffer (non-NULL when size > 0 and a != b).
 *   size (cl_isize)     - Number of bytes to compare (bytes).
 *
 * Returns:
 *   (bool) true if all size bytes match (or size <= 0 or a == b); false otherwise.
 */
bool cl_mem_eq(const void *a, const void *b, cl_isize size) {
    return cl_mem_cmp(a, b, size) == 0;
}

/*
 * Copies up to (dst_cap - 1) bytes from NUL-terminated string src into dst and
 * writes a trailing NUL byte whenever dst != NULL and dst_cap > 0.
 *
 * Parameters:
 *   dst     (char *)       - Destination character buffer (may be NULL).
 *   dst_cap (cl_isize)     - Total buffer capacity in bytes, including NUL terminator.
 *   src     (const char *) - NUL-terminated source C string (NULL writes empty string).
 *
 * Returns:
 *   (cl_isize) Full length of src in bytes excluding NUL (0 if src is NULL);
 *              truncation occurred if the returned value >= dst_cap.
 */
cl_isize cl_cstr_copy_n(char *dst, cl_isize dst_cap, const char *src) {
    if (src == NULL) {
        if (dst != NULL && dst_cap > 0) {
            dst[0] = '\0';
        }
        return 0;
    }
    cl_isize src_len = (cl_isize)strlen(src);
    if (dst != NULL && dst_cap > 0) {
        cl_isize to_copy = (src_len < dst_cap - 1) ? src_len : (dst_cap - 1);
        cl_mem_copy(dst, src, to_copy);
        dst[to_copy] = '\0';
    }
    return src_len;
}

/*
 * Appends NUL-terminated string src to the existing NUL-terminated string in
 * dst without exceeding dst_cap bytes, preserving NUL termination when a NUL
 * exists within dst_cap.
 *
 * Parameters:
 *   dst     (char *)       - Destination buffer holding a NUL-terminated C string (may be NULL).
 *   dst_cap (cl_isize)     - Total buffer capacity in bytes, including NUL terminator.
 *   src     (const char *) - NUL-terminated source C string to append (NULL is a no-op).
 *
 * Returns:
 *   (cl_isize) Intended combined length in bytes excluding NUL: min(existing dst len,
 *              dst_cap) + strlen(src); truncation occurred if the returned value >= dst_cap.
 */
cl_isize cl_cstr_cat_n(char *dst, cl_isize dst_cap, const char *src) {
    if (dst == NULL || dst_cap <= 0) {
        return src ? (cl_isize)strlen(src) : 0;
    }
    cl_isize dst_len = 0;
    while (dst_len < dst_cap && dst[dst_len] != '\0') {
        dst_len++;
    }
    if (dst_len == dst_cap) {
        return dst_cap + (src ? (cl_isize)strlen(src) : 0);
    }
    if (src == NULL) {
        return dst_len;
    }
    cl_isize src_len = (cl_isize)strlen(src);
    cl_isize avail = dst_cap - dst_len - 1;
    cl_isize to_copy = (src_len < avail) ? src_len : avail;
    cl_mem_copy(dst + dst_len, src, to_copy);
    dst[dst_len + to_copy] = '\0';
    return dst_len + src_len;
}
