/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_map.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Implementation of the Swiss-inspired H2 control-byte + dense-array
 *   HashMap engine backing all CL_MAP_DEFINE types.
 * ============================================================================
 */

#include "cl/cl_map.h"

/*
 * Control-byte sentinel (0xFF) marking an unoccupied bucket that has never
 * been filled since the last rehash or clear. Terminates linear probing.
 */
#define CL_MAP_CTRL_EMPTY     0xFFu

/*
 * Control-byte sentinel (0xFE) marking a previously occupied bucket whose
 * entry was deleted. Linear probes continue past tombstones, and insertions
 * reuse the first tombstone observed along the probe sequence.
 */
#define CL_MAP_CTRL_TOMBSTONE 0xFEu

/*
 * Extracts the 7-bit H2 metadata tag (low 7 bits, range [0x00, 0x7F]) from a
 * 64-bit key hash. Guaranteed disjoint from CL_MAP_CTRL_EMPTY (0xFF) and
 * CL_MAP_CTRL_TOMBSTONE (0xFE).
 *
 * Parameters:
 *   hash (cl_u64) - Full 64-bit hash value of a key.
 *
 * Returns:
 *   (cl_u8) 7-bit H2 control tag in [0x00, 0x7F].
 */
static inline cl_u8 cl_map_h2(cl_u64 hash) {
    return (cl_u8)(hash & 0x7Fu);
}

/*
 * Computes the initial open-addressing bucket index (H1) from the upper 57
 * bits of a 64-bit key hash masked against a power-of-two bucket mask.
 *
 * Parameters:
 *   hash (cl_u64)   - Full 64-bit hash value of a key.
 *   mask (cl_usize) - Bucket index mask equal to (bucket_cap - 1).
 *
 * Returns:
 *   (cl_usize) 0-based initial bucket index in [0, bucket_cap).
 */
static inline cl_usize cl_map_h1(cl_u64 hash, cl_usize mask) {
    return (cl_usize)((hash >> 7) & mask);
}

/*
 * Lazily populates unset defaults on a zero-initialized map header: binds
 * cl_ctx_allocator() when allocator is invalid, cl_map_hash_bytes when
 * hash_fn is NULL, and cl_map_eq_bytes when eq_fn is NULL.
 *
 * Parameters:
 *   hdr (Cl_Map_Header *) - Non-NULL pointer to the map header.
 */
static inline void cl_map_ensure_defaults(Cl_Map_Header *hdr) {
    if (!cl_allocator_is_valid(hdr->allocator)) {
        hdr->allocator = cl_ctx_allocator();
    }
    if (hdr->hash_fn == NULL) {
        hdr->hash_fn = cl_map_hash_bytes;
    }
    if (hdr->eq_fn == NULL) {
        hdr->eq_fn = cl_map_eq_bytes;
    }
}

/*
 * Rounds v upward to the smallest power of two >= max(v, 16), stopping before
 * doubling would overflow PTRDIFF_MAX.
 *
 * Parameters:
 *   v (cl_isize) - Minimum target bucket count (buckets).
 *
 * Returns:
 *   (cl_isize) Power-of-two bucket count >= 16 (buckets).
 */
static cl_isize cl_next_pow2_isize(cl_isize v) {
    cl_isize p = 16;
    while (p < v) {
        if (p > PTRDIFF_MAX / 2) {
            return p;
        }
        p *= 2;
    }
    return p;
}

/*
 * Allocates fresh ctrl[] and slot_indices[] tables of power-of-two size
 * >= max(new_bucket_cap, 16), re-inserts all hdr->len active dense entries
 * using their cached 64-bit hashes (eliminating all tombstones), frees the old
 * bucket arrays, and resets hdr->tombstones to 0.
 *
 * Parameters:
 *   hdr            (Cl_Map_Header *) - Non-NULL map header with valid allocator.
 *   new_bucket_cap (cl_isize)        - Requested minimum bucket count (buckets).
 *   loc            (Cl_Source_Loc)   - Caller source location for diagnostics.
 *
 * Returns:
 *   (bool) true if rehashing succeeded, or false on allocation failure
 *          (leaving the previous bucket table intact).
 */
static bool cl_map_rehash_buckets(Cl_Map_Header *hdr, cl_isize new_bucket_cap, Cl_Source_Loc loc) {
    new_bucket_cap = cl_next_pow2_isize(new_bucket_cap);
    cl_u8 *new_ctrl = (cl_u8 *)cl_alloc_non_zeroed_aligned_loc(
        hdr->allocator, new_bucket_cap, CL_DEFAULT_ALIGNMENT, loc
    );
    if (new_ctrl == NULL) {
        return false;
    }
    cl_isize *new_slots = (cl_isize *)cl_alloc_array_loc(
        hdr->allocator, new_bucket_cap, (cl_isize)sizeof(cl_isize), CL_ALIGNOF(cl_isize), false, loc
    );
    if (new_slots == NULL) {
        cl_free_loc(hdr->allocator, new_ctrl, new_bucket_cap, loc);
        return false;
    }

    cl_mem_set(new_ctrl, CL_MAP_CTRL_EMPTY, new_bucket_cap);

    cl_usize mask = (cl_usize)(new_bucket_cap - 1);
    for (cl_isize d = 0; d < hdr->len; d++) {
        cl_u64 h = hdr->hashes[d];
        cl_u8 tag = cl_map_h2(h);
        cl_usize b = cl_map_h1(h, mask);
        while (new_ctrl[b] != CL_MAP_CTRL_EMPTY) {
            b = (b + 1u) & mask;
        }
        new_ctrl[b]  = tag;
        new_slots[b] = d;
    }

    if (hdr->ctrl != NULL) {
        cl_free_loc(hdr->allocator, hdr->ctrl, hdr->bucket_cap, loc);
    }
    if (hdr->slot_indices != NULL) {
        cl_free_loc(
            hdr->allocator,
            hdr->slot_indices,
            hdr->bucket_cap * (cl_isize)sizeof(cl_isize),
            loc
        );
    }

    hdr->ctrl         = new_ctrl;
    hdr->slot_indices = new_slots;
    hdr->bucket_cap   = new_bucket_cap;
    hdr->tombstones   = 0;
    return true;
}

/*
 * Exponentially grows the parallel dense keys, values, and hashes arrays
 * (starting at 8 entries and doubling until >= min_dense_cap, clamped before
 * PTRDIFF_MAX / 2 overflow) and updates bufs->keys, bufs->values, hdr->hashes,
 * and hdr->dense_cap.
 *
 * Parameters:
 *   hdr           (Cl_Map_Header *)     - Non-NULL map header with valid allocator.
 *   bufs          (Cl_Map_Dense_Bufs *) - Non-NULL in/out dense buffer pointers.
 *   min_dense_cap (cl_isize)            - Minimum required dense capacity (entries).
 *   key_size      (cl_isize)            - Size of one key (bytes; > 0).
 *   key_align     (cl_isize)            - Power-of-two key alignment (bytes).
 *   val_size      (cl_isize)            - Size of one value (bytes; > 0).
 *   val_align     (cl_isize)            - Power-of-two value alignment (bytes).
 *   loc           (Cl_Source_Loc)       - Caller source location for diagnostics.
 *
 * Returns:
 *   (bool) true if dense capacity satisfies min_dense_cap, or false on
 *          byte-size overflow or allocation failure.
 */
static bool cl_map_grow_dense(
    Cl_Map_Header *hdr,
    Cl_Map_Dense_Bufs *bufs,
    cl_isize min_dense_cap,
    cl_isize key_size,
    cl_isize key_align,
    cl_isize val_size,
    cl_isize val_align,
    Cl_Source_Loc loc
) {
    if (min_dense_cap <= hdr->dense_cap) {
        return true;
    }

    cl_isize new_cap = (hdr->dense_cap > 0) ? hdr->dense_cap : 8;
    while (new_cap < min_dense_cap) {
        if (new_cap > PTRDIFF_MAX / 2) {
            new_cap = min_dense_cap;
            break;
        }
        new_cap *= 2;
    }

    cl_isize old_k_bytes = 0, new_k_bytes = 0;
    cl_isize old_v_bytes = 0, new_v_bytes = 0;
    cl_isize old_h_bytes = 0, new_h_bytes = 0;
    if (cl_mul_overflow_isize(hdr->dense_cap, key_size, &old_k_bytes) ||
        cl_mul_overflow_isize(new_cap,        key_size, &new_k_bytes) ||
        cl_mul_overflow_isize(hdr->dense_cap, val_size, &old_v_bytes) ||
        cl_mul_overflow_isize(new_cap,        val_size, &new_v_bytes) ||
        cl_mul_overflow_isize(hdr->dense_cap, (cl_isize)sizeof(cl_u64), &old_h_bytes) ||
        cl_mul_overflow_isize(new_cap,        (cl_isize)sizeof(cl_u64), &new_h_bytes)) {
        return false;
    }

    void *new_keys = cl_resize_aligned_loc(
        hdr->allocator, bufs->keys, old_k_bytes, new_k_bytes, key_align, loc
    );
    if (new_keys == NULL) {
        return false;
    }
    bufs->keys = new_keys;

    void *new_vals = cl_resize_aligned_loc(
        hdr->allocator, bufs->values, old_v_bytes, new_v_bytes, val_align, loc
    );
    if (new_vals == NULL) {
        return false;
    }
    bufs->values = new_vals;

    cl_u64 *new_hashes = (cl_u64 *)cl_resize_aligned_loc(
        hdr->allocator, hdr->hashes, old_h_bytes, new_h_bytes, CL_ALIGNOF(cl_u64), loc
    );
    if (new_hashes == NULL) {
        return false;
    }
    hdr->hashes    = new_hashes;
    hdr->dense_cap = new_cap;
    return true;
}

/*
 * Zeroes *hdr and installs the given allocator, hash_fn (defaulting to
 * cl_map_hash_bytes if NULL), and eq_fn (defaulting to cl_map_eq_bytes if NULL).
 *
 * Parameters:
 *   hdr     (Cl_Map_Header *) - Non-NULL pointer to the map header.
 *   alloc   (Cl_Allocator)    - Backing allocator handle.
 *   hash_fn (Cl_Hash_Proc)    - Key hash callback, or NULL for bytewise default.
 *   eq_fn   (Cl_Eq_Proc)      - Key equality callback, or NULL for bytewise default.
 */
void cl_map_init_hdr(
    Cl_Map_Header *hdr,
    Cl_Allocator alloc,
    Cl_Hash_Proc hash_fn,
    Cl_Eq_Proc eq_fn
) {
    CL_ENSURE(hdr != NULL);
    CL_ZERO_STRUCT(hdr);
    hdr->allocator = alloc;
    hdr->hash_fn   = hash_fn ? hash_fn : cl_map_hash_bytes;
    hdr->eq_fn     = eq_fn   ? eq_fn   : cl_map_eq_bytes;
}

/*
 * Pre-allocates dense buffers for min_entries entries and rehashes the bucket
 * table if bucket_cap < (min_entries * 4) / 3 + 2 to maintain load factor <= 75%.
 *
 * Parameters:
 *   hdr         (Cl_Map_Header *)     - Non-NULL map header.
 *   bufs        (Cl_Map_Dense_Bufs *) - Non-NULL in/out dense buffer pointers.
 *   min_entries (cl_isize)            - Minimum entry count to reserve (entries).
 *   key_size    (cl_isize)            - Size of one key (bytes; > 0).
 *   key_align   (cl_isize)            - Power-of-two key alignment (bytes).
 *   val_size    (cl_isize)            - Size of one value (bytes; > 0).
 *   val_align   (cl_isize)            - Power-of-two value alignment (bytes).
 *   loc         (Cl_Source_Loc)       - Caller source location for diagnostics.
 *
 * Returns:
 *   (bool) true on success (or if min_entries <= 0), or false on overflow or
 *          allocation failure.
 */
bool cl_map_reserve_raw(
    Cl_Map_Header *hdr,
    Cl_Map_Dense_Bufs *bufs,
    cl_isize min_entries,
    cl_isize key_size,
    cl_isize key_align,
    cl_isize val_size,
    cl_isize val_align,
    Cl_Source_Loc loc
) {
    CL_ENSURE(hdr != NULL && bufs != NULL);
    if (min_entries <= 0) {
        return true;
    }
    cl_map_ensure_defaults(hdr);

    if (!cl_map_grow_dense(hdr, bufs, min_entries, key_size, key_align, val_size, val_align, loc)) {
        return false;
    }

    /* Keep bucket load factor <= 75% (so bucket_cap >= ceil(min_entries * 4 / 3)) */
    cl_isize needed_buckets = (min_entries * 4) / 3 + 2;
    if (needed_buckets > hdr->bucket_cap) {
        if (!cl_map_rehash_buckets(hdr, needed_buckets, loc)) {
            return false;
        }
    }
    return true;
}

/*
 * Inserts (key_ptr, val_ptr) as a new dense entry or updates an existing key's
 * value in place. Rehashes when (len + tombstones + 1) * 4 >= bucket_cap * 3
 * (doubling bucket_cap when len * 2 >= bucket_cap, otherwise rehashing in place
 * to reclaim tombstones). Reuses the first tombstone seen on insertion.
 *
 * Parameters:
 *   hdr       (Cl_Map_Header *)     - Non-NULL map header.
 *   bufs      (Cl_Map_Dense_Bufs *) - Non-NULL in/out dense buffer pointers.
 *   key_ptr   (const void *)        - Non-NULL pointer to key bytes.
 *   val_ptr   (const void *)        - Non-NULL pointer to value bytes.
 *   key_size  (cl_isize)            - Size of one key (bytes; > 0).
 *   key_align (cl_isize)            - Power-of-two key alignment (bytes).
 *   val_size  (cl_isize)            - Size of one value (bytes; > 0).
 *   val_align (cl_isize)            - Power-of-two value alignment (bytes).
 *   loc       (Cl_Source_Loc)       - Caller source location for diagnostics.
 *
 * Returns:
 *   (bool) true if a new key was inserted, or false if an existing key's value
 *          was overwritten in place.
 */
bool cl_map_put_raw(
    Cl_Map_Header *hdr,
    Cl_Map_Dense_Bufs *bufs,
    const void *key_ptr,
    const void *val_ptr,
    cl_isize key_size,
    cl_isize key_align,
    cl_isize val_size,
    cl_isize val_align,
    Cl_Source_Loc loc
) {
    CL_ENSURE(hdr != NULL && bufs != NULL && key_ptr != NULL && val_ptr != NULL);
    cl_map_ensure_defaults(hdr);

    /* Ensure bucket table exists and load factor (including tombstones) stays <= 75% */
    if (hdr->bucket_cap == 0) {
        CL_ENSURE(cl_map_rehash_buckets(hdr, 16, loc));
    } else if ((hdr->len + hdr->tombstones + 1) * 4 >= hdr->bucket_cap * 3) {
        cl_isize target = (hdr->len * 2 >= hdr->bucket_cap) ? (hdr->bucket_cap * 2) : hdr->bucket_cap;
        CL_ENSURE(cl_map_rehash_buckets(hdr, target, loc));
    }

    cl_u64 hash = hdr->hash_fn(key_ptr, key_size);
    cl_u8  tag  = cl_map_h2(hash);
    cl_usize mask = (cl_usize)(hdr->bucket_cap - 1);
    cl_usize b    = cl_map_h1(hash, mask);
    cl_isize first_tomb = -1;

    const cl_u8 *keys_bytes = (const cl_u8 *)bufs->keys;

    for (cl_isize probe = 0; probe < hdr->bucket_cap; probe++) {
        cl_u8 c = hdr->ctrl[b];
        if (c == CL_MAP_CTRL_EMPTY) {
            /* Key not found -> insert new dense entry */
            CL_ENSURE(cl_map_grow_dense(
                hdr, bufs, hdr->len + 1, key_size, key_align, val_size, val_align, loc
            ));
            cl_isize target_bucket = (first_tomb >= 0) ? first_tomb : (cl_isize)b;
            if (first_tomb >= 0) {
                hdr->tombstones -= 1;
            }
            cl_isize d = hdr->len;
            cl_mem_copy((cl_u8 *)bufs->keys + d * key_size, key_ptr, key_size);
            cl_mem_copy((cl_u8 *)bufs->values + d * val_size, val_ptr, val_size);
            hdr->hashes[d] = hash;
            hdr->ctrl[target_bucket]         = tag;
            hdr->slot_indices[target_bucket] = d;
            hdr->len += 1;
            return true;
        }
        if (c == CL_MAP_CTRL_TOMBSTONE) {
            if (first_tomb < 0) {
                first_tomb = (cl_isize)b;
            }
        } else if (c == tag) {
            cl_isize d = hdr->slot_indices[b];
            if (hdr->hashes[d] == hash &&
                hdr->eq_fn(keys_bytes + d * key_size, key_ptr, key_size)) {
                /* Key already exists -> overwrite value in place */
                cl_mem_copy((cl_u8 *)bufs->values + d * val_size, val_ptr, val_size);
                return false;
            }
        }
        b = (b + 1u) & mask;
    }

    CL_UNREACHABLE();
    return false;
}

/*
 * Searches the open-addressing bucket table linearly starting at H1(hash),
 * comparing 7-bit H2 tags first, then full 64-bit cached hashes, then eq_fn.
 * Stops upon encountering CL_MAP_CTRL_EMPTY.
 *
 * Parameters:
 *   hdr      (const Cl_Map_Header *) - Map header (may be NULL or empty).
 *   keys     (const void *)          - Dense keys buffer.
 *   key_ptr  (const void *)          - Pointer to lookup key bytes.
 *   key_size (cl_isize)              - Size of one key (bytes).
 *
 * Returns:
 *   (cl_isize) 0-based dense entry index in [0, hdr->len) if found, or -1 if
 *              absent or any precondition is unmet.
 */
cl_isize cl_map_find_raw(
    const Cl_Map_Header *hdr,
    const void *keys,
    const void *key_ptr,
    cl_isize key_size
) {
    if (hdr == NULL || hdr->len == 0 || hdr->bucket_cap == 0 || keys == NULL || key_ptr == NULL) {
        return -1;
    }

    Cl_Hash_Proc hash_fn = hdr->hash_fn ? hdr->hash_fn : cl_map_hash_bytes;
    Cl_Eq_Proc   eq_fn   = hdr->eq_fn   ? hdr->eq_fn   : cl_map_eq_bytes;

    cl_u64 hash = hash_fn(key_ptr, key_size);
    cl_u8  tag  = cl_map_h2(hash);
    cl_usize mask = (cl_usize)(hdr->bucket_cap - 1);
    cl_usize b    = cl_map_h1(hash, mask);
    const cl_u8 *keys_bytes = (const cl_u8 *)keys;

    for (cl_isize probe = 0; probe < hdr->bucket_cap; probe++) {
        cl_u8 c = hdr->ctrl[b];
        if (c == CL_MAP_CTRL_EMPTY) {
            return -1;
        }
        if (c == tag) {
            cl_isize d = hdr->slot_indices[b];
            if (hdr->hashes[d] == hash &&
                eq_fn(keys_bytes + d * key_size, key_ptr, key_size)) {
                return d;
            }
        }
        b = (b + 1u) & mask;
    }
    return -1;
}

/*
 * Removes the entry matching *key_ptr if present by writing
 * CL_MAP_CTRL_TOMBSTONE into its bucket, relocating the last dense entry
 * (hdr->len - 1) into the vacated dense slot, updating that entry's bucket
 * slot_indices, and decrementing hdr->len.
 *
 * Parameters:
 *   hdr      (Cl_Map_Header *) - Map header (may be NULL or empty).
 *   keys     (void *)          - Dense keys buffer.
 *   values   (void *)          - Dense values buffer.
 *   key_ptr  (const void *)    - Pointer to key bytes to delete.
 *   key_size (cl_isize)        - Size of one key (bytes).
 *   val_size (cl_isize)        - Size of one value (bytes).
 *
 * Returns:
 *   (bool) true if the entry was found and deleted, or false if absent or
 *          arguments/map are empty/NULL.
 */
bool cl_map_delete_raw(
    Cl_Map_Header *hdr,
    void *keys,
    void *values,
    const void *key_ptr,
    cl_isize key_size,
    cl_isize val_size
) {
    if (hdr == NULL || hdr->len == 0 || hdr->bucket_cap == 0 || keys == NULL || key_ptr == NULL) {
        return false;
    }

    Cl_Hash_Proc hash_fn = hdr->hash_fn ? hdr->hash_fn : cl_map_hash_bytes;
    Cl_Eq_Proc   eq_fn   = hdr->eq_fn   ? hdr->eq_fn   : cl_map_eq_bytes;

    cl_u64 hash = hash_fn(key_ptr, key_size);
    cl_u8  tag  = cl_map_h2(hash);
    cl_usize mask = (cl_usize)(hdr->bucket_cap - 1);
    cl_usize b    = cl_map_h1(hash, mask);
    cl_u8 *keys_bytes = (cl_u8 *)keys;
    cl_u8 *vals_bytes = (cl_u8 *)values;

    cl_isize found_bucket = -1;
    cl_isize found_dense  = -1;

    for (cl_isize probe = 0; probe < hdr->bucket_cap; probe++) {
        cl_u8 c = hdr->ctrl[b];
        if (c == CL_MAP_CTRL_EMPTY) {
            return false;
        }
        if (c == tag) {
            cl_isize d = hdr->slot_indices[b];
            if (hdr->hashes[d] == hash &&
                eq_fn(keys_bytes + d * key_size, key_ptr, key_size)) {
                found_bucket = (cl_isize)b;
                found_dense  = d;
                break;
            }
        }
        b = (b + 1u) & mask;
    }

    if (found_bucket < 0) {
        return false;
    }

    /* Mark deleted entry's bucket as tombstone to keep probe chains intact */
    hdr->ctrl[found_bucket] = CL_MAP_CTRL_TOMBSTONE;
    hdr->tombstones += 1;

    cl_isize last = hdr->len - 1;
    if (found_dense != last) {
        /* Relocate the last dense entry into slot `found_dense` */
        cl_u64 last_hash = hdr->hashes[last];
        cl_u8  last_tag  = cl_map_h2(last_hash);
        cl_usize lb      = cl_map_h1(last_hash, mask);

        bool updated = false;
        for (cl_isize probe = 0; probe < hdr->bucket_cap; probe++) {
            if (hdr->ctrl[lb] == last_tag && hdr->slot_indices[lb] == last) {
                hdr->slot_indices[lb] = found_dense;
                updated = true;
                break;
            }
            lb = (lb + 1u) & mask;
        }
        CL_ASSERT(updated);
        CL_UNUSED_VAR(updated);

        cl_mem_copy(keys_bytes + found_dense * key_size, keys_bytes + last * key_size, key_size);
        cl_mem_copy(vals_bytes + found_dense * val_size, vals_bytes + last * val_size, val_size);
        hdr->hashes[found_dense] = last_hash;
    }

    hdr->len -= 1;
    return true;
}

/*
 * Resets all bucket control bytes to CL_MAP_CTRL_EMPTY and zeroes hdr->len and
 * hdr->tombstones while keeping allocated bucket and dense buffers for reuse.
 * Safe no-op if hdr == NULL.
 *
 * Parameters:
 *   hdr (Cl_Map_Header *) - Pointer to the map header to clear.
 */
void cl_map_clear_raw(Cl_Map_Header *hdr) {
    if (hdr == NULL) {
        return;
    }
    if (hdr->ctrl != NULL && hdr->bucket_cap > 0) {
        cl_mem_set(hdr->ctrl, CL_MAP_CTRL_EMPTY, hdr->bucket_cap);
    }
    hdr->len        = 0;
    hdr->tombstones = 0;
}

/*
 * Frees all five backing buffers (ctrl, slot_indices, hashes, keys, values)
 * through cl_alloc_or_ctx(hdr->allocator) and clears header buffer pointers,
 * capacities, len, and tombstones to 0/NULL. Safe no-op if hdr == NULL.
 *
 * Parameters:
 *   hdr      (Cl_Map_Header *) - Pointer to the map header.
 *   keys     (void *)          - Dense keys buffer to free, or NULL.
 *   values   (void *)          - Dense values buffer to free, or NULL.
 *   key_size (cl_isize)        - Size of one key (bytes).
 *   val_size (cl_isize)        - Size of one value (bytes).
 *   loc      (Cl_Source_Loc)   - Caller source location for diagnostics.
 */
void cl_map_free_raw(
    Cl_Map_Header *hdr,
    void *keys,
    void *values,
    cl_isize key_size,
    cl_isize val_size,
    Cl_Source_Loc loc
) {
    if (hdr == NULL) {
        return;
    }
    Cl_Allocator alloc = cl_alloc_or_ctx(hdr->allocator);
    if (hdr->ctrl != NULL) {
        cl_free_loc(alloc, hdr->ctrl, hdr->bucket_cap, loc);
    }
    if (hdr->slot_indices != NULL) {
        cl_free_loc(alloc, hdr->slot_indices, hdr->bucket_cap * (cl_isize)sizeof(cl_isize), loc);
    }
    if (hdr->hashes != NULL) {
        cl_free_loc(alloc, hdr->hashes, hdr->dense_cap * (cl_isize)sizeof(cl_u64), loc);
    }
    if (keys != NULL) {
        cl_free_loc(alloc, keys, hdr->dense_cap * key_size, loc);
    }
    if (values != NULL) {
        cl_free_loc(alloc, values, hdr->dense_cap * val_size, loc);
    }
    hdr->ctrl         = NULL;
    hdr->slot_indices = NULL;
    hdr->hashes       = NULL;
    hdr->bucket_cap   = 0;
    hdr->dense_cap    = 0;
    hdr->len          = 0;
    hdr->tombstones   = 0;
}
