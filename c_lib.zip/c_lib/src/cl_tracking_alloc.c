/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_tracking_alloc.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Implementation of Cl_Tracking_Allocator with O(1) active-pointer hash
 *   table, front/back 0xFD guard redzones, 0xCD/0xDD poison patterns,
 *   double-free ring history, bad-pointer detection, and live pointer
 *   validation.
 * ============================================================================
 */

/*
 * Feature test macro selecting POSIX.1-2008 declarations (including pthread
 * interfaces when CL_ENABLE_THREAD_SAFETY is enabled) under strict ISO C99.
 */
#define _POSIX_C_SOURCE 200809L

#include "cl/cl_tracking_alloc.h"
#include <stdlib.h>

#if CL_ENABLE_THREAD_SAFETY
    #include <pthread.h>
#endif

/*
 * Slot occupancy states stored in Cl_Tracking_Allocator.slot_states (cl_u8)
 * for open-addressed linear probing.
 *
 * Enumerators:
 *   CL_SLOT_EMPTY     (0) - Slot has never been filled since the last rehash (terminates probe).
 *   CL_SLOT_OCCUPIED  (1) - Slot holds an active Cl_Alloc_Entry record.
 *   CL_SLOT_TOMBSTONE (2) - Slot previously held an entry that was deleted (continues probe).
 */
enum {
    CL_SLOT_EMPTY     = 0,
    CL_SLOT_OCCUPIED  = 1,
    CL_SLOT_TOMBSTONE = 2
};

/* ----------------------------------------------------------------------------
 * Mutex Helpers
 * ---------------------------------------------------------------------------- */

/*
 * Acquires the tracking allocator's internal pthread mutex if thread safety is
 * compiled in and t->mutex is initialized; no-op otherwise.
 *
 * Parameters:
 *   t (const Cl_Tracking_Allocator *) - Tracker instance to lock (may be NULL).
 */
static void cl_track_lock(const Cl_Tracking_Allocator *t) {
#if CL_ENABLE_THREAD_SAFETY
    if (t && t->mutex) {
        pthread_mutex_lock((pthread_mutex_t *)t->mutex);
    }
#else
    CL_UNUSED_VAR(t);
#endif
}

/*
 * Releases the tracking allocator's internal pthread mutex if thread safety is
 * compiled in and t->mutex is initialized; no-op otherwise.
 *
 * Parameters:
 *   t (const Cl_Tracking_Allocator *) - Tracker instance to unlock (may be NULL).
 */
static void cl_track_unlock(const Cl_Tracking_Allocator *t) {
#if CL_ENABLE_THREAD_SAFETY
    if (t && t->mutex) {
        pthread_mutex_unlock((pthread_mutex_t *)t->mutex);
    }
#else
    CL_UNUSED_VAR(t);
#endif
}

/* ----------------------------------------------------------------------------
 * Pointer Hashing & Internal Table Management (Uses Raw libc calloc/free)
 * ---------------------------------------------------------------------------- */

/*
 * Computes a 64-bit SplitMix64-style avalanche hash of a raw pointer address
 * for indexing into the tracker's open-addressed active-allocation table.
 *
 * Parameters:
 *   ptr (const void *) - Virtual address to hash.
 *
 * Returns:
 *   (cl_u64) Well-mixed 64-bit unsigned hash value.
 */
static cl_u64 cl_hash_ptr(const void *ptr) {
    cl_u64 x = (cl_u64)(cl_uintptr)ptr;
    x ^= x >> 30;
    x *= 0xBF58476D1CE4E5B9ull;
    x ^= x >> 27;
    x *= 0x94D049BB133111EBull;
    x ^= x >> 31;
    return x;
}

/*
 * Allocates a fresh hash table of new_cap slots via libc calloc, re-inserts
 * all currently occupied Cl_Alloc_Entry records (clearing tombstones), and
 * replaces t->slots and t->slot_states.
 *
 * Parameters:
 *   t       (Cl_Tracking_Allocator *) - Tracker whose active table is rehashed.
 *   new_cap (cl_isize)                - New table capacity in slots; must be > 0 and a power of two.
 *
 * Returns:
 *   (bool) true if rehash succeeded; false if libc calloc failed (table left unchanged).
 */
static bool cl_track_table_rehash(Cl_Tracking_Allocator *t, cl_isize new_cap) {
    Cl_Alloc_Entry *new_slots  = (Cl_Alloc_Entry *)calloc((cl_usize)new_cap, sizeof(Cl_Alloc_Entry));
    cl_u8          *new_states = (cl_u8 *)calloc((cl_usize)new_cap, sizeof(cl_u8));
    if (!new_slots || !new_states) {
        free(new_slots);
        free(new_states);
        return false;
    }

    cl_usize mask = (cl_usize)(new_cap - 1);
    for (cl_isize i = 0; i < t->slot_cap; i++) {
        if (t->slot_states[i] == CL_SLOT_OCCUPIED) {
            cl_usize idx = (cl_usize)(cl_hash_ptr(t->slots[i].user_ptr) & mask);
            while (new_states[idx] == CL_SLOT_OCCUPIED) {
                idx = (idx + 1u) & mask;
            }
            new_slots[idx]  = t->slots[i];
            new_states[idx] = CL_SLOT_OCCUPIED;
        }
    }

    free(t->slots);
    free(t->slot_states);
    t->slots           = new_slots;
    t->slot_states     = new_states;
    t->slot_cap        = new_cap;
    t->tombstone_count = 0;
    return true;
}

/*
 * Looks up an active allocation by its exact user_ptr address using linear
 * probing in the tracker's hash table.
 *
 * Parameters:
 *   t        (const Cl_Tracking_Allocator *) - Tracker to search.
 *   user_ptr (const void *)                  - Caller-facing pointer to locate.
 *
 * Returns:
 *   (cl_isize) Zero-based slot index in [0, slot_cap) if found; -1 if not present or table empty.
 */
static cl_isize cl_track_table_find(const Cl_Tracking_Allocator *t, const void *user_ptr) {
    if (t->slot_cap == 0 || user_ptr == NULL) {
        return -1;
    }
    cl_usize mask = (cl_usize)(t->slot_cap - 1);
    cl_usize idx  = (cl_usize)(cl_hash_ptr(user_ptr) & mask);
    for (cl_isize probe = 0; probe < t->slot_cap; probe++) {
        cl_u8 st = t->slot_states[idx];
        if (st == CL_SLOT_EMPTY) {
            return -1;
        }
        if (st == CL_SLOT_OCCUPIED && t->slots[idx].user_ptr == user_ptr) {
            return (cl_isize)idx;
        }
        idx = (idx + 1u) & mask;
    }
    return -1;
}

/*
 * Inserts an active Cl_Alloc_Entry into the tracker's hash table, rehashing
 * when empty or when load + tombstones reaches 75% (3/4 of slot_cap), and
 * reusing the first encountered tombstone slot along the probe chain.
 *
 * Parameters:
 *   t     (Cl_Tracking_Allocator *) - Tracker to modify.
 *   entry (Cl_Alloc_Entry)          - Allocation metadata record to insert.
 *
 * Returns:
 *   (bool) true if inserted; false if rehash allocation failed or no slot was available.
 */
static bool cl_track_table_insert(Cl_Tracking_Allocator *t, Cl_Alloc_Entry entry) {
    if (t->slot_cap == 0) {
        if (!cl_track_table_rehash(t, 64)) {
            return false;
        }
    } else if ((t->active_count + t->tombstone_count + 1) * 4 >= t->slot_cap * 3) {
        cl_isize next_cap = (t->active_count * 2 >= t->slot_cap) ? (t->slot_cap * 2) : t->slot_cap;
        if (next_cap < 64) {
            next_cap = 64;
        }
        if (!cl_track_table_rehash(t, next_cap)) {
            return false;
        }
    }

    cl_usize mask = (cl_usize)(t->slot_cap - 1);
    cl_usize idx  = (cl_usize)(cl_hash_ptr(entry.user_ptr) & mask);
    cl_isize first_tomb = -1;

    for (cl_isize probe = 0; probe < t->slot_cap; probe++) {
        cl_u8 st = t->slot_states[idx];
        if (st == CL_SLOT_EMPTY) {
            cl_isize target = (first_tomb >= 0) ? first_tomb : (cl_isize)idx;
            if (first_tomb >= 0) {
                t->tombstone_count -= 1;
            }
            t->slots[target]       = entry;
            t->slot_states[target] = CL_SLOT_OCCUPIED;
            t->active_count       += 1;
            return true;
        }
        if (st == CL_SLOT_TOMBSTONE && first_tomb < 0) {
            first_tomb = (cl_isize)idx;
        }
        idx = (idx + 1u) & mask;
    }
    return false;
}

/*
 * Removes the occupied entry at slot_idx by marking it CL_SLOT_TOMBSTONE,
 * decrementing active_count, and incrementing tombstone_count.
 *
 * Parameters:
 *   t        (Cl_Tracking_Allocator *) - Tracker to modify.
 *   slot_idx (cl_isize)                - Valid index of an occupied slot in [0, slot_cap).
 */
static void cl_track_table_remove_at(Cl_Tracking_Allocator *t, cl_isize slot_idx) {
    CL_ASSERT(slot_idx >= 0 && slot_idx < t->slot_cap);
    CL_ASSERT(t->slot_states[slot_idx] == CL_SLOT_OCCUPIED);
    t->slot_states[slot_idx] = CL_SLOT_TOMBSTONE;
    t->active_count         -= 1;
    t->tombstone_count      += 1;
}

/* ----------------------------------------------------------------------------
 * Diagnostics & Redzone Helpers
 * ---------------------------------------------------------------------------- */

/*
 * Appends a memory safety violation event to t->errors (up to
 * CL_TRACKING_ERRORS_CAP) and traps immediately via cl_assert_fail_fmt() when
 * t->panic_on_error is true.
 *
 * Parameters:
 *   t  (Cl_Tracking_Allocator *) - Tracker recording the error.
 *   ev (Cl_Mem_Error_Event)      - Populated safety violation event.
 */
static void cl_track_record_error(Cl_Tracking_Allocator *t, Cl_Mem_Error_Event ev) {
    if (t->error_count < CL_TRACKING_ERRORS_CAP) {
        t->errors[t->error_count++] = ev;
    }
    if (t->panic_on_error) {
        cl_assert_fail_fmt(
            "MEMORY SAFETY VIOLATION",
            ev.event_loc,
            "%s at ptr=%p (expected_size=%lld, actual_size=%lld)",
            cl_mem_error_kind_name(ev.kind),
            ev.ptr,
            (long long)ev.expected_size,
            (long long)ev.actual_size
        );
    }
}

/*
 * Pushes a freed allocation record into the tracker's circular free_history
 * ring buffer, overwriting the oldest record once CL_TRACKING_HISTORY_CAP is full.
 *
 * Parameters:
 *   t        (Cl_Tracking_Allocator *) - Tracker to update.
 *   entry    (const Cl_Alloc_Entry *)  - Metadata of the allocation being freed.
 *   free_loc (Cl_Source_Loc)           - Call site where the free occurred.
 */
static void cl_track_push_history(
    Cl_Tracking_Allocator *t,
    const Cl_Alloc_Entry *entry,
    Cl_Source_Loc free_loc
) {
    Cl_Free_Record rec;
    rec.user_ptr  = entry->user_ptr;
    rec.size      = entry->size;
    rec.alloc_loc = entry->loc;
    rec.free_loc  = free_loc;
    rec.seq_id    = entry->seq_id;

    t->free_history[t->free_history_head] = rec;
    t->free_history_head = (t->free_history_head + 1) % CL_TRACKING_HISTORY_CAP;
    if (t->free_history_count < CL_TRACKING_HISTORY_CAP) {
        t->free_history_count += 1;
    }
}

/*
 * Searches the free_history ring buffer from most recent to oldest for a
 * freed record matching exact pointer address ptr.
 *
 * Parameters:
 *   t   (const Cl_Tracking_Allocator *) - Tracker whose free history is scanned.
 *   ptr (const void *)                  - Pointer address to match against user_ptr.
 *
 * Returns:
 *   (const Cl_Free_Record *) Pointer to the most recent matching Cl_Free_Record, or NULL if absent.
 */
static const Cl_Free_Record *cl_track_find_in_history(
    const Cl_Tracking_Allocator *t,
    const void *ptr
) {
    for (cl_isize i = 0; i < t->free_history_count; i++) {
        cl_isize idx = (t->free_history_head - 1 - i + CL_TRACKING_HISTORY_CAP) % CL_TRACKING_HISTORY_CAP;
        if (t->free_history[idx].user_ptr == ptr) {
            return &t->free_history[idx];
        }
    }
    return NULL;
}

/*
 * Linearly scans all occupied slots to find an active allocation whose half-open
 * byte interval [user_ptr, user_ptr + size) contains address ptr.
 *
 * Parameters:
 *   t   (const Cl_Tracking_Allocator *) - Tracker whose active slots are scanned.
 *   ptr (const void *)                  - Address to test for containment.
 *
 * Returns:
 *   (const Cl_Alloc_Entry *) Pointer to the owning Cl_Alloc_Entry, or NULL if none contains ptr.
 */
static const Cl_Alloc_Entry *cl_track_find_containing(
    const Cl_Tracking_Allocator *t,
    const void *ptr
) {
    cl_uintptr target = (cl_uintptr)ptr;
    for (cl_isize i = 0; i < t->slot_cap; i++) {
        if (t->slot_states[i] == CL_SLOT_OCCUPIED) {
            cl_uintptr start = (cl_uintptr)t->slots[i].user_ptr;
            cl_uintptr end   = start + (cl_uintptr)t->slots[i].size;
            if (target >= start && target < end) {
                return &t->slots[i];
            }
        }
    }
    return NULL;
}

/*
 * Paints CL_TRACKING_REDZONE_SIZE bytes immediately before e->user_ptr and
 * immediately after (e->user_ptr + e->size) with CL_MEM_POISON_REDZONE (0xFD).
 *
 * Parameters:
 *   e (const Cl_Alloc_Entry *) - Allocation entry with redzone space reserved around user_ptr.
 */
static void cl_track_paint_redzones(const Cl_Alloc_Entry *e) {
    cl_u8 *u = (cl_u8 *)e->user_ptr;
    cl_mem_set(u - CL_TRACKING_REDZONE_SIZE, CL_MEM_POISON_REDZONE, CL_TRACKING_REDZONE_SIZE);
    cl_mem_set(u + e->size,                  CL_MEM_POISON_REDZONE, CL_TRACKING_REDZONE_SIZE);
}

/*
 * Verifies that all CL_TRACKING_REDZONE_SIZE front and back guard bytes around
 * allocation e still equal CL_MEM_POISON_REDZONE (0xFD). Records underflow and/or
 * overflow error events and increments t->redzone_corruptions on mismatch.
 *
 * Parameters:
 *   t   (Cl_Tracking_Allocator *) - Tracker recording any detected corruptions.
 *   e   (const Cl_Alloc_Entry *)  - Active allocation entry to inspect.
 *   loc (Cl_Source_Loc)           - Call site recorded as event_loc if corruption is found.
 *
 * Returns:
 *   (bool) true if redzones are disabled or both guard zones are intact; false if corrupted.
 */
static bool cl_track_verify_redzones(
    Cl_Tracking_Allocator *t,
    const Cl_Alloc_Entry *e,
    Cl_Source_Loc loc
) {
    if (!t->enable_redzones) {
        return true;
    }
    const cl_u8 *u = (const cl_u8 *)e->user_ptr;
    bool ok = true;

    const cl_u8 *front = u - CL_TRACKING_REDZONE_SIZE;
    for (cl_isize i = 0; i < CL_TRACKING_REDZONE_SIZE; i++) {
        if (front[i] != CL_MEM_POISON_REDZONE) {
            t->redzone_corruptions += 1;
            Cl_Mem_Error_Event ev = {0};
            ev.kind           = CL_MEM_ERR_REDZONE_UNDERFLOW;
            ev.ptr            = e->user_ptr;
            ev.expected_size  = e->size;
            ev.event_loc      = loc;
            ev.orig_alloc_loc = e->loc;
            cl_track_record_error(t, ev);
            ok = false;
            break;
        }
    }

    const cl_u8 *back = u + e->size;
    for (cl_isize i = 0; i < CL_TRACKING_REDZONE_SIZE; i++) {
        if (back[i] != CL_MEM_POISON_REDZONE) {
            t->redzone_corruptions += 1;
            Cl_Mem_Error_Event ev = {0};
            ev.kind           = CL_MEM_ERR_REDZONE_OVERFLOW;
            ev.ptr            = e->user_ptr;
            ev.expected_size  = e->size;
            ev.event_loc      = loc;
            ev.orig_alloc_loc = e->loc;
            cl_track_record_error(t, ev);
            ok = false;
            break;
        }
    }

    return ok;
}

/* ----------------------------------------------------------------------------
 * Core Tracked Allocation Operations
 * ---------------------------------------------------------------------------- */

/*
 * Internal locked allocation routine for Cl_Tracking_Allocator. Reserves space
 * for optional front/back redzones from t->backing, paints redzones and poison
 * or zero bytes, records the entry in the active hash table, and updates stats.
 * Caller must hold t->mutex.
 *
 * Parameters:
 *   t         (Cl_Tracking_Allocator *) - Target tracker (mutex held).
 *   size      (cl_isize)                - Caller-requested byte size (<= 0 returns NULL).
 *   alignment (cl_isize)                - Power-of-two alignment in bytes (<= 0 defaults to CL_DEFAULT_ALIGNMENT).
 *   zeroed    (bool)                    - If true, zero-initialize user payload; else fill with 0xCD.
 *   loc       (Cl_Source_Loc)           - Caller allocation site recorded for leak/error reports.
 *
 * Returns:
 *   (void *) Caller-facing aligned pointer, or NULL if size <= 0, backing OOM, or table insert fails.
 */
static void *cl_track_alloc_locked(
    Cl_Tracking_Allocator *t,
    cl_isize size,
    cl_isize alignment,
    bool zeroed,
    Cl_Source_Loc loc
) {
    if (size <= 0) {
        return NULL;
    }
    if (alignment <= 0) {
        alignment = CL_DEFAULT_ALIGNMENT;
    }
    CL_ASSERT(cl_is_power_of_two(alignment));

    cl_isize eff_align = (alignment < CL_DEFAULT_ALIGNMENT) ? CL_DEFAULT_ALIGNMENT : alignment;
    cl_isize front_prefix = t->enable_redzones
                                ? cl_align_forward_isize(CL_TRACKING_REDZONE_SIZE, eff_align)
                                : 0;
    cl_isize back_suffix  = t->enable_redzones ? CL_TRACKING_REDZONE_SIZE : 0;
    cl_isize raw_size     = front_prefix + size + back_suffix;

    void *raw_ptr = cl_alloc_non_zeroed_aligned_loc(t->backing, raw_size, eff_align, loc);
    if (raw_ptr == NULL) {
        return NULL;
    }

    void *user_ptr = (cl_u8 *)raw_ptr + front_prefix;

    Cl_Alloc_Entry entry;
    entry.user_ptr  = user_ptr;
    entry.raw_ptr   = raw_ptr;
    entry.size      = size;
    entry.raw_size  = raw_size;
    entry.alignment = eff_align;
    entry.seq_id    = ++t->next_seq_id;
    entry.loc       = loc;

    if (t->enable_redzones) {
        cl_track_paint_redzones(&entry);
    }

    if (zeroed) {
        cl_mem_zero(user_ptr, size);
    } else {
        cl_mem_set(user_ptr, CL_MEM_POISON_ALLOC_UNINIT, size);
    }

    if (!cl_track_table_insert(t, entry)) {
        cl_free_loc(t->backing, raw_ptr, raw_size, loc);
        return NULL;
    }

    t->total_alloc_count     += 1;
    t->total_bytes_allocated += size;
    t->current_bytes         += size;
    if (t->current_bytes > t->peak_bytes) {
        t->peak_bytes = t->current_bytes;
    }

    return user_ptr;
}

/*
 * Internal locked deallocation routine for Cl_Tracking_Allocator. Detects
 * double frees, interior/unknown bad frees, size mismatches, and redzone
 * corruptions; scrubs user payload with 0xDD, logs free history, removes the
 * active slot, and releases raw storage to t->backing. Caller must hold t->mutex.
 *
 * Parameters:
 *   t        (Cl_Tracking_Allocator *) - Target tracker (mutex held).
 *   ptr      (void *)                  - Caller pointer to free (NULL is a safe no-op).
 *   old_size (cl_isize)                - Caller-reported byte size (> 0 checked against entry.size).
 *   loc      (Cl_Source_Loc)           - Call site recorded in history and error reports.
 */
static void cl_track_free_locked(
    Cl_Tracking_Allocator *t,
    void *ptr,
    cl_isize old_size,
    Cl_Source_Loc loc
) {
    if (ptr == NULL) {
        return;
    }

    cl_isize slot_idx = cl_track_table_find(t, ptr);
    if (slot_idx < 0) {
        const Cl_Free_Record *prev = cl_track_find_in_history(t, ptr);
        if (prev != NULL) {
            t->double_free_count += 1;
            Cl_Mem_Error_Event ev = {0};
            ev.kind           = CL_MEM_ERR_DOUBLE_FREE;
            ev.ptr            = ptr;
            ev.expected_size  = prev->size;
            ev.actual_size    = old_size;
            ev.event_loc      = loc;
            ev.orig_alloc_loc = prev->alloc_loc;
            ev.prev_free_loc  = prev->free_loc;
            cl_track_record_error(t, ev);
            return;
        }

        const Cl_Alloc_Entry *owner = cl_track_find_containing(t, ptr);
        t->bad_free_count += 1;
        Cl_Mem_Error_Event ev = {0};
        ev.kind        = owner ? CL_MEM_ERR_BAD_FREE_INTERIOR : CL_MEM_ERR_BAD_FREE_UNKNOWN;
        ev.ptr         = ptr;
        ev.actual_size = old_size;
        ev.event_loc   = loc;
        if (owner) {
            ev.expected_size  = owner->size;
            ev.orig_alloc_loc = owner->loc;
        }
        cl_track_record_error(t, ev);
        return;
    }

    Cl_Alloc_Entry entry = t->slots[slot_idx];

    if (old_size > 0 && old_size != entry.size) {
        t->size_mismatch_count += 1;
        Cl_Mem_Error_Event ev = {0};
        ev.kind           = CL_MEM_ERR_SIZE_MISMATCH;
        ev.ptr            = ptr;
        ev.expected_size  = entry.size;
        ev.actual_size    = old_size;
        ev.event_loc      = loc;
        ev.orig_alloc_loc = entry.loc;
        cl_track_record_error(t, ev);
    }

    cl_track_verify_redzones(t, &entry, loc);

    /* Scrub freed user bytes with poison pattern to catch use-after-free */
    cl_mem_set(entry.user_ptr, CL_MEM_POISON_FREED, entry.size);

    cl_track_push_history(t, &entry, loc);
    cl_track_table_remove_at(t, slot_idx);

    t->total_free_count += 1;
    t->current_bytes    -= entry.size;

    cl_free_loc(t->backing, entry.raw_ptr, entry.raw_size, loc);
}

/*
 * Internal locked resize routine for Cl_Tracking_Allocator. Verifies the old
 * block's redzones, allocates a fresh tracked block of new_size bytes, copies
 * min(old_entry.size, new_size) bytes, and frees the old block (forcing pointer
 * relocation to expose stale-pointer bugs). Caller must hold t->mutex.
 *
 * Parameters:
 *   t         (Cl_Tracking_Allocator *) - Target tracker (mutex held).
 *   old_ptr   (void *)                  - Existing caller pointer, or NULL to allocate fresh memory.
 *   old_size  (cl_isize)                - Caller-supplied previous size in bytes.
 *   new_size  (cl_isize)                - Desired new size in bytes (<= 0 frees old_ptr and returns NULL).
 *   alignment (cl_isize)                - Power-of-two alignment in bytes.
 *   zeroed    (bool)                    - If true, zero-initialize newly grown bytes; else fill with 0xCD.
 *   loc       (Cl_Source_Loc)           - Call site recorded for diagnostics.
 *
 * Returns:
 *   (void *) Pointer to the newly allocated resized block, or NULL on invalid old_ptr,
 *            new_size <= 0, or OOM.
 */
static void *cl_track_resize_locked(
    Cl_Tracking_Allocator *t,
    void *old_ptr,
    cl_isize old_size,
    cl_isize new_size,
    cl_isize alignment,
    bool zeroed,
    Cl_Source_Loc loc
) {
    if (old_ptr == NULL) {
        return cl_track_alloc_locked(t, new_size, alignment, zeroed, loc);
    }
    if (new_size <= 0) {
        cl_track_free_locked(t, old_ptr, old_size, loc);
        return NULL;
    }

    cl_isize slot_idx = cl_track_table_find(t, old_ptr);
    if (slot_idx < 0) {
        cl_track_free_locked(t, old_ptr, old_size, loc);
        return NULL;
    }

    Cl_Alloc_Entry old_entry = t->slots[slot_idx];
    cl_track_verify_redzones(t, &old_entry, loc);

    void *new_ptr = cl_track_alloc_locked(t, new_size, alignment, zeroed, loc);
    if (new_ptr == NULL) {
        return NULL;
    }

    cl_isize copy_len = (old_entry.size < new_size) ? old_entry.size : new_size;
    cl_mem_copy(new_ptr, old_entry.user_ptr, copy_len);

    cl_track_free_locked(t, old_ptr, old_entry.size, loc);
    return new_ptr;
}

/*
 * Cl_Alloc_Proc dispatch callback for Cl_Tracking_Allocator. Acquires t->mutex,
 * dispatches ALLOC/FREE/FREE_ALL/RESIZE to locked helpers (verifying redzones
 * and pushing free history for all active blocks on FREE_ALL), and unlocks.
 *
 * Parameters:
 *   allocator_data (void *)        - Pointer to the Cl_Tracking_Allocator instance.
 *   mode           (Cl_Alloc_Mode) - Requested allocator operation.
 *   size           (cl_isize)      - Requested allocation or resize byte length (bytes).
 *   alignment      (cl_isize)      - Power-of-two alignment in bytes.
 *   old_memory     (void *)        - Existing user pointer for FREE/RESIZE, or NULL.
 *   old_size       (cl_isize)      - Caller-supplied previous byte length.
 *   loc            (Cl_Source_Loc) - Caller source location for tracking and diagnostics.
 *
 * Returns:
 *   (void *) Pointer to allocated/resized block, or NULL on FREE, FREE_ALL, or failure.
 */
static void *cl_track_alloc_proc(
    void          *allocator_data,
    Cl_Alloc_Mode  mode,
    cl_isize       size,
    cl_isize       alignment,
    void          *old_memory,
    cl_isize       old_size,
    Cl_Source_Loc  loc
) {
    Cl_Tracking_Allocator *t = (Cl_Tracking_Allocator *)allocator_data;
    void *result = NULL;

    cl_track_lock(t);
    switch (mode) {
        case CL_ALLOC_ALLOC:
            result = cl_track_alloc_locked(t, size, alignment, true, loc);
            break;
        case CL_ALLOC_ALLOC_NON_ZEROED:
            result = cl_track_alloc_locked(t, size, alignment, false, loc);
            break;
        case CL_ALLOC_FREE:
            cl_track_free_locked(t, old_memory, old_size, loc);
            break;
        case CL_ALLOC_FREE_ALL:
            for (cl_isize i = 0; i < t->slot_cap; i++) {
                if (t->slot_states[i] == CL_SLOT_OCCUPIED) {
                    cl_track_verify_redzones(t, &t->slots[i], loc);
                    cl_track_push_history(t, &t->slots[i], loc);
                    t->slot_states[i] = CL_SLOT_EMPTY;
                    t->total_free_count += 1;
                }
            }
            t->active_count    = 0;
            t->tombstone_count = 0;
            t->current_bytes   = 0;
            cl_free_all_loc(t->backing, loc);
            break;
        case CL_ALLOC_RESIZE:
            result = cl_track_resize_locked(t, old_memory, old_size, size, alignment, true, loc);
            break;
        case CL_ALLOC_RESIZE_NON_ZEROED:
            result = cl_track_resize_locked(t, old_memory, old_size, size, alignment, false, loc);
            break;
    }
    cl_track_unlock(t);
    return result;
}

/* ----------------------------------------------------------------------------
 * Public API
 * ---------------------------------------------------------------------------- */

/*
 * Initializes a Cl_Tracking_Allocator wrapping backing, enabling guard redzones
 * by default, disabling panic_on_error by default, and initializing a pthread
 * mutex when CL_ENABLE_THREAD_SAFETY is enabled.
 *
 * Parameters:
 *   t       (Cl_Tracking_Allocator *) - Tracker struct to initialize; must be non-NULL.
 *   backing (Cl_Allocator)            - Valid underlying allocator (backing.proc must be non-NULL).
 */
void cl_tracking_init(Cl_Tracking_Allocator *t, Cl_Allocator backing) {
    CL_ENSURE(t != NULL);
    CL_ENSURE(cl_allocator_is_valid(backing));
    CL_ZERO_STRUCT(t);
    t->backing         = backing;
    t->enable_redzones = true;
    t->panic_on_error  = false;

#if CL_ENABLE_THREAD_SAFETY
    pthread_mutex_t *mtx = (pthread_mutex_t *)malloc(sizeof(pthread_mutex_t));
    if (mtx != NULL) {
        pthread_mutex_init(mtx, NULL);
        t->mutex = mtx;
    }
#endif
}

/*
 * Frees internal hash table arrays and destroys the internal pthread mutex,
 * then zeroes the Cl_Tracking_Allocator struct. Does not free leaked user blocks.
 *
 * Parameters:
 *   t (Cl_Tracking_Allocator *) - Tracker to destroy (safe no-op if NULL).
 */
void cl_tracking_destroy(Cl_Tracking_Allocator *t) {
    if (t == NULL) {
        return;
    }
    free(t->slots);
    free(t->slot_states);
#if CL_ENABLE_THREAD_SAFETY
    if (t->mutex != NULL) {
        pthread_mutex_destroy((pthread_mutex_t *)t->mutex);
        free(t->mutex);
    }
#endif
    CL_ZERO_STRUCT(t);
}

/*
 * Wraps a Cl_Tracking_Allocator pointer into a polymorphic Cl_Allocator handle.
 *
 * Parameters:
 *   t (Cl_Tracking_Allocator *) - Tracker to wrap; must be non-NULL.
 *
 * Returns:
 *   (Cl_Allocator) Allocator handle with proc = cl_track_alloc_proc and data = t.
 */
Cl_Allocator cl_tracking_allocator(Cl_Tracking_Allocator *t) {
    CL_ENSURE(t != NULL);
    return (Cl_Allocator){ cl_track_alloc_proc, t };
}

/*
 * Iterates over all occupied active-allocation slots under lock and verifies
 * front and back redzones on each block.
 *
 * Parameters:
 *   t   (Cl_Tracking_Allocator *) - Tracker to scan (NULL returns 0).
 *   loc (Cl_Source_Loc)           - Call site recorded in any generated corruption events.
 *
 * Returns:
 *   (cl_isize) Number of active blocks with corrupted redzones found (block count).
 */
cl_isize cl_tracking_check_integrity(Cl_Tracking_Allocator *t, Cl_Source_Loc loc) {
    if (t == NULL) {
        return 0;
    }
    cl_isize bad = 0;
    cl_track_lock(t);
    for (cl_isize i = 0; i < t->slot_cap; i++) {
        if (t->slot_states[i] == CL_SLOT_OCCUPIED) {
            if (!cl_track_verify_redzones(t, &t->slots[i], loc)) {
                bad += 1;
            }
        }
    }
    cl_track_unlock(t);
    return bad;
}

/*
 * Checks under lock whether ptr falls inside a live tracked block with at least
 * access_size bytes available before block end, or matches a recently freed block.
 *
 * Parameters:
 *   t           (const Cl_Tracking_Allocator *) - Tracker to inspect (NULL yields CL_PTR_UNKNOWN).
 *   ptr         (const void *)                  - Pointer to validate (NULL yields CL_PTR_NULL).
 *   access_size (cl_isize)                      - Byte length of intended memory access (<= 0 treated as 0).
 *
 * Returns:
 *   (Cl_Ptr_Status) CL_PTR_VALID, CL_PTR_NULL, CL_PTR_OUT_OF_BOUNDS, CL_PTR_FREED, or CL_PTR_UNKNOWN.
 */
Cl_Ptr_Status cl_tracking_validate_ptr(
    const Cl_Tracking_Allocator *t,
    const void *ptr,
    cl_isize access_size
) {
    if (ptr == NULL) {
        return CL_PTR_NULL;
    }
    if (t == NULL) {
        return CL_PTR_UNKNOWN;
    }

    cl_track_lock(t);
    Cl_Ptr_Status status = CL_PTR_UNKNOWN;
    const Cl_Alloc_Entry *owner = cl_track_find_containing(t, ptr);
    if (owner != NULL) {
        cl_uintptr start = (cl_uintptr)owner->user_ptr;
        cl_uintptr end   = start + (cl_uintptr)owner->size;
        cl_uintptr p     = (cl_uintptr)ptr;
        cl_usize   need  = (access_size > 0) ? (cl_usize)access_size : 0u;
        if (need <= (cl_usize)(end - p)) {
            status = CL_PTR_VALID;
        } else {
            status = CL_PTR_OUT_OF_BOUNDS;
        }
    } else if (cl_track_find_in_history(t, ptr) != NULL) {
        status = CL_PTR_FREED;
    } else {
        status = CL_PTR_UNKNOWN;
    }
    cl_track_unlock(t);
    return status;
}

/*
 * Returns true if the tracker has zero live blocks/bytes and zero recorded
 * double-free, bad-free, redzone-corruption, or size-mismatch errors.
 *
 * Parameters:
 *   t (const Cl_Tracking_Allocator *) - Tracker to check (NULL returns true).
 *
 * Returns:
 *   (bool) true if clean (0 leaks and 0 safety errors); false otherwise.
 */
bool cl_tracking_is_clean(const Cl_Tracking_Allocator *t) {
    if (t == NULL) {
        return true;
    }
    return t->active_count == 0 &&
           t->current_bytes == 0 &&
           t->double_free_count == 0 &&
           t->bad_free_count == 0 &&
           t->redzone_corruptions == 0 &&
           t->size_mismatch_count == 0;
}

/*
 * Maps a Cl_Mem_Error_Kind enum value to a static human-readable ASCII string.
 *
 * Parameters:
 *   kind (Cl_Mem_Error_Kind) - Error kind to format.
 *
 * Returns:
 *   (const char *) Static NUL-terminated ASCII name, or "UNKNOWN" if unrecognized.
 */
const char *cl_mem_error_kind_name(Cl_Mem_Error_Kind kind) {
    switch (kind) {
        case CL_MEM_ERR_NONE:              return "NONE";
        case CL_MEM_ERR_DOUBLE_FREE:       return "DOUBLE_FREE";
        case CL_MEM_ERR_BAD_FREE_UNKNOWN:  return "BAD_FREE_UNKNOWN_POINTER";
        case CL_MEM_ERR_BAD_FREE_INTERIOR: return "BAD_FREE_INTERIOR_POINTER";
        case CL_MEM_ERR_REDZONE_UNDERFLOW: return "BUFFER_UNDERFLOW_REDZONE";
        case CL_MEM_ERR_REDZONE_OVERFLOW:  return "BUFFER_OVERFLOW_REDZONE";
        case CL_MEM_ERR_SIZE_MISMATCH:     return "FREE_SIZE_MISMATCH";
        default:                           return "UNKNOWN";
    }
}

/*
 * Maps a Cl_Ptr_Status enum value to a static human-readable ASCII string.
 *
 * Parameters:
 *   status (Cl_Ptr_Status) - Pointer validation status to format.
 *
 * Returns:
 *   (const char *) Static NUL-terminated ASCII name, or "UNKNOWN" if unrecognized.
 */
const char *cl_ptr_status_name(Cl_Ptr_Status status) {
    switch (status) {
        case CL_PTR_VALID:         return "VALID";
        case CL_PTR_NULL:          return "NULL";
        case CL_PTR_OUT_OF_BOUNDS: return "OUT_OF_BOUNDS";
        case CL_PTR_FREED:         return "FREED (DANGLING)";
        case CL_PTR_UNKNOWN:       return "UNKNOWN";
        default:                   return "UNKNOWN";
    }
}

/*
 * Formats and prints a diagnostic report of cumulative stats, peak usage,
 * leaked allocations (with sequence ID, pointer, size, and source location),
 * and recorded safety violations to out under lock.
 *
 * Parameters:
 *   t   (const Cl_Tracking_Allocator *) - Tracker to report (safe no-op if NULL).
 *   out (FILE *)                        - Destination stdio stream (NULL defaults to stderr).
 */
void cl_tracking_print_report(const Cl_Tracking_Allocator *t, FILE *out) {
    if (t == NULL) {
        return;
    }
    if (out == NULL) {
        out = stderr;
    }

    cl_track_lock(t);
    fprintf(out, "\n================ c_lib Tracking Allocator Report ================\n");
    fprintf(out, "  Total allocations : %lld (%lld bytes cumulative)\n",
            (long long)t->total_alloc_count, (long long)t->total_bytes_allocated);
    fprintf(out, "  Total frees       : %lld\n", (long long)t->total_free_count);
    fprintf(out, "  Peak live memory  : %lld bytes\n", (long long)t->peak_bytes);
    fprintf(out, "  Leaked blocks     : %lld (%lld bytes)\n",
            (long long)t->active_count, (long long)t->current_bytes);
    fprintf(out, "  Double frees      : %lld\n", (long long)t->double_free_count);
    fprintf(out, "  Bad pointer frees : %lld\n", (long long)t->bad_free_count);
    fprintf(out, "  Redzone overflows : %lld\n", (long long)t->redzone_corruptions);
    fprintf(out, "  Size mismatches   : %lld\n", (long long)t->size_mismatch_count);

    if (t->active_count > 0) {
        fprintf(out, "\n  [LEAKED ALLOCATIONS]\n");
        for (cl_isize i = 0; i < t->slot_cap; i++) {
            if (t->slot_states[i] == CL_SLOT_OCCUPIED) {
                const Cl_Alloc_Entry *e = &t->slots[i];
                fprintf(out, "    #%llu  ptr=%p  size=%lld bytes  at %s:%d (%s)\n",
                        (unsigned long long)e->seq_id,
                        e->user_ptr,
                        (long long)e->size,
                        e->loc.file ? e->loc.file : "?",
                        (int)e->loc.line,
                        e->loc.func ? e->loc.func : "?");
            }
        }
    }

    if (t->error_count > 0) {
        fprintf(out, "\n  [SAFETY ERRORS RECORDED]\n");
        for (cl_isize i = 0; i < t->error_count; i++) {
            const Cl_Mem_Error_Event *ev = &t->errors[i];
            fprintf(out, "    [%s] ptr=%p at %s:%d (%s)\n",
                    cl_mem_error_kind_name(ev->kind),
                    ev->ptr,
                    ev->event_loc.file ? ev->event_loc.file : "?",
                    (int)ev->event_loc.line,
                    ev->event_loc.func ? ev->event_loc.func : "?");
            if (ev->orig_alloc_loc.file != NULL) {
                fprintf(out, "      allocated at %s:%d (%s) [size=%lld]\n",
                        ev->orig_alloc_loc.file,
                        (int)ev->orig_alloc_loc.line,
                        ev->orig_alloc_loc.func ? ev->orig_alloc_loc.func : "?",
                        (long long)ev->expected_size);
            }
            if (ev->prev_free_loc.file != NULL) {
                fprintf(out, "      previously freed at %s:%d (%s)\n",
                        ev->prev_free_loc.file,
                        (int)ev->prev_free_loc.line,
                        ev->prev_free_loc.func ? ev->prev_free_loc.func : "?");
            }
        }
    }
    fprintf(out, "=================================================================\n");
    cl_track_unlock(t);
}
