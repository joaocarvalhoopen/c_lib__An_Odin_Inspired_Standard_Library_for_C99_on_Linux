/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_log.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Implementation of Cl_Logger sinks (console, file, multi, nil), ANSI color
 *   TTY auto-detection, thread-safe output, and zero-allocation formatting
 *   for messages under 1024 bytes.
 * ============================================================================
 */

/*
 * Macro: _POSIX_C_SOURCE
 * Purpose:
 *   Feature-test macro enabling POSIX.1-2008 APIs (clock_gettime, localtime_r,
 *   fileno, isatty) under strict ISO C99 compilation.
 * Expansion:
 *   Long integer constant 200809L (POSIX.1-2008 standard revision).
 */
#define _POSIX_C_SOURCE 200809L

#include "cl/cl_log.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#if CL_ENABLE_THREAD_SAFETY
    #include <pthread.h>
    /* Global mutex serializing concurrent stream writes when thread safety is enabled. */
    static pthread_mutex_t cl_log_mutex = PTHREAD_MUTEX_INITIALIZER;
#endif

#if CL_COMPILER_GNU_COMPAT
    /* Thread-local active logger handle (falls back to default console logger when proc == NULL). */
    CL_EXTENSION static __thread Cl_Logger cl_tls_logger = {0};
#else
    /* Process-wide active logger handle when compiler thread-local storage is unavailable. */
    static Cl_Logger cl_tls_logger = {0};
#endif

/*
 * Function: cl_log_level_name
 * Purpose:
 *   Maps a Cl_Log_Level enumerator to its fixed-width 5-character label.
 * Parameters:
 *   level (Cl_Log_Level): Log severity level.
 * Returns:
 *   const char *: Static NUL-terminated label ("DEBUG", "INFO ", "WARN ",
 *     "ERROR", "FATAL", or "?????").
 */
const char *cl_log_level_name(Cl_Log_Level level) {
    switch (level) {
        case CL_LOG_LEVEL_DEBUG: return "DEBUG";
        case CL_LOG_LEVEL_INFO:  return "INFO ";
        case CL_LOG_LEVEL_WARN:  return "WARN ";
        case CL_LOG_LEVEL_ERROR: return "ERROR";
        case CL_LOG_LEVEL_FATAL: return "FATAL";
        default:                 return "?????";
    }
}

/*
 * Function: cl_log_level_color
 * Purpose:
 *   Maps a Cl_Log_Level enumerator to its ANSI SGR terminal color escape
 *   sequence.
 * Parameters:
 *   level (Cl_Log_Level): Log severity level.
 * Returns:
 *   const char *: Static NUL-terminated ANSI escape string (cyan, green,
 *     yellow, red, bold red, or reset).
 */
static const char *cl_log_level_color(Cl_Log_Level level) {
    switch (level) {
        case CL_LOG_LEVEL_DEBUG: return "\x1b[36m";   /* Cyan */
        case CL_LOG_LEVEL_INFO:  return "\x1b[32m";   /* Green */
        case CL_LOG_LEVEL_WARN:  return "\x1b[33m";   /* Yellow */
        case CL_LOG_LEVEL_ERROR: return "\x1b[31m";   /* Red */
        case CL_LOG_LEVEL_FATAL: return "\x1b[1;31m"; /* Bold Red */
        default:                 return "\x1b[0m";
    }
}

/*
 * Function: cl_basename
 * Purpose:
 *   Returns the filename component after the last '/' in a POSIX path string,
 *   or "?" if path is NULL.
 * Parameters:
 *   path (const char *): NUL-terminated path string, or NULL.
 * Returns:
 *   const char *: Pointer to the basename substring inside path, or "?".
 */
static const char *cl_basename(const char *path) {
    if (path == NULL) {
        return "?";
    }
    const char *slash = strrchr(path, '/');
    return slash ? (slash + 1) : path;
}

/*
 * Function: cl_stream_log_proc
 * Purpose:
 *   Cl_Log_Proc backend that formats optional wall timestamp (HH:MM:SS.mmm),
 *   colored or plain severity tag, source file:line, function name, and
 *   message body onto a FILE stream (or stderr if logger_data is NULL),
 *   protected by cl_log_mutex when CL_ENABLE_THREAD_SAFETY is active.
 * Parameters:
 *   logger_data (void *): Target FILE * cast to void *, or NULL for stderr.
 *   level (Cl_Log_Level): Message severity level.
 *   text (Cl_Str): Formatted message body byte slice.
 *   options (cl_u32): Log formatting bitmask (CL_LOG_OPT_* flags).
 *   loc (Cl_Source_Loc): Call-site source location metadata.
 * Returns:
 *   void.
 */
static void cl_stream_log_proc(
    void          *logger_data,
    Cl_Log_Level   level,
    Cl_Str         text,
    cl_u32         options,
    Cl_Source_Loc  loc
) {
    FILE *fp = logger_data ? (FILE *)logger_data : stderr;

    bool use_color = false;
    if (options & CL_LOG_OPT_COLOR) {
        use_color = true;
    } else if (options & CL_LOG_OPT_AUTO_COLOR) {
        int fd = fileno(fp);
        if (fd >= 0 && isatty(fd)) {
            use_color = true;
        }
    }

#if CL_ENABLE_THREAD_SAFETY
    pthread_mutex_lock(&cl_log_mutex);
#endif

    if (options & CL_LOG_OPT_TIME) {
        struct timespec ts;
        if (clock_gettime(CLOCK_REALTIME, &ts) == 0) {
            struct tm tm_now;
            localtime_r(&ts.tv_sec, &tm_now);
            int ms = (int)(ts.tv_nsec / 1000000L);
            fprintf(fp, "%02d:%02d:%02d.%03d ",
                    tm_now.tm_hour, tm_now.tm_min, tm_now.tm_sec, ms);
        }
    }

    if (options & CL_LOG_OPT_LEVEL) {
        if (use_color) {
            fprintf(fp, "%s[%s]\x1b[0m ", cl_log_level_color(level), cl_log_level_name(level));
        } else {
            fprintf(fp, "[%s] ", cl_log_level_name(level));
        }
    }

    if (options & CL_LOG_OPT_LONG_FILE) {
        fprintf(fp, "%s:%d ", loc.file ? loc.file : "?", (int)loc.line);
    } else if (options & CL_LOG_OPT_SHORT_FILE) {
        fprintf(fp, "%s:%d ", cl_basename(loc.file), (int)loc.line);
    }

    if (options & CL_LOG_OPT_FUNC) {
        fprintf(fp, "(%s) ", loc.func ? loc.func : "?");
    }

    fprintf(fp, CL_STR_FMT "\n", CL_STR_ARG(text));
    fflush(fp);

#if CL_ENABLE_THREAD_SAFETY
    pthread_mutex_unlock(&cl_log_mutex);
#endif
}

/*
 * Function: cl_nil_log_proc
 * Purpose:
 *   Silent Cl_Log_Proc backend that discards all log messages without I/O.
 * Parameters:
 *   logger_data (void *): Unused.
 *   level (Cl_Log_Level): Unused.
 *   text (Cl_Str): Unused.
 *   options (cl_u32): Unused.
 *   loc (Cl_Source_Loc): Unused.
 * Returns:
 *   void.
 */
static void cl_nil_log_proc(
    void          *logger_data,
    Cl_Log_Level   level,
    Cl_Str         text,
    cl_u32         options,
    Cl_Source_Loc  loc
) {
    CL_UNUSED_VAR(logger_data);
    CL_UNUSED_VAR(level);
    CL_UNUSED_VAR(text);
    CL_UNUSED_VAR(options);
    CL_UNUSED_VAR(loc);
}

/*
 * Function: cl_multi_log_proc
 * Purpose:
 *   Cl_Log_Proc fan-out backend that forwards each message to every sink
 *   registered in the Cl_Multi_Logger pointed to by logger_data.
 * Parameters:
 *   logger_data (void *): Pointer to Cl_Multi_Logger, or NULL (no-op).
 *   level (Cl_Log_Level): Message severity level.
 *   text (Cl_Str): Formatted message body byte slice.
 *   options (cl_u32): Unused (each child sink uses its own options bitmask).
 *   loc (Cl_Source_Loc): Call-site source location metadata.
 * Returns:
 *   void.
 */
static void cl_multi_log_proc(
    void          *logger_data,
    Cl_Log_Level   level,
    Cl_Str         text,
    cl_u32         options,
    Cl_Source_Loc  loc
) {
    CL_UNUSED_VAR(options);
    Cl_Multi_Logger *ml = (Cl_Multi_Logger *)logger_data;
    if (ml == NULL) {
        return;
    }
    for (cl_isize i = 0; i < ml->count; i++) {
        cl_log_write(ml->sinks[i], level, loc, text);
    }
}

/*
 * Function: cl_console_logger
 * Purpose:
 *   Constructs a Cl_Logger writing to stderr using cl_stream_log_proc.
 * Parameters:
 *   lowest_level (Cl_Log_Level): Minimum severity threshold to emit.
 *   options (cl_u32): Bitmask of CL_LOG_OPT_* flags.
 * Returns:
 *   Cl_Logger: Console logger handle.
 */
Cl_Logger cl_console_logger(Cl_Log_Level lowest_level, cl_u32 options) {
    return (Cl_Logger){ cl_stream_log_proc, NULL, lowest_level, options };
}

/*
 * Function: cl_file_logger
 * Purpose:
 *   Constructs a Cl_Logger writing to fp using cl_stream_log_proc.
 * Parameters:
 *   fp (FILE *): Open writable FILE stream, or NULL (defaults to stderr).
 *   lowest_level (Cl_Log_Level): Minimum severity threshold to emit.
 *   options (cl_u32): Bitmask of CL_LOG_OPT_* flags.
 * Returns:
 *   Cl_Logger: File stream logger handle.
 */
Cl_Logger cl_file_logger(FILE *fp, Cl_Log_Level lowest_level, cl_u32 options) {
    /* Strip color options unless explicitly requested */
    return (Cl_Logger){ cl_stream_log_proc, fp, lowest_level, options };
}

/*
 * Function: cl_nil_logger
 * Purpose:
 *   Constructs a silent Cl_Logger backed by cl_nil_log_proc.
 * Parameters:
 *   None (void).
 * Returns:
 *   Cl_Logger: No-op logger handle.
 */
Cl_Logger cl_nil_logger(void) {
    return (Cl_Logger){ cl_nil_log_proc, NULL, CL_LOG_LEVEL_FATAL, 0u };
}

/*
 * Function: cl_multi_logger_init
 * Purpose:
 *   Zero-initializes a Cl_Multi_Logger structure so count == 0.
 * Parameters:
 *   ml (Cl_Multi_Logger *): Target multi-logger state, or NULL (no-op).
 * Returns:
 *   void.
 */
void cl_multi_logger_init(Cl_Multi_Logger *ml) {
    if (ml == NULL) {
        return;
    }
    memset(ml, 0, sizeof(*ml));
}

/*
 * Function: cl_multi_logger_add
 * Purpose:
 *   Adds a child sink to ml if ml is non-NULL and count < CL_MULTI_LOGGER_MAX.
 * Parameters:
 *   ml (Cl_Multi_Logger *): Target multi-logger state, or NULL.
 *   sink (Cl_Logger): Child logger handle to register.
 * Returns:
 *   bool: true if added; false if ml is NULL or already at capacity.
 */
bool cl_multi_logger_add(Cl_Multi_Logger *ml, Cl_Logger sink) {
    if (ml == NULL || ml->count >= CL_MULTI_LOGGER_MAX) {
        return false;
    }
    ml->sinks[ml->count++] = sink;
    return true;
}

/*
 * Function: cl_multi_logger
 * Purpose:
 *   Returns a Cl_Logger handle backed by ml using cl_multi_log_proc.
 * Parameters:
 *   ml (Cl_Multi_Logger *): Backing multi-logger state.
 *   lowest_level (Cl_Log_Level): Minimum severity threshold to forward.
 * Returns:
 *   Cl_Logger: Multi-sink fan-out logger handle.
 */
Cl_Logger cl_multi_logger(Cl_Multi_Logger *ml, Cl_Log_Level lowest_level) {
    return (Cl_Logger){ cl_multi_log_proc, ml, lowest_level, 0u };
}

/*
 * Function: cl_log_set_active
 * Purpose:
 *   Stores logger in the current thread's active logger slot (cl_tls_logger).
 * Parameters:
 *   logger (Cl_Logger): Logger handle to install as active.
 * Returns:
 *   void.
 */
void cl_log_set_active(Cl_Logger logger) {
    cl_tls_logger = logger;
}

/*
 * Function: cl_log_get_active
 * Purpose:
 *   Returns the current thread's active logger, or a default stderr console
 *   logger (CL_LOG_LEVEL_DEBUG, CL_LOG_DEFAULT_OPTIONS) if unset.
 * Parameters:
 *   None (void).
 * Returns:
 *   Cl_Logger: Active logger handle.
 */
Cl_Logger cl_log_get_active(void) {
    if (cl_tls_logger.proc == NULL) {
        return cl_console_logger(CL_LOG_LEVEL_DEBUG, CL_LOG_DEFAULT_OPTIONS);
    }
    return cl_tls_logger;
}

/*
 * Function: cl_log_write
 * Purpose:
 *   Invokes logger.proc with msg if logger.proc is non-NULL and
 *   level >= logger.lowest_level.
 * Parameters:
 *   logger (Cl_Logger): Target logger handle.
 *   level (Cl_Log_Level): Severity level of the message.
 *   loc (Cl_Source_Loc): Call-site source location metadata.
 *   msg (Cl_Str): Message payload byte slice.
 * Returns:
 *   void.
 */
void cl_log_write(Cl_Logger logger, Cl_Log_Level level, Cl_Source_Loc loc, Cl_Str msg) {
    if (logger.proc == NULL || level < logger.lowest_level) {
        return;
    }
    logger.proc(logger.data, level, msg, logger.options, loc);
}

/*
 * Function: cl_log_vfmt
 * Purpose:
 *   Internal va_list formatter that renders messages shorter than 1024 bytes
 *   on the stack without heap allocation and falls back to malloc for longer
 *   messages before dispatching to logger.proc.
 * Parameters:
 *   logger (Cl_Logger): Target logger handle.
 *   level (Cl_Log_Level): Severity level of the message.
 *   loc (Cl_Source_Loc): Call-site source location metadata.
 *   fmt (const char *): NUL-terminated printf format string (NULL is a no-op).
 *   args (va_list): Variadic arguments matching fmt.
 * Returns:
 *   void.
 */
static void cl_log_vfmt(
    Cl_Logger logger,
    Cl_Log_Level level,
    Cl_Source_Loc loc,
    const char *fmt,
    va_list args
) {
    if (logger.proc == NULL || level < logger.lowest_level || fmt == NULL) {
        return;
    }

    char stack_buf[1024];
    va_list copy;
    va_copy(copy, args);
    int needed = vsnprintf(stack_buf, sizeof(stack_buf), fmt, args);

    if (needed < 0) {
        va_end(copy);
        return;
    }

    if ((cl_usize)needed < sizeof(stack_buf)) {
        va_end(copy);
        Cl_Str s = { (const cl_u8 *)stack_buf, (cl_isize)needed };
        logger.proc(logger.data, level, s, logger.options, loc);
        return;
    }

    char *heap_buf = (char *)malloc((cl_usize)needed + 1u);
    if (heap_buf != NULL) {
        vsnprintf(heap_buf, (cl_usize)needed + 1u, fmt, copy);
        Cl_Str s = { (const cl_u8 *)heap_buf, (cl_isize)needed };
        logger.proc(logger.data, level, s, logger.options, loc);
        free(heap_buf);
    }
    va_end(copy);
}

/*
 * Function: cl_log_write_fmt
 * Purpose:
 *   Variadic formatted logging entry point targeting an explicit Cl_Logger.
 * Parameters:
 *   logger (Cl_Logger): Target logger handle.
 *   level (Cl_Log_Level): Severity level of the message.
 *   loc (Cl_Source_Loc): Call-site source location metadata.
 *   fmt (const char *): NUL-terminated printf format string.
 *   ... (variadic): Arguments matching fmt.
 * Returns:
 *   void.
 */
void cl_log_write_fmt(
    Cl_Logger logger,
    Cl_Log_Level level,
    Cl_Source_Loc loc,
    const char *fmt,
    ...
) {
    va_list args;
    va_start(args, fmt);
    cl_log_vfmt(logger, level, loc, fmt, args);
    va_end(args);
}

/*
 * Function: cl_log_active_fmt
 * Purpose:
 *   Variadic formatted logging entry point targeting the current thread's
 *   active logger (cl_log_get_active()).
 * Parameters:
 *   level (Cl_Log_Level): Severity level of the message.
 *   loc (Cl_Source_Loc): Call-site source location metadata.
 *   fmt (const char *): NUL-terminated printf format string.
 *   ... (variadic): Arguments matching fmt.
 * Returns:
 *   void.
 */
void cl_log_active_fmt(
    Cl_Log_Level level,
    Cl_Source_Loc loc,
    const char *fmt,
    ...
) {
    Cl_Logger logger = cl_log_get_active();
    va_list args;
    va_start(args, fmt);
    cl_log_vfmt(logger, level, loc, fmt, args);
    va_end(args);
}
