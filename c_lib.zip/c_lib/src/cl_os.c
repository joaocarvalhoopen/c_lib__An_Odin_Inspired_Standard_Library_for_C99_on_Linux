/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_os.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Linux implementation of whole-file read/write operations (regular files,
 *   Linux /proc virtual files, and crash-safe atomic writes), environment
 *   lookups, POSIX fd cleanup, and monotonic nanosecond stopwatch.
 * ============================================================================
 */

/*
 * Macro: _POSIX_C_SOURCE
 * Purpose:
 *   Feature-test macro enabling POSIX.1-2008 APIs (clock_gettime, nanosleep,
 *   fsync, fstat, open, read, write, unlink) under strict ISO C99 compilation.
 * Expansion:
 *   Long integer constant 200809L (POSIX.1-2008 standard revision).
 */
#define _POSIX_C_SOURCE 200809L

#include "cl/cl_os.h"
#include "cl/cl_string_builder.h"
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

/*
 * Function: cl_errno_to_error
 * Purpose:
 *   Maps common POSIX errno values (ENOENT, EACCES, EPERM, ENOMEM, EINVAL) to
 *   standard Cl_Error codes, falling back to fallback for all other values.
 * Parameters:
 *   err_num (int): POSIX errno code captured from a failed syscall.
 *   fallback (Cl_Error): Default Cl_Error returned when err_num has no
 *     specific mapping.
 * Returns:
 *   Cl_Error: Mapped Cl_Error value.
 */
static Cl_Error cl_errno_to_error(int err_num, Cl_Error fallback) {
    switch (err_num) {
        case ENOENT: return CL_ERR_NOT_FOUND;
        case EACCES:
        case EPERM:  return CL_ERR_PERMISSION;
        case ENOMEM: return CL_ERR_OUT_OF_MEMORY;
        case EINVAL: return CL_ERR_INVALID_ARG;
        default:     return fallback;
    }
}

/*
 * Function: cl_os_read_fd_streaming
 * Purpose:
 *   Reads all bytes from an open POSIX file descriptor until EOF using a
 *   growing buffer (starting at 4096 bytes, doubling when < 1024 bytes remain,
 *   retrying on EINTR), then shrinks the allocation to the exact byte length.
 *   Used for Linux /proc and /sys virtual files, pipes, or 0-size stat files.
 * Parameters:
 *   fd (int): Open readable POSIX file descriptor (>= 0).
 *   dst_alloc (Cl_Allocator): Validated allocator for the output byte buffer.
 * Returns:
 *   Cl_Res_Bytes: CL_OK(bytes) with exact byte length (empty slice on EOF at
 *     0 bytes), or CL_ERR(err) on read or memory allocation failure.
 */
static Cl_Res_Bytes cl_os_read_fd_streaming(int fd, Cl_Allocator dst_alloc) {
    cl_isize cap = 4096;
    cl_isize len = 0;
    cl_u8 *buf = (cl_u8 *)cl_alloc_non_zeroed_aligned_loc(dst_alloc, cap, 1, CL_HERE);
    if (buf == NULL) {
        return CL_ERR(Cl_Res_Bytes, CL_ERR_OUT_OF_MEMORY);
    }

    for (;;) {
        if (cap - len < 1024) {
            cl_isize new_cap = cap * 2;
            cl_u8 *grown = (cl_u8 *)cl_resize_non_zeroed_aligned_loc(
                dst_alloc, buf, cap, new_cap, 1, CL_HERE
            );
            if (grown == NULL) {
                cl_free_loc(dst_alloc, buf, cap, CL_HERE);
                return CL_ERR(Cl_Res_Bytes, CL_ERR_OUT_OF_MEMORY);
            }
            buf = grown;
            cap = new_cap;
        }

        ssize_t n = read(fd, buf + len, (size_t)(cap - len));
        if (n < 0) {
            if (errno == EINTR) {
                continue;
            }
            cl_free_loc(dst_alloc, buf, cap, CL_HERE);
            return CL_ERR(Cl_Res_Bytes, cl_errno_to_error(errno, CL_ERR_IO_READ));
        }
        if (n == 0) {
            break;
        }
        len += (cl_isize)n;
    }

    if (len == 0) {
        cl_free_loc(dst_alloc, buf, cap, CL_HERE);
        return CL_OK(Cl_Res_Bytes, CL_SLICE_EMPTY(Cl_Bytes));
    }

    /* Shrink allocation to exact `len` bytes so CL_SLICE_FREE matches exact size */
    if (len < cap) {
        cl_u8 *exact = (cl_u8 *)cl_resize_non_zeroed_aligned_loc(
            dst_alloc, buf, cap, len, 1, CL_HERE
        );
        if (exact != NULL) {
            buf = exact;
        }
    }
    return CL_OK(Cl_Res_Bytes, ((Cl_Bytes){ buf, len }));
}

/*
 * Function: cl_os_write_all_fd
 * Purpose:
 *   Writes every byte of data to an open POSIX file descriptor, looping over
 *   partial writes and retrying automatically on EINTR.
 * Parameters:
 *   fd (int): Open writable POSIX file descriptor (>= 0).
 *   data (Cl_Bytes): Source byte slice (length in bytes).
 * Returns:
 *   Cl_Error: CL_ERR_NONE when all bytes are written, or a mapped Cl_Error
 *     (default CL_ERR_IO_WRITE) on write failure.
 */
static Cl_Error cl_os_write_all_fd(int fd, Cl_Bytes data) {
    cl_isize offset = 0;
    while (offset < data.len) {
        ssize_t n = write(fd, data.data + offset, (size_t)(data.len - offset));
        if (n < 0) {
            if (errno == EINTR) {
                continue;
            }
            return cl_errno_to_error(errno, CL_ERR_IO_WRITE);
        }
        offset += (cl_isize)n;
    }
    return CL_ERR_NONE;
}

/*
 * Function: cl_os_read_entire_file
 * Purpose:
 *   Opens path read-only, inspects fstat(), and reads the entire file into
 *   alloc using either a single exact-size buffer (regular files with
 *   st_size > 0) or streaming chunks (virtual files / pipes / st_size == 0).
 * Parameters:
 *   path (Cl_Str): Filesystem path byte slice.
 *   alloc (Cl_Allocator): Destination allocator (falls back to context).
 * Returns:
 *   Cl_Res_Bytes: CL_OK(bytes) on success, or CL_ERR(err) on failure.
 */
Cl_Res_Bytes cl_os_read_entire_file(Cl_Str path, Cl_Allocator alloc) {
    Cl_Allocator dst_alloc = cl_alloc_or_ctx(alloc);
    Cl_Scratch scratch = cl_scratch_begin(&dst_alloc, 1);
    CL_DEFER_SCRATCH(scratch);

    char *cpath = cl_str_to_cstr(path, scratch.allocator);
    if (cpath == NULL) {
        return CL_ERR(Cl_Res_Bytes, CL_ERR_OUT_OF_MEMORY);
    }

    int fd = open(cpath, O_RDONLY);
    if (fd < 0) {
        return CL_ERR(Cl_Res_Bytes, cl_errno_to_error(errno, CL_ERR_IO_OPEN));
    }
    CL_DEFER_FD(fd);

    struct stat st;
    if (fstat(fd, &st) != 0) {
        return CL_ERR(Cl_Res_Bytes, cl_errno_to_error(errno, CL_ERR_IO_STAT));
    }

    /* Fallback to chunked read for Linux virtual files (/proc, /sys, pipes) or st_size == 0 */
    if (!S_ISREG(st.st_mode) || st.st_size <= 0) {
        return cl_os_read_fd_streaming(fd, dst_alloc);
    }

    cl_isize total = (cl_isize)st.st_size;
    cl_u8 *buf = (cl_u8 *)cl_alloc_non_zeroed_aligned_loc(dst_alloc, total, 1, CL_HERE);
    if (buf == NULL) {
        return CL_ERR(Cl_Res_Bytes, CL_ERR_OUT_OF_MEMORY);
    }

    cl_isize offset = 0;
    while (offset < total) {
        ssize_t n = read(fd, buf + offset, (size_t)(total - offset));
        if (n < 0) {
            if (errno == EINTR) {
                continue;
            }
            cl_free_loc(dst_alloc, buf, total, CL_HERE);
            return CL_ERR(Cl_Res_Bytes, cl_errno_to_error(errno, CL_ERR_IO_READ));
        }
        if (n == 0) {
            break;
        }
        offset += (cl_isize)n;
    }

    if (offset == 0) {
        cl_free_loc(dst_alloc, buf, total, CL_HERE);
        return CL_OK(Cl_Res_Bytes, CL_SLICE_EMPTY(Cl_Bytes));
    }

    if (offset < total) {
        cl_u8 *resized = (cl_u8 *)cl_resize_non_zeroed_aligned_loc(
            dst_alloc, buf, total, offset, 1, CL_HERE
        );
        if (resized != NULL) {
            buf = resized;
        }
    }

    return CL_OK(Cl_Res_Bytes, ((Cl_Bytes){ buf, offset }));
}

/*
 * Function: cl_os_read_entire_file_str
 * Purpose:
 *   Reads an entire file via cl_os_read_entire_file and wraps the resulting
 *   bytes as a Cl_Str.
 * Parameters:
 *   path (Cl_Str): Filesystem path byte slice.
 *   alloc (Cl_Allocator): Destination allocator (falls back to context).
 * Returns:
 *   Cl_Res_Str: CL_OK(str) on success, or CL_ERR(err) on failure.
 */
Cl_Res_Str cl_os_read_entire_file_str(Cl_Str path, Cl_Allocator alloc) {
    Cl_Bytes bytes;
    CL_OR_RETURN(bytes, cl_os_read_entire_file(path, alloc), Cl_Res_Str);
    return CL_OK(Cl_Res_Str, ((Cl_Str){ bytes.data, bytes.len }));
}

/*
 * Function: cl_os_read_entire_file_cstr
 * Purpose:
 *   C-string path wrapper forwarding to cl_os_read_entire_file.
 * Parameters:
 *   path (const char *): NUL-terminated filesystem path, or NULL.
 *   alloc (Cl_Allocator): Destination allocator (falls back to context).
 * Returns:
 *   Cl_Res_Bytes: CL_OK(bytes) on success, or CL_ERR(err) on failure.
 */
Cl_Res_Bytes cl_os_read_entire_file_cstr(const char *path, Cl_Allocator alloc) {
    return cl_os_read_entire_file(cl_str_from_cstr(path), alloc);
}

/*
 * Function: cl_os_write_entire_file
 * Purpose:
 *   Opens path with O_WRONLY | O_CREAT | O_TRUNC (mode 0644) and writes all
 *   bytes in data.
 * Parameters:
 *   path (Cl_Str): Destination path byte slice.
 *   data (Cl_Bytes): Byte slice to write (length in bytes).
 * Returns:
 *   Cl_Error: CL_ERR_NONE on success, or a Cl_Error failure code.
 */
Cl_Error cl_os_write_entire_file(Cl_Str path, Cl_Bytes data) {
    Cl_Scratch scratch = cl_scratch_begin(NULL, 0);
    CL_DEFER_SCRATCH(scratch);

    char *cpath = cl_str_to_cstr(path, scratch.allocator);
    if (cpath == NULL) {
        return CL_ERR_OUT_OF_MEMORY;
    }

    int fd = open(cpath, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) {
        return cl_errno_to_error(errno, CL_ERR_IO_OPEN);
    }
    CL_DEFER_FD(fd);

    return cl_os_write_all_fd(fd, data);
}

/*
 * Function: cl_os_write_entire_file_str
 * Purpose:
 *   Writes all bytes of a Cl_Str to path by forwarding to
 *   cl_os_write_entire_file.
 * Parameters:
 *   path (Cl_Str): Destination path byte slice.
 *   text (Cl_Str): Source byte slice (length in bytes).
 * Returns:
 *   Cl_Error: CL_ERR_NONE on success, or a Cl_Error failure code.
 */
Cl_Error cl_os_write_entire_file_str(Cl_Str path, Cl_Str text) {
    Cl_Bytes bytes = { (cl_u8 *)(cl_uintptr)text.data, text.len };
    return cl_os_write_entire_file(path, bytes);
}

/*
 * Function: cl_os_write_entire_file_cstr
 * Purpose:
 *   C-string path wrapper forwarding to cl_os_write_entire_file.
 * Parameters:
 *   path (const char *): NUL-terminated destination path, or NULL.
 *   data (Cl_Bytes): Byte slice to write (length in bytes).
 * Returns:
 *   Cl_Error: CL_ERR_NONE on success, or a Cl_Error failure code.
 */
Cl_Error cl_os_write_entire_file_cstr(const char *path, Cl_Bytes data) {
    return cl_os_write_entire_file(cl_str_from_cstr(path), data);
}

/*
 * Function: cl_os_write_entire_file_atomic
 * Purpose:
 *   Writes data to "<path>.tmp.<pid>" (mode 0644), calls fsync() to flush to
 *   storage, closes the descriptor, and atomically replaces path via rename().
 *   Unlinks the temporary file on any write, sync, or rename failure.
 * Parameters:
 *   path (Cl_Str): Destination path byte slice.
 *   data (Cl_Bytes): Byte slice to write (length in bytes).
 * Returns:
 *   Cl_Error: CL_ERR_NONE on success, or a mapped Cl_Error code on failure.
 */
Cl_Error cl_os_write_entire_file_atomic(Cl_Str path, Cl_Bytes data) {
    Cl_Scratch scratch = cl_scratch_begin(NULL, 0);
    CL_DEFER_SCRATCH(scratch);

    char *cpath = cl_str_to_cstr(path, scratch.allocator);
    if (cpath == NULL) {
        return CL_ERR_OUT_OF_MEMORY;
    }

    Cl_Str tmp_str = cl_aprintf(
        scratch.allocator,
        CL_STR_FMT ".tmp.%ld",
        CL_STR_ARG(path),
        (long)getpid()
    );
    char *tmp_path = cl_str_to_cstr(tmp_str, scratch.allocator);
    if (tmp_path == NULL) {
        return CL_ERR_OUT_OF_MEMORY;
    }

    int fd = open(tmp_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) {
        return cl_errno_to_error(errno, CL_ERR_IO_OPEN);
    }

    Cl_Error err = cl_os_write_all_fd(fd, data);
    if (err == CL_ERR_NONE && fsync(fd) != 0) {
        err = cl_errno_to_error(errno, CL_ERR_IO_WRITE);
    }
    close(fd);

    if (err != CL_ERR_NONE) {
        (void)unlink(tmp_path);
        return err;
    }

    if (rename(tmp_path, cpath) != 0) {
        Cl_Error rerr = cl_errno_to_error(errno, CL_ERR_IO_WRITE);
        (void)unlink(tmp_path);
        return rerr;
    }

    return CL_ERR_NONE;
}

/*
 * Function: cl_os_file_exists
 * Purpose:
 *   Tests whether path exists on the filesystem using POSIX stat().
 * Parameters:
 *   path (Cl_Str): Filesystem path byte slice.
 * Returns:
 *   bool: true if stat() returns 0; false otherwise.
 */
bool cl_os_file_exists(Cl_Str path) {
    Cl_Scratch scratch = cl_scratch_begin(NULL, 0);
    CL_DEFER_SCRATCH(scratch);

    char *cpath = cl_str_to_cstr(path, scratch.allocator);
    if (cpath == NULL) {
        return false;
    }
    struct stat st;
    return stat(cpath, &st) == 0;
}

/*
 * Function: cl_os_file_size
 * Purpose:
 *   Retrieves st_size in bytes for path via POSIX stat().
 * Parameters:
 *   path (Cl_Str): Filesystem path byte slice.
 * Returns:
 *   Cl_Res_ISize: CL_OK(size_bytes) on success, or CL_ERR(err) on failure.
 */
Cl_Res_ISize cl_os_file_size(Cl_Str path) {
    Cl_Scratch scratch = cl_scratch_begin(NULL, 0);
    CL_DEFER_SCRATCH(scratch);

    char *cpath = cl_str_to_cstr(path, scratch.allocator);
    if (cpath == NULL) {
        return CL_ERR(Cl_Res_ISize, CL_ERR_OUT_OF_MEMORY);
    }
    struct stat st;
    if (stat(cpath, &st) != 0) {
        return CL_ERR(Cl_Res_ISize, cl_errno_to_error(errno, CL_ERR_IO_STAT));
    }
    return CL_OK(Cl_Res_ISize, (cl_isize)st.st_size);
}

/*
 * Function: cl_os_remove_file
 * Purpose:
 *   Unlinks the file at path using POSIX unlink().
 * Parameters:
 *   path (Cl_Str): Filesystem path byte slice.
 * Returns:
 *   Cl_Error: CL_ERR_NONE on success, or a mapped Cl_Error code on failure.
 */
Cl_Error cl_os_remove_file(Cl_Str path) {
    Cl_Scratch scratch = cl_scratch_begin(NULL, 0);
    CL_DEFER_SCRATCH(scratch);

    char *cpath = cl_str_to_cstr(path, scratch.allocator);
    if (cpath == NULL) {
        return CL_ERR_OUT_OF_MEMORY;
    }
    if (unlink(cpath) != 0) {
        return cl_errno_to_error(errno, CL_ERR_IO_WRITE);
    }
    return CL_ERR_NONE;
}

/*
 * Function: cl_os_env_get
 * Purpose:
 *   Queries the process environment via getenv() using a scratch NUL-terminated
 *   copy of name and returns a non-owning Cl_Str view of the value.
 * Parameters:
 *   name (Cl_Str): Environment variable name byte slice.
 * Returns:
 *   Cl_Opt_Str: CL_SOME(value_view) if present, or CL_NONE if absent or OOM.
 */
Cl_Opt_Str cl_os_env_get(Cl_Str name) {
    Cl_Scratch scratch = cl_scratch_begin(NULL, 0);
    CL_DEFER_SCRATCH(scratch);

    char *cname = cl_str_to_cstr(name, scratch.allocator);
    if (cname == NULL) {
        return CL_NONE(Cl_Opt_Str);
    }
    const char *val = getenv(cname);
    if (val == NULL) {
        return CL_NONE(Cl_Opt_Str);
    }
    return CL_SOME(Cl_Opt_Str, cl_str_from_cstr(val));
}

/*
 * Function: cl_os_close_fd
 * Purpose:
 *   Closes *fd with POSIX close() if fd != NULL and *fd >= 0, then resets
 *   *fd to -1.
 * Parameters:
 *   fd (int *): Pointer to a POSIX file descriptor variable, or NULL.
 * Returns:
 *   void.
 */
void cl_os_close_fd(int *fd) {
    if (fd != NULL && *fd >= 0) {
        close(*fd);
        *fd = -1;
    }
}

/* ----------------------------------------------------------------------------
 * Monotonic Time & Stopwatch
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_time_now_ns
 * Purpose:
 *   Reads CLOCK_MONOTONIC via clock_gettime() and converts it to nanoseconds.
 * Parameters:
 *   None (void).
 * Returns:
 *   cl_i64: Monotonic timestamp in nanoseconds, or 0 on clock_gettime failure.
 */
cl_i64 cl_time_now_ns(void) {
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) {
        return 0;
    }
    return (cl_i64)ts.tv_sec * CL_TIME_NS_PER_SEC + (cl_i64)ts.tv_nsec;
}

/*
 * Function: cl_time_sleep_ms
 * Purpose:
 *   Sleeps for at least milliseconds using nanosleep(), looping on EINTR with
 *   the remaining timespec duration.
 * Parameters:
 *   milliseconds (cl_i64): Sleep duration in milliseconds (<= 0 is a no-op).
 * Returns:
 *   void.
 */
void cl_time_sleep_ms(cl_i64 milliseconds) {
    if (milliseconds <= 0) {
        return;
    }
    struct timespec req, rem;
    req.tv_sec  = (time_t)(milliseconds / 1000);
    req.tv_nsec = (long)((milliseconds % 1000) * 1000000L);
    while (nanosleep(&req, &rem) == -1 && errno == EINTR) {
        req = rem;
    }
}

/*
 * Function: cl_stopwatch_start
 * Purpose:
 *   Records the current monotonic start timestamp and marks sw as running
 *   if it is currently stopped.
 * Parameters:
 *   sw (Cl_Stopwatch *): Target stopwatch; must be non-NULL.
 * Returns:
 *   void.
 */
void cl_stopwatch_start(Cl_Stopwatch *sw) {
    CL_ENSURE(sw != NULL);
    if (!sw->running) {
        sw->start_ns = cl_time_now_ns();
        sw->running  = true;
    }
}

/*
 * Function: cl_stopwatch_stop
 * Purpose:
 *   Accumulates the active interval duration (nanoseconds) into
 *   sw->accumulated_ns and marks sw as stopped.
 * Parameters:
 *   sw (Cl_Stopwatch *): Target stopwatch; must be non-NULL.
 * Returns:
 *   void.
 */
void cl_stopwatch_stop(Cl_Stopwatch *sw) {
    CL_ENSURE(sw != NULL);
    if (sw->running) {
        sw->accumulated_ns += (cl_time_now_ns() - sw->start_ns);
        sw->running = false;
    }
}

/*
 * Function: cl_stopwatch_reset
 * Purpose:
 *   Stops sw and clears start_ns and accumulated_ns to 0 nanoseconds.
 * Parameters:
 *   sw (Cl_Stopwatch *): Target stopwatch; must be non-NULL.
 * Returns:
 *   void.
 */
void cl_stopwatch_reset(Cl_Stopwatch *sw) {
    CL_ENSURE(sw != NULL);
    sw->start_ns       = 0;
    sw->accumulated_ns = 0;
    sw->running        = false;
}

/*
 * Function: cl_stopwatch_elapsed_ns
 * Purpose:
 *   Computes total elapsed time in nanoseconds across all stopped intervals
 *   plus the active interval if running.
 * Parameters:
 *   sw (const Cl_Stopwatch *): Target stopwatch; must be non-NULL.
 * Returns:
 *   cl_i64: Total elapsed duration in nanoseconds.
 */
cl_i64 cl_stopwatch_elapsed_ns(const Cl_Stopwatch *sw) {
    CL_ENSURE(sw != NULL);
    cl_i64 total = sw->accumulated_ns;
    if (sw->running) {
        total += (cl_time_now_ns() - sw->start_ns);
    }
    return total;
}

/*
 * Function: cl_stopwatch_elapsed_us
 * Purpose:
 *   Computes total elapsed time in microseconds by dividing elapsed
 *   nanoseconds by CL_TIME_NS_PER_US (1000.0).
 * Parameters:
 *   sw (const Cl_Stopwatch *): Target stopwatch; must be non-NULL.
 * Returns:
 *   cl_f64: Elapsed duration in microseconds.
 */
cl_f64 cl_stopwatch_elapsed_us(const Cl_Stopwatch *sw) {
    return (cl_f64)cl_stopwatch_elapsed_ns(sw) / (cl_f64)CL_TIME_NS_PER_US;
}

/*
 * Function: cl_stopwatch_elapsed_ms
 * Purpose:
 *   Computes total elapsed time in milliseconds by dividing elapsed
 *   nanoseconds by CL_TIME_NS_PER_MS (1000000.0).
 * Parameters:
 *   sw (const Cl_Stopwatch *): Target stopwatch; must be non-NULL.
 * Returns:
 *   cl_f64: Elapsed duration in milliseconds.
 */
cl_f64 cl_stopwatch_elapsed_ms(const Cl_Stopwatch *sw) {
    return (cl_f64)cl_stopwatch_elapsed_ns(sw) / (cl_f64)CL_TIME_NS_PER_MS;
}

/*
 * Function: cl_stopwatch_elapsed_sec
 * Purpose:
 *   Computes total elapsed time in seconds by dividing elapsed nanoseconds by
 *   CL_TIME_NS_PER_SEC (1000000000.0).
 * Parameters:
 *   sw (const Cl_Stopwatch *): Target stopwatch; must be non-NULL.
 * Returns:
 *   cl_f64: Elapsed duration in seconds.
 */
cl_f64 cl_stopwatch_elapsed_sec(const Cl_Stopwatch *sw) {
    return (cl_f64)cl_stopwatch_elapsed_ns(sw) / (cl_f64)CL_TIME_NS_PER_SEC;
}
