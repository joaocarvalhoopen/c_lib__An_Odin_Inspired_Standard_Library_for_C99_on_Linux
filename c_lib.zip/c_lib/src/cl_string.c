/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_string.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Implementation of all Cl_Str C-string conversions, zero-allocation views,
 *   split iterators, allocating transformations, and strict numeric/complex
 *   parsers.
 * ============================================================================
 */

#include "cl/cl_string.h"
#include "cl/cl_array.h"
#include <errno.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

/*
 * Function: cl_is_ascii_space
 * Purpose:
 *   Checks whether a byte is an ASCII whitespace character (' ', '\t', '\n',
 *   '\r', '\v', or '\f').
 * Parameters:
 *   c (cl_u8): Unsigned byte to classify.
 * Returns:
 *   bool: true if c is ASCII whitespace; false otherwise.
 */
static inline bool cl_is_ascii_space(cl_u8 c) {
    return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\v' || c == '\f';
}

/*
 * Function: cl_ascii_lower
 * Purpose:
 *   Converts an ASCII uppercase letter ('A'..'Z') to lowercase ('a'..'z');
 *   leaves all other byte values unchanged.
 * Parameters:
 *   c (cl_u8): Input byte value.
 * Returns:
 *   cl_u8: Lowercased ASCII byte if c was in ['A', 'Z'], otherwise c.
 */
static inline cl_u8 cl_ascii_lower(cl_u8 c) {
    return (c >= 'A' && c <= 'Z') ? (cl_u8)(c + ('a' - 'A')) : c;
}

/*
 * Function: cl_ascii_upper
 * Purpose:
 *   Converts an ASCII lowercase letter ('a'..'z') to uppercase ('A'..'Z');
 *   leaves all other byte values unchanged.
 * Parameters:
 *   c (cl_u8): Input byte value.
 * Returns:
 *   cl_u8: Uppercased ASCII byte if c was in ['a', 'z'], otherwise c.
 */
static inline cl_u8 cl_ascii_upper(cl_u8 c) {
    return (c >= 'a' && c <= 'z') ? (cl_u8)(c - ('a' - 'A')) : c;
}

/* ----------------------------------------------------------------------------
 * 1. Construction & C-String Conversions
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_str_from_cstr
 * Purpose:
 *   Wraps a NUL-terminated C string in a non-owning Cl_Str view using strlen.
 * Parameters:
 *   cs (const char *): Pointer to a NUL-terminated C string, or NULL.
 * Returns:
 *   Cl_Str: View referencing cs with length strlen(cs) bytes, or CL_STR_EMPTY
 *     if cs is NULL.
 */
Cl_Str cl_str_from_cstr(const char *cs) {
    if (cs == NULL) {
        return CL_STR_EMPTY;
    }
    return (Cl_Str){ (const cl_u8 *)cs, (cl_isize)strlen(cs) };
}

/*
 * Function: cl_str_to_cstr
 * Purpose:
 *   Allocates a NUL-terminated copy of s (s.len + 1 bytes) from alloc.
 * Parameters:
 *   s (Cl_Str): Source byte slice (length in bytes).
 *   alloc (Cl_Allocator): Allocator to use (falls back to cl_ctx_allocator()).
 * Returns:
 *   char *: Newly allocated NUL-terminated string, or NULL on allocation error.
 */
char *cl_str_to_cstr(Cl_Str s, Cl_Allocator alloc) {
    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    cl_isize n = (s.len > 0) ? s.len : 0;
    char *out = (char *)cl_alloc_non_zeroed_aligned_loc(a, n + 1, 1, CL_HERE);
    if (out == NULL) {
        return NULL;
    }
    if (n > 0 && s.data != NULL) {
        cl_mem_copy(out, s.data, n);
    }
    out[n] = '\0';
    return out;
}

/*
 * Function: cl_str_to_cstr_temp
 * Purpose:
 *   Allocates a NUL-terminated copy of s from the thread-local temporary
 *   allocator (cl_ctx_temp_allocator()).
 * Parameters:
 *   s (Cl_Str): Source byte slice (length in bytes).
 * Returns:
 *   char *: Temp-allocated NUL-terminated string, or NULL on failure.
 */
char *cl_str_to_cstr_temp(Cl_Str s) {
    return cl_str_to_cstr(s, cl_ctx_temp_allocator());
}

/*
 * Function: cl_str_to_cstr_buf
 * Purpose:
 *   Copies s into a fixed caller-owned buffer with guaranteed NUL termination
 *   when buf != NULL and buf_cap > 0.
 * Parameters:
 *   s (Cl_Str): Source byte slice (length in bytes).
 *   buf (char *): Destination buffer, or NULL.
 *   buf_cap (cl_isize): Total destination capacity in bytes, including NUL.
 * Returns:
 *   Cl_CStr_Buf_Res: { written (bytes copied excluding NUL), truncated (bool) }.
 */
Cl_CStr_Buf_Res cl_str_to_cstr_buf(Cl_Str s, char *buf, cl_isize buf_cap) {
    if (buf == NULL || buf_cap <= 0) {
        return (Cl_CStr_Buf_Res){ 0, s.len > 0 };
    }
    cl_isize src_len = (s.len > 0 && s.data != NULL) ? s.len : 0;
    cl_isize max_copy = buf_cap - 1;
    bool truncated = (src_len > max_copy);
    cl_isize copy_len = truncated ? max_copy : src_len;
    if (copy_len > 0) {
        cl_mem_copy(buf, s.data, copy_len);
    }
    buf[copy_len] = '\0';
    return (Cl_CStr_Buf_Res){ copy_len, truncated };
}

/*
 * Function: cl_str_clone
 * Purpose:
 *   Allocates an exact-size (s.len bytes) copy of s from alloc.
 * Parameters:
 *   s (Cl_Str): Source byte slice (length in bytes).
 *   alloc (Cl_Allocator): Allocator to use (falls back to cl_ctx_allocator()).
 * Returns:
 *   Cl_Str: Newly allocated byte slice, or CL_STR_EMPTY if empty or OOM.
 */
Cl_Str cl_str_clone(Cl_Str s, Cl_Allocator alloc) {
    if (s.len <= 0 || s.data == NULL) {
        return CL_STR_EMPTY;
    }
    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    cl_u8 *buf = (cl_u8 *)cl_alloc_non_zeroed_aligned_loc(a, s.len, 1, CL_HERE);
    if (buf == NULL) {
        return CL_STR_EMPTY;
    }
    cl_mem_copy(buf, s.data, s.len);
    return (Cl_Str){ buf, s.len };
}

/*
 * Function: cl_str_clone_from_cstr
 * Purpose:
 *   Clones a NUL-terminated C string into a newly allocated exact-length Cl_Str.
 * Parameters:
 *   cs (const char *): Source NUL-terminated C string, or NULL.
 *   alloc (Cl_Allocator): Allocator to use (falls back to cl_ctx_allocator()).
 * Returns:
 *   Cl_Str: Newly allocated Cl_Str copy, or CL_STR_EMPTY if NULL/empty/OOM.
 */
Cl_Str cl_str_clone_from_cstr(const char *cs, Cl_Allocator alloc) {
    return cl_str_clone(cl_str_from_cstr(cs), alloc);
}

/*
 * Function: cl_str_free
 * Purpose:
 *   Releases the s.len-byte allocation backing an owned Cl_Str.
 * Parameters:
 *   s (Cl_Str): Owned string slice (no-op if s.data == NULL or s.len <= 0).
 *   alloc (Cl_Allocator): Matching allocator (falls back to cl_ctx_allocator()).
 * Returns:
 *   void.
 */
void cl_str_free(Cl_Str s, Cl_Allocator alloc) {
    if (s.data == NULL || s.len <= 0) {
        return;
    }
    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    cl_free_loc(a, (void *)(cl_uintptr)s.data, s.len, CL_HERE);
}

/*
 * Function: cl_cstr_free
 * Purpose:
 *   Releases a NUL-terminated C string allocated by cl_str_to_cstr.
 * Parameters:
 *   cs (char *): Pointer to the C string, or NULL (no-op).
 *   str_len (cl_isize): String length in bytes excluding NUL (>= 0), or < 0
 *     to derive it with strlen(cs). Frees str_len + 1 bytes.
 *   alloc (Cl_Allocator): Matching allocator (falls back to cl_ctx_allocator()).
 * Returns:
 *   void.
 */
void cl_cstr_free(char *cs, cl_isize str_len, Cl_Allocator alloc) {
    if (cs == NULL) {
        return;
    }
    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    cl_isize total = (str_len >= 0) ? (str_len + 1) : ((cl_isize)strlen(cs) + 1);
    cl_free_loc(a, cs, total, CL_HERE);
}

/* ----------------------------------------------------------------------------
 * 2. Zero-Allocation Comparisons & Searches
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_str_eq
 * Purpose:
 *   Compares two Cl_Str slices for exact byte-for-byte equality.
 * Parameters:
 *   a (Cl_Str): First byte slice.
 *   b (Cl_Str): Second byte slice.
 * Returns:
 *   bool: true if lengths and all bytes match; false otherwise.
 */
bool cl_str_eq(Cl_Str a, Cl_Str b) {
    if (a.len != b.len) {
        return false;
    }
    return cl_mem_eq(a.data, b.data, a.len);
}

/*
 * Function: cl_str_eq_fold
 * Purpose:
 *   Compares two Cl_Str slices for ASCII case-insensitive equality.
 * Parameters:
 *   a (Cl_Str): First byte slice.
 *   b (Cl_Str): Second byte slice.
 * Returns:
 *   bool: true if lengths match and every byte matches after ASCII lowercasing.
 */
bool cl_str_eq_fold(Cl_Str a, Cl_Str b) {
    if (a.len != b.len) {
        return false;
    }
    for (cl_isize i = 0; i < a.len; i++) {
        if (cl_ascii_lower(a.data[i]) != cl_ascii_lower(b.data[i])) {
            return false;
        }
    }
    return true;
}

/*
 * Function: cl_str_cmp
 * Purpose:
 *   Performs lexicographical unsigned-byte ordering comparison of a and b.
 * Parameters:
 *   a (Cl_Str): First byte slice.
 *   b (Cl_Str): Second byte slice.
 * Returns:
 *   int: -1 if a < b, 0 if a == b, or +1 if a > b.
 */
int cl_str_cmp(Cl_Str a, Cl_Str b) {
    cl_isize min_len = (a.len < b.len) ? a.len : b.len;
    if (min_len > 0) {
        int c = cl_mem_cmp(a.data, b.data, min_len);
        if (c != 0) {
            return (c < 0) ? -1 : 1;
        }
    }
    return (a.len > b.len) - (a.len < b.len);
}

/*
 * Function: cl_str_has_prefix
 * Purpose:
 *   Checks whether s starts with prefix.
 * Parameters:
 *   s (Cl_Str): Haystack byte slice.
 *   prefix (Cl_Str): Prefix byte slice (empty prefix always matches).
 * Returns:
 *   bool: true if prefix is empty or matches the leading bytes of s; else false.
 */
bool cl_str_has_prefix(Cl_Str s, Cl_Str prefix) {
    if (prefix.len <= 0) {
        return true;
    }
    if (s.len < prefix.len) {
        return false;
    }
    return cl_mem_eq(s.data, prefix.data, prefix.len);
}

/*
 * Function: cl_str_has_suffix
 * Purpose:
 *   Checks whether s ends with suffix.
 * Parameters:
 *   s (Cl_Str): Haystack byte slice.
 *   suffix (Cl_Str): Suffix byte slice (empty suffix always matches).
 * Returns:
 *   bool: true if suffix is empty or matches the trailing bytes of s; else false.
 */
bool cl_str_has_suffix(Cl_Str s, Cl_Str suffix) {
    if (suffix.len <= 0) {
        return true;
    }
    if (s.len < suffix.len) {
        return false;
    }
    return cl_mem_eq(s.data + (s.len - suffix.len), suffix.data, suffix.len);
}

/*
 * Function: cl_str_index_byte
 * Purpose:
 *   Searches forward for the first occurrence of byte_val in s.
 * Parameters:
 *   s (Cl_Str): Haystack byte slice (length in bytes).
 *   byte_val (cl_u8): Target byte value.
 * Returns:
 *   cl_isize: 0-based byte offset in [0, s.len) of first match, or -1 if absent.
 */
cl_isize cl_str_index_byte(Cl_Str s, cl_u8 byte_val) {
    for (cl_isize i = 0; i < s.len; i++) {
        if (s.data[i] == byte_val) {
            return i;
        }
    }
    return -1;
}

/*
 * Function: cl_str_last_index_byte
 * Purpose:
 *   Searches backward for the last occurrence of byte_val in s.
 * Parameters:
 *   s (Cl_Str): Haystack byte slice (length in bytes).
 *   byte_val (cl_u8): Target byte value.
 * Returns:
 *   cl_isize: 0-based byte offset in [0, s.len) of last match, or -1 if absent.
 */
cl_isize cl_str_last_index_byte(Cl_Str s, cl_u8 byte_val) {
    for (cl_isize i = s.len - 1; i >= 0; i--) {
        if (s.data[i] == byte_val) {
            return i;
        }
    }
    return -1;
}

/*
 * Function: cl_str_index
 * Purpose:
 *   Searches forward for the first occurrence of substr in s.
 * Parameters:
 *   s (Cl_Str): Haystack byte slice (length in bytes).
 *   substr (Cl_Str): Needle byte slice (length in bytes).
 * Returns:
 *   cl_isize: 0-based byte offset of first match, 0 if substr is empty, or -1
 *     if not found.
 */
cl_isize cl_str_index(Cl_Str s, Cl_Str substr) {
    if (substr.len <= 0) {
        return 0;
    }
    if (substr.len > s.len || s.data == NULL || substr.data == NULL) {
        return -1;
    }
    if (substr.len == 1) {
        return cl_str_index_byte(s, substr.data[0]);
    }
    cl_u8 first = substr.data[0];
    cl_isize limit = s.len - substr.len;
    for (cl_isize i = 0; i <= limit; i++) {
        if (s.data[i] == first && cl_mem_eq(s.data + i, substr.data, substr.len)) {
            return i;
        }
    }
    return -1;
}

/*
 * Function: cl_str_last_index
 * Purpose:
 *   Searches backward for the last occurrence of substr in s.
 * Parameters:
 *   s (Cl_Str): Haystack byte slice (length in bytes).
 *   substr (Cl_Str): Needle byte slice (length in bytes).
 * Returns:
 *   cl_isize: 0-based byte offset of last match, s.len if substr is empty, or
 *     -1 if not found.
 */
cl_isize cl_str_last_index(Cl_Str s, Cl_Str substr) {
    if (substr.len <= 0) {
        return s.len;
    }
    if (substr.len > s.len || s.data == NULL || substr.data == NULL) {
        return -1;
    }
    if (substr.len == 1) {
        return cl_str_last_index_byte(s, substr.data[0]);
    }
    cl_u8 first = substr.data[0];
    for (cl_isize i = s.len - substr.len; i >= 0; i--) {
        if (s.data[i] == first && cl_mem_eq(s.data + i, substr.data, substr.len)) {
            return i;
        }
    }
    return -1;
}

/*
 * Function: cl_str_index_any
 * Purpose:
 *   Searches forward for the first byte in s that appears anywhere in chars.
 * Parameters:
 *   s (Cl_Str): Haystack byte slice (length in bytes).
 *   chars (Cl_Str): Set of target bytes.
 * Returns:
 *   cl_isize: 0-based byte offset of first matching byte, or -1 if none match.
 */
cl_isize cl_str_index_any(Cl_Str s, Cl_Str chars) {
    if (chars.len <= 0 || s.len <= 0) {
        return -1;
    }
    for (cl_isize i = 0; i < s.len; i++) {
        if (cl_str_index_byte(chars, s.data[i]) >= 0) {
            return i;
        }
    }
    return -1;
}

/*
 * Function: cl_str_contains
 * Purpose:
 *   Tests whether substr occurs anywhere within s.
 * Parameters:
 *   s (Cl_Str): Haystack byte slice.
 *   substr (Cl_Str): Needle byte slice.
 * Returns:
 *   bool: true if cl_str_index(s, substr) >= 0; false otherwise.
 */
bool cl_str_contains(Cl_Str s, Cl_Str substr) {
    return cl_str_index(s, substr) >= 0;
}

/*
 * Function: cl_str_contains_any
 * Purpose:
 *   Tests whether any byte from chars occurs in s.
 * Parameters:
 *   s (Cl_Str): Haystack byte slice.
 *   chars (Cl_Str): Set of target bytes.
 * Returns:
 *   bool: true if cl_str_index_any(s, chars) >= 0; false otherwise.
 */
bool cl_str_contains_any(Cl_Str s, Cl_Str chars) {
    return cl_str_index_any(s, chars) >= 0;
}

/*
 * Function: cl_str_count
 * Purpose:
 *   Counts non-overlapping occurrences of substr in s.
 * Parameters:
 *   s (Cl_Str): Haystack byte slice (length in bytes).
 *   substr (Cl_Str): Needle byte slice (empty needle yields s.len + 1).
 * Returns:
 *   cl_isize: Number of non-overlapping occurrences (>= 0).
 */
cl_isize cl_str_count(Cl_Str s, Cl_Str substr) {
    if (substr.len <= 0) {
        return s.len + 1;
    }
    cl_isize count = 0;
    cl_isize pos = 0;
    while (pos <= s.len - substr.len) {
        Cl_Str tail = { s.data + pos, s.len - pos };
        cl_isize idx = cl_str_index(tail, substr);
        if (idx < 0) {
            break;
        }
        count += 1;
        pos += idx + substr.len;
    }
    return count;
}

/*
 * Function: cl_str_cut
 * Purpose:
 *   Splits s around the first occurrence of sep into zero-copy views before
 *   and after sep.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 *   sep (Cl_Str): Separator byte slice.
 * Returns:
 *   Cl_Str_Cut: { before, after, true } when sep is found, or
 *     { s, CL_STR_EMPTY, false } when sep is absent.
 */
Cl_Str_Cut cl_str_cut(Cl_Str s, Cl_Str sep) {
    cl_isize idx = cl_str_index(s, sep);
    if (idx < 0) {
        return (Cl_Str_Cut){ s, CL_STR_EMPTY, false };
    }
    Cl_Str before = (idx > 0) ? (Cl_Str){ s.data, idx } : CL_STR_EMPTY;
    cl_isize after_off = idx + sep.len;
    Cl_Str after = (after_off < s.len)
                       ? (Cl_Str){ s.data + after_off, s.len - after_off }
                       : CL_STR_EMPTY;
    return (Cl_Str_Cut){ before, after, true };
}

/*
 * Function: cl_str_trim_left_space
 * Purpose:
 *   Strips leading ASCII whitespace from s without allocating.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 * Returns:
 *   Cl_Str: Zero-copy sub-view of s without leading ASCII whitespace.
 */
Cl_Str cl_str_trim_left_space(Cl_Str s) {
    cl_isize i = 0;
    while (i < s.len && cl_is_ascii_space(s.data[i])) {
        i += 1;
    }
    return (i < s.len) ? (Cl_Str){ s.data + i, s.len - i } : CL_STR_EMPTY;
}

/*
 * Function: cl_str_trim_right_space
 * Purpose:
 *   Strips trailing ASCII whitespace from s without allocating.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 * Returns:
 *   Cl_Str: Zero-copy sub-view of s without trailing ASCII whitespace.
 */
Cl_Str cl_str_trim_right_space(Cl_Str s) {
    cl_isize end = s.len;
    while (end > 0 && cl_is_ascii_space(s.data[end - 1])) {
        end -= 1;
    }
    return (end > 0) ? (Cl_Str){ s.data, end } : CL_STR_EMPTY;
}

/*
 * Function: cl_str_trim_space
 * Purpose:
 *   Strips both leading and trailing ASCII whitespace from s without allocating.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 * Returns:
 *   Cl_Str: Zero-copy trimmed sub-view of s.
 */
Cl_Str cl_str_trim_space(Cl_Str s) {
    return cl_str_trim_right_space(cl_str_trim_left_space(s));
}

/*
 * Function: cl_str_trim_left_cutset
 * Purpose:
 *   Strips all leading bytes appearing in cutset from s without allocating.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 *   cutset (Cl_Str): Byte set to remove from the start of s.
 * Returns:
 *   Cl_Str: Zero-copy trimmed sub-view of s.
 */
Cl_Str cl_str_trim_left_cutset(Cl_Str s, Cl_Str cutset) {
    cl_isize i = 0;
    while (i < s.len && cl_str_index_byte(cutset, s.data[i]) >= 0) {
        i += 1;
    }
    return (i < s.len) ? (Cl_Str){ s.data + i, s.len - i } : CL_STR_EMPTY;
}

/*
 * Function: cl_str_trim_right_cutset
 * Purpose:
 *   Strips all trailing bytes appearing in cutset from s without allocating.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 *   cutset (Cl_Str): Byte set to remove from the end of s.
 * Returns:
 *   Cl_Str: Zero-copy trimmed sub-view of s.
 */
Cl_Str cl_str_trim_right_cutset(Cl_Str s, Cl_Str cutset) {
    cl_isize end = s.len;
    while (end > 0 && cl_str_index_byte(cutset, s.data[end - 1]) >= 0) {
        end -= 1;
    }
    return (end > 0) ? (Cl_Str){ s.data, end } : CL_STR_EMPTY;
}

/*
 * Function: cl_str_trim_cutset
 * Purpose:
 *   Strips all leading and trailing bytes appearing in cutset from s without
 *   allocating.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 *   cutset (Cl_Str): Byte set to remove from both ends of s.
 * Returns:
 *   Cl_Str: Zero-copy trimmed sub-view of s.
 */
Cl_Str cl_str_trim_cutset(Cl_Str s, Cl_Str cutset) {
    return cl_str_trim_right_cutset(cl_str_trim_left_cutset(s, cutset), cutset);
}

/*
 * Function: cl_str_trim_prefix
 * Purpose:
 *   Removes one leading occurrence of prefix from s if present.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 *   prefix (Cl_Str): Prefix byte slice to strip once.
 * Returns:
 *   Cl_Str: Sub-view without prefix if present, or s unchanged otherwise.
 */
Cl_Str cl_str_trim_prefix(Cl_Str s, Cl_Str prefix) {
    if (cl_str_has_prefix(s, prefix)) {
        return cl_str_slice(s, prefix.len, s.len);
    }
    return s;
}

/*
 * Function: cl_str_trim_suffix
 * Purpose:
 *   Removes one trailing occurrence of suffix from s if present.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 *   suffix (Cl_Str): Suffix byte slice to strip once.
 * Returns:
 *   Cl_Str: Sub-view without suffix if present, or s unchanged otherwise.
 */
Cl_Str cl_str_trim_suffix(Cl_Str s, Cl_Str suffix) {
    if (cl_str_has_suffix(s, suffix)) {
        return cl_str_slice(s, 0, s.len - suffix.len);
    }
    return s;
}

/* ----------------------------------------------------------------------------
 * 3. Zero-Allocation Split Iterators
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_str_split_iter
 * Purpose:
 *   Yields the next sep-delimited zero-copy slice from *rest and advances
 *   *rest past the separator. If sep is empty, yields 1 byte per call.
 * Parameters:
 *   rest (Cl_Str *): In/out cursor over remaining bytes; cleared to
 *     CL_STR_EMPTY once exhausted. Safe if NULL.
 *   sep (Cl_Str): Delimiter byte slice.
 * Returns:
 *   Cl_Opt_Str: CL_SOME(piece) on each piece, or CL_NONE when exhausted.
 */
Cl_Opt_Str cl_str_split_iter(Cl_Str *rest, Cl_Str sep) {
    if (rest == NULL || rest->data == NULL) {
        return CL_NONE(Cl_Opt_Str);
    }
    if (sep.len <= 0) {
        /* Empty separator: yield one byte at a time until exhausted */
        if (rest->len <= 0) {
            *rest = CL_STR_EMPTY;
            return CL_NONE(Cl_Opt_Str);
        }
        Cl_Str piece = { rest->data, 1 };
        rest->len -= 1;
        rest->data = (rest->len > 0) ? (rest->data + 1) : NULL;
        return CL_SOME(Cl_Opt_Str, piece);
    }

    cl_isize idx = cl_str_index(*rest, sep);
    if (idx < 0) {
        Cl_Str piece = *rest;
        *rest = CL_STR_EMPTY;
        return CL_SOME(Cl_Opt_Str, piece);
    }

    Cl_Str piece = (idx > 0) ? (Cl_Str){ rest->data, idx } : CL_STR_EMPTY;
    cl_isize advance = idx + sep.len;
    /* Keep rest->data non-NULL if trailing separator leaves a final empty piece */
    rest->data = rest->data + advance;
    rest->len  = rest->len - advance;
    return CL_SOME(Cl_Opt_Str, piece);
}

/*
 * Function: cl_str_split_lines_iter
 * Purpose:
 *   Yields the next line from *rest with trailing '\n' or '\r\n' stripped and
 *   advances *rest past the newline.
 * Parameters:
 *   rest (Cl_Str *): In/out cursor over remaining bytes. Safe if NULL.
 * Returns:
 *   Cl_Opt_Str: CL_SOME(line) for each line, or CL_NONE when exhausted.
 */
Cl_Opt_Str cl_str_split_lines_iter(Cl_Str *rest) {
    if (rest == NULL || rest->data == NULL || rest->len <= 0) {
        return CL_NONE(Cl_Opt_Str);
    }
    cl_isize nl = cl_str_index_byte(*rest, '\n');
    if (nl < 0) {
        Cl_Str line = *rest;
        if (line.len > 0 && line.data[line.len - 1] == '\r') {
            line.len -= 1;
        }
        *rest = CL_STR_EMPTY;
        return CL_SOME(Cl_Opt_Str, line);
    }

    cl_isize line_len = nl;
    if (line_len > 0 && rest->data[line_len - 1] == '\r') {
        line_len -= 1;
    }
    Cl_Str line = (line_len > 0) ? (Cl_Str){ rest->data, line_len } : CL_STR_EMPTY;
    cl_isize rem = rest->len - (nl + 1);
    if (rem > 0) {
        rest->data = rest->data + (nl + 1);
        rest->len  = rem;
    } else {
        *rest = CL_STR_EMPTY;
    }
    return CL_SOME(Cl_Opt_Str, line);
}

/*
 * Function: cl_str_fields_iter
 * Purpose:
 *   Skips leading ASCII whitespace in *rest and yields the next maximal
 *   non-whitespace token view, advancing *rest past that token.
 * Parameters:
 *   rest (Cl_Str *): In/out cursor over remaining bytes. Safe if NULL.
 * Returns:
 *   Cl_Opt_Str: CL_SOME(token) for each non-empty token, or CL_NONE when done.
 */
Cl_Opt_Str cl_str_fields_iter(Cl_Str *rest) {
    if (rest == NULL || rest->data == NULL || rest->len <= 0) {
        return CL_NONE(Cl_Opt_Str);
    }
    *rest = cl_str_trim_left_space(*rest);
    if (rest->len <= 0) {
        *rest = CL_STR_EMPTY;
        return CL_NONE(Cl_Opt_Str);
    }
    cl_isize end = 0;
    while (end < rest->len && !cl_is_ascii_space(rest->data[end])) {
        end += 1;
    }
    Cl_Str tok = { rest->data, end };
    cl_isize rem = rest->len - end;
    if (rem > 0) {
        rest->data = rest->data + end;
        rest->len  = rem;
    } else {
        *rest = CL_STR_EMPTY;
    }
    return CL_SOME(Cl_Opt_Str, tok);
}

/* ----------------------------------------------------------------------------
 * 4. Allocating String Transformations
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_str_split
 * Purpose:
 *   Splits s around sep using a two-pass count-and-fill strategy so the
 *   returned Cl_Slice_Str has exact allocated length matching CL_SLICE_FREE.
 * Parameters:
 *   s (Cl_Str): Source byte slice (backing storage must outlive returned views).
 *   sep (Cl_Str): Delimiter byte slice.
 *   alloc (Cl_Allocator): Allocator for the slice array (falls back to context).
 * Returns:
 *   Cl_Slice_Str: Allocated slice of zero-copy views, or an empty slice.
 */
Cl_Slice_Str cl_str_split(Cl_Str s, Cl_Str sep, Cl_Allocator alloc) {
    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    if (s.len == 0 && s.data == NULL) {
        return CL_SLICE_EMPTY(Cl_Slice_Str);
    }
    /* Two-pass allocation so slice length == allocated capacity (exact free size!) */
    cl_isize count = 0;
    Cl_Str cursor = s;
    for (;;) {
        Cl_Opt_Str part = cl_str_split_iter(&cursor, sep);
        if (!part.ok) break;
        count += 1;
    }
    if (count == 0) {
        return CL_SLICE_EMPTY(Cl_Slice_Str);
    }

    Cl_Slice_Str out = CL_SLICE_MAKE(Cl_Slice_Str, a, count);
    if (out.data == NULL) {
        return CL_SLICE_EMPTY(Cl_Slice_Str);
    }
    cursor = s;
    for (cl_isize i = 0; i < count; i++) {
        Cl_Opt_Str part = cl_str_split_iter(&cursor, sep);
        out.data[i] = part.value;
    }
    return out;
}

/*
 * Function: cl_str_split_lines
 * Purpose:
 *   Splits s into lines (stripping '\n' and '\r\n') into an exact-sized
 *   allocated slice of zero-copy Cl_Str views.
 * Parameters:
 *   s (Cl_Str): Source byte slice.
 *   alloc (Cl_Allocator): Allocator for the slice array (falls back to context).
 * Returns:
 *   Cl_Slice_Str: Allocated slice of line views, or an empty slice.
 */
Cl_Slice_Str cl_str_split_lines(Cl_Str s, Cl_Allocator alloc) {
    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    cl_isize count = 0;
    Cl_Str cursor = s;
    for (;;) {
        Cl_Opt_Str line = cl_str_split_lines_iter(&cursor);
        if (!line.ok) break;
        count += 1;
    }
    if (count == 0) {
        return CL_SLICE_EMPTY(Cl_Slice_Str);
    }
    Cl_Slice_Str out = CL_SLICE_MAKE(Cl_Slice_Str, a, count);
    if (out.data == NULL) {
        return CL_SLICE_EMPTY(Cl_Slice_Str);
    }
    cursor = s;
    for (cl_isize i = 0; i < count; i++) {
        Cl_Opt_Str line = cl_str_split_lines_iter(&cursor);
        out.data[i] = line.value;
    }
    return out;
}

/*
 * Function: cl_str_fields
 * Purpose:
 *   Splits s on ASCII whitespace runs into an exact-sized allocated slice of
 *   zero-copy Cl_Str token views.
 * Parameters:
 *   s (Cl_Str): Source byte slice.
 *   alloc (Cl_Allocator): Allocator for the slice array (falls back to context).
 * Returns:
 *   Cl_Slice_Str: Allocated slice of non-empty token views, or an empty slice.
 */
Cl_Slice_Str cl_str_fields(Cl_Str s, Cl_Allocator alloc) {
    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    cl_isize count = 0;
    Cl_Str cursor = s;
    for (;;) {
        Cl_Opt_Str tok = cl_str_fields_iter(&cursor);
        if (!tok.ok) break;
        count += 1;
    }
    if (count == 0) {
        return CL_SLICE_EMPTY(Cl_Slice_Str);
    }
    Cl_Slice_Str out = CL_SLICE_MAKE(Cl_Slice_Str, a, count);
    if (out.data == NULL) {
        return CL_SLICE_EMPTY(Cl_Slice_Str);
    }
    cursor = s;
    for (cl_isize i = 0; i < count; i++) {
        Cl_Opt_Str tok = cl_str_fields_iter(&cursor);
        out.data[i] = tok.value;
    }
    return out;
}

/*
 * Function: cl_str_join
 * Purpose:
 *   Concatenates parts separated by sep into a newly allocated Cl_Str.
 * Parameters:
 *   parts (Cl_Slice_Str): Slice of strings to join.
 *   sep (Cl_Str): Separator byte slice placed between adjacent elements.
 *   alloc (Cl_Allocator): Allocator for output bytes (falls back to context).
 * Returns:
 *   Cl_Str: Newly allocated joined string, or CL_STR_EMPTY if empty or OOM.
 */
Cl_Str cl_str_join(Cl_Slice_Str parts, Cl_Str sep, Cl_Allocator alloc) {
    if (parts.len <= 0) {
        return CL_STR_EMPTY;
    }
    cl_isize total = 0;
    for (cl_isize i = 0; i < parts.len; i++) {
        total += parts.data[i].len;
        if (i > 0) {
            total += sep.len;
        }
    }
    if (total <= 0) {
        return CL_STR_EMPTY;
    }

    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    cl_u8 *buf = (cl_u8 *)cl_alloc_non_zeroed_aligned_loc(a, total, 1, CL_HERE);
    if (buf == NULL) {
        return CL_STR_EMPTY;
    }

    cl_isize pos = 0;
    for (cl_isize i = 0; i < parts.len; i++) {
        if (i > 0 && sep.len > 0) {
            cl_mem_copy(buf + pos, sep.data, sep.len);
            pos += sep.len;
        }
        if (parts.data[i].len > 0) {
            cl_mem_copy(buf + pos, parts.data[i].data, parts.data[i].len);
            pos += parts.data[i].len;
        }
    }
    return (Cl_Str){ buf, total };
}

/*
 * Function: cl_str_concat
 * Purpose:
 *   Concatenates parts with no separator into a newly allocated Cl_Str.
 * Parameters:
 *   parts (Cl_Slice_Str): Slice of strings to concatenate.
 *   alloc (Cl_Allocator): Allocator for output bytes (falls back to context).
 * Returns:
 *   Cl_Str: Newly allocated concatenated string, or CL_STR_EMPTY.
 */
Cl_Str cl_str_concat(Cl_Slice_Str parts, Cl_Allocator alloc) {
    return cl_str_join(parts, CL_STR_EMPTY, alloc);
}

/*
 * Function: cl_str_repeat
 * Purpose:
 *   Allocates a Cl_Str containing count contiguous copies of s, guarding
 *   against signed multiplication overflow in s.len * count.
 * Parameters:
 *   s (Cl_Str): Source pattern byte slice.
 *   count (cl_isize): Repetition count (<= 0 returns CL_STR_EMPTY).
 *   alloc (Cl_Allocator): Allocator for output bytes (falls back to context).
 * Returns:
 *   Cl_Str: Newly allocated string of s.len * count bytes, or CL_STR_EMPTY.
 */
Cl_Str cl_str_repeat(Cl_Str s, cl_isize count, Cl_Allocator alloc) {
    if (s.len <= 0 || count <= 0) {
        return CL_STR_EMPTY;
    }
    cl_isize total = 0;
    if (cl_mul_overflow_isize(s.len, count, &total)) {
        return CL_STR_EMPTY;
    }
    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    cl_u8 *buf = (cl_u8 *)cl_alloc_non_zeroed_aligned_loc(a, total, 1, CL_HERE);
    if (buf == NULL) {
        return CL_STR_EMPTY;
    }
    for (cl_isize i = 0; i < count; i++) {
        cl_mem_copy(buf + i * s.len, s.data, s.len);
    }
    return (Cl_Str){ buf, total };
}

/*
 * Function: cl_str_replace_n
 * Purpose:
 *   Allocates a new string from s with up to max_n non-overlapping matches of
 *   old_s replaced by new_s (or all matches when max_n < 0).
 * Parameters:
 *   s (Cl_Str): Source byte slice.
 *   old_s (Cl_Str): Substring to replace (empty yields a clone of s).
 *   new_s (Cl_Str): Replacement byte slice.
 *   max_n (cl_isize): Maximum replacements (< 0 replaces all, 0 clones s).
 *   alloc (Cl_Allocator): Allocator for output bytes (falls back to context).
 * Returns:
 *   Cl_Str: Newly allocated string, or CL_STR_EMPTY if result is empty or OOM.
 */
Cl_Str cl_str_replace_n(Cl_Str s, Cl_Str old_s, Cl_Str new_s, cl_isize max_n, Cl_Allocator alloc) {
    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    if (s.len <= 0 || old_s.len <= 0 || max_n == 0) {
        return cl_str_clone(s, a);
    }

    cl_isize occurrences = cl_str_count(s, old_s);
    if (occurrences == 0) {
        return cl_str_clone(s, a);
    }
    cl_isize to_replace = (max_n < 0 || max_n > occurrences) ? occurrences : max_n;
    cl_isize new_len = s.len + to_replace * (new_s.len - old_s.len);
    if (new_len <= 0) {
        return CL_STR_EMPTY;
    }

    cl_u8 *buf = (cl_u8 *)cl_alloc_non_zeroed_aligned_loc(a, new_len, 1, CL_HERE);
    if (buf == NULL) {
        return CL_STR_EMPTY;
    }

    cl_isize src_pos = 0;
    cl_isize dst_pos = 0;
    cl_isize replaced = 0;
    while (src_pos < s.len && replaced < to_replace) {
        Cl_Str tail = { s.data + src_pos, s.len - src_pos };
        cl_isize idx = cl_str_index(tail, old_s);
        if (idx < 0) {
            break;
        }
        if (idx > 0) {
            cl_mem_copy(buf + dst_pos, s.data + src_pos, idx);
            dst_pos += idx;
        }
        if (new_s.len > 0) {
            cl_mem_copy(buf + dst_pos, new_s.data, new_s.len);
            dst_pos += new_s.len;
        }
        src_pos += idx + old_s.len;
        replaced += 1;
    }
    if (src_pos < s.len) {
        cl_isize rem = s.len - src_pos;
        cl_mem_copy(buf + dst_pos, s.data + src_pos, rem);
        dst_pos += rem;
    }
    CL_ASSERT(dst_pos == new_len);
    return (Cl_Str){ buf, new_len };
}

/*
 * Function: cl_str_replace_all
 * Purpose:
 *   Allocates a copy of s with all non-overlapping occurrences of old_s
 *   replaced by new_s.
 * Parameters:
 *   s (Cl_Str): Source byte slice.
 *   old_s (Cl_Str): Substring to replace.
 *   new_s (Cl_Str): Replacement byte slice.
 *   alloc (Cl_Allocator): Allocator for output bytes (falls back to context).
 * Returns:
 *   Cl_Str: Newly allocated string, or CL_STR_EMPTY.
 */
Cl_Str cl_str_replace_all(Cl_Str s, Cl_Str old_s, Cl_Str new_s, Cl_Allocator alloc) {
    return cl_str_replace_n(s, old_s, new_s, -1, alloc);
}

/*
 * Function: cl_str_to_lower
 * Purpose:
 *   Allocates an ASCII-lowercased copy of s.
 * Parameters:
 *   s (Cl_Str): Source byte slice.
 *   alloc (Cl_Allocator): Allocator for output bytes (falls back to context).
 * Returns:
 *   Cl_Str: Newly allocated string of s.len bytes, or CL_STR_EMPTY.
 */
Cl_Str cl_str_to_lower(Cl_Str s, Cl_Allocator alloc) {
    if (s.len <= 0) {
        return CL_STR_EMPTY;
    }
    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    cl_u8 *buf = (cl_u8 *)cl_alloc_non_zeroed_aligned_loc(a, s.len, 1, CL_HERE);
    if (buf == NULL) {
        return CL_STR_EMPTY;
    }
    for (cl_isize i = 0; i < s.len; i++) {
        buf[i] = cl_ascii_lower(s.data[i]);
    }
    return (Cl_Str){ buf, s.len };
}

/*
 * Function: cl_str_to_upper
 * Purpose:
 *   Allocates an ASCII-uppercased copy of s.
 * Parameters:
 *   s (Cl_Str): Source byte slice.
 *   alloc (Cl_Allocator): Allocator for output bytes (falls back to context).
 * Returns:
 *   Cl_Str: Newly allocated string of s.len bytes, or CL_STR_EMPTY.
 */
Cl_Str cl_str_to_upper(Cl_Str s, Cl_Allocator alloc) {
    if (s.len <= 0) {
        return CL_STR_EMPTY;
    }
    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    cl_u8 *buf = (cl_u8 *)cl_alloc_non_zeroed_aligned_loc(a, s.len, 1, CL_HERE);
    if (buf == NULL) {
        return CL_STR_EMPTY;
    }
    for (cl_isize i = 0; i < s.len; i++) {
        buf[i] = cl_ascii_upper(s.data[i]);
    }
    return (Cl_Str){ buf, s.len };
}

/*
 * Function: cl_str_reverse_utf8
 * Purpose:
 *   Allocates a copy of s with UTF-8 runes placed in reverse order while
 *   keeping each multi-byte rune's internal bytes intact.
 * Parameters:
 *   s (Cl_Str): Source UTF-8 byte slice.
 *   alloc (Cl_Allocator): Allocator for output bytes (falls back to context).
 * Returns:
 *   Cl_Str: Newly allocated reversed string of s.len bytes, or CL_STR_EMPTY.
 */
Cl_Str cl_str_reverse_utf8(Cl_Str s, Cl_Allocator alloc) {
    if (s.len <= 0) {
        return CL_STR_EMPTY;
    }
    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    cl_u8 *buf = (cl_u8 *)cl_alloc_non_zeroed_aligned_loc(a, s.len, 1, CL_HERE);
    if (buf == NULL) {
        return CL_STR_EMPTY;
    }
    cl_isize src = 0;
    cl_isize dst = s.len;
    while (src < s.len) {
        Cl_Str rem = { s.data + src, s.len - src };
        Cl_Utf8_Decode d = cl_utf8_decode_rune(rem);
        cl_isize w = (d.width > 0) ? d.width : 1;
        dst -= w;
        cl_mem_copy(buf + dst, s.data + src, w);
        src += w;
    }
    return (Cl_Str){ buf, s.len };
}

/*
 * Function: cl_str_pad_left
 * Purpose:
 *   Allocates a copy of s padded on the left with pad_byte to target_len bytes,
 *   or clones s if target_len <= s.len.
 * Parameters:
 *   s (Cl_Str): Source byte slice.
 *   target_len (cl_isize): Desired total length in bytes.
 *   pad_byte (cl_u8): Byte repeated for left padding.
 *   alloc (Cl_Allocator): Allocator for output bytes (falls back to context).
 * Returns:
 *   Cl_Str: Newly allocated padded string, or CL_STR_EMPTY on empty/OOM.
 */
Cl_Str cl_str_pad_left(Cl_Str s, cl_isize target_len, cl_u8 pad_byte, Cl_Allocator alloc) {
    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    if (target_len <= s.len) {
        return cl_str_clone(s, a);
    }
    cl_u8 *buf = (cl_u8 *)cl_alloc_non_zeroed_aligned_loc(a, target_len, 1, CL_HERE);
    if (buf == NULL) {
        return CL_STR_EMPTY;
    }
    cl_isize pad = target_len - s.len;
    cl_mem_set(buf, pad_byte, pad);
    cl_mem_copy(buf + pad, s.data, s.len);
    return (Cl_Str){ buf, target_len };
}

/*
 * Function: cl_str_pad_right
 * Purpose:
 *   Allocates a copy of s padded on the right with pad_byte to target_len
 *   bytes, or clones s if target_len <= s.len.
 * Parameters:
 *   s (Cl_Str): Source byte slice.
 *   target_len (cl_isize): Desired total length in bytes.
 *   pad_byte (cl_u8): Byte repeated for right padding.
 *   alloc (Cl_Allocator): Allocator for output bytes (falls back to context).
 * Returns:
 *   Cl_Str: Newly allocated padded string, or CL_STR_EMPTY on empty/OOM.
 */
Cl_Str cl_str_pad_right(Cl_Str s, cl_isize target_len, cl_u8 pad_byte, Cl_Allocator alloc) {
    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    if (target_len <= s.len) {
        return cl_str_clone(s, a);
    }
    cl_u8 *buf = (cl_u8 *)cl_alloc_non_zeroed_aligned_loc(a, target_len, 1, CL_HERE);
    if (buf == NULL) {
        return CL_STR_EMPTY;
    }
    cl_mem_copy(buf, s.data, s.len);
    cl_mem_set(buf + s.len, pad_byte, target_len - s.len);
    return (Cl_Str){ buf, target_len };
}

/* ----------------------------------------------------------------------------
 * 5. Strict Value Parsing (core:strconv)
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_digit_value
 * Purpose:
 *   Maps an ASCII alphanumeric character ('0'..'9', 'a'..'z', 'A'..'Z') to its
 *   numeric digit value in [0, 35] for radix parsing.
 * Parameters:
 *   c (cl_u8): ASCII byte to convert.
 * Returns:
 *   int: Digit value in [0, 35], or -1 if c is not an ASCII alphanumeric digit.
 */
static int cl_digit_value(cl_u8 c) {
    if (c >= '0' && c <= '9') return (int)(c - '0');
    if (c >= 'a' && c <= 'z') return (int)(c - 'a' + 10);
    if (c >= 'A' && c <= 'Z') return (int)(c - 'A' + 10);
    return -1;
}

/*
 * Function: cl_str_parse_u64
 * Purpose:
 *   Strictly parses an unsigned 64-bit integer from trimmed text, accepting
 *   optional '+', '_' digit separators, base auto-detection (0x/0b/0o when
 *   base == 0), and checking for uint64_t overflow.
 * Parameters:
 *   s (Cl_Str): Input text slice.
 *   base (int): Radix in [2, 36], or 0 to auto-detect prefix (default 10).
 * Returns:
 *   Cl_Opt_U64: CL_SOME(value) on valid parse, or CL_NONE on error/overflow.
 */
Cl_Opt_U64 cl_str_parse_u64(Cl_Str s, int base) {
    s = cl_str_trim_space(s);
    if (s.len <= 0) {
        return CL_NONE(Cl_Opt_U64);
    }

    cl_isize i = 0;
    if (s.data[i] == '+') {
        i += 1;
    } else if (s.data[i] == '-') {
        return CL_NONE(Cl_Opt_U64);
    }

    if (base == 0) {
        if (i + 1 < s.len && s.data[i] == '0') {
            cl_u8 p = cl_ascii_lower(s.data[i + 1]);
            if (p == 'x')      { base = 16; i += 2; }
            else if (p == 'b') { base = 2;  i += 2; }
            else if (p == 'o') { base = 8;  i += 2; }
            else               { base = 10; }
        } else {
            base = 10;
        }
    } else if (base < 2 || base > 36) {
        return CL_NONE(Cl_Opt_U64);
    }

    if (i >= s.len) {
        return CL_NONE(Cl_Opt_U64);
    }

    cl_u64 acc = 0;
    cl_u64 ubase = (cl_u64)base;
    bool has_digit = false;

    for (; i < s.len; i++) {
        if (s.data[i] == '_') {
            continue; /* Odin-style digit separator (e.g. 1_000_000) */
        }
        int d = cl_digit_value(s.data[i]);
        if (d < 0 || d >= base) {
            return CL_NONE(Cl_Opt_U64);
        }
        cl_u64 ud = (cl_u64)d;
        if (acc > (UINT64_MAX - ud) / ubase) {
            return CL_NONE(Cl_Opt_U64); /* Overflow */
        }
        acc = acc * ubase + ud;
        has_digit = true;
    }

    if (!has_digit) {
        return CL_NONE(Cl_Opt_U64);
    }
    return CL_SOME(Cl_Opt_U64, acc);
}

/*
 * Function: cl_str_parse_i64
 * Purpose:
 *   Strictly parses a signed 64-bit integer from trimmed text, handling
 *   optional '+'/'-' sign, INT64_MIN accurately, and rejecting overflow.
 * Parameters:
 *   s (Cl_Str): Input text slice.
 *   base (int): Radix in [2, 36], or 0 to auto-detect prefix (0x/0b/0o).
 * Returns:
 *   Cl_Opt_I64: CL_SOME(value) on valid parse, or CL_NONE on error/overflow.
 */
Cl_Opt_I64 cl_str_parse_i64(Cl_Str s, int base) {
    s = cl_str_trim_space(s);
    if (s.len <= 0) {
        return CL_NONE(Cl_Opt_I64);
    }
    bool neg = false;
    cl_isize i = 0;
    if (s.data[i] == '-') {
        neg = true;
        i += 1;
    } else if (s.data[i] == '+') {
        i += 1;
    }
    if (i >= s.len) {
        return CL_NONE(Cl_Opt_I64);
    }
    Cl_Opt_U64 mag = cl_str_parse_u64(cl_str_slice(s, i, s.len), base);
    if (!mag.ok) {
        return CL_NONE(Cl_Opt_I64);
    }
    if (neg) {
        cl_u64 max_neg = (cl_u64)INT64_MAX + 1ull; /* 9223372036854775808 */
        if (mag.value > max_neg) {
            return CL_NONE(Cl_Opt_I64);
        }
        if (mag.value == max_neg) {
            return CL_SOME(Cl_Opt_I64, INT64_MIN);
        }
        return CL_SOME(Cl_Opt_I64, -(cl_i64)mag.value);
    }
    if (mag.value > (cl_u64)INT64_MAX) {
        return CL_NONE(Cl_Opt_I64);
    }
    return CL_SOME(Cl_Opt_I64, (cl_i64)mag.value);
}

/*
 * Function: cl_str_parse_f64
 * Purpose:
 *   Strictly parses a 64-bit IEEE-754 floating-point number using strtod on a
 *   stack-copied NUL-terminated buffer, rejecting trailing characters, ERANGE,
 *   and trimmed inputs of 128 bytes or more.
 * Parameters:
 *   s (Cl_Str): Input text slice (trimmed length must be in [1, 127] bytes).
 * Returns:
 *   Cl_Opt_F64: CL_SOME(value) on valid parse, or CL_NONE on failure.
 */
Cl_Opt_F64 cl_str_parse_f64(Cl_Str s) {
    s = cl_str_trim_space(s);
    if (s.len <= 0 || s.len >= 128) {
        return CL_NONE(Cl_Opt_F64);
    }
    char buf[128];
    cl_mem_copy(buf, s.data, s.len);
    buf[s.len] = '\0';

    char *end = NULL;
    errno = 0;
    double val = strtod(buf, &end);
    if (end == buf || *end != '\0' || errno == ERANGE) {
        return CL_NONE(Cl_Opt_F64);
    }
    return CL_SOME(Cl_Opt_F64, val);
}

/*
 * Function: cl_str_parse_bool
 * Purpose:
 *   Strictly parses a boolean token ("true"/"1"/"yes" or "false"/"0"/"no",
 *   ASCII case-insensitive) after trimming surrounding whitespace.
 * Parameters:
 *   s (Cl_Str): Input text slice.
 * Returns:
 *   Cl_Opt_Bool: CL_SOME(true/false) on recognized token, or CL_NONE otherwise.
 */
Cl_Opt_Bool cl_str_parse_bool(Cl_Str s) {
    s = cl_str_trim_space(s);
    if (cl_str_eq_fold(s, CL_STR("true")) || cl_str_eq(s, CL_STR("1")) || cl_str_eq_fold(s, CL_STR("yes"))) {
        return CL_SOME(Cl_Opt_Bool, true);
    }
    if (cl_str_eq_fold(s, CL_STR("false")) || cl_str_eq(s, CL_STR("0")) || cl_str_eq_fold(s, CL_STR("no"))) {
        return CL_SOME(Cl_Opt_Bool, false);
    }
    return CL_NONE(Cl_Opt_Bool);
}

/*
 * Function: cl_str_parse_c128
 * Purpose:
 *   Strictly parses a double-precision complex number from tuple syntax
 *   "(re, im)", pure real text, pure imaginary text ("i", "-4.5j"), or
 *   algebraic "a + bi" / "a - bi" syntax (ignoring internal whitespace and
 *   exponent signs 'e+'/'e-').
 * Parameters:
 *   s (Cl_Str): Input text slice (compact non-whitespace length < 160 bytes).
 * Returns:
 *   Cl_Opt_C128: CL_SOME(value) on valid complex parse, or CL_NONE on failure.
 */
Cl_Opt_C128 cl_str_parse_c128(Cl_Str s) {
    s = cl_str_trim_space(s);
    if (s.len <= 0) {
        return CL_NONE(Cl_Opt_C128);
    }

    /* Tuple syntax: "(re, im)" */
    if (s.data[0] == '(' && s.data[s.len - 1] == ')') {
        Cl_Str inner = cl_str_slice(s, 1, s.len - 1);
        Cl_Str_Cut cut = cl_str_cut(inner, CL_STR(","));
        if (!cut.found) {
            return CL_NONE(Cl_Opt_C128);
        }
        Cl_Opt_F64 re = cl_str_parse_f64(cut.before);
        Cl_Opt_F64 im = cl_str_parse_f64(cut.after);
        if (!re.ok || !im.ok) {
            return CL_NONE(Cl_Opt_C128);
        }
        return CL_SOME(Cl_Opt_C128, cl_c128_make(re.value, im.value));
    }

    /* Strip internal whitespace into a small compact buffer for "3 - 4i" style */
    char compact[160];
    cl_isize clen = 0;
    for (cl_isize i = 0; i < s.len; i++) {
        if (!cl_is_ascii_space(s.data[i])) {
            if (clen >= (cl_isize)sizeof(compact) - 1) {
                return CL_NONE(Cl_Opt_C128);
            }
            compact[clen++] = (char)s.data[i];
        }
    }
    compact[clen] = '\0';
    if (clen == 0) {
        return CL_NONE(Cl_Opt_C128);
    }

    Cl_Str cs = { (const cl_u8 *)compact, clen };

    /* Pure real number (no trailing 'i'/'I'/'j'/'J') */
    cl_u8 last = cl_ascii_lower(cs.data[cs.len - 1]);
    if (last != 'i' && last != 'j') {
        Cl_Opt_F64 re = cl_str_parse_f64(cs);
        if (!re.ok) {
            return CL_NONE(Cl_Opt_C128);
        }
        return CL_SOME(Cl_Opt_C128, cl_c128_make(re.value, 0.0));
    }

    /* Remove trailing 'i'/'j' */
    Cl_Str body = cl_str_slice(cs, 0, cs.len - 1);
    if (body.len == 0 || cl_str_eq(body, CL_STR("+"))) {
        return CL_SOME(Cl_Opt_C128, cl_c128_make(0.0, 1.0));
    }
    if (cl_str_eq(body, CL_STR("-"))) {
        return CL_SOME(Cl_Opt_C128, cl_c128_make(0.0, -1.0));
    }

    /* Find the split '+' or '-' separating real and imaginary parts (skipping leading sign and 'e'/'E' exponent signs!) */
    cl_isize split_idx = -1;
    for (cl_isize i = body.len - 1; i >= 1; i--) {
        cl_u8 ch = body.data[i];
        if (ch == '+' || ch == '-') {
            cl_u8 prev = cl_ascii_lower(body.data[i - 1]);
            if (prev != 'e') {
                split_idx = i;
                break;
            }
        }
    }

    if (split_idx < 0) {
        /* Pure imaginary number like "4.5i" or "-2e-3i" */
        Cl_Opt_F64 im = cl_str_parse_f64(body);
        if (!im.ok) {
            return CL_NONE(Cl_Opt_C128);
        }
        return CL_SOME(Cl_Opt_C128, cl_c128_make(0.0, im.value));
    }

    Cl_Str re_part = cl_str_slice(body, 0, split_idx);
    Cl_Str im_part = cl_str_slice(body, split_idx, body.len);

    Cl_Opt_F64 re = cl_str_parse_f64(re_part);
    if (!re.ok) {
        return CL_NONE(Cl_Opt_C128);
    }

    cl_f64 im_val = 0.0;
    if (cl_str_eq(im_part, CL_STR("+"))) {
        im_val = 1.0;
    } else if (cl_str_eq(im_part, CL_STR("-"))) {
        im_val = -1.0;
    } else {
        Cl_Opt_F64 im = cl_str_parse_f64(im_part);
        if (!im.ok) {
            return CL_NONE(Cl_Opt_C128);
        }
        im_val = im.value;
    }

    return CL_SOME(Cl_Opt_C128, cl_c128_make(re.value, im_val));
}

/*
 * Function: cl_str_parse_c64
 * Purpose:
 *   Strictly parses a single-precision complex number by parsing as cl_c128
 *   and narrowing the result to cl_c64.
 * Parameters:
 *   s (Cl_Str): Input text slice.
 * Returns:
 *   Cl_Opt_C64: CL_SOME(value) on valid parse, or CL_NONE on failure.
 */
Cl_Opt_C64 cl_str_parse_c64(Cl_Str s) {
    Cl_Opt_C128 r = cl_str_parse_c128(s);
    if (!r.ok) {
        return CL_NONE(Cl_Opt_C64);
    }
    return CL_SOME(Cl_Opt_C64, cl_c128_to_c64(r.value));
}
