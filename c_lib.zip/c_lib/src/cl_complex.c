/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_complex.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Implementation of complex64 (cl_c64), complex128 (cl_c128), and
 *   quaternion128 / quaternion256 mathematical operations.
 * ============================================================================
 */

#include "cl/cl_complex.h"
#include <complex.h>
#include <math.h>

/* ----------------------------------------------------------------------------
 * complex64 (cl_c64) Implementation
 * ---------------------------------------------------------------------------- */

/*
 * Computes the Euclidean magnitude |z| = sqrt(Re(z)^2 + Im(z)^2) via cabsf().
 *
 * Parameters:
 *   z (cl_c64, dimensionless) - Input complex number.
 *
 * Returns:
 *   cl_f32 - Non-negative modulus |z| (dimensionless).
 */
cl_f32 cl_c64_abs(cl_c64 z) {
    return cabsf(z);
}

/*
 * Computes the principal phase angle arg(z) = atan2(Im(z), Re(z)) via cargf().
 *
 * Parameters:
 *   z (cl_c64, dimensionless) - Input complex number.
 *
 * Returns:
 *   cl_f32 - Phase angle in radians, in the closed interval [-pi, pi].
 */
cl_f32 cl_c64_arg(cl_c64 z) {
    return cargf(z);
}

/*
 * Constructs a cl_c64 from polar coordinates:
 *   z = radius * (cos(angle_rad) + i * sin(angle_rad)) = radius * e^(i*angle_rad).
 *
 * Parameters:
 *   radius    (cl_f32, dimensionless) - Radial magnitude (typically >= 0).
 *   angle_rad (cl_f32, radians)       - Phase angle in radians.
 *
 * Returns:
 *   cl_c64 - Complex number in Cartesian form.
 */
cl_c64 cl_c64_from_polar(cl_f32 radius, cl_f32 angle_rad) {
    return cl_c64_make(radius * cosf(angle_rad), radius * sinf(angle_rad));
}

/*
 * Computes the complex exponential e^z via cexpf().
 *
 * Parameters:
 *   z (cl_c64, dimensionless; Im(z) in radians) - Complex exponent.
 *
 * Returns:
 *   cl_c64 - Complex exponential e^z = e^Re(z) * (cos(Im(z)) + i * sin(Im(z))).
 */
cl_c64 cl_c64_exp(cl_c64 z) {
    return cexpf(z);
}

/*
 * Computes the principal complex natural logarithm ln(z) = ln(|z|) + i * arg(z) via clogf().
 *
 * Parameters:
 *   z (cl_c64, dimensionless) - Input complex number (non-zero for finite output).
 *
 * Returns:
 *   cl_c64 - Principal natural logarithm with Im(ln(z)) in [-pi, pi] radians.
 */
cl_c64 cl_c64_log(cl_c64 z) {
    return clogf(z);
}

/*
 * Computes the principal complex square root sqrt(z) with Re(sqrt(z)) >= 0 via csqrtf().
 *
 * Parameters:
 *   z (cl_c64, dimensionless) - Input complex number.
 *
 * Returns:
 *   cl_c64 - Principal square root of z.
 */
cl_c64 cl_c64_sqrt(cl_c64 z) {
    return csqrtf(z);
}

/*
 * Computes the principal complex power base^exponent via cpowf().
 *
 * Parameters:
 *   base     (cl_c64, dimensionless) - Complex base value.
 *   exponent (cl_c64, dimensionless) - Complex exponent value.
 *
 * Returns:
 *   cl_c64 - Principal value of base raised to exponent.
 */
cl_c64 cl_c64_pow(cl_c64 base, cl_c64 exponent) {
    return cpowf(base, exponent);
}

/*
 * Computes the complex sine sin(z) = (e^(i*z) - e^(-i*z)) / (2*i) via csinf().
 *
 * Parameters:
 *   z (cl_c64, complex radians) - Input complex angle.
 *
 * Returns:
 *   cl_c64 - Complex sine of z (dimensionless).
 */
cl_c64 cl_c64_sin(cl_c64 z) {
    return csinf(z);
}

/*
 * Computes the complex cosine cos(z) = (e^(i*z) + e^(-i*z)) / 2 via ccosf().
 *
 * Parameters:
 *   z (cl_c64, complex radians) - Input complex angle.
 *
 * Returns:
 *   cl_c64 - Complex cosine of z (dimensionless).
 */
cl_c64 cl_c64_cos(cl_c64 z) {
    return ccosf(z);
}

/*
 * Checks component-wise approximate equality between two cl_c64 values:
 *   |Re(a) - Re(b)| <= eps and |Im(a) - Im(b)| <= eps.
 *
 * Parameters:
 *   a   (cl_c64, dimensionless)     - First complex number.
 *   b   (cl_c64, dimensionless)     - Second complex number.
 *   eps (cl_f32, tolerance epsilon) - Non-negative absolute tolerance (>= 0).
 *
 * Returns:
 *   bool - true if both real and imaginary absolute differences are <= eps, false otherwise.
 */
bool cl_c64_approx_eq(cl_c64 a, cl_c64 b, cl_f32 eps) {
    cl_f32 dre = fabsf(cl_c64_real(a) - cl_c64_real(b));
    cl_f32 dim = fabsf(cl_c64_imag(a) - cl_c64_imag(b));
    return (dre <= eps) && (dim <= eps);
}

/*
 * Tests whether both Re(z) and Im(z) of a cl_c64 are finite (neither NaN nor +/-Inf).
 *
 * Parameters:
 *   z (cl_c64, dimensionless) - Complex number to inspect.
 *
 * Returns:
 *   bool - true if both components are finite, false otherwise.
 */
bool cl_c64_is_finite(cl_c64 z) {
    return isfinite(cl_c64_real(z)) && isfinite(cl_c64_imag(z));
}

/* ----------------------------------------------------------------------------
 * complex128 (cl_c128) Implementation
 * ---------------------------------------------------------------------------- */

/*
 * Computes the Euclidean magnitude |z| = sqrt(Re(z)^2 + Im(z)^2) via cabs().
 *
 * Parameters:
 *   z (cl_c128, dimensionless) - Input complex number.
 *
 * Returns:
 *   cl_f64 - Non-negative modulus |z| (dimensionless).
 */
cl_f64 cl_c128_abs(cl_c128 z) {
    return cabs(z);
}

/*
 * Computes the principal phase angle arg(z) = atan2(Im(z), Re(z)) via carg().
 *
 * Parameters:
 *   z (cl_c128, dimensionless) - Input complex number.
 *
 * Returns:
 *   cl_f64 - Phase angle in radians, in the closed interval [-pi, pi].
 */
cl_f64 cl_c128_arg(cl_c128 z) {
    return carg(z);
}

/*
 * Constructs a cl_c128 from polar coordinates:
 *   z = radius * (cos(angle_rad) + i * sin(angle_rad)) = radius * e^(i*angle_rad).
 *
 * Parameters:
 *   radius    (cl_f64, dimensionless) - Radial magnitude (typically >= 0).
 *   angle_rad (cl_f64, radians)       - Phase angle in radians.
 *
 * Returns:
 *   cl_c128 - Complex number in Cartesian form.
 */
cl_c128 cl_c128_from_polar(cl_f64 radius, cl_f64 angle_rad) {
    return cl_c128_make(radius * cos(angle_rad), radius * sin(angle_rad));
}

/*
 * Computes the complex exponential e^z via cexp().
 *
 * Parameters:
 *   z (cl_c128, dimensionless; Im(z) in radians) - Complex exponent.
 *
 * Returns:
 *   cl_c128 - Complex exponential e^z = e^Re(z) * (cos(Im(z)) + i * sin(Im(z))).
 */
cl_c128 cl_c128_exp(cl_c128 z) {
    return cexp(z);
}

/*
 * Computes the principal complex natural logarithm ln(z) = ln(|z|) + i * arg(z) via clog().
 *
 * Parameters:
 *   z (cl_c128, dimensionless) - Input complex number (non-zero for finite output).
 *
 * Returns:
 *   cl_c128 - Principal natural logarithm with Im(ln(z)) in [-pi, pi] radians.
 */
cl_c128 cl_c128_log(cl_c128 z) {
    return clog(z);
}

/*
 * Computes the principal complex square root sqrt(z) with Re(sqrt(z)) >= 0 via csqrt().
 *
 * Parameters:
 *   z (cl_c128, dimensionless) - Input complex number.
 *
 * Returns:
 *   cl_c128 - Principal square root of z.
 */
cl_c128 cl_c128_sqrt(cl_c128 z) {
    return csqrt(z);
}

/*
 * Computes the principal complex power base^exponent via cpow().
 *
 * Parameters:
 *   base     (cl_c128, dimensionless) - Complex base value.
 *   exponent (cl_c128, dimensionless) - Complex exponent value.
 *
 * Returns:
 *   cl_c128 - Principal value of base raised to exponent.
 */
cl_c128 cl_c128_pow(cl_c128 base, cl_c128 exponent) {
    return cpow(base, exponent);
}

/*
 * Computes the complex sine sin(z) = (e^(i*z) - e^(-i*z)) / (2*i) via csin().
 *
 * Parameters:
 *   z (cl_c128, complex radians) - Input complex angle.
 *
 * Returns:
 *   cl_c128 - Complex sine of z (dimensionless).
 */
cl_c128 cl_c128_sin(cl_c128 z) {
    return csin(z);
}

/*
 * Computes the complex cosine cos(z) = (e^(i*z) + e^(-i*z)) / 2 via ccos().
 *
 * Parameters:
 *   z (cl_c128, complex radians) - Input complex angle.
 *
 * Returns:
 *   cl_c128 - Complex cosine of z (dimensionless).
 */
cl_c128 cl_c128_cos(cl_c128 z) {
    return ccos(z);
}

/*
 * Checks component-wise approximate equality between two cl_c128 values:
 *   |Re(a) - Re(b)| <= eps and |Im(a) - Im(b)| <= eps.
 *
 * Parameters:
 *   a   (cl_c128, dimensionless)    - First complex number.
 *   b   (cl_c128, dimensionless)    - Second complex number.
 *   eps (cl_f64, tolerance epsilon) - Non-negative absolute tolerance (>= 0).
 *
 * Returns:
 *   bool - true if both real and imaginary absolute differences are <= eps, false otherwise.
 */
bool cl_c128_approx_eq(cl_c128 a, cl_c128 b, cl_f64 eps) {
    cl_f64 dre = fabs(cl_c128_real(a) - cl_c128_real(b));
    cl_f64 dim = fabs(cl_c128_imag(a) - cl_c128_imag(b));
    return (dre <= eps) && (dim <= eps);
}

/*
 * Tests whether both Re(z) and Im(z) of a cl_c128 are finite (neither NaN nor +/-Inf).
 *
 * Parameters:
 *   z (cl_c128, dimensionless) - Complex number to inspect.
 *
 * Returns:
 *   bool - true if both components are finite, false otherwise.
 */
bool cl_c128_is_finite(cl_c128 z) {
    return isfinite(cl_c128_real(z)) && isfinite(cl_c128_imag(z));
}

/* ----------------------------------------------------------------------------
 * Quaternion128 Implementation
 * ---------------------------------------------------------------------------- */

/*
 * Constructs a single-precision quaternion q = w + x*i + y*j + z*k.
 *
 * Parameters:
 *   x (cl_f32, dimensionless) - Imaginary i-component.
 *   y (cl_f32, dimensionless) - Imaginary j-component.
 *   z (cl_f32, dimensionless) - Imaginary k-component.
 *   w (cl_f32, dimensionless) - Real (scalar) component.
 *
 * Returns:
 *   Cl_Quat128 - Constructed quaternion (x, y, z, w).
 */
Cl_Quat128 cl_quat128_make(cl_f32 x, cl_f32 y, cl_f32 z, cl_f32 w) {
    return (Cl_Quat128){ x, y, z, w };
}

/*
 * Constructs a unit single-precision rotation quaternion from an axis (ax, ay, az)
 * and rotation angle:
 *   q = cos(angle_rad / 2) + sin(angle_rad / 2) * (ax*i + ay*j + az*k) / |(ax, ay, az)|.
 * Returns cl_quat128_identity() if the axis norm is <= 0.
 *
 * Parameters:
 *   ax        (cl_f32, dimensionless) - Rotation axis X component.
 *   ay        (cl_f32, dimensionless) - Rotation axis Y component.
 *   az        (cl_f32, dimensionless) - Rotation axis Z component.
 *   angle_rad (cl_f32, radians)       - Right-handed rotation angle in radians.
 *
 * Returns:
 *   Cl_Quat128 - Unit rotation quaternion, or identity if axis length <= 0.
 */
Cl_Quat128 cl_quat128_from_axis_angle(cl_f32 ax, cl_f32 ay, cl_f32 az, cl_f32 angle_rad) {
    cl_f32 len = sqrtf(ax * ax + ay * ay + az * az);
    if (len <= 0.0f) {
        return cl_quat128_identity();
    }
    cl_f32 inv = 1.0f / len;
    cl_f32 half = 0.5f * angle_rad;
    cl_f32 s = sinf(half) * inv;
    return (Cl_Quat128){ ax * s, ay * s, az * s, cosf(half) };
}

/*
 * Computes the Hamilton product a * b of two single-precision quaternions.
 *
 * Parameters:
 *   a (Cl_Quat128, dimensionless) - Left quaternion operand.
 *   b (Cl_Quat128, dimensionless) - Right quaternion operand.
 *
 * Returns:
 *   Cl_Quat128 - Hamilton product a * b.
 */
Cl_Quat128 cl_quat128_mul(Cl_Quat128 a, Cl_Quat128 b) {
    return (Cl_Quat128){
        a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
        a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
        a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w,
        a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z
    };
}

/*
 * Computes the conjugate conj(q) = (-q.x, -q.y, -q.z, q.w) of a single-precision quaternion.
 *
 * Parameters:
 *   q (Cl_Quat128, dimensionless) - Input quaternion.
 *
 * Returns:
 *   Cl_Quat128 - Conjugated quaternion.
 */
Cl_Quat128 cl_quat128_conj(Cl_Quat128 q) {
    return (Cl_Quat128){ -q.x, -q.y, -q.z, q.w };
}

/*
 * Computes the 4D Euclidean dot product a.x*b.x + a.y*b.y + a.z*b.z + a.w*b.w.
 *
 * Parameters:
 *   a (Cl_Quat128, dimensionless) - First quaternion.
 *   b (Cl_Quat128, dimensionless) - Second quaternion.
 *
 * Returns:
 *   cl_f32 - Scalar dot product (dimensionless).
 */
cl_f32 cl_quat128_dot(Cl_Quat128 a, Cl_Quat128 b) {
    return a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w;
}

/*
 * Computes the Euclidean norm |q| = sqrt(dot(q, q)) of a single-precision quaternion.
 *
 * Parameters:
 *   q (Cl_Quat128, dimensionless) - Input quaternion.
 *
 * Returns:
 *   cl_f32 - Non-negative quaternion magnitude (dimensionless).
 */
cl_f32 cl_quat128_len(Cl_Quat128 q) {
    return sqrtf(cl_quat128_dot(q, q));
}

/*
 * Normalizes a single-precision quaternion to unit length q / |q|.
 * Returns cl_quat128_identity() if |q| <= 0.
 *
 * Parameters:
 *   q (Cl_Quat128, dimensionless) - Input quaternion.
 *
 * Returns:
 *   Cl_Quat128 - Unit quaternion, or identity for degenerate zero-length input.
 */
Cl_Quat128 cl_quat128_normalize(Cl_Quat128 q) {
    cl_f32 len = cl_quat128_len(q);
    if (len <= 0.0f) {
        return cl_quat128_identity();
    }
    cl_f32 inv = 1.0f / len;
    return (Cl_Quat128){ q.x * inv, q.y * inv, q.z * inv, q.w * inv };
}

/*
 * Performs shortest-path spherical linear interpolation (SLERP) between unit
 * single-precision quaternions a and b. Negates b when dot(a, b) < 0 to ensure
 * the shortest arc, and falls back to normalized LERP when |dot(a, b)| > 0.9995.
 *
 * Parameters:
 *   a (Cl_Quat128, unit quaternion) - Starting orientation (unit length expected).
 *   b (Cl_Quat128, unit quaternion) - Ending orientation (unit length expected).
 *   t (cl_f32, dimensionless)       - Interpolation factor, typically in [0.0, 1.0].
 *
 * Returns:
 *   Cl_Quat128 - Interpolated unit orientation quaternion.
 */
Cl_Quat128 cl_quat128_slerp(Cl_Quat128 a, Cl_Quat128 b, cl_f32 t) {
    cl_f32 dot = cl_quat128_dot(a, b);
    if (dot < 0.0f) {
        dot = -dot;
        b.x = -b.x; b.y = -b.y; b.z = -b.z; b.w = -b.w;
    }
    if (dot > 0.9995f) {
        Cl_Quat128 r = {
            a.x + t * (b.x - a.x),
            a.y + t * (b.y - a.y),
            a.z + t * (b.z - a.z),
            a.w + t * (b.w - a.w)
        };
        return cl_quat128_normalize(r);
    }
    cl_f32 theta0 = acosf(dot);
    cl_f32 theta  = theta0 * t;
    cl_f32 sin_t0 = sinf(theta0);
    cl_f32 s0 = cosf(theta) - dot * sinf(theta) / sin_t0;
    cl_f32 s1 = sinf(theta) / sin_t0;
    return (Cl_Quat128){
        s0 * a.x + s1 * b.x,
        s0 * a.y + s1 * b.y,
        s0 * a.z + s1 * b.z,
        s0 * a.w + s1 * b.w
    };
}

/* ----------------------------------------------------------------------------
 * Quaternion256 Implementation
 * ---------------------------------------------------------------------------- */

/*
 * Constructs a double-precision quaternion q = w + x*i + y*j + z*k.
 *
 * Parameters:
 *   x (cl_f64, dimensionless) - Imaginary i-component.
 *   y (cl_f64, dimensionless) - Imaginary j-component.
 *   z (cl_f64, dimensionless) - Imaginary k-component.
 *   w (cl_f64, dimensionless) - Real (scalar) component.
 *
 * Returns:
 *   Cl_Quat256 - Constructed quaternion (x, y, z, w).
 */
Cl_Quat256 cl_quat256_make(cl_f64 x, cl_f64 y, cl_f64 z, cl_f64 w) {
    return (Cl_Quat256){ x, y, z, w };
}

/*
 * Constructs a unit double-precision rotation quaternion from an axis (ax, ay, az)
 * and rotation angle:
 *   q = cos(angle_rad / 2) + sin(angle_rad / 2) * (ax*i + ay*j + az*k) / |(ax, ay, az)|.
 * Returns cl_quat256_identity() if the axis norm is <= 0.
 *
 * Parameters:
 *   ax        (cl_f64, dimensionless) - Rotation axis X component.
 *   ay        (cl_f64, dimensionless) - Rotation axis Y component.
 *   az        (cl_f64, dimensionless) - Rotation axis Z component.
 *   angle_rad (cl_f64, radians)       - Right-handed rotation angle in radians.
 *
 * Returns:
 *   Cl_Quat256 - Unit rotation quaternion, or identity if axis length <= 0.
 */
Cl_Quat256 cl_quat256_from_axis_angle(cl_f64 ax, cl_f64 ay, cl_f64 az, cl_f64 angle_rad) {
    cl_f64 len = sqrt(ax * ax + ay * ay + az * az);
    if (len <= 0.0) {
        return cl_quat256_identity();
    }
    cl_f64 inv = 1.0 / len;
    cl_f64 half = 0.5 * angle_rad;
    cl_f64 s = sin(half) * inv;
    return (Cl_Quat256){ ax * s, ay * s, az * s, cos(half) };
}

/*
 * Computes the Hamilton product a * b of two double-precision quaternions.
 *
 * Parameters:
 *   a (Cl_Quat256, dimensionless) - Left quaternion operand.
 *   b (Cl_Quat256, dimensionless) - Right quaternion operand.
 *
 * Returns:
 *   Cl_Quat256 - Hamilton product a * b.
 */
Cl_Quat256 cl_quat256_mul(Cl_Quat256 a, Cl_Quat256 b) {
    return (Cl_Quat256){
        a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
        a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
        a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w,
        a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z
    };
}

/*
 * Computes the conjugate conj(q) = (-q.x, -q.y, -q.z, q.w) of a double-precision quaternion.
 *
 * Parameters:
 *   q (Cl_Quat256, dimensionless) - Input quaternion.
 *
 * Returns:
 *   Cl_Quat256 - Conjugated quaternion.
 */
Cl_Quat256 cl_quat256_conj(Cl_Quat256 q) {
    return (Cl_Quat256){ -q.x, -q.y, -q.z, q.w };
}

/*
 * Computes the 4D Euclidean dot product a.x*b.x + a.y*b.y + a.z*b.z + a.w*b.w.
 *
 * Parameters:
 *   a (Cl_Quat256, dimensionless) - First quaternion.
 *   b (Cl_Quat256, dimensionless) - Second quaternion.
 *
 * Returns:
 *   cl_f64 - Scalar dot product (dimensionless).
 */
cl_f64 cl_quat256_dot(Cl_Quat256 a, Cl_Quat256 b) {
    return a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w;
}

/*
 * Computes the Euclidean norm |q| = sqrt(dot(q, q)) of a double-precision quaternion.
 *
 * Parameters:
 *   q (Cl_Quat256, dimensionless) - Input quaternion.
 *
 * Returns:
 *   cl_f64 - Non-negative quaternion magnitude (dimensionless).
 */
cl_f64 cl_quat256_len(Cl_Quat256 q) {
    return sqrt(cl_quat256_dot(q, q));
}

/*
 * Normalizes a double-precision quaternion to unit length q / |q|.
 * Returns cl_quat256_identity() if |q| <= 0.
 *
 * Parameters:
 *   q (Cl_Quat256, dimensionless) - Input quaternion.
 *
 * Returns:
 *   Cl_Quat256 - Unit quaternion, or identity for degenerate zero-length input.
 */
Cl_Quat256 cl_quat256_normalize(Cl_Quat256 q) {
    cl_f64 len = cl_quat256_len(q);
    if (len <= 0.0) {
        return cl_quat256_identity();
    }
    cl_f64 inv = 1.0 / len;
    return (Cl_Quat256){ q.x * inv, q.y * inv, q.z * inv, q.w * inv };
}

/*
 * Performs shortest-path spherical linear interpolation (SLERP) between unit
 * double-precision quaternions a and b. Negates b when dot(a, b) < 0 to ensure
 * the shortest arc, and falls back to normalized LERP when |dot(a, b)| > 0.999999.
 *
 * Parameters:
 *   a (Cl_Quat256, unit quaternion) - Starting orientation (unit length expected).
 *   b (Cl_Quat256, unit quaternion) - Ending orientation (unit length expected).
 *   t (cl_f64, dimensionless)       - Interpolation factor, typically in [0.0, 1.0].
 *
 * Returns:
 *   Cl_Quat256 - Interpolated unit orientation quaternion.
 */
Cl_Quat256 cl_quat256_slerp(Cl_Quat256 a, Cl_Quat256 b, cl_f64 t) {
    cl_f64 dot = cl_quat256_dot(a, b);
    if (dot < 0.0) {
        dot = -dot;
        b.x = -b.x; b.y = -b.y; b.z = -b.z; b.w = -b.w;
    }
    if (dot > 0.999999) {
        Cl_Quat256 r = {
            a.x + t * (b.x - a.x),
            a.y + t * (b.y - a.y),
            a.z + t * (b.z - a.z),
            a.w + t * (b.w - a.w)
        };
        return cl_quat256_normalize(r);
    }
    cl_f64 theta0 = acos(dot);
    cl_f64 theta  = theta0 * t;
    cl_f64 sin_t0 = sin(theta0);
    cl_f64 s0 = cos(theta) - dot * sin(theta) / sin_t0;
    cl_f64 s1 = sin(theta) / sin_t0;
    return (Cl_Quat256){
        s0 * a.x + s1 * b.x,
        s0 * a.y + s1 * b.y,
        s0 * a.z + s1 * b.z,
        s0 * a.w + s1 * b.w
    };
}
