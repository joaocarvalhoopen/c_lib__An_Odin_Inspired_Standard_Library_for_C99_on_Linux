/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_strbuf.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Implementation of Cl_Str_Buf fixed-capacity, always-NUL-terminated,
 *   zero-heap in-place string buffer manipulation functions.
 * ============================================================================
 */

#include "cl/cl_strbuf.h"
#include <stdio.h>
#include <string.h>

/*
 * Function: cl_sb_is_space
 * Purpose:
 *   Checks whether a char is an ASCII whitespace character (' ', '\t', '\n',
 *   '\r', '\v', or '\f').
 * Parameters:
 *   c (char): Character to test.
 * Returns:
 *   bool: true if c is ASCII whitespace; false otherwise.
 */
static inline bool cl_sb_is_space(char c) {
    return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\v' || c == '\f';
}

/*
 * Function: cl_strbuf_init
 * Purpose:
 *   Initializes an empty Cl_Str_Buf over backing[cap], setting backing[0] = '\0'
 *   when backing is non-NULL and cap > 0.
 * Parameters:
 *   backing (char *): Caller-owned storage array, or NULL.
 *   cap (cl_isize): Total storage capacity in bytes, including NUL.
 * Returns:
 *   Cl_Str_Buf: Initialized empty string buffer.
 */
Cl_Str_Buf cl_strbuf_init(char *backing, cl_isize cap) {
    Cl_Str_Buf b;
    b.data      = backing;
    b.len       = 0;
    b.cap       = (backing != NULL && cap > 0) ? cap : 0;
    b.truncated = false;
    if (b.cap > 0) {
        b.data[0] = '\0';
    }
    return b;
}

/*
 * Function: cl_strbuf_from_existing
 * Purpose:
 *   Wraps an existing C string inside backing[cap], bounding its length to
 *   cap - 1 bytes and ensuring NUL termination.
 * Parameters:
 *   backing (char *): Caller-owned storage containing an existing C string.
 *   cap (cl_isize): Total storage capacity in bytes, including NUL.
 * Returns:
 *   Cl_Str_Buf: Initialized buffer referencing the existing contents.
 */
Cl_Str_Buf cl_strbuf_from_existing(char *backing, cl_isize cap) {
    Cl_Str_Buf b = cl_strbuf_init(backing, cap);
    if (b.cap > 0) {
        cl_isize n = 0;
        while (n < b.cap - 1 && backing[n] != '\0') {
            n += 1;
        }
        b.len = n;
        b.data[b.len] = '\0';
    }
    return b;
}

/*
 * Function: cl_strbuf_clear
 * Purpose:
 *   Resets length to 0 bytes, clears truncated, and writes data[0] = '\0'.
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer, or NULL (no-op).
 * Returns:
 *   void.
 */
void cl_strbuf_clear(Cl_Str_Buf *b) {
    if (b == NULL) {
        return;
    }
    b->len = 0;
    b->truncated = false;
    if (b->data != NULL && b->cap > 0) {
        b->data[0] = '\0';
    }
}

/*
 * Function: cl_strbuf_set
 * Purpose:
 *   Replaces the contents of b with s (truncating at cap - 1 bytes if needed).
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer; must be non-NULL.
 *   s (Cl_Str): Source byte slice.
 * Returns:
 *   bool: true if s fit completely; false if truncated.
 */
bool cl_strbuf_set(Cl_Str_Buf *b, Cl_Str s) {
    CL_ENSURE(b != NULL);
    cl_strbuf_clear(b);
    return cl_strbuf_append_str(b, s);
}

/*
 * Function: cl_strbuf_set_cstr
 * Purpose:
 *   Replaces the contents of b with a NUL-terminated C string.
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer; must be non-NULL.
 *   cs (const char *): Source C string, or NULL.
 * Returns:
 *   bool: true if cs fit completely; false if truncated.
 */
bool cl_strbuf_set_cstr(Cl_Str_Buf *b, const char *cs) {
    return cl_strbuf_set(b, cl_str_from_cstr(cs));
}

/*
 * Function: cl_strbuf_append_char
 * Purpose:
 *   Appends one character to b if space remains before cap - 1 bytes.
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer; must be non-NULL.
 *   c (char): Character to append.
 * Returns:
 *   bool: true if appended; false if full (sets b->truncated = true).
 */
bool cl_strbuf_append_char(Cl_Str_Buf *b, char c) {
    CL_ENSURE(b != NULL);
    if (b->cap <= 0 || b->len >= b->cap - 1) {
        b->truncated = true;
        return false;
    }
    b->data[b->len++] = c;
    b->data[b->len]   = '\0';
    return true;
}

/*
 * Function: cl_strbuf_append_str
 * Purpose:
 *   Appends bytes from s into b up to cap - 1 total bytes using cl_mem_move
 *   and re-terminates with NUL.
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer; must be non-NULL.
 *   s (Cl_Str): Source byte slice.
 * Returns:
 *   bool: true if all bytes fit; false if truncated (sets b->truncated).
 */
bool cl_strbuf_append_str(Cl_Str_Buf *b, Cl_Str s) {
    CL_ENSURE(b != NULL);
    if (s.len <= 0 || s.data == NULL) {
        return true;
    }
    if (b->cap <= 0) {
        b->truncated = true;
        return false;
    }
    cl_isize avail = (b->cap - 1) - b->len;
    bool fit = (s.len <= avail);
    cl_isize n = fit ? s.len : avail;
    if (n > 0) {
        cl_mem_move(b->data + b->len, s.data, n);
        b->len += n;
    }
    b->data[b->len] = '\0';
    if (!fit) {
        b->truncated = true;
    }
    return fit;
}

/*
 * Function: cl_strbuf_append_cstr
 * Purpose:
 *   Appends a NUL-terminated C string to b.
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer; must be non-NULL.
 *   cs (const char *): Source C string, or NULL.
 * Returns:
 *   bool: true if all bytes fit; false if truncated.
 */
bool cl_strbuf_append_cstr(Cl_Str_Buf *b, const char *cs) {
    return cl_strbuf_append_str(b, cl_str_from_cstr(cs));
}

/*
 * Function: cl_strbuf_append_fmt
 * Purpose:
 *   Formats printf-style text directly into the remaining bytes of b with
 *   vsnprintf and guaranteed NUL termination.
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer; must be non-NULL.
 *   fmt (const char *): NUL-terminated printf format string.
 *   ... (variadic): Arguments matching fmt.
 * Returns:
 *   bool: true if formatted output fit completely; false on error or overflow.
 */
bool cl_strbuf_append_fmt(Cl_Str_Buf *b, const char *fmt, ...) {
    CL_ENSURE(b != NULL);
    if (fmt == NULL || b->cap <= 0) {
        return false;
    }
    cl_isize avail = b->cap - b->len;
    if (avail <= 1) {
        b->truncated = true;
        return false;
    }

    va_list args;
    va_start(args, fmt);
    int n = vsnprintf(b->data + b->len, (cl_usize)avail, fmt, args);
    va_end(args);

    if (n < 0) {
        return false;
    }
    if ((cl_isize)n >= avail) {
        b->len = b->cap - 1;
        b->data[b->len] = '\0';
        b->truncated = true;
        return false;
    }
    b->len += (cl_isize)n;
    return true;
}

/*
 * Function: cl_strbuf_insert
 * Purpose:
 *   Inserts s at 0-based byte offset idx in place, shifting existing tail
 *   bytes right and truncating cleanly at cap - 1 bytes.
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer; must be non-NULL.
 *   idx (cl_isize): 0-based byte offset; must satisfy 0 <= idx <= b->len.
 *   s (Cl_Str): Byte slice to insert.
 * Returns:
 *   bool: true if no bytes were truncated; false otherwise (sets truncated).
 */
bool cl_strbuf_insert(Cl_Str_Buf *b, cl_isize idx, Cl_Str s) {
    CL_ENSURE(b != NULL);
    CL_BOUNDS_CHECK_RANGE(idx, idx, b->len);
    if (s.len <= 0 || s.data == NULL) {
        return true;
    }
    if (b->cap <= 0) {
        b->truncated = true;
        return false;
    }

    cl_isize max_len = b->cap - 1;
    cl_isize avail   = max_len - b->len;
    bool fit = (s.len <= avail);
    if (!fit) {
        b->truncated = true;
    }

    /* Bytes of `s` that fit starting at `idx` */
    cl_isize insert_len = (idx + s.len <= max_len) ? s.len : (max_len - idx);
    cl_isize tail_len   = b->len - idx;
    cl_isize new_tail_pos = idx + insert_len;
    cl_isize kept_tail  = (new_tail_pos + tail_len <= max_len)
                              ? tail_len
                              : (max_len - new_tail_pos);
    if (kept_tail < 0) {
        kept_tail = 0;
    }

    if (kept_tail > 0) {
        cl_mem_move(b->data + new_tail_pos, b->data + idx, kept_tail);
    }
    if (insert_len > 0) {
        cl_mem_copy(b->data + idx, s.data, insert_len);
    }
    b->len = new_tail_pos + kept_tail;
    b->data[b->len] = '\0';
    return fit;
}

/*
 * Function: cl_strbuf_erase
 * Purpose:
 *   Deletes up to count bytes starting at 0-based byte offset idx in place,
 *   compacting the tail left and keeping NUL termination.
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer; must be non-NULL.
 *   idx (cl_isize): 0-based start offset in [0, b->len].
 *   count (cl_isize): Number of bytes to delete (<= 0 is a no-op).
 * Returns:
 *   void.
 */
void cl_strbuf_erase(Cl_Str_Buf *b, cl_isize idx, cl_isize count) {
    CL_ENSURE(b != NULL);
    if (count <= 0) {
        return;
    }
    CL_BOUNDS_CHECK_RANGE(idx, idx, b->len);
    if (idx + count > b->len) {
        count = b->len - idx;
    }
    cl_isize tail = b->len - (idx + count);
    if (tail > 0) {
        cl_mem_move(b->data + idx, b->data + idx + count, tail);
    }
    b->len -= count;
    if (b->data != NULL && b->cap > 0) {
        b->data[b->len] = '\0';
    }
}

/*
 * Function: cl_strbuf_replace_in_place
 * Purpose:
 *   Replaces non-overlapping matches of old_s with new_s directly inside b,
 *   stopping and setting b->truncated = true if growth would exceed cap - 1.
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer; must be non-NULL.
 *   old_s (Cl_Str): Substring to find (empty returns 0).
 *   new_s (Cl_Str): Replacement bytes.
 * Returns:
 *   cl_isize: Count of completed replacements (>= 0).
 */
cl_isize cl_strbuf_replace_in_place(Cl_Str_Buf *b, Cl_Str old_s, Cl_Str new_s) {
    CL_ENSURE(b != NULL);
    if (b->cap <= 0 || b->len <= 0 || old_s.len <= 0) {
        return 0;
    }

    cl_isize replaced = 0;
    cl_isize pos = 0;
    cl_isize max_len = b->cap - 1;

    while (pos <= b->len - old_s.len) {
        Cl_Str tail = { (const cl_u8 *)(b->data + pos), b->len - pos };
        cl_isize rel = cl_str_index(tail, old_s);
        if (rel < 0) {
            break;
        }
        cl_isize match_pos = pos + rel;
        cl_isize diff = new_s.len - old_s.len;

        if (diff > 0 && b->len + diff > max_len) {
            /* Would overflow capacity: mark truncated and stop cleanly */
            b->truncated = true;
            break;
        }

        cl_isize after_old = match_pos + old_s.len;
        cl_isize rest_len  = b->len - after_old;
        if (diff != 0 && rest_len > 0) {
            cl_mem_move(b->data + match_pos + new_s.len, b->data + after_old, rest_len);
        }
        if (new_s.len > 0) {
            cl_mem_copy(b->data + match_pos, new_s.data, new_s.len);
        }
        b->len += diff;
        b->data[b->len] = '\0';
        pos = match_pos + new_s.len;
        replaced += 1;
    }

    return replaced;
}

/*
 * Function: cl_strbuf_trim_space_in_place
 * Purpose:
 *   Removes leading and trailing ASCII whitespace in place, shifting the
 *   trimmed bytes to index 0 and NUL-terminating.
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer; must be non-NULL.
 * Returns:
 *   void.
 */
void cl_strbuf_trim_space_in_place(Cl_Str_Buf *b) {
    CL_ENSURE(b != NULL);
    if (b->data == NULL || b->len <= 0) {
        return;
    }
    cl_isize start = 0;
    while (start < b->len && cl_sb_is_space(b->data[start])) {
        start += 1;
    }
    cl_isize end = b->len;
    while (end > start && cl_sb_is_space(b->data[end - 1])) {
        end -= 1;
    }
    cl_isize new_len = end - start;
    if (start > 0 && new_len > 0) {
        cl_mem_move(b->data, b->data + start, new_len);
    }
    b->len = new_len;
    b->data[b->len] = '\0';
}

/*
 * Function: cl_strbuf_to_upper_in_place
 * Purpose:
 *   Converts ASCII 'a'..'z' bytes in b to 'A'..'Z' in place.
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer; must be non-NULL.
 * Returns:
 *   void.
 */
void cl_strbuf_to_upper_in_place(Cl_Str_Buf *b) {
    CL_ENSURE(b != NULL);
    for (cl_isize i = 0; i < b->len; i++) {
        if (b->data[i] >= 'a' && b->data[i] <= 'z') {
            b->data[i] = (char)(b->data[i] - ('a' - 'A'));
        }
    }
}

/*
 * Function: cl_strbuf_to_lower_in_place
 * Purpose:
 *   Converts ASCII 'A'..'Z' bytes in b to 'a'..'z' in place.
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer; must be non-NULL.
 * Returns:
 *   void.
 */
void cl_strbuf_to_lower_in_place(Cl_Str_Buf *b) {
    CL_ENSURE(b != NULL);
    for (cl_isize i = 0; i < b->len; i++) {
        if (b->data[i] >= 'A' && b->data[i] <= 'Z') {
            b->data[i] = (char)(b->data[i] + ('a' - 'A'));
        }
    }
}

/*
 * Function: cl_strbuf_reverse_in_place
 * Purpose:
 *   Reverses b->data[0 .. b->len - 1] bytewise in place.
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer; must be non-NULL.
 * Returns:
 *   void.
 */
void cl_strbuf_reverse_in_place(Cl_Str_Buf *b) {
    CL_ENSURE(b != NULL);
    if (b->len <= 1) {
        return;
    }
    cl_isize lo = 0;
    cl_isize hi = b->len - 1;
    while (lo < hi) {
        char tmp = b->data[lo];
        b->data[lo] = b->data[hi];
        b->data[hi] = tmp;
        lo += 1;
        hi -= 1;
    }
}

/*
 * Function: cl_strbuf_pad_left_in_place
 * Purpose:
 *   Left-pads b with pad_char up to min(target_len, cap - 1) bytes in place.
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer; must be non-NULL.
 *   target_len (cl_isize): Desired total length in bytes.
 *   pad_char (char): Padding byte value.
 * Returns:
 *   bool: true if target_len fit without truncation; false if truncated.
 */
bool cl_strbuf_pad_left_in_place(Cl_Str_Buf *b, cl_isize target_len, char pad_char) {
    CL_ENSURE(b != NULL);
    if (target_len <= b->len) {
        return true;
    }
    cl_isize max_len = cl_strbuf_max_len(b);
    bool fit = (target_len <= max_len);
    cl_isize eff_target = fit ? target_len : max_len;
    cl_isize pad = eff_target - b->len;
    if (pad > 0) {
        cl_mem_move(b->data + pad, b->data, b->len);
        cl_mem_set(b->data, (cl_u8)pad_char, pad);
        b->len = eff_target;
        b->data[b->len] = '\0';
    }
    if (!fit) {
        b->truncated = true;
    }
    return fit;
}

/*
 * Function: cl_strbuf_pad_right_in_place
 * Purpose:
 *   Right-pads b with pad_char up to min(target_len, cap - 1) bytes in place.
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer; must be non-NULL.
 *   target_len (cl_isize): Desired total length in bytes.
 *   pad_char (char): Padding byte value.
 * Returns:
 *   bool: true if target_len fit without truncation; false if truncated.
 */
bool cl_strbuf_pad_right_in_place(Cl_Str_Buf *b, cl_isize target_len, char pad_char) {
    CL_ENSURE(b != NULL);
    if (target_len <= b->len) {
        return true;
    }
    cl_isize max_len = cl_strbuf_max_len(b);
    bool fit = (target_len <= max_len);
    cl_isize eff_target = fit ? target_len : max_len;
    cl_isize pad = eff_target - b->len;
    if (pad > 0) {
        cl_mem_set(b->data + b->len, (cl_u8)pad_char, pad);
        b->len = eff_target;
        b->data[b->len] = '\0';
    }
    if (!fit) {
        b->truncated = true;
    }
    return fit;
}

/*
 * Function: cl_strbuf_truncate
 * Purpose:
 *   Truncates b to new_len bytes with bounds checking and writes a NUL byte.
 * Parameters:
 *   b (Cl_Str_Buf *): Target buffer; must be non-NULL.
 *   new_len (cl_isize): New length in bytes; must satisfy 0 <= new_len <= b->len.
 * Returns:
 *   void.
 */
void cl_strbuf_truncate(Cl_Str_Buf *b, cl_isize new_len) {
    CL_ENSURE(b != NULL);
    CL_BOUNDS_CHECK_RANGE(0, new_len, b->len);
    b->len = new_len;
    if (b->data != NULL && b->cap > 0) {
        b->data[b->len] = '\0';
    }
}
