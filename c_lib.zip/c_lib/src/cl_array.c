/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_array.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Implementation of shared growth/shrink engines for Cl_DA_* dynamic
 *   arrays and Cl_Queue_* circular ring queues, plus Cl_Bit_Set operations.
 * ============================================================================
 */

#include "cl/cl_array.h"

/* ----------------------------------------------------------------------------
 * Dynamic Array Shared Growth & Shrink Engine
 * ---------------------------------------------------------------------------- */

/*
 * Ensures a dynamic array buffer holds at least min_cap elements by doubling
 * capacity (starting from 8 elements, clamping to min_cap before overflowing
 * PTRDIFF_MAX / 2) and resizing with zero-initialization of grown bytes.
 * Lazily binds *alloc to cl_ctx_allocator() if invalid.
 *
 * Parameters:
 *   old_data   (void *)         - Existing element buffer, or NULL.
 *   cap        (cl_isize *)     - Non-NULL in/out capacity pointer (elements).
 *   alloc      (Cl_Allocator *) - Non-NULL in/out allocator pointer.
 *   min_cap    (cl_isize)       - Minimum required capacity (elements).
 *   elem_size  (cl_isize)       - Size of one element (bytes; must be > 0).
 *   elem_align (cl_isize)       - Power-of-two element alignment (bytes).
 *   loc        (Cl_Source_Loc)  - Caller source location for diagnostics.
 *
 * Returns:
 *   (void *) Existing or newly resized buffer pointer, or NULL if byte-size
 *            multiplication overflows or allocation fails (leaving *cap
 *            unchanged).
 */
void *cl_da_reserve_raw(
    void *old_data,
    cl_isize *cap,
    Cl_Allocator *alloc,
    cl_isize min_cap,
    cl_isize elem_size,
    cl_isize elem_align,
    Cl_Source_Loc loc
) {
    CL_ASSERT(cap != NULL && alloc != NULL && elem_size > 0);
    if (min_cap <= *cap) {
        return old_data;
    }

    if (!cl_allocator_is_valid(*alloc)) {
        *alloc = cl_ctx_allocator();
    }

    cl_isize new_cap = (*cap > 0) ? (*cap) : 8;
    while (new_cap < min_cap) {
        if (new_cap > PTRDIFF_MAX / 2) {
            new_cap = min_cap;
            break;
        }
        new_cap *= 2;
    }

    cl_isize old_bytes = 0;
    cl_isize new_bytes = 0;
    if (cl_mul_overflow_isize(*cap, elem_size, &old_bytes) ||
        cl_mul_overflow_isize(new_cap, elem_size, &new_bytes)) {
        return NULL;
    }

    void *new_data = cl_resize_aligned_loc(*alloc, old_data, old_bytes, new_bytes, elem_align, loc);
    if (new_data == NULL) {
        return NULL;
    }

    *cap = new_cap;
    return new_data;
}

/*
 * Shrinks a dynamic array's backing allocation to exactly len elements using
 * non-zeroing aligned resize. Frees old_data and sets *cap = 0 if len <= 0.
 *
 * Parameters:
 *   old_data   (void *)         - Existing element buffer, or NULL.
 *   len        (cl_isize)       - Active element count (elements).
 *   cap        (cl_isize *)     - Non-NULL in/out capacity pointer (elements).
 *   alloc      (Cl_Allocator *) - Non-NULL allocator pointer (falls back to
 *                                 context allocator if invalid).
 *   elem_size  (cl_isize)       - Size of one element (bytes; must be > 0).
 *   elem_align (cl_isize)       - Power-of-two element alignment (bytes).
 *   loc        (Cl_Source_Loc)  - Caller source location for diagnostics.
 *
 * Returns:
 *   (void *) Shrunk buffer pointer, NULL if len <= 0 (buffer freed), or
 *            old_data unchanged if old_data == NULL, len >= *cap, or resize
 *            fails.
 */
void *cl_da_shrink_raw(
    void *old_data,
    cl_isize len,
    cl_isize *cap,
    Cl_Allocator *alloc,
    cl_isize elem_size,
    cl_isize elem_align,
    Cl_Source_Loc loc
) {
    CL_ASSERT(cap != NULL && alloc != NULL && elem_size > 0);
    if (old_data == NULL || len >= *cap) {
        return old_data;
    }

    Cl_Allocator a = cl_alloc_or_ctx(*alloc);
    cl_isize old_bytes = (*cap) * elem_size;
    if (len <= 0) {
        cl_free_loc(a, old_data, old_bytes, loc);
        *cap = 0;
        return NULL;
    }

    cl_isize new_bytes = len * elem_size;
    void *new_data = cl_resize_non_zeroed_aligned_loc(a, old_data, old_bytes, new_bytes, elem_align, loc);
    if (new_data == NULL) {
        return old_data;
    }
    *cap = len;
    return new_data;
}

/* ----------------------------------------------------------------------------
 * Circular Ring Queue Shared Growth Engine (Power-of-Two Capacity)
 * ---------------------------------------------------------------------------- */

/*
 * Doubles a circular ring queue's power-of-two capacity (starting at 8
 * elements when *cap == 0), unwraps the up to two contiguous ring segments
 * linearly into [0, len) of the new buffer, frees old_data, and resets
 * *head = 0 and *cap = new_cap. Lazily binds *alloc to cl_ctx_allocator() if
 * invalid.
 *
 * Parameters:
 *   old_data   (void *)         - Existing ring buffer, or NULL.
 *   head       (cl_isize *)     - Non-NULL in/out physical front index
 *                                 (elements).
 *   len        (cl_isize)       - Active element count (elements).
 *   cap        (cl_isize *)     - Non-NULL in/out power-of-two capacity
 *                                 (elements).
 *   alloc      (Cl_Allocator *) - Non-NULL in/out allocator pointer.
 *   elem_size  (cl_isize)       - Size of one element (bytes; must be > 0).
 *   elem_align (cl_isize)       - Power-of-two element alignment (bytes).
 *   loc        (Cl_Source_Loc)  - Caller source location for diagnostics.
 *
 * Returns:
 *   (void *) Newly allocated linearized ring buffer, or NULL on byte-size
 *            overflow or allocation failure (leaving caller state untouched).
 */
void *cl_queue_grow_raw(
    void *old_data,
    cl_isize *head,
    cl_isize len,
    cl_isize *cap,
    Cl_Allocator *alloc,
    cl_isize elem_size,
    cl_isize elem_align,
    Cl_Source_Loc loc
) {
    CL_ASSERT(head != NULL && cap != NULL && alloc != NULL && elem_size > 0);
    if (!cl_allocator_is_valid(*alloc)) {
        *alloc = cl_ctx_allocator();
    }

    cl_isize old_cap = *cap;
    cl_isize new_cap = (old_cap > 0) ? (old_cap * 2) : 8;
    cl_isize new_bytes = 0;
    if (cl_mul_overflow_isize(new_cap, elem_size, &new_bytes)) {
        return NULL;
    }

    void *new_data = cl_alloc_aligned_loc(*alloc, new_bytes, elem_align, loc);
    if (new_data == NULL) {
        return NULL;
    }

    if (old_data != NULL && len > 0) {
        cl_u8 *dst = (cl_u8 *)new_data;
        const cl_u8 *src = (const cl_u8 *)old_data;
        cl_isize first_part = old_cap - *head;
        if (first_part > len) {
            first_part = len;
        }
        cl_mem_copy(dst, src + (*head) * elem_size, first_part * elem_size);
        cl_isize second_part = len - first_part;
        if (second_part > 0) {
            cl_mem_copy(dst + first_part * elem_size, src, second_part * elem_size);
        }
    }

    if (old_data != NULL) {
        cl_free_loc(*alloc, old_data, old_cap * elem_size, loc);
    }

    *head = 0;
    *cap  = new_cap;
    return new_data;
}

/* ----------------------------------------------------------------------------
 * Dense Bit Set Implementation
 * ---------------------------------------------------------------------------- */

/*
 * Counts the number of 1-bits (population count) in a 64-bit unsigned integer
 * using __builtin_popcountll on GNU-compatible compilers or Brian Kernighan's
 * bit-clearing loop otherwise.
 *
 * Parameters:
 *   x (cl_u64) - 64-bit unsigned word to inspect.
 *
 * Returns:
 *   (cl_isize) Number of set bits in x (bits; in [0, 64]).
 */
static cl_isize cl_popcount64(cl_u64 x) {
#if CL_COMPILER_GNU_COMPAT
    return (cl_isize)__builtin_popcountll((unsigned long long)x);
#else
    cl_isize count = 0;
    while (x != 0) {
        x &= (x - 1u);
        count += 1;
    }
    return count;
#endif
}

/*
 * Allocates and zero-initializes a Cl_Bit_Set with (bit_count + 63) / 64
 * 64-bit words via alloc (falling back to cl_ctx_allocator() if invalid).
 *
 * Parameters:
 *   bs        (Cl_Bit_Set *) - Non-NULL pointer to the bit set to initialize.
 *   bit_count (cl_isize)     - Number of usable bits (bits; must be > 0).
 *   alloc     (Cl_Allocator) - Backing allocator handle.
 *
 * Returns:
 *   (bool) true on successful allocation, or false if bit_count <= 0 or
 *          allocation fails (leaving *bs zeroed).
 */
bool cl_bitset_init(Cl_Bit_Set *bs, cl_isize bit_count, Cl_Allocator alloc) {
    CL_ENSURE(bs != NULL);
    CL_ZERO_STRUCT(bs);
    if (bit_count <= 0) {
        return false;
    }

    Cl_Allocator a = cl_alloc_or_ctx(alloc);
    cl_isize words = (bit_count + 63) / 64;
    cl_u64 *buf = (cl_u64 *)cl_alloc_array_loc(
        a, words, (cl_isize)sizeof(cl_u64), CL_ALIGNOF(cl_u64), true, CL_HERE
    );
    if (buf == NULL) {
        return false;
    }

    bs->words     = buf;
    bs->bit_cap   = bit_count;
    bs->word_cap  = words;
    bs->allocator = a;
    return true;
}

/*
 * Frees bs->words using bs->allocator and zeroes the Cl_Bit_Set struct.
 * Safe no-op if bs == NULL.
 *
 * Parameters:
 *   bs (Cl_Bit_Set *) - Pointer to the bit set to destroy.
 */
void cl_bitset_destroy(Cl_Bit_Set *bs) {
    if (bs == NULL) {
        return;
    }
    if (bs->words != NULL) {
        cl_free_loc(bs->allocator, bs->words, bs->word_cap * (cl_isize)sizeof(cl_u64), CL_HERE);
    }
    CL_ZERO_STRUCT(bs);
}

/*
 * Zeroes all allocated 64-bit words in *bs without freeing the buffer.
 * Safe no-op if bs == NULL or bs->words == NULL.
 *
 * Parameters:
 *   bs (Cl_Bit_Set *) - Pointer to the bit set to clear.
 */
void cl_bitset_clear_all(Cl_Bit_Set *bs) {
    if (bs == NULL || bs->words == NULL) {
        return;
    }
    cl_mem_zero(bs->words, bs->word_cap * (cl_isize)sizeof(cl_u64));
}

/*
 * Sets the bit at 0-based index bit_idx to 1 after bounds-checking against
 * [0, bs->bit_cap).
 *
 * Parameters:
 *   bs      (Cl_Bit_Set *) - Non-NULL initialized bit set.
 *   bit_idx (cl_isize)     - 0-based bit index (bits; 0 <= bit_idx < bs->bit_cap).
 */
void cl_bitset_set(Cl_Bit_Set *bs, cl_isize bit_idx) {
    CL_ENSURE(bs != NULL);
    cl_isize idx = CL_BOUNDS_CHECK_INDEX(bit_idx, bs->bit_cap);
    bs->words[idx >> 6] |= (1ull << (idx & 63));
}

/*
 * Clears the bit at 0-based index bit_idx to 0 after bounds-checking against
 * [0, bs->bit_cap).
 *
 * Parameters:
 *   bs      (Cl_Bit_Set *) - Non-NULL initialized bit set.
 *   bit_idx (cl_isize)     - 0-based bit index (bits; 0 <= bit_idx < bs->bit_cap).
 */
void cl_bitset_clear(Cl_Bit_Set *bs, cl_isize bit_idx) {
    CL_ENSURE(bs != NULL);
    cl_isize idx = CL_BOUNDS_CHECK_INDEX(bit_idx, bs->bit_cap);
    bs->words[idx >> 6] &= ~(1ull << (idx & 63));
}

/*
 * Toggles (inverts) the bit at 0-based index bit_idx after bounds-checking
 * against [0, bs->bit_cap).
 *
 * Parameters:
 *   bs      (Cl_Bit_Set *) - Non-NULL initialized bit set.
 *   bit_idx (cl_isize)     - 0-based bit index (bits; 0 <= bit_idx < bs->bit_cap).
 */
void cl_bitset_toggle(Cl_Bit_Set *bs, cl_isize bit_idx) {
    CL_ENSURE(bs != NULL);
    cl_isize idx = CL_BOUNDS_CHECK_INDEX(bit_idx, bs->bit_cap);
    bs->words[idx >> 6] ^= (1ull << (idx & 63));
}

/*
 * Tests whether the bit at 0-based index bit_idx is 1 after bounds-checking
 * against [0, bs->bit_cap).
 *
 * Parameters:
 *   bs      (const Cl_Bit_Set *) - Non-NULL initialized bit set.
 *   bit_idx (cl_isize)           - 0-based bit index (bits;
 *                                  0 <= bit_idx < bs->bit_cap).
 *
 * Returns:
 *   (bool) true if bit bit_idx is 1, false if 0.
 */
bool cl_bitset_test(const Cl_Bit_Set *bs, cl_isize bit_idx) {
    CL_ENSURE(bs != NULL);
    cl_isize idx = CL_BOUNDS_CHECK_INDEX(bit_idx, bs->bit_cap);
    return ((bs->words[idx >> 6] >> (idx & 63)) & 1ull) != 0u;
}

/*
 * Sums cl_popcount64() across all word_cap words of *bs.
 *
 * Parameters:
 *   bs (const Cl_Bit_Set *) - Pointer to the bit set (may be NULL).
 *
 * Returns:
 *   (cl_isize) Total number of 1-bits (bits), or 0 if bs == NULL or
 *              bs->words == NULL.
 */
cl_isize cl_bitset_count_ones(const Cl_Bit_Set *bs) {
    if (bs == NULL || bs->words == NULL) {
        return 0;
    }
    cl_isize total = 0;
    for (cl_isize i = 0; i < bs->word_cap; i++) {
        total += cl_popcount64(bs->words[i]);
    }
    return total;
}

/*
 * Performs in-place bitwise OR (dst->words[i] |= src->words[i]) over the
 * overlapping prefix of min(dst->word_cap, src->word_cap) 64-bit words.
 *
 * Parameters:
 *   dst (Cl_Bit_Set *)       - Non-NULL destination bit set modified in place.
 *   src (const Cl_Bit_Set *) - Non-NULL source bit set.
 */
void cl_bitset_union_in_place(Cl_Bit_Set *dst, const Cl_Bit_Set *src) {
    CL_ENSURE(dst != NULL && src != NULL);
    cl_isize words = (dst->word_cap < src->word_cap) ? dst->word_cap : src->word_cap;
    for (cl_isize i = 0; i < words; i++) {
        dst->words[i] |= src->words[i];
    }
}

/*
 * Performs in-place bitwise AND (dst->words[i] &= src->words[i]) over
 * min(dst->word_cap, src->word_cap) 64-bit words and clears all remaining
 * words in dst from that index through dst->word_cap - 1.
 *
 * Parameters:
 *   dst (Cl_Bit_Set *)       - Non-NULL destination bit set modified in place.
 *   src (const Cl_Bit_Set *) - Non-NULL source bit set.
 */
void cl_bitset_intersect_in_place(Cl_Bit_Set *dst, const Cl_Bit_Set *src) {
    CL_ENSURE(dst != NULL && src != NULL);
    cl_isize words = (dst->word_cap < src->word_cap) ? dst->word_cap : src->word_cap;
    for (cl_isize i = 0; i < words; i++) {
        dst->words[i] &= src->words[i];
    }
    for (cl_isize i = words; i < dst->word_cap; i++) {
        dst->words[i] = 0u;
    }
}
