/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_alloc.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Implementation of the allocator dispatch helpers, cl_heap_allocator(),
 *   and cl_panic_allocator().
 * ============================================================================
 */

/*
 * Feature test macro selecting POSIX.1-2008 APIs so posix_memalign() is
 * declared by <stdlib.h> under strict ISO C99 (-std=c99).
 */
#define _POSIX_C_SOURCE 200809L

#include "cl/cl_alloc.h"
#include <stdlib.h>

/* ----------------------------------------------------------------------------
 * Heap Allocator Implementation (Aligned malloc/calloc/realloc/free)
 * ---------------------------------------------------------------------------- */

/*
 * Internal helper that allocates size bytes from the C runtime heap with at
 * least alignment-byte alignment, using calloc/malloc for standard alignments
 * (with posix_memalign fallback) and posix_memalign for over-aligned requests.
 *
 * Parameters:
 *   size      (cl_isize) - Number of bytes to allocate (bytes; <= 0 returns NULL).
 *   alignment (cl_isize) - Power-of-two alignment in bytes (<= 0 defaults to CL_DEFAULT_ALIGNMENT).
 *   zeroed    (bool)     - If true, zero-initialize the returned bytes; if false, leave uninitialized.
 *
 * Returns:
 *   (void *) Pointer to allocated heap memory aligned to alignment, or NULL if size <= 0 or OOM.
 */
static void *cl_heap_alloc_raw(cl_isize size, cl_isize alignment, bool zeroed) {
    if (size <= 0) {
        return NULL;
    }
    if (alignment <= 0) {
        alignment = CL_DEFAULT_ALIGNMENT;
    }
    CL_ASSERT(cl_is_power_of_two(alignment));

    void *ptr = NULL;
    if (alignment <= CL_DEFAULT_ALIGNMENT) {
        if (zeroed) {
            ptr = calloc(1u, (cl_usize)size);
        } else {
            ptr = malloc((cl_usize)size);
        }
        /* Verify system malloc alignment; fallback to posix_memalign if ever unaligned */
        if (ptr != NULL && (((cl_uintptr)ptr & ((cl_uintptr)alignment - 1u)) != 0u)) {
            free(ptr);
            ptr = NULL;
            cl_usize req_align = (cl_usize)alignment;
            if (req_align < sizeof(void *)) {
                req_align = sizeof(void *);
            }
            if (posix_memalign(&ptr, req_align, (cl_usize)size) != 0) {
                return NULL;
            }
            if (zeroed) {
                cl_mem_zero(ptr, size);
            }
        }
    } else {
        cl_usize req_align = (cl_usize)alignment;
        if (req_align < sizeof(void *)) {
            req_align = sizeof(void *);
        }
        if (posix_memalign(&ptr, req_align, (cl_usize)size) != 0) {
            return NULL;
        }
        if (zeroed) {
            cl_mem_zero(ptr, size);
        }
    }
    return ptr;
}

/*
 * Cl_Alloc_Proc dispatch implementation for cl_heap_allocator(). Handles
 * ALLOC, ALLOC_NON_ZEROED, FREE, RESIZE, and RESIZE_NON_ZEROED using libc
 * heap routines; FREE_ALL is a no-op returning NULL.
 *
 * Parameters:
 *   allocator_data (void *)        - Unused (always NULL for the stateless heap allocator).
 *   mode           (Cl_Alloc_Mode) - Requested allocation operation.
 *   size           (cl_isize)      - Requested allocation or resize byte count (bytes).
 *   alignment      (cl_isize)      - Power-of-two alignment in bytes (<= 0 defaults to CL_DEFAULT_ALIGNMENT).
 *   old_memory     (void *)        - Existing heap pointer for FREE/RESIZE, or NULL.
 *   old_size       (cl_isize)      - Previous allocation size in bytes (used for resize copy/zeroing).
 *   loc            (Cl_Source_Loc) - Unused caller source location.
 *
 * Returns:
 *   (void *) Pointer to allocated or resized heap block, or NULL on FREE, FREE_ALL,
 *            size <= 0, or allocation failure.
 */
static void *cl_heap_alloc_proc(
    void          *allocator_data,
    Cl_Alloc_Mode  mode,
    cl_isize       size,
    cl_isize       alignment,
    void          *old_memory,
    cl_isize       old_size,
    Cl_Source_Loc  loc
) {
    CL_UNUSED_VAR(allocator_data);
    CL_UNUSED_VAR(loc);

    if (alignment <= 0) {
        alignment = CL_DEFAULT_ALIGNMENT;
    }

    switch (mode) {
        case CL_ALLOC_ALLOC:
            return cl_heap_alloc_raw(size, alignment, true);

        case CL_ALLOC_ALLOC_NON_ZEROED:
            return cl_heap_alloc_raw(size, alignment, false);

        case CL_ALLOC_FREE:
            free(old_memory);
            return NULL;

        case CL_ALLOC_FREE_ALL:
            /* Heap allocator does not support bulk free_all */
            return NULL;

        case CL_ALLOC_RESIZE:
        case CL_ALLOC_RESIZE_NON_ZEROED: {
            bool zeroed = (mode == CL_ALLOC_RESIZE);
            if (old_memory == NULL) {
                return cl_heap_alloc_raw(size, alignment, zeroed);
            }
            if (size <= 0) {
                free(old_memory);
                return NULL;
            }
            if (alignment <= CL_DEFAULT_ALIGNMENT) {
                void *new_ptr = realloc(old_memory, (cl_usize)size);
                if (new_ptr == NULL) {
                    return NULL;
                }
                if (zeroed && size > old_size) {
                    cl_mem_zero((cl_u8 *)new_ptr + old_size, size - old_size);
                }
                return new_ptr;
            } else {
                void *new_ptr = cl_heap_alloc_raw(size, alignment, zeroed);
                if (new_ptr == NULL) {
                    return NULL;
                }
                cl_isize copy_len = (old_size < size) ? old_size : size;
                cl_mem_copy(new_ptr, old_memory, copy_len);
                free(old_memory);
                return new_ptr;
            }
        }
    }
    return NULL;
}

/*
 * Constructs and returns the stateless Cl_Allocator backed by the libc heap.
 *
 * Returns:
 *   (Cl_Allocator) Allocator handle with proc = cl_heap_alloc_proc and data = NULL.
 */
Cl_Allocator cl_heap_allocator(void) {
    return (Cl_Allocator){ cl_heap_alloc_proc, NULL };
}

/* ----------------------------------------------------------------------------
 * Panic Allocator Implementation
 * ---------------------------------------------------------------------------- */

/*
 * Cl_Alloc_Proc dispatch implementation for cl_panic_allocator(). Permits
 * freeing NULL as a no-op and triggers a formatted assertion failure on any
 * other allocator operation.
 *
 * Parameters:
 *   allocator_data (void *)        - Unused (NULL).
 *   mode           (Cl_Alloc_Mode) - Requested operation reported in the panic message.
 *   size           (cl_isize)      - Requested byte size reported in the panic message (bytes).
 *   alignment      (cl_isize)      - Unused alignment in bytes.
 *   old_memory     (void *)        - Existing pointer; if NULL with CL_ALLOC_FREE, returns NULL without panicking.
 *   old_size       (cl_isize)      - Unused prior size in bytes.
 *   loc            (Cl_Source_Loc) - Caller source location reported in the panic diagnostic.
 *
 * Returns:
 *   (void *) NULL if freeing NULL (or if the custom assert handler returns).
 */
static void *cl_panic_alloc_proc(
    void          *allocator_data,
    Cl_Alloc_Mode  mode,
    cl_isize       size,
    cl_isize       alignment,
    void          *old_memory,
    cl_isize       old_size,
    Cl_Source_Loc  loc
) {
    CL_UNUSED_VAR(allocator_data);
    CL_UNUSED_VAR(alignment);
    CL_UNUSED_VAR(old_memory);
    CL_UNUSED_VAR(old_size);
    if (mode == CL_ALLOC_FREE && old_memory == NULL) {
        return NULL;
    }
    cl_assert_fail_fmt(
        "PANIC ALLOCATOR",
        loc,
        "Forbidden allocation attempt (mode=%d, size=%lld) in no-alloc scope",
        (int)mode,
        (long long)size
    );
    return NULL;
}

/*
 * Constructs and returns the stateless Cl_Allocator that traps on allocation.
 *
 * Returns:
 *   (Cl_Allocator) Allocator handle with proc = cl_panic_alloc_proc and data = NULL.
 */
Cl_Allocator cl_panic_allocator(void) {
    return (Cl_Allocator){ cl_panic_alloc_proc, NULL };
}

/* ----------------------------------------------------------------------------
 * Public Dispatch Wrappers
 * ---------------------------------------------------------------------------- */

/*
 * Dispatches a CL_ALLOC_ALLOC request to allocator a after ensuring a.proc is
 * non-NULL and guarding size <= 0.
 *
 * Parameters:
 *   a     (Cl_Allocator)  - Valid allocator handle (a.proc must be non-NULL).
 *   size  (cl_isize)      - Allocation length in bytes (<= 0 returns NULL).
 *   align (cl_isize)      - Power-of-two alignment in bytes.
 *   loc   (Cl_Source_Loc) - Caller source location for diagnostics.
 *
 * Returns:
 *   (void *) Pointer to zero-initialized aligned memory, or NULL if size <= 0 or OOM.
 */
void *cl_alloc_aligned_loc(Cl_Allocator a, cl_isize size, cl_isize align, Cl_Source_Loc loc) {
    CL_ENSURE(a.proc != NULL);
    if (size <= 0) {
        return NULL;
    }
    return a.proc(a.data, CL_ALLOC_ALLOC, size, align, NULL, 0, loc);
}

/*
 * Dispatches a CL_ALLOC_ALLOC_NON_ZEROED request to allocator a after ensuring
 * a.proc is non-NULL and guarding size <= 0.
 *
 * Parameters:
 *   a     (Cl_Allocator)  - Valid allocator handle (a.proc must be non-NULL).
 *   size  (cl_isize)      - Allocation length in bytes (<= 0 returns NULL).
 *   align (cl_isize)      - Power-of-two alignment in bytes.
 *   loc   (Cl_Source_Loc) - Caller source location for diagnostics.
 *
 * Returns:
 *   (void *) Pointer to uninitialized aligned memory, or NULL if size <= 0 or OOM.
 */
void *cl_alloc_non_zeroed_aligned_loc(Cl_Allocator a, cl_isize size, cl_isize align, Cl_Source_Loc loc) {
    CL_ENSURE(a.proc != NULL);
    if (size <= 0) {
        return NULL;
    }
    return a.proc(a.data, CL_ALLOC_ALLOC_NON_ZEROED, size, align, NULL, 0, loc);
}

/*
 * Dispatches a CL_ALLOC_RESIZE request to allocator a after ensuring a.proc is
 * non-NULL.
 *
 * Parameters:
 *   a        (Cl_Allocator)  - Valid allocator handle (a.proc must be non-NULL).
 *   old_ptr  (void *)        - Existing block pointer, or NULL to allocate fresh memory.
 *   old_size (cl_isize)      - Previous allocation length in bytes.
 *   new_size (cl_isize)      - Desired new allocation length in bytes.
 *   align    (cl_isize)      - Power-of-two alignment in bytes.
 *   loc      (Cl_Source_Loc) - Caller source location for diagnostics.
 *
 * Returns:
 *   (void *) Pointer to resized block with zeroed growth bytes, or NULL if freed or OOM.
 */
void *cl_resize_aligned_loc(
    Cl_Allocator a,
    void *old_ptr,
    cl_isize old_size,
    cl_isize new_size,
    cl_isize align,
    Cl_Source_Loc loc
) {
    CL_ENSURE(a.proc != NULL);
    return a.proc(a.data, CL_ALLOC_RESIZE, new_size, align, old_ptr, old_size, loc);
}

/*
 * Dispatches a CL_ALLOC_RESIZE_NON_ZEROED request to allocator a after ensuring
 * a.proc is non-NULL.
 *
 * Parameters:
 *   a        (Cl_Allocator)  - Valid allocator handle (a.proc must be non-NULL).
 *   old_ptr  (void *)        - Existing block pointer, or NULL to allocate fresh memory.
 *   old_size (cl_isize)      - Previous allocation length in bytes.
 *   new_size (cl_isize)      - Desired new allocation length in bytes.
 *   align    (cl_isize)      - Power-of-two alignment in bytes.
 *   loc      (Cl_Source_Loc) - Caller source location for diagnostics.
 *
 * Returns:
 *   (void *) Pointer to resized block without zeroing growth bytes, or NULL if freed or OOM.
 */
void *cl_resize_non_zeroed_aligned_loc(
    Cl_Allocator a,
    void *old_ptr,
    cl_isize old_size,
    cl_isize new_size,
    cl_isize align,
    Cl_Source_Loc loc
) {
    CL_ENSURE(a.proc != NULL);
    return a.proc(a.data, CL_ALLOC_RESIZE_NON_ZEROED, new_size, align, old_ptr, old_size, loc);
}

/*
 * Dispatches a CL_ALLOC_FREE request to allocator a; returns immediately
 * without calling a.proc if ptr is NULL.
 *
 * Parameters:
 *   a        (Cl_Allocator)  - Valid allocator handle (a.proc must be non-NULL when ptr != NULL).
 *   ptr      (void *)        - Allocation pointer to free (NULL is a safe no-op).
 *   old_size (cl_isize)      - Original allocation length in bytes (0 if unknown).
 *   loc      (Cl_Source_Loc) - Caller source location for diagnostics.
 */
void cl_free_loc(Cl_Allocator a, void *ptr, cl_isize old_size, Cl_Source_Loc loc) {
    if (ptr == NULL) {
        return;
    }
    CL_ENSURE(a.proc != NULL);
    a.proc(a.data, CL_ALLOC_FREE, 0, CL_DEFAULT_ALIGNMENT, ptr, old_size, loc);
}

/*
 * Dispatches a CL_ALLOC_FREE_ALL request to allocator a after ensuring a.proc
 * is non-NULL.
 *
 * Parameters:
 *   a   (Cl_Allocator)  - Valid allocator handle (a.proc must be non-NULL).
 *   loc (Cl_Source_Loc) - Caller source location for diagnostics.
 */
void cl_free_all_loc(Cl_Allocator a, Cl_Source_Loc loc) {
    CL_ENSURE(a.proc != NULL);
    a.proc(a.data, CL_ALLOC_FREE_ALL, 0, CL_DEFAULT_ALIGNMENT, NULL, 0, loc);
}

/*
 * Computes total = count * elem_size with signed overflow checking and
 * allocates total aligned bytes from allocator a.
 *
 * Parameters:
 *   a         (Cl_Allocator)  - Valid allocator handle (a.proc must be non-NULL).
 *   count     (cl_isize)      - Number of array elements (element count; <= 0 returns NULL).
 *   elem_size (cl_isize)      - Size of a single element in bytes (<= 0 returns NULL).
 *   align     (cl_isize)      - Power-of-two alignment in bytes.
 *   zeroed    (bool)          - If true, zero-initialize the buffer; if false, leave uninitialized.
 *   loc       (Cl_Source_Loc) - Caller source location for diagnostics.
 *
 * Returns:
 *   (void *) Pointer to the allocated array, or NULL on invalid count/elem_size,
 *            multiplication overflow, or OOM.
 */
void *cl_alloc_array_loc(
    Cl_Allocator a,
    cl_isize count,
    cl_isize elem_size,
    cl_isize align,
    bool zeroed,
    Cl_Source_Loc loc
) {
    if (count <= 0 || elem_size <= 0) {
        return NULL;
    }
    cl_isize total = 0;
    if (CL_UNLIKELY(cl_mul_overflow_isize(count, elem_size, &total))) {
        return NULL;
    }
    if (zeroed) {
        return cl_alloc_aligned_loc(a, total, align, loc);
    }
    return cl_alloc_non_zeroed_aligned_loc(a, total, align, loc);
}
