/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_assert.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Implementation of assertion handlers, panic formatting, bounds-check
 *   failure diagnostics, and Linux glibc backtrace printing.
 * ============================================================================
 */

/* Feature-test macro enabling glibc default BSD/POSIX/SysV declarations (e.g., execinfo). */
#define _DEFAULT_SOURCE

/* Feature-test macro requesting POSIX.1-2008 system declarations (version 200809L). */
#define _POSIX_C_SOURCE 200809L

#include "cl/cl_assert.h"
#include <stdio.h>
#include <stdlib.h>

#if CL_ENABLE_BACKTRACE
    #include <execinfo.h>
    #include <unistd.h>
#endif

#if CL_COMPILER_GNU_COMPAT
    /* Thread-local active assertion failure handler (NULL selects cl_default_assert_proc). */
    CL_EXTENSION static __thread Cl_Assert_Proc cl_tls_assert_proc = NULL;
#else
    /* Process-wide fallback assertion failure handler when __thread is unavailable. */
    static Cl_Assert_Proc cl_tls_assert_proc = NULL;
#endif

/*
 * Sets the active thread-local assertion failure handler for the calling thread.
 * Passing NULL restores cl_default_assert_proc.
 *
 * Parameters:
 *   proc (Cl_Assert_Proc) - Custom assertion callback, or NULL for the default handler.
 */
void cl_assert_set_proc(Cl_Assert_Proc proc) {
    cl_tls_assert_proc = proc;
}

/*
 * Returns the active thread-local assertion failure handler for the calling thread,
 * defaulting to cl_default_assert_proc when no custom handler is installed.
 *
 * Returns:
 *   Cl_Assert_Proc - Non-NULL assertion failure callback pointer.
 */
Cl_Assert_Proc cl_assert_get_proc(void) {
    return cl_tls_assert_proc ? cl_tls_assert_proc : cl_default_assert_proc;
}

/*
 * Captures up to 64 stack frames and writes resolved symbols to stderr using Linux
 * glibc backtrace() and backtrace_symbols_fd(). No-op when CL_ENABLE_BACKTRACE == 0.
 *
 * Parameters:
 *   skip_frames (int, stack frame count) - Number of innermost frames to skip;
 *                                          values < 0 are clamped to 0.
 */
void cl_print_backtrace(int skip_frames) {
#if CL_ENABLE_BACKTRACE
    void *frames[64];
    int count = backtrace(frames, 64);
    if (skip_frames < 0) {
        skip_frames = 0;
    }
    if (count > skip_frames) {
        fprintf(stderr, "Stack trace (%d frames):\n", count - skip_frames);
        fflush(stderr);
        backtrace_symbols_fd(frames + skip_frames, count - skip_frames, STDERR_FILENO);
    }
#else
    CL_UNUSED_VAR(skip_frames);
#endif
}

/*
 * Default non-returning assertion handler: prints formatted failure header,
 * file:line/function location, detail message, and stack trace (skipping 2 internal
 * frames) to stderr, then halts via CL_TRAP() or abort().
 *
 * Parameters:
 *   prefix  (const char *)  - Category label (falls back to "FATAL" if NULL).
 *   message (const char *)  - Diagnostic detail text (falls back to "(no message)" if NULL).
 *   loc     (Cl_Source_Loc) - Source file, 1-based line number, and function name.
 */
CL_NORETURN void cl_default_assert_proc(const char *prefix, const char *message, Cl_Source_Loc loc) {
    fprintf(
        stderr,
        "\n================================================================\n"
        "[c_lib %s]\n"
        "  Location : %s:%d in %s()\n"
        "  Details  : %s\n"
        "================================================================\n",
        prefix ? prefix : "FATAL",
        loc.file ? loc.file : "<unknown>",
        (int)loc.line,
        loc.func ? loc.func : "<unknown>",
        message ? message : "(no message)"
    );
    cl_print_backtrace(2);
    fflush(stderr);

#if CL_BOUNDS_CHECK_TRAP
    CL_TRAP();
#else
    abort();
#endif
}

/*
 * Non-returning dispatcher that invokes the active assertion callback with a plain
 * expression or message string and calls abort() if the callback returns.
 *
 * Parameters:
 *   prefix (const char *)  - Failure category label (e.g., "ASSERTION FAILED").
 *   expr   (const char *)  - Failing expression text or error message.
 *   loc    (Cl_Source_Loc) - Call-site source location.
 */
CL_NOINLINE CL_NORETURN void cl_assert_fail(const char *prefix, const char *expr, Cl_Source_Loc loc) {
    Cl_Assert_Proc proc = cl_assert_get_proc();
    proc(prefix, expr, loc);
    abort();
}

/*
 * Non-returning dispatcher that formats a printf-style diagnostic message into a
 * 1024-byte stack buffer, invokes the active assertion callback, and calls abort()
 * if the callback returns.
 *
 * Parameters:
 *   prefix (const char *)  - Failure category label (e.g., "PANIC").
 *   loc    (Cl_Source_Loc) - Call-site source location.
 *   fmt    (const char *)  - Non-NULL printf format string.
 *   ...    (variadic args) - Arguments corresponding to format specifiers in fmt.
 */
CL_NOINLINE CL_NORETURN void cl_assert_fail_fmt(
    const char *prefix,
    Cl_Source_Loc loc,
    const char *fmt,
    ...
) {
    char buf[1024];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);

    Cl_Assert_Proc proc = cl_assert_get_proc();
    proc(prefix, buf, loc);
    abort();
}

/*
 * Non-returning dispatcher for out-of-bounds single-index access: formats index,
 * length, and expression text into a 512-byte buffer, invokes the active assertion
 * handler under "BOUNDS CHECK FAILED", and calls abort() if it returns.
 *
 * Parameters:
 *   index (cl_isize, 0-based index) - Invalid element index outside [0, len).
 *   len   (cl_isize, element count) - Container length.
 *   expr  (const char *)            - Stringified expression text (or NULL).
 *   loc   (Cl_Source_Loc)           - Call-site source location.
 */
CL_NOINLINE CL_NORETURN void cl_bounds_check_index_fail(
    cl_isize index,
    cl_isize len,
    const char *expr,
    Cl_Source_Loc loc
) {
    char buf[512];
    snprintf(
        buf,
        sizeof(buf),
        "Index out of bounds: index=%lld not in [0, %lld) (%s)",
        (long long)index,
        (long long)len,
        expr ? expr : ""
    );
    Cl_Assert_Proc proc = cl_assert_get_proc();
    proc("BOUNDS CHECK FAILED", buf, loc);
    abort();
}

/*
 * Non-returning dispatcher for invalid sub-slice range [lo, hi): formats bounds,
 * length, and expression text into a 512-byte buffer, invokes the active assertion
 * handler under "BOUNDS CHECK FAILED", and calls abort() if it returns.
 *
 * Parameters:
 *   lo   (cl_isize, 0-based index) - Inclusive start index of the slice range.
 *   hi   (cl_isize, 0-based index) - Exclusive end index of the slice range.
 *   len  (cl_isize, element count) - Container length.
 *   expr (const char *)            - Stringified range expression text (or NULL).
 *   loc  (Cl_Source_Loc)           - Call-site source location.
 */
CL_NOINLINE CL_NORETURN void cl_bounds_check_range_fail(
    cl_isize lo,
    cl_isize hi,
    cl_isize len,
    const char *expr,
    Cl_Source_Loc loc
) {
    char buf[512];
    snprintf(
        buf,
        sizeof(buf),
        "Slice range out of bounds: [%lld:%lld] invalid for length %lld (%s)",
        (long long)lo,
        (long long)hi,
        (long long)len,
        expr ? expr : ""
    );
    Cl_Assert_Proc proc = cl_assert_get_proc();
    proc("BOUNDS CHECK FAILED", buf, loc);
    abort();
}
