/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_hash.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Implementation of FNV-1a 64-bit, SplitMix64 mixing, and Cl_Map key
 *   hash/equality callbacks.
 * ============================================================================
 */

#include "cl/cl_hash.h"
#include "cl/cl_mem.h"
#include <string.h>

/*
 * Standard 64-bit FNV-1a initial offset basis (0xCBF29CE484222325ULL),
 * defined as the FNV-0 hash of the canonical 32-byte ASCII seed string.
 */
#define CL_FNV1A_OFFSET_BASIS 14695981039346656037ull

/*
 * Standard 64-bit FNV-1a prime multiplier (0x00000100000001B3ULL, equal to
 * 2^40 + 2^8 + 0xB3), applied modulo 2^64 after XORing each input byte.
 */
#define CL_FNV1A_PRIME        1099511628211ull

/*
 * Computes a seeded (or incremental) 64-bit FNV-1a hash over len bytes at
 * data by updating h = (h ^ byte) * CL_FNV1A_PRIME for each byte.
 *
 * Parameters:
 *   data (const void *) - Input byte buffer (may be NULL when len <= 0).
 *   len  (cl_isize)     - Number of bytes to hash (bytes).
 *   seed (cl_u64)       - Initial 64-bit hash seed or prior FNV-1a state.
 *
 * Returns:
 *   (cl_u64) Final 64-bit FNV-1a state (returns seed if data == NULL or
 *            len <= 0).
 */
cl_u64 cl_hash_fnv1a64_seed(const void *data, cl_isize len, cl_u64 seed) {
    const cl_u8 *bytes = (const cl_u8 *)data;
    cl_u64 h = seed;
    if (bytes == NULL || len <= 0) {
        return h;
    }
    for (cl_isize i = 0; i < len; i++) {
        h ^= (cl_u64)bytes[i];
        h *= CL_FNV1A_PRIME;
    }
    return h;
}

/*
 * Computes the standard unseeded 64-bit FNV-1a hash of len bytes at data
 * using CL_FNV1A_OFFSET_BASIS.
 *
 * Parameters:
 *   data (const void *) - Input byte buffer (may be NULL when len <= 0).
 *   len  (cl_isize)     - Number of bytes to hash (bytes).
 *
 * Returns:
 *   (cl_u64) 64-bit FNV-1a hash value.
 */
cl_u64 cl_hash_fnv1a64(const void *data, cl_isize len) {
    return cl_hash_fnv1a64_seed(data, len, CL_FNV1A_OFFSET_BASIS);
}

/*
 * Mixes a 64-bit unsigned integer with the SplitMix64 bijective finalizer:
 * adds the golden-ratio constant 0x9E3779B97F4A7C15ULL, then performs two
 * xorshift-multiply rounds and a final x ^ (x >> 31).
 *
 * Parameters:
 *   x (cl_u64) - 64-bit unsigned integer to mix.
 *
 * Returns:
 *   (cl_u64) Avalanche-mixed 64-bit hash value.
 */
cl_u64 cl_hash_u64_mix(cl_u64 x) {
    x += 0x9E3779B97F4A7C15ull;
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ull;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBull;
    return x ^ (x >> 31);
}

/*
 * Computes the 64-bit FNV-1a hash of the s.len bytes referenced by Cl_Str s.
 *
 * Parameters:
 *   s (Cl_Str) - Non-owning UTF-8 string view.
 *
 * Returns:
 *   (cl_u64) 64-bit FNV-1a hash of s's byte contents.
 */
cl_u64 cl_hash_str(Cl_Str s) {
    return cl_hash_fnv1a64(s.data, s.len);
}

/*
 * Computes the 64-bit FNV-1a hash of a NUL-terminated C string s (excluding
 * the terminating NUL byte).
 *
 * Parameters:
 *   s (const char *) - NUL-terminated C string, or NULL.
 *
 * Returns:
 *   (cl_u64) 64-bit FNV-1a hash of s, or CL_FNV1A_OFFSET_BASIS if s == NULL.
 */
cl_u64 cl_hash_cstr(const char *s) {
    if (s == NULL) {
        return CL_FNV1A_OFFSET_BASIS;
    }
    return cl_hash_fnv1a64(s, (cl_isize)strlen(s));
}

/*
 * Cl_Map hasher callback for fixed-size POD keys: computes 64-bit FNV-1a over
 * key_size bytes at key.
 *
 * Parameters:
 *   key      (const void *) - Pointer to POD key bytes.
 *   key_size (cl_isize)     - Key size (bytes).
 *
 * Returns:
 *   (cl_u64) 64-bit FNV-1a hash value.
 */
cl_u64 cl_map_hash_bytes(const void *key, cl_isize key_size) {
    return cl_hash_fnv1a64(key, key_size);
}

/*
 * Cl_Map equality callback for fixed-size POD keys: compares key_size bytes
 * at a and b via cl_mem_eq.
 *
 * Parameters:
 *   a        (const void *) - Pointer to the first POD key.
 *   b        (const void *) - Pointer to the second POD key.
 *   key_size (cl_isize)     - Key size (bytes).
 *
 * Returns:
 *   (bool) true if all key_size bytes are identical (or key_size <= 0), false
 *          otherwise.
 */
bool cl_map_eq_bytes(const void *a, const void *b, cl_isize key_size) {
    return cl_mem_eq(a, b, key_size);
}

/*
 * Cl_Map hasher callback for Cl_Str keys: hashes the string's byte contents
 * using cl_hash_str.
 *
 * Parameters:
 *   key      (const void *) - Non-NULL pointer to a Cl_Str key.
 *   key_size (cl_isize)     - Unused (sizeof(Cl_Str) in bytes).
 *
 * Returns:
 *   (cl_u64) 64-bit FNV-1a hash of the Cl_Str's byte contents.
 */
cl_u64 cl_map_hash_str(const void *key, cl_isize key_size) {
    CL_UNUSED_VAR(key_size);
    const Cl_Str *s = (const Cl_Str *)key;
    return cl_hash_str(*s);
}

/*
 * Cl_Map equality callback for Cl_Str keys: checks that lengths match and that
 * all sa->len bytes match via cl_mem_eq.
 *
 * Parameters:
 *   a        (const void *) - Non-NULL pointer to the first Cl_Str key.
 *   b        (const void *) - Non-NULL pointer to the second Cl_Str key.
 *   key_size (cl_isize)     - Unused (sizeof(Cl_Str) in bytes).
 *
 * Returns:
 *   (bool) true if both Cl_Str descriptors contain identical bytes, false
 *          otherwise.
 */
bool cl_map_eq_str(const void *a, const void *b, cl_isize key_size) {
    CL_UNUSED_VAR(key_size);
    const Cl_Str *sa = (const Cl_Str *)a;
    const Cl_Str *sb = (const Cl_Str *)b;
    if (sa->len != sb->len) {
        return false;
    }
    return cl_mem_eq(sa->data, sb->data, sa->len);
}

/*
 * Cl_Map hasher callback for `const char *` keys: loads the stored C-string
 * pointer from key and hashes its contents via cl_hash_cstr.
 *
 * Parameters:
 *   key      (const void *) - Non-NULL pointer to a `const char *` key slot.
 *   key_size (cl_isize)     - Unused (sizeof(const char *) in bytes).
 *
 * Returns:
 *   (cl_u64) 64-bit FNV-1a hash of the C string (or CL_FNV1A_OFFSET_BASIS if
 *            the stored pointer is NULL).
 */
cl_u64 cl_map_hash_cstr(const void *key, cl_isize key_size) {
    CL_UNUSED_VAR(key_size);
    const char *const *sp = (const char *const *)key;
    return cl_hash_cstr(*sp);
}

/*
 * Cl_Map equality callback for `const char *` keys: compares the stored
 * C-string pointers for identity/NULL first, then compares characters using
 * strcmp.
 *
 * Parameters:
 *   a        (const void *) - Non-NULL pointer to the first `const char *` slot.
 *   b        (const void *) - Non-NULL pointer to the second `const char *` slot.
 *   key_size (cl_isize)     - Unused (sizeof(const char *) in bytes).
 *
 * Returns:
 *   (bool) true if both pointers are equal or reference identical NUL-terminated
 *          strings, false otherwise.
 */
bool cl_map_eq_cstr(const void *a, const void *b, cl_isize key_size) {
    CL_UNUSED_VAR(key_size);
    const char *sa = *(const char *const *)a;
    const char *sb = *(const char *const *)b;
    if (sa == sb) {
        return true;
    }
    if (sa == NULL || sb == NULL) {
        return false;
    }
    return strcmp(sa, sb) == 0;
}

/*
 * Cl_Map hasher callback for cl_u64 keys: applies SplitMix64 via
 * cl_hash_u64_mix.
 *
 * Parameters:
 *   key      (const void *) - Non-NULL pointer to a cl_u64 key.
 *   key_size (cl_isize)     - Unused (sizeof(cl_u64) in bytes).
 *
 * Returns:
 *   (cl_u64) SplitMix64-mixed 64-bit hash value.
 */
cl_u64 cl_map_hash_u64(const void *key, cl_isize key_size) {
    CL_UNUSED_VAR(key_size);
    return cl_hash_u64_mix(*(const cl_u64 *)key);
}

/*
 * Cl_Map equality callback for cl_u64 keys.
 *
 * Parameters:
 *   a        (const void *) - Non-NULL pointer to the first cl_u64 key.
 *   b        (const void *) - Non-NULL pointer to the second cl_u64 key.
 *   key_size (cl_isize)     - Unused (sizeof(cl_u64) in bytes).
 *
 * Returns:
 *   (bool) true if *(const cl_u64 *)a == *(const cl_u64 *)b, false otherwise.
 */
bool cl_map_eq_u64(const void *a, const void *b, cl_isize key_size) {
    CL_UNUSED_VAR(key_size);
    return *(const cl_u64 *)a == *(const cl_u64 *)b;
}

/*
 * Cl_Map hasher callback for cl_i64 keys: copies 8 bytes into a cl_u64 via
 * cl_mem_copy (strict-aliasing safe) and mixes with cl_hash_u64_mix.
 *
 * Parameters:
 *   key      (const void *) - Non-NULL pointer to a cl_i64 key.
 *   key_size (cl_isize)     - Unused (sizeof(cl_i64) in bytes).
 *
 * Returns:
 *   (cl_u64) SplitMix64-mixed 64-bit hash of the key's bit pattern.
 */
cl_u64 cl_map_hash_i64(const void *key, cl_isize key_size) {
    CL_UNUSED_VAR(key_size);
    cl_u64 v = 0;
    cl_mem_copy(&v, key, (cl_isize)sizeof(cl_u64));
    return cl_hash_u64_mix(v);
}

/*
 * Cl_Map equality callback for cl_i64 keys.
 *
 * Parameters:
 *   a        (const void *) - Non-NULL pointer to the first cl_i64 key.
 *   b        (const void *) - Non-NULL pointer to the second cl_i64 key.
 *   key_size (cl_isize)     - Unused (sizeof(cl_i64) in bytes).
 *
 * Returns:
 *   (bool) true if *(const cl_i64 *)a == *(const cl_i64 *)b, false otherwise.
 */
bool cl_map_eq_i64(const void *a, const void *b, cl_isize key_size) {
    CL_UNUSED_VAR(key_size);
    return *(const cl_i64 *)a == *(const cl_i64 *)b;
}

/*
 * Cl_Map hasher callback for cl_i32 keys: zero-extends the 32-bit key to
 * cl_u64 via (cl_u64)(cl_u32) and mixes with cl_hash_u64_mix.
 *
 * Parameters:
 *   key      (const void *) - Non-NULL pointer to a cl_i32 key.
 *   key_size (cl_isize)     - Unused (sizeof(cl_i32) in bytes).
 *
 * Returns:
 *   (cl_u64) SplitMix64-mixed 64-bit hash value.
 */
cl_u64 cl_map_hash_i32(const void *key, cl_isize key_size) {
    CL_UNUSED_VAR(key_size);
    return cl_hash_u64_mix((cl_u64)(cl_u32)(*(const cl_i32 *)key));
}

/*
 * Cl_Map equality callback for cl_i32 keys.
 *
 * Parameters:
 *   a        (const void *) - Non-NULL pointer to the first cl_i32 key.
 *   b        (const void *) - Non-NULL pointer to the second cl_i32 key.
 *   key_size (cl_isize)     - Unused (sizeof(cl_i32) in bytes).
 *
 * Returns:
 *   (bool) true if *(const cl_i32 *)a == *(const cl_i32 *)b, false otherwise.
 */
bool cl_map_eq_i32(const void *a, const void *b, cl_isize key_size) {
    CL_UNUSED_VAR(key_size);
    return *(const cl_i32 *)a == *(const cl_i32 *)b;
}
