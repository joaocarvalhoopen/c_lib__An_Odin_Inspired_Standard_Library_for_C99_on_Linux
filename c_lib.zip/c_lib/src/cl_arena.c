/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_arena.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Implementation of Cl_Arena fixed-buffer bump allocator with O(1) in-place
 *   top-allocation resize, temp checkpoints, and AddressSanitizer poisoning.
 * ============================================================================
 */

#include "cl/cl_arena.h"

/*
 * Internal O(1) bump allocation helper for Cl_Arena. Aligns the current bump
 * pointer upward, verifies remaining capacity, updates offset/prev_offset/peak_used,
 * unpoisons the region under ASan, and zeroes or debug-fills the bytes.
 *
 * Parameters:
 *   arena     (Cl_Arena *) - Target arena (returns NULL if NULL or base is NULL).
 *   size      (cl_isize)   - Requested allocation size in bytes (<= 0 returns NULL).
 *   alignment (cl_isize)   - Power-of-two alignment in bytes (<= 0 defaults to CL_DEFAULT_ALIGNMENT).
 *   zeroed    (bool)       - If true, zero-initialize bytes; otherwise paint 0xCD in debug builds.
 *
 * Returns:
 *   (void *) Aligned pointer inside arena->base, or NULL if size <= 0 or capacity is exhausted.
 */
static void *cl_arena_alloc_internal(
    Cl_Arena *arena,
    cl_isize size,
    cl_isize alignment,
    bool zeroed
) {
    if (size <= 0 || arena == NULL || arena->base == NULL) {
        return NULL;
    }
    if (alignment <= 0) {
        alignment = CL_DEFAULT_ALIGNMENT;
    }
    CL_ASSERT(cl_is_power_of_two(alignment));

    cl_uintptr curr_addr = (cl_uintptr)(arena->base + arena->offset);
    cl_isize padding = cl_align_padding(curr_addr, alignment);
    cl_isize aligned_offset = arena->offset + padding;

    if (aligned_offset < 0 || size > (arena->cap - aligned_offset)) {
        return NULL; /* Out of arena capacity */
    }

    void *ptr = arena->base + aligned_offset;
    arena->prev_offset = aligned_offset;
    arena->offset = aligned_offset + size;
    if (arena->offset > arena->peak_used) {
        arena->peak_used = arena->offset;
    }

    /* Unpoison allocated region before touching it */
    CL_ASAN_UNPOISON(ptr, (cl_usize)size);

    if (zeroed) {
        cl_mem_zero(ptr, size);
    }
#ifndef NDEBUG
    else {
        cl_mem_set(ptr, CL_MEM_POISON_ALLOC_UNINIT, size);
    }
#endif

    return ptr;
}

/*
 * Internal resize helper for Cl_Arena. Performs an O(1) in-place grow/shrink
 * when old_memory is the most recent allocation (base + prev_offset); otherwise
 * allocates a fresh block and copies min(old_size, new_size) bytes.
 *
 * Parameters:
 *   arena      (Cl_Arena *) - Target arena.
 *   old_memory (void *)     - Previous pointer in arena, or NULL to allocate fresh memory.
 *   old_size   (cl_isize)   - Previous allocation size in bytes.
 *   new_size   (cl_isize)   - Requested new size in bytes (<= 0 returns NULL).
 *   alignment  (cl_isize)   - Power-of-two alignment in bytes (<= 0 defaults to CL_DEFAULT_ALIGNMENT).
 *   zeroed     (bool)       - If true, zero-initialize newly grown bytes; otherwise paint 0xCD in debug.
 *
 * Returns:
 *   (void *) Pointer to the resized block, or NULL if new_size <= 0 or capacity is exhausted.
 */
static void *cl_arena_resize_internal(
    Cl_Arena *arena,
    void *old_memory,
    cl_isize old_size,
    cl_isize new_size,
    cl_isize alignment,
    bool zeroed
) {
    if (old_memory == NULL) {
        return cl_arena_alloc_internal(arena, new_size, alignment, zeroed);
    }
    if (new_size <= 0) {
        return NULL;
    }
    if (alignment <= 0) {
        alignment = CL_DEFAULT_ALIGNMENT;
    }
    CL_ASSERT(cl_is_power_of_two(alignment));

    /* Check pointer belongs to this arena */
    cl_u8 *old_ptr = (cl_u8 *)old_memory;
    CL_ASSERT(old_ptr >= arena->base && old_ptr < arena->base + arena->cap);

    /* Fast path: if this was the most recent allocation, resize in place! */
    if (old_ptr == arena->base + arena->prev_offset) {
        if (new_size > (arena->cap - arena->prev_offset)) {
            return NULL;
        }
        cl_isize prev_end = arena->offset;
        cl_isize new_end  = arena->prev_offset + new_size;
        arena->offset = new_end;
        if (arena->offset > arena->peak_used) {
            arena->peak_used = arena->offset;
        }

        if (new_size > old_size) {
            cl_isize diff = new_size - old_size;
            CL_ASAN_UNPOISON(old_ptr + old_size, (cl_usize)diff);
            if (zeroed) {
                cl_mem_zero(old_ptr + old_size, diff);
            }
#ifndef NDEBUG
            else {
                cl_mem_set(old_ptr + old_size, CL_MEM_POISON_ALLOC_UNINIT, diff);
            }
#endif
        } else if (new_end < prev_end) {
            cl_isize shrink = prev_end - new_end;
#ifndef NDEBUG
            cl_mem_set(arena->base + new_end, CL_MEM_POISON_FREED, shrink);
#endif
            CL_ASAN_POISON(arena->base + new_end, (cl_usize)shrink);
        }
        return old_memory;
    }

    /* Fallback: allocate new block and copy existing bytes */
    void *new_ptr = cl_arena_alloc_internal(arena, new_size, alignment, zeroed);
    if (new_ptr == NULL) {
        return NULL;
    }
    cl_isize copy_len = (old_size < new_size) ? old_size : new_size;
    cl_mem_copy(new_ptr, old_memory, copy_len);
    return new_ptr;
}

/*
 * Cl_Alloc_Proc dispatch callback for Cl_Arena. Maps ALLOC/ALLOC_NON_ZEROED,
 * RESIZE/RESIZE_NON_ZEROED, and FREE_ALL (via cl_arena_reset); individual FREE
 * is a no-op returning NULL.
 *
 * Parameters:
 *   allocator_data (void *)        - Pointer to the backing Cl_Arena struct.
 *   mode           (Cl_Alloc_Mode) - Requested allocator operation.
 *   size           (cl_isize)      - Requested allocation or resize byte length (bytes).
 *   alignment      (cl_isize)      - Power-of-two alignment in bytes.
 *   old_memory     (void *)        - Existing arena pointer for RESIZE/FREE, or NULL.
 *   old_size       (cl_isize)      - Prior allocation length in bytes.
 *   loc            (Cl_Source_Loc) - Unused caller source location.
 *
 * Returns:
 *   (void *) Pointer to allocated/resized arena block, or NULL on FREE, FREE_ALL, or failure.
 */
static void *cl_arena_alloc_proc(
    void          *allocator_data,
    Cl_Alloc_Mode  mode,
    cl_isize       size,
    cl_isize       alignment,
    void          *old_memory,
    cl_isize       old_size,
    Cl_Source_Loc  loc
) {
    CL_UNUSED_VAR(loc);
    Cl_Arena *arena = (Cl_Arena *)allocator_data;

    switch (mode) {
        case CL_ALLOC_ALLOC:
            return cl_arena_alloc_internal(arena, size, alignment, true);
        case CL_ALLOC_ALLOC_NON_ZEROED:
            return cl_arena_alloc_internal(arena, size, alignment, false);
        case CL_ALLOC_FREE:
            /* Individual free is a no-op on linear arenas */
            return NULL;
        case CL_ALLOC_FREE_ALL:
            cl_arena_reset(arena);
            return NULL;
        case CL_ALLOC_RESIZE:
            return cl_arena_resize_internal(arena, old_memory, old_size, size, alignment, true);
        case CL_ALLOC_RESIZE_NON_ZEROED:
            return cl_arena_resize_internal(arena, old_memory, old_size, size, alignment, false);
    }
    return NULL;
}

/*
 * Initializes a Cl_Arena over a caller-owned buffer and poisons the entire
 * buffer under AddressSanitizer until allocations unpoison subranges.
 *
 * Parameters:
 *   arena  (Cl_Arena *) - Arena struct to initialize; must be non-NULL.
 *   buffer (void *)     - Caller-owned backing memory buffer; must be non-NULL.
 *   cap    (cl_isize)   - Buffer capacity in bytes; must be > 0.
 */
void cl_arena_init_buffer(Cl_Arena *arena, void *buffer, cl_isize cap) {
    CL_ENSURE(arena != NULL);
    CL_ENSURE(buffer != NULL && cap > 0);
    CL_ZERO_STRUCT(arena);
    arena->base = (cl_u8 *)buffer;
    arena->cap  = cap;
    CL_ASAN_POISON(arena->base, (cl_usize)cap);
}

/*
 * Initializes a Cl_Arena by allocating cap bytes from backing with
 * CL_DEFAULT_ALIGNMENT and poisoning the newly allocated buffer under ASan.
 *
 * Parameters:
 *   arena   (Cl_Arena *)   - Arena struct to initialize; must be non-NULL.
 *   cap     (cl_isize)     - Capacity to allocate in bytes; must be > 0.
 *   backing (Cl_Allocator) - Allocator used to allocate and later free the buffer.
 *
 * Returns:
 *   (bool) true if the backing buffer was allocated; false on OOM.
 */
bool cl_arena_init_alloc(Cl_Arena *arena, cl_isize cap, Cl_Allocator backing) {
    CL_ENSURE(arena != NULL);
    CL_ENSURE(cap > 0);
    CL_ZERO_STRUCT(arena);
    void *buf = cl_alloc_non_zeroed_aligned_loc(backing, cap, CL_DEFAULT_ALIGNMENT, CL_HERE);
    if (buf == NULL) {
        return false;
    }
    arena->base = (cl_u8 *)buf;
    arena->cap = cap;
    arena->backing_alloc = backing;
    CL_ASAN_POISON(arena->base, (cl_usize)cap);
    return true;
}

/*
 * Unpoisons the arena buffer, releases it via backing_alloc if owned, and
 * zeroes all fields of the Cl_Arena descriptor; safe no-op if arena is NULL.
 *
 * Parameters:
 *   arena (Cl_Arena *) - Arena to destroy (may be NULL).
 */
void cl_arena_destroy(Cl_Arena *arena) {
    if (arena == NULL) {
        return;
    }
    if (arena->base != NULL) {
        /* Always unpoison before releasing buffer back to stack or heap */
        CL_ASAN_UNPOISON(arena->base, (cl_usize)arena->cap);
        if (cl_allocator_is_valid(arena->backing_alloc)) {
            cl_free_loc(arena->backing_alloc, arena->base, arena->cap, CL_HERE);
        }
    }
    CL_ZERO_STRUCT(arena);
}

/*
 * Resets offset, prev_offset, and temp_count to 0 in O(1), scrubbing previously
 * used bytes with CL_MEM_POISON_FREED in debug builds and re-poisoning the full
 * capacity under AddressSanitizer.
 *
 * Parameters:
 *   arena (Cl_Arena *) - Arena to reset (safe no-op if NULL or base is NULL).
 */
void cl_arena_reset(Cl_Arena *arena) {
    if (arena == NULL || arena->base == NULL) {
        return;
    }
#ifndef NDEBUG
    /* Unpoison active region before scrubbing with freed pattern */
    if (arena->offset > 0) {
        CL_ASAN_UNPOISON(arena->base, (cl_usize)arena->offset);
        cl_mem_set(arena->base, CL_MEM_POISON_FREED, arena->offset);
    }
#endif
    arena->offset = 0;
    arena->prev_offset = 0;
    arena->temp_count = 0;
    CL_ASAN_POISON(arena->base, (cl_usize)arena->cap);
}

/*
 * Wraps a Cl_Arena pointer into a polymorphic Cl_Allocator handle.
 *
 * Parameters:
 *   arena (Cl_Arena *) - Arena to wrap; must be non-NULL.
 *
 * Returns:
 *   (Cl_Allocator) Allocator handle with proc = cl_arena_alloc_proc and data = arena.
 */
Cl_Allocator cl_arena_allocator(Cl_Arena *arena) {
    CL_ENSURE(arena != NULL);
    return (Cl_Allocator){ cl_arena_alloc_proc, arena };
}

/*
 * Captures the current offset and prev_offset of arena into a Cl_Arena_Temp
 * checkpoint and increments arena->temp_count.
 *
 * Parameters:
 *   arena (Cl_Arena *) - Arena to checkpoint; must be non-NULL.
 *
 * Returns:
 *   (Cl_Arena_Temp) Checkpoint value to pass to cl_arena_temp_end().
 */
Cl_Arena_Temp cl_arena_temp_begin(Cl_Arena *arena) {
    CL_ENSURE(arena != NULL);
    arena->temp_count += 1;
    return (Cl_Arena_Temp){
        arena,
        arena->offset,
        arena->prev_offset
    };
}

/*
 * Restores an arena to its saved checkpoint offset and prev_offset in O(1),
 * scrubbing rewound bytes with CL_MEM_POISON_FREED in debug builds, poisoning
 * them under ASan, and decrementing temp_count.
 *
 * Parameters:
 *   temp (Cl_Arena_Temp) - Saved checkpoint from cl_arena_temp_begin()
 *                          (safe no-op if temp.arena is NULL).
 */
void cl_arena_temp_end(Cl_Arena_Temp temp) {
    if (temp.arena == NULL) {
        return;
    }
    Cl_Arena *arena = temp.arena;
    CL_ASSERT(arena->offset >= temp.saved_offset);
    cl_isize rewound = arena->offset - temp.saved_offset;
    if (rewound > 0) {
#ifndef NDEBUG
        CL_ASAN_UNPOISON(arena->base + temp.saved_offset, (cl_usize)rewound);
        cl_mem_set(arena->base + temp.saved_offset, CL_MEM_POISON_FREED, rewound);
#endif
        CL_ASAN_POISON(arena->base + temp.saved_offset, (cl_usize)rewound);
    }
    arena->offset = temp.saved_offset;
    arena->prev_offset = temp.saved_prev_offset;
    if (arena->temp_count > 0) {
        arena->temp_count -= 1;
    }
}
