/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_slice.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Implementation of generic slice algorithms (copy, reverse, equal, sort,
 *   binary search) and built-in primitive/string comparators.
 * ============================================================================
 */

#include "cl/cl_slice.h"
#include <stdlib.h>

/*
 * Copies min(dst_len, src_len) elements from src_data into dst_data using
 * overlap-safe cl_mem_move.
 *
 * Parameters:
 *   dst_data  (void *)       - Destination element buffer (may overlap src).
 *   dst_len   (cl_isize)     - Destination slice length (elements).
 *   src_data  (const void *) - Source element buffer.
 *   src_len   (cl_isize)     - Source slice length (elements).
 *   elem_size (cl_isize)     - Size of a single element (bytes; must be > 0).
 *
 * Returns:
 *   (cl_isize) Number of elements copied (elements), or 0 if any length or
 *              elem_size is <= 0 or either pointer is NULL.
 */
cl_isize cl_slice_copy_raw(
    void *dst_data,
    cl_isize dst_len,
    const void *src_data,
    cl_isize src_len,
    cl_isize elem_size
) {
    if (dst_len <= 0 || src_len <= 0 || elem_size <= 0 || dst_data == NULL || src_data == NULL) {
        return 0;
    }
    cl_isize count = (dst_len < src_len) ? dst_len : src_len;
    cl_mem_move(dst_data, src_data, count * elem_size);
    return count;
}

/*
 * Reverses len elements of elem_size bytes in place using a two-pointer swap.
 * Uses a 256-byte stack scratch buffer when elem_size <= 256 bytes and falls
 * back to malloc/free for larger elements.
 *
 * Parameters:
 *   data      (void *)   - Pointer to the element buffer to reverse.
 *   len       (cl_isize) - Number of elements in the slice (elements).
 *   elem_size (cl_isize) - Size of a single element (bytes; must be > 0).
 */
void cl_slice_reverse_raw(void *data, cl_isize len, cl_isize elem_size) {
    if (data == NULL || len <= 1 || elem_size <= 0) {
        return;
    }
    cl_u8 *bytes = (cl_u8 *)data;
    cl_u8 stack_tmp[256];
    cl_u8 *tmp = (elem_size <= (cl_isize)sizeof(stack_tmp))
                     ? stack_tmp
                     : (cl_u8 *)malloc((cl_usize)elem_size);
    if (tmp == NULL) {
        return;
    }

    cl_isize lo = 0;
    cl_isize hi = len - 1;
    while (lo < hi) {
        cl_u8 *a = bytes + lo * elem_size;
        cl_u8 *b = bytes + hi * elem_size;
        cl_mem_copy(tmp, a, elem_size);
        cl_mem_copy(a, b, elem_size);
        cl_mem_copy(b, tmp, elem_size);
        lo += 1;
        hi -= 1;
    }

    if (tmp != stack_tmp) {
        free(tmp);
    }
}

/*
 * Compares two plain-old-data (POD) element buffers for bytewise equality.
 *
 * Parameters:
 *   a_data    (const void *) - First element buffer.
 *   a_len     (cl_isize)     - First slice length (elements).
 *   b_data    (const void *) - Second element buffer.
 *   b_len     (cl_isize)     - Second slice length (elements).
 *   elem_size (cl_isize)     - Size of a single element (bytes).
 *
 * Returns:
 *   (bool) true if a_len == b_len and either a_len <= 0, elem_size <= 0, or
 *          all (a_len * elem_size) bytes match; false otherwise.
 */
bool cl_slice_equal_raw(
    const void *a_data,
    cl_isize a_len,
    const void *b_data,
    cl_isize b_len,
    cl_isize elem_size
) {
    if (a_len != b_len) {
        return false;
    }
    if (a_len <= 0 || elem_size <= 0) {
        return true;
    }
    return cl_mem_eq(a_data, b_data, a_len * elem_size);
}

/*
 * Sorts len elements in place using libc qsort after guarding invalid or
 * trivially sorted inputs (len <= 1).
 *
 * Parameters:
 *   data      (void *)      - Pointer to the element buffer to sort.
 *   len       (cl_isize)    - Number of elements to sort (elements).
 *   elem_size (cl_isize)    - Size of a single element (bytes; must be > 0).
 *   cmp       (Cl_Cmp_Proc) - Three-way comparator callback.
 */
void cl_slice_sort_raw(void *data, cl_isize len, cl_isize elem_size, Cl_Cmp_Proc cmp) {
    if (data == NULL || len <= 1 || elem_size <= 0 || cmp == NULL) {
        return;
    }
    qsort(data, (cl_usize)len, (cl_usize)elem_size, cmp);
}

/*
 * Performs iterative binary search over a slice sorted in ascending order per
 * cmp, using overflow-safe midpoint computation lo + (hi - lo) / 2.
 *
 * Parameters:
 *   data      (const void *) - Pointer to the sorted element buffer.
 *   len       (cl_isize)     - Number of elements in the slice (elements).
 *   elem_size (cl_isize)     - Size of a single element (bytes; must be > 0).
 *   key       (const void *) - Pointer to the target key element.
 *   cmp       (Cl_Cmp_Proc)  - Comparator matching the slice's sort order.
 *
 * Returns:
 *   (cl_isize) 0-based element index in [0, len) of a matching element, or -1
 *              if absent or any argument is invalid.
 */
cl_isize cl_slice_bsearch_raw(
    const void *data,
    cl_isize len,
    cl_isize elem_size,
    const void *key,
    Cl_Cmp_Proc cmp
) {
    if (data == NULL || len <= 0 || elem_size <= 0 || key == NULL || cmp == NULL) {
        return -1;
    }
    const cl_u8 *bytes = (const cl_u8 *)data;
    cl_isize lo = 0;
    cl_isize hi = len - 1;
    while (lo <= hi) {
        cl_isize mid = lo + (hi - lo) / 2;
        int c = cmp(bytes + mid * elem_size, key);
        if (c == 0) {
            return mid;
        }
        if (c < 0) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

/* ----------------------------------------------------------------------------
 * Standard Comparators
 * ---------------------------------------------------------------------------- */

/*
 * Overflow-safe ascending comparator for cl_i32 values.
 *
 * Parameters:
 *   a (const void *) - Non-NULL pointer to a cl_i32 element.
 *   b (const void *) - Non-NULL pointer to a cl_i32 element.
 *
 * Returns:
 *   (int) -1 if *a < *b, 0 if *a == *b, or +1 if *a > *b.
 */
int cl_cmp_i32(const void *a, const void *b) {
    cl_i32 va = *(const cl_i32 *)a;
    cl_i32 vb = *(const cl_i32 *)b;
    return (va > vb) - (va < vb);
}

/*
 * Overflow-safe ascending comparator for cl_i64 values.
 *
 * Parameters:
 *   a (const void *) - Non-NULL pointer to a cl_i64 element.
 *   b (const void *) - Non-NULL pointer to a cl_i64 element.
 *
 * Returns:
 *   (int) -1 if *a < *b, 0 if *a == *b, or +1 if *a > *b.
 */
int cl_cmp_i64(const void *a, const void *b) {
    cl_i64 va = *(const cl_i64 *)a;
    cl_i64 vb = *(const cl_i64 *)b;
    return (va > vb) - (va < vb);
}

/*
 * Overflow-safe ascending comparator for cl_u64 values.
 *
 * Parameters:
 *   a (const void *) - Non-NULL pointer to a cl_u64 element.
 *   b (const void *) - Non-NULL pointer to a cl_u64 element.
 *
 * Returns:
 *   (int) -1 if *a < *b, 0 if *a == *b, or +1 if *a > *b.
 */
int cl_cmp_u64(const void *a, const void *b) {
    cl_u64 va = *(const cl_u64 *)a;
    cl_u64 vb = *(const cl_u64 *)b;
    return (va > vb) - (va < vb);
}

/*
 * Overflow-safe ascending comparator for cl_isize values.
 *
 * Parameters:
 *   a (const void *) - Non-NULL pointer to a cl_isize element.
 *   b (const void *) - Non-NULL pointer to a cl_isize element.
 *
 * Returns:
 *   (int) -1 if *a < *b, 0 if *a == *b, or +1 if *a > *b.
 */
int cl_cmp_isize(const void *a, const void *b) {
    cl_isize va = *(const cl_isize *)a;
    cl_isize vb = *(const cl_isize *)b;
    return (va > vb) - (va < vb);
}

/*
 * Ascending comparator for cl_f32 values. Inputs must be non-NaN to satisfy
 * strict weak ordering.
 *
 * Parameters:
 *   a (const void *) - Non-NULL pointer to a cl_f32 element.
 *   b (const void *) - Non-NULL pointer to a cl_f32 element.
 *
 * Returns:
 *   (int) -1 if *a < *b, 0 if *a == *b, or +1 if *a > *b.
 */
int cl_cmp_f32(const void *a, const void *b) {
    cl_f32 va = *(const cl_f32 *)a;
    cl_f32 vb = *(const cl_f32 *)b;
    return (va > vb) - (va < vb);
}

/*
 * Ascending comparator for cl_f64 values. Inputs must be non-NaN to satisfy
 * strict weak ordering.
 *
 * Parameters:
 *   a (const void *) - Non-NULL pointer to a cl_f64 element.
 *   b (const void *) - Non-NULL pointer to a cl_f64 element.
 *
 * Returns:
 *   (int) -1 if *a < *b, 0 if *a == *b, or +1 if *a > *b.
 */
int cl_cmp_f64(const void *a, const void *b) {
    cl_f64 va = *(const cl_f64 *)a;
    cl_f64 vb = *(const cl_f64 *)b;
    return (va > vb) - (va < vb);
}

/*
 * Ascending lexicographical comparator for Cl_Str descriptors. Compares the
 * first min(sa->len, sb->len) bytes via cl_mem_cmp and breaks ties by byte
 * length.
 *
 * Parameters:
 *   a (const void *) - Non-NULL pointer to a Cl_Str descriptor.
 *   b (const void *) - Non-NULL pointer to a Cl_Str descriptor.
 *
 * Returns:
 *   (int) Negative if *a < *b, 0 if *a == *b, or positive if *a > *b.
 */
int cl_cmp_str(const void *a, const void *b) {
    const Cl_Str *sa = (const Cl_Str *)a;
    const Cl_Str *sb = (const Cl_Str *)b;
    cl_isize min_len = (sa->len < sb->len) ? sa->len : sb->len;
    if (min_len > 0) {
        int c = cl_mem_cmp(sa->data, sb->data, min_len);
        if (c != 0) {
            return c;
        }
    }
    return (sa->len > sb->len) - (sa->len < sb->len);
}
