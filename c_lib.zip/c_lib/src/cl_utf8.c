/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_utf8.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   RFC 3629 strict UTF-8 rune encoding, decoding, validation, and counting.
 * ============================================================================
 */

#include "cl/cl_utf8.h"

/*
 * Function: cl_utf8_is_valid_rune
 * Purpose:
 *   Checks whether a code point is a valid Unicode scalar value allowed by
 *   RFC 3629 UTF-8 (within [0, CL_RUNE_MAX] and outside UTF-16 surrogates).
 * Parameters:
 *   r (cl_rune): Unicode code point to validate.
 * Returns:
 *   bool: true if r is a valid Unicode scalar value; false otherwise.
 */
bool cl_utf8_is_valid_rune(cl_rune r) {
    if (r < 0 || r > CL_RUNE_MAX) {
        return false;
    }
    if (r >= 0xD800 && r <= 0xDFFF) {
        return false; /* UTF-16 surrogates are forbidden in UTF-8 */
    }
    return true;
}

/*
 * Function: cl_utf8_rune_width
 * Purpose:
 *   Determines how many UTF-8 bytes are required to encode a Unicode code
 *   point; returns 3 bytes for invalid code points (width of U+FFFD).
 * Parameters:
 *   r (cl_rune): Unicode code point to measure.
 * Returns:
 *   cl_isize: Encoded length in bytes, in the range [1, 4].
 */
cl_isize cl_utf8_rune_width(cl_rune r) {
    if (!cl_utf8_is_valid_rune(r)) {
        return 3; /* Replacement character U+FFFD takes 3 bytes */
    }
    if (r <= 0x7F)    return 1;
    if (r <= 0x7FF)   return 2;
    if (r <= 0xFFFF)  return 3;
    return 4;
}

/*
 * Function: cl_utf8_encode_rune
 * Purpose:
 *   Encodes a Unicode scalar value into 1 to 4 UTF-8 bytes following RFC 3629.
 *   Invalid scalar values are silently replaced with CL_RUNE_ERROR (U+FFFD).
 * Parameters:
 *   r (cl_rune): Unicode code point to encode.
 *   out (cl_u8[4]): Destination buffer of at least 4 bytes; must be non-NULL.
 * Returns:
 *   cl_isize: Number of bytes written to out, in [1, 4] bytes.
 */
cl_isize cl_utf8_encode_rune(cl_rune r, cl_u8 out[4]) {
    if (!cl_utf8_is_valid_rune(r)) {
        r = CL_RUNE_ERROR;
    }
    cl_u32 cp = (cl_u32)r;
    if (cp <= 0x7Fu) {
        out[0] = (cl_u8)cp;
        return 1;
    }
    if (cp <= 0x7FFu) {
        out[0] = (cl_u8)(0xC0u | (cp >> 6));
        out[1] = (cl_u8)(0x80u | (cp & 0x3Fu));
        return 2;
    }
    if (cp <= 0xFFFFu) {
        out[0] = (cl_u8)(0xE0u | (cp >> 12));
        out[1] = (cl_u8)(0x80u | ((cp >> 6) & 0x3Fu));
        out[2] = (cl_u8)(0x80u | (cp & 0x3Fu));
        return 3;
    }
    out[0] = (cl_u8)(0xF0u | (cp >> 18));
    out[1] = (cl_u8)(0x80u | ((cp >> 12) & 0x3Fu));
    out[2] = (cl_u8)(0x80u | ((cp >> 6) & 0x3Fu));
    out[3] = (cl_u8)(0x80u | (cp & 0x3Fu));
    return 4;
}

/*
 * Function: cl_utf8_decode_rune
 * Purpose:
 *   Decodes the leading RFC 3629 UTF-8 sequence from a byte slice, rejecting
 *   overlong forms, surrogates, invalid continuation bytes, truncation, and
 *   code points exceeding CL_RUNE_MAX.
 * Parameters:
 *   s (Cl_Str): Source UTF-8 byte slice (data pointer and length in bytes).
 * Returns:
 *   Cl_Utf8_Decode: { codepoint (cl_rune), width (cl_isize, bytes), valid
 *     (bool) }. Returns { 0, 0, false } for empty/NULL input, { cp, 1..4, true }
 *     for valid runes, and { CL_RUNE_ERROR, 1, false } for invalid sequences.
 */
Cl_Utf8_Decode cl_utf8_decode_rune(Cl_Str s) {
    if (s.data == NULL || s.len <= 0) {
        return (Cl_Utf8_Decode){ 0, 0, false };
    }

    cl_u8 b0 = s.data[0];
    if (b0 < 0x80u) {
        return (Cl_Utf8_Decode){ (cl_rune)b0, 1, true };
    }

    /* 2-byte sequence: 110xxxxx 10xxxxxx (0x80 .. 0x7FF) */
    if ((b0 & 0xE0u) == 0xC0u) {
        if (s.len < 2) {
            return (Cl_Utf8_Decode){ CL_RUNE_ERROR, 1, false };
        }
        cl_u8 b1 = s.data[1];
        if ((b1 & 0xC0u) != 0x80u) {
            return (Cl_Utf8_Decode){ CL_RUNE_ERROR, 1, false };
        }
        cl_rune cp = (cl_rune)(((cl_u32)(b0 & 0x1Fu) << 6) | (cl_u32)(b1 & 0x3Fu));
        if (cp < 0x80) {
            return (Cl_Utf8_Decode){ CL_RUNE_ERROR, 1, false }; /* Overlong */
        }
        return (Cl_Utf8_Decode){ cp, 2, true };
    }

    /* 3-byte sequence: 1110xxxx 10xxxxxx 10xxxxxx (0x800 .. 0xFFFF) */
    if ((b0 & 0xF0u) == 0xE0u) {
        if (s.len < 3) {
            return (Cl_Utf8_Decode){ CL_RUNE_ERROR, 1, false };
        }
        cl_u8 b1 = s.data[1];
        cl_u8 b2 = s.data[2];
        if ((b1 & 0xC0u) != 0x80u || (b2 & 0xC0u) != 0x80u) {
            return (Cl_Utf8_Decode){ CL_RUNE_ERROR, 1, false };
        }
        cl_rune cp = (cl_rune)(
            ((cl_u32)(b0 & 0x0Fu) << 12) |
            ((cl_u32)(b1 & 0x3Fu) << 6)  |
            ((cl_u32)(b2 & 0x3Fu))
        );
        if (cp < 0x800 || (cp >= 0xD800 && cp <= 0xDFFF)) {
            return (Cl_Utf8_Decode){ CL_RUNE_ERROR, 1, false }; /* Overlong or surrogate */
        }
        return (Cl_Utf8_Decode){ cp, 3, true };
    }

    /* 4-byte sequence: 11110xxx 10xxxxxx 10xxxxxx 10xxxxxx (0x10000 .. 0x10FFFF) */
    if ((b0 & 0xF8u) == 0xF0u) {
        if (s.len < 4) {
            return (Cl_Utf8_Decode){ CL_RUNE_ERROR, 1, false };
        }
        cl_u8 b1 = s.data[1];
        cl_u8 b2 = s.data[2];
        cl_u8 b3 = s.data[3];
        if ((b1 & 0xC0u) != 0x80u || (b2 & 0xC0u) != 0x80u || (b3 & 0xC0u) != 0x80u) {
            return (Cl_Utf8_Decode){ CL_RUNE_ERROR, 1, false };
        }
        cl_rune cp = (cl_rune)(
            ((cl_u32)(b0 & 0x07u) << 18) |
            ((cl_u32)(b1 & 0x3Fu) << 12) |
            ((cl_u32)(b2 & 0x3Fu) << 6)  |
            ((cl_u32)(b3 & 0x3Fu))
        );
        if (cp < 0x10000 || cp > CL_RUNE_MAX) {
            return (Cl_Utf8_Decode){ CL_RUNE_ERROR, 1, false }; /* Overlong or > U+10FFFF */
        }
        return (Cl_Utf8_Decode){ cp, 4, true };
    }

    return (Cl_Utf8_Decode){ CL_RUNE_ERROR, 1, false };
}

/*
 * Function: cl_utf8_valid
 * Purpose:
 *   Scans an entire byte slice and checks that every sequence decodes as
 *   strictly valid RFC 3629 UTF-8.
 * Parameters:
 *   s (Cl_Str): Input byte slice (length in bytes).
 * Returns:
 *   bool: true if all bytes form valid UTF-8 sequences (including empty
 *     strings); false on the first invalid byte sequence.
 */
bool cl_utf8_valid(Cl_Str s) {
    cl_isize off = 0;
    while (off < s.len) {
        Cl_Str rem = { s.data + off, s.len - off };
        Cl_Utf8_Decode d = cl_utf8_decode_rune(rem);
        if (!d.valid) {
            return false;
        }
        off += d.width;
    }
    return true;
}

/*
 * Function: cl_utf8_rune_count
 * Purpose:
 *   Counts the number of Unicode runes in a byte slice, advancing 1 byte per
 *   malformed byte so invalid input still terminates in O(n) time.
 * Parameters:
 *   s (Cl_Str): Input byte slice (length in bytes).
 * Returns:
 *   cl_isize: Total count of decoded runes (and replacement bytes), >= 0.
 */
cl_isize cl_utf8_rune_count(Cl_Str s) {
    cl_isize count = 0;
    cl_isize off = 0;
    while (off < s.len) {
        Cl_Str rem = { s.data + off, s.len - off };
        Cl_Utf8_Decode d = cl_utf8_decode_rune(rem);
        off += (d.width > 0) ? d.width : 1;
        count += 1;
    }
    return count;
}
