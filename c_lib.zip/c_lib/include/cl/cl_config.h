/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_config.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Compile-time configuration, compiler/platform detection, and safely
 *   guarded GCC/Clang/ASan primitives that preserve strict ISO C99
 *   (-std=c99 -Wall -Wextra -Wpedantic -Werror) compatibility.
 *
 * Key Build Macros (override via compiler flags, e.g. -DCL_BOUNDS_CHECK=0):
 *   CL_BOUNDS_CHECK         - 1 to enable bounds checking (default: 1 in debug,
 *                             0 when NDEBUG is defined).
 *   CL_BOUNDS_CHECK_TRAP    - 1 to issue __builtin_trap() on failed bounds
 *                             checks / asserts so GDB stops at the exact frame.
 *   CL_ENABLE_BACKTRACE     - 1 to print glibc backtrace() on Linux panics
 *                             (default: 1 on __linux__ && __GLIBC__).
 *   CL_LOG_MIN_LEVEL        - Compile-time minimum log level (0=DEBUG..4=FATAL,
 *                             5=NONE). Lower levels compile away completely.
 *   CL_ENABLE_THREAD_SAFETY - 1 to guard logger / global state with pthreads
 *                             (default: 1 on Linux).
 *   CL_SHORT_NAMES          - Define before including <cl/cl.h> to also expose
 *                             unprefixed Odin-style aliases via cl_short.h.
 * ============================================================================
 */

#ifndef CL_CONFIG_H
#define CL_CONFIG_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* ----------------------------------------------------------------------------
 * Version
 * ---------------------------------------------------------------------------- */

/*
 * Semantic library major version number (dimensionless integer).
 */
#define CL_VERSION_MAJOR 1

/*
 * Semantic library minor version number (dimensionless integer).
 */
#define CL_VERSION_MINOR 0

/*
 * Semantic library patch version number (dimensionless integer).
 */
#define CL_VERSION_PATCH 0

/* ----------------------------------------------------------------------------
 * Compiler & Platform Detection
 * ---------------------------------------------------------------------------- */
#if defined(__clang__)
    /*
     * Compile-time flag (int, 0 or 1): 1 when compiling with Clang.
     */
    #define CL_COMPILER_CLANG 1

    /*
     * Compile-time flag (int, 0 or 1): 0 because Clang is active rather than GCC.
     */
    #define CL_COMPILER_GCC   0
#elif defined(__GNUC__)
    /*
     * Compile-time flag (int, 0 or 1): 0 because GCC is active rather than Clang.
     */
    #define CL_COMPILER_CLANG 0

    /*
     * Compile-time flag (int, 0 or 1): 1 when compiling with GCC.
     */
    #define CL_COMPILER_GCC   1
#else
    /*
     * Compile-time flag (int, 0 or 1): 0 when compiling with a non-Clang compiler.
     */
    #define CL_COMPILER_CLANG 0

    /*
     * Compile-time flag (int, 0 or 1): 0 when compiling with a non-GCC compiler.
     */
    #define CL_COMPILER_GCC   0
#endif

#if CL_COMPILER_GCC || CL_COMPILER_CLANG
    /*
     * Compile-time flag (int, 0 or 1): 1 when GCC/Clang GNU C extensions are available.
     */
    #define CL_COMPILER_GNU_COMPAT 1
#else
    /*
     * Compile-time flag (int, 0 or 1): 0 when GNU C extensions are unavailable.
     */
    #define CL_COMPILER_GNU_COMPAT 0
#endif

#if defined(__linux__)
    /*
     * Compile-time platform flag (int, 0 or 1): 1 when targeting Linux.
     */
    #define CL_OS_LINUX 1
#else
    /*
     * Compile-time platform flag (int, 0 or 1): 0 when targeting a non-Linux OS.
     */
    #define CL_OS_LINUX 0
#endif

/* ----------------------------------------------------------------------------
 * Sanitizer Detection (AddressSanitizer / UndefinedBehaviorSanitizer)
 * ---------------------------------------------------------------------------- */
#if defined(__SANITIZE_ADDRESS__)
    /*
     * Compile-time flag (int, 0 or 1): 1 when AddressSanitizer is enabled (GCC/MSVC).
     */
    #define CL_ASAN_ENABLED 1
#elif defined(__has_feature)
    #if __has_feature(address_sanitizer)
        /*
         * Compile-time flag (int, 0 or 1): 1 when AddressSanitizer is enabled (Clang).
         */
        #define CL_ASAN_ENABLED 1
    #else
        /*
         * Compile-time flag (int, 0 or 1): 0 when AddressSanitizer is disabled (Clang).
         */
        #define CL_ASAN_ENABLED 0
    #endif
#else
    /*
     * Compile-time flag (int, 0 or 1): 0 when AddressSanitizer is not detected.
     */
    #define CL_ASAN_ENABLED 0
#endif

/* ----------------------------------------------------------------------------
 * Toggleable Bounds Checking & Debug Controls
 *
 * Defaults:
 *   - Debug builds (NDEBUG not defined): CL_BOUNDS_CHECK = 1
 *   - Release builds (NDEBUG defined):   CL_BOUNDS_CHECK = 0
 * Users can override explicitly with -DCL_BOUNDS_CHECK=1 or -DCL_BOUNDS_CHECK=0.
 * ---------------------------------------------------------------------------- */
#ifndef CL_BOUNDS_CHECK
    #ifdef NDEBUG
        /*
         * Bounds-check toggle (int, 0 or 1): defaults to 0 (disabled) when NDEBUG is set.
         */
        #define CL_BOUNDS_CHECK 0
    #else
        /*
         * Bounds-check toggle (int, 0 or 1): defaults to 1 (enabled) in debug builds.
         */
        #define CL_BOUNDS_CHECK 1
    #endif
#endif

#ifndef CL_BOUNDS_CHECK_TRAP
    #ifdef NDEBUG
        /*
         * Trap-on-failure toggle (int, 0 or 1): defaults to 0 (call abort) when NDEBUG is set.
         */
        #define CL_BOUNDS_CHECK_TRAP 0
    #else
        /*
         * Trap-on-failure toggle (int, 0 or 1): defaults to 1 (emit hardware trap) in debug builds.
         */
        #define CL_BOUNDS_CHECK_TRAP 1
    #endif
#endif

#ifndef CL_ENABLE_BACKTRACE
    #if CL_OS_LINUX && defined(__GLIBC__)
        /*
         * Backtrace toggle (int, 0 or 1): defaults to 1 on Linux with glibc execinfo support.
         */
        #define CL_ENABLE_BACKTRACE 1
    #else
        /*
         * Backtrace toggle (int, 0 or 1): defaults to 0 when glibc backtrace is unavailable.
         */
        #define CL_ENABLE_BACKTRACE 0
    #endif
#endif

#ifndef CL_ENABLE_THREAD_SAFETY
    #if CL_OS_LINUX
        /*
         * Thread-safety toggle (int, 0 or 1): defaults to 1 on Linux to guard shared state with pthreads.
         */
        #define CL_ENABLE_THREAD_SAFETY 1
    #else
        /*
         * Thread-safety toggle (int, 0 or 1): defaults to 0 on non-Linux targets.
         */
        #define CL_ENABLE_THREAD_SAFETY 0
    #endif
#endif

#ifndef CL_LOG_MIN_LEVEL
    #ifdef NDEBUG
        /*
         * Compile-time minimum log severity level (int, 0=DEBUG..4=FATAL, 5=NONE):
         * defaults to 1 (INFO and above) in release builds.
         */
        #define CL_LOG_MIN_LEVEL 1
    #else
        /*
         * Compile-time minimum log severity level (int, 0=DEBUG..4=FATAL, 5=NONE):
         * defaults to 0 (DEBUG and above) in debug builds.
         */
        #define CL_LOG_MIN_LEVEL 0
    #endif
#endif

/* ----------------------------------------------------------------------------
 * Compiler Primitives & Attributes (Strictly C99 -Wpedantic Safe)
 * ---------------------------------------------------------------------------- */
#if CL_COMPILER_GNU_COMPAT
    /*
     * Prefix keyword that silences -Wpedantic warnings on intentionally guarded GNU C extensions.
     */
    #define CL_EXTENSION        __extension__

    /*
     * Branch-prediction hint indicating a boolean condition is expected to be true.
     *
     * Parameters:
     *   x (scalar expression) - Condition evaluated to truthy (non-zero) or falsy (zero).
     *
     * Returns:
     *   long - Normalized boolean value (1 if x != 0, 0 otherwise).
     */
    #define CL_LIKELY(x)        __builtin_expect(!!(x), 1)

    /*
     * Branch-prediction hint indicating a boolean condition is expected to be false.
     *
     * Parameters:
     *   x (scalar expression) - Condition evaluated to truthy (non-zero) or falsy (zero).
     *
     * Returns:
     *   long - Normalized boolean value (1 if x != 0, 0 otherwise).
     */
    #define CL_UNLIKELY(x)      __builtin_expect(!!(x), 0)

    /*
     * Function linkage and attribute specifier forcing inline expansion under GCC/Clang.
     */
    #define CL_INLINE           static inline __attribute__((always_inline))

    /*
     * Function attribute preventing inline expansion (used on cold failure paths).
     */
    #define CL_NOINLINE         __attribute__((noinline))

    /*
     * Function attribute indicating the function never returns to its caller.
     */
    #define CL_NORETURN         __attribute__((noreturn))

    /*
     * Function attribute emitting a warning if the caller discards the return value.
     */
    #define CL_NODISCARD        __attribute__((warn_unused_result))

    /*
     * Variable or function attribute suppressing unused-entity compiler warnings.
     */
    #define CL_UNUSED           __attribute__((unused))

    /*
     * Function attribute enabling compile-time printf format-string validation.
     *
     * Parameters:
     *   f (int, 1-based parameter index) - Position of the printf format string parameter.
     *   a (int, 1-based parameter index) - Position of the first variadic argument (or 0 for vprintf).
     */
    #define CL_PRINTF_LIKE(f,a) __attribute__((format(printf, f, a)))

    /*
     * Variable attribute attaching a scope-exit cleanup callback under GCC/Clang.
     *
     * Parameters:
     *   fn (function identifier) - Cleanup function with signature void fn(T *var_ptr).
     */
    #define CL_CLEANUP(fn)      __attribute__((cleanup(fn)))

    /*
     * Emits a target-specific hardware trap instruction to halt execution cleanly in a debugger.
     */
    #define CL_TRAP()           __builtin_trap()

    /*
     * Hints to the optimizer that execution can never reach this point (undefined behavior if reached).
     */
    #define CL_UNREACHABLE_HW() __builtin_unreachable()

    /*
     * Feature flag (int, 0 or 1): 1 when GCC/Clang __typeof__ is available.
     */
    #define CL_HAVE_TYPEOF      1

    /*
     * Feature flag (int, 0 or 1): 1 when GCC/Clang statement expressions ({ ... }) are available.
     */
    #define CL_HAVE_STMT_EXPR   1

    /*
     * Feature flag (int, 0 or 1): 1 when __attribute__((cleanup)) is available.
     */
    #define CL_HAVE_CLEANUP     1
#else
    /*
     * No-op fallback for CL_EXTENSION on non-GNU compilers.
     */
    #define CL_EXTENSION

    /*
     * Portable fallback branch-prediction hint without compiler builtin support.
     *
     * Parameters:
     *   x (scalar expression) - Condition evaluated to truthy (non-zero) or falsy (zero).
     *
     * Returns:
     *   int - Normalized boolean value (1 if x != 0, 0 otherwise).
     */
    #define CL_LIKELY(x)        (!!(x))

    /*
     * Portable fallback branch-prediction hint without compiler builtin support.
     *
     * Parameters:
     *   x (scalar expression) - Condition evaluated to truthy (non-zero) or falsy (zero).
     *
     * Returns:
     *   int - Normalized boolean value (1 if x != 0, 0 otherwise).
     */
    #define CL_UNLIKELY(x)      (!!(x))

    /*
     * Portable inline linkage specifier fallback for non-GNU compilers.
     */
    #define CL_INLINE           static inline

    /*
     * No-op fallback for CL_NOINLINE on non-GNU compilers.
     */
    #define CL_NOINLINE

    /*
     * No-op fallback for CL_NORETURN on non-GNU compilers.
     */
    #define CL_NORETURN

    /*
     * No-op fallback for CL_NODISCARD on non-GNU compilers.
     */
    #define CL_NODISCARD

    /*
     * No-op fallback for CL_UNUSED on non-GNU compilers.
     */
    #define CL_UNUSED

    /*
     * No-op fallback for printf format checking on non-GNU compilers.
     *
     * Parameters:
     *   f (int, 1-based parameter index) - Ignored format string parameter position.
     *   a (int, 1-based parameter index) - Ignored first variadic argument position.
     */
    #define CL_PRINTF_LIKE(f,a)

    /*
     * Portable fallback for CL_TRAP() that terminates via standard abort().
     */
    #define CL_TRAP()           abort()

    /*
     * Portable fallback for CL_UNREACHABLE_HW() that terminates via standard abort().
     */
    #define CL_UNREACHABLE_HW() abort()

    /*
     * Feature flag (int, 0 or 1): 0 when __typeof__ is unavailable.
     */
    #define CL_HAVE_TYPEOF      0

    /*
     * Feature flag (int, 0 or 1): 0 when statement expressions are unavailable.
     */
    #define CL_HAVE_STMT_EXPR   0

    /*
     * Feature flag (int, 0 or 1): 0 when __attribute__((cleanup)) is unavailable.
     */
    #define CL_HAVE_CLEANUP     0
#endif

/* ----------------------------------------------------------------------------
 * Preprocessor Helpers
 * ---------------------------------------------------------------------------- */

/*
 * Internal single-stage stringification helper (does not macro-expand x).
 *
 * Parameters:
 *   x (preprocessor token sequence) - Raw tokens converted into a string literal.
 *
 * Returns:
 *   const char[] - String literal containing the unexpanded spelling of x.
 */
#define CL_STRINGIFY_IMPL(x) #x

/*
 * Converts a macro-expanded preprocessor argument into a C string literal.
 *
 * Parameters:
 *   x (preprocessor token sequence) - Tokens expanded before stringification.
 *
 * Returns:
 *   const char[] - String literal of the expanded argument.
 */
#define CL_STRINGIFY(x)      CL_STRINGIFY_IMPL(x)

/*
 * Internal single-stage token-pasting helper (does not macro-expand a or b).
 *
 * Parameters:
 *   a (preprocessor token) - Left token to concatenate.
 *   b (preprocessor token) - Right token to concatenate.
 *
 * Returns:
 *   Combined preprocessor token formed by pasting a and b.
 */
#define CL_CONCAT_IMPL(a, b) a##b

/*
 * Macro-expands and concatenates two preprocessor tokens into a single identifier.
 *
 * Parameters:
 *   a (preprocessor token) - Left token (expanded before pasting).
 *   b (preprocessor token) - Right token (expanded before pasting).
 *
 * Returns:
 *   Combined preprocessor identifier formed by pasting expanded a and b.
 */
#define CL_CONCAT(a, b)      CL_CONCAT_IMPL(a, b)

/*
 * Generates a line-unique local identifier by suffixing prefix with __LINE__.
 *
 * Parameters:
 *   prefix (identifier token) - Identifier prefix; must not be empty.
 *
 * Returns:
 *   Unique identifier token scoped to the current source line number.
 */
#define CL_UNIQUE(prefix)    CL_CONCAT(prefix, __LINE__)

/*
 * Pure ISO C99 compile-time static assertion using a negative-size array typedef.
 *
 * Parameters:
 *   cond (constant integral expression) - Condition that must evaluate to non-zero.
 *   name (identifier token)             - Unique suffix for the generated typedef name.
 */
#define CL_STATIC_ASSERT(cond, name) \
    typedef char CL_CONCAT(cl_static_assert_, name)[(cond) ? 1 : -1]

/*
 * Computes the compile-time element count of a fixed-size C array.
 *
 * Parameters:
 *   arr (T[N] array expression) - Must be an actual C array, never a decayed pointer.
 *
 * Returns:
 *   ptrdiff_t - Number of elements in arr (element count).
 */
#define CL_ARRAY_LEN(arr) ((ptrdiff_t)(sizeof(arr) / sizeof((arr)[0])))

/*
 * Portably silences unused-parameter or unused-variable compiler warnings.
 *
 * Parameters:
 *   x (any expression) - Variable or parameter value cast to void.
 */
#define CL_UNUSED_VAR(x) ((void)(x))

/* Alignment-of macros (type and expression variants, strictly C99-pedantic safe) */
#if CL_COMPILER_GNU_COMPAT
    /*
     * Returns the required alignment of a type T in bytes using GNU __alignof__.
     *
     * Parameters:
     *   T (C type name) - Complete object type whose alignment is queried.
     *
     * Returns:
     *   ptrdiff_t - Alignment requirement of T in bytes (power of two, >= 1).
     */
    #define CL_ALIGNOF(T)         ((ptrdiff_t)(CL_EXTENSION __alignof__(T)))

    /*
     * Returns the required alignment of an expression's type in bytes using GNU __alignof__.
     *
     * Parameters:
     *   expr (C expression) - Unevaluated expression whose type alignment is queried.
     *
     * Returns:
     *   ptrdiff_t - Alignment requirement of expr's type in bytes (power of two, >= 1).
     */
    #define CL_ALIGNOF_EXPR(expr) ((ptrdiff_t)(CL_EXTENSION __alignof__(expr)))
#else
    /*
     * Portable C99 fallback computing the alignment of type T in bytes via struct offsetof.
     *
     * Parameters:
     *   T (C type name) - Complete object type whose alignment is queried.
     *
     * Returns:
     *   ptrdiff_t - Alignment requirement of T in bytes (power of two, >= 1).
     */
    #define CL_ALIGNOF(T)         ((ptrdiff_t)offsetof(struct { char _c; T _t; }, _t))

    /*
     * Portable fallback returning CL_DEFAULT_ALIGNMENT when expression alignment is unsupported.
     *
     * Parameters:
     *   expr (C expression) - Unused expression placeholder.
     *
     * Returns:
     *   ptrdiff_t - Default alignment in bytes (CL_DEFAULT_ALIGNMENT).
     */
    #define CL_ALIGNOF_EXPR(expr) CL_DEFAULT_ALIGNMENT
#endif

/*
 * Default allocation alignment in bytes (16 bytes), matching maximum fundamental
 * scalar/SIMD alignment on x86_64 Linux (ptrdiff_t, bytes).
 */
#define CL_DEFAULT_ALIGNMENT ((ptrdiff_t)16)

#endif /* CL_CONFIG_H */
