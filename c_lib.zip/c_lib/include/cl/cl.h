/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Single umbrella header that includes every module of `c_lib`.
 *   Define `CL_SHORT_NAMES` before including `<cl/cl.h>` if you also want
 *   unprefixed Odin-style aliases (`u8`, `i64`, `complex64`, `complex128`,
 *   `Str`, `Arena`, etc.).
 * ============================================================================
 */

#ifndef CL_H
#define CL_H

/* Include all c_lib modules in dependency order. */
#include "cl_config.h"
#include "cl_types.h"
#include "cl_complex.h"
#include "cl_assert.h"
#include "cl_mem.h"
#include "cl_result.h"
#include "cl_alloc.h"
#include "cl_arena.h"
#include "cl_virtual_arena.h"
#include "cl_pool.h"
#include "cl_tracking_alloc.h"
#include "cl_log.h"
#include "cl_context.h"
#include "cl_defer.h"
#include "cl_slice.h"
#include "cl_array.h"
#include "cl_hash.h"
#include "cl_map.h"
#include "cl_utf8.h"
#include "cl_string.h"
#include "cl_string_builder.h"
#include "cl_strbuf.h"
#include "cl_os.h"

/* Optionally expose unprefixed Odin-style aliases when CL_SHORT_NAMES is defined. */
#ifdef CL_SHORT_NAMES
    #include "cl_short.h"
#endif

#endif /* CL_H */
