/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_complex.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   First-class math and construction helpers for Odin-equivalent complex
 *   numbers (cl_c64 / complex64 and cl_c128 / complex128) and quaternions
 *   (Cl_Quat128 / quaternion128 and Cl_Quat256 / quaternion256).
 *
 * Mathematical Notation (Plain-Text ASCII):
 *   Complex number:   z = a + b*i, where i^2 = -1
 *   Conjugate:        conj(z) = a - b*i
 *   Magnitude:        |z| = sqrt(a^2 + b^2)
 *   Squared norm:     |z|^2 = a^2 + b^2
 *   Phase angle:      arg(z) = atan2(b, a) in [-pi, pi]
 *   Polar form:       z = r * (cos(theta) + i * sin(theta)) = r * e^(i*theta)
 *   Quaternion:       q = w + x*i + y*j + z*k
 *
 * Native Operators:
 *   Because cl_c64 and cl_c128 are native C99 `_Complex` types, standard C
 *   operators `+`, `-`, `*`, `/`, and unary `-` work directly without
 *   function-call syntax:
 *     cl_c128 a = cl_c128_make(1.0, 2.0);
 *     cl_c128 b = cl_c128_make(3.0, -4.0);
 *     cl_c128 prod = a * b;   (yields 11 + 2*i)
 * ============================================================================
 */

#ifndef CL_COMPLEX_H
#define CL_COMPLEX_H

#include "cl_types.h"

/* Useful mathematical constants (plain-text ASCII) */

/* Single-precision mathematical constant pi (cl_f32, radians / dimensionless, ~3.14159265). */
#define CL_PI_F32   3.14159265358979323846f

/* Single-precision mathematical constant tau = 2*pi (cl_f32, radians / dimensionless, ~6.28318531). */
#define CL_TAU_F32  6.28318530717958647692f

/* Double-precision mathematical constant pi (cl_f64, radians / dimensionless, ~3.141592653589793). */
#define CL_PI_F64   3.14159265358979323846

/* Double-precision mathematical constant tau = 2*pi (cl_f64, radians / dimensionless, ~6.283185307179586). */
#define CL_TAU_F64  6.28318530717958647692

/* ----------------------------------------------------------------------------
 * complex64 (cl_c64 = float _Complex) Inline Accessors & Constructors
 * ---------------------------------------------------------------------------- */

/*
 * Constructs a single-precision complex number z = re + im*i.
 *
 * Parameters:
 *   re (cl_f32, dimensionless) - Real component Re(z).
 *   im (cl_f32, dimensionless) - Imaginary component Im(z).
 *
 * Returns:
 *   cl_c64 - Complex value re + im*i.
 */
static inline cl_c64 cl_c64_make(cl_f32 re, cl_f32 im) {
    /*
     * Layout-punning union mapping cl_c64 to cl_f32[2] per C99 6.2.5p13.
     * Fields: z (cl_c64), parts (cl_f32[2]: [0]=real, [1]=imag).
     */
    union {
        cl_c64 z;
        cl_f32 parts[2];
    } u;
    u.parts[0] = re;
    u.parts[1] = im;
    return u.z;
}

/*
 * Extracts the real component Re(z) of a single-precision complex number.
 *
 * Parameters:
 *   z (cl_c64, dimensionless) - Complex number a + b*i.
 *
 * Returns:
 *   cl_f32 - Real part a.
 */
static inline cl_f32 cl_c64_real(cl_c64 z) {
    /*
     * Layout-punning union mapping cl_c64 to cl_f32[2] per C99 6.2.5p13.
     * Fields: z (cl_c64), parts (cl_f32[2]: [0]=real, [1]=imag).
     */
    union {
        cl_c64 z;
        cl_f32 parts[2];
    } u;
    u.z = z;
    return u.parts[0];
}

/*
 * Extracts the imaginary component Im(z) of a single-precision complex number.
 *
 * Parameters:
 *   z (cl_c64, dimensionless) - Complex number a + b*i.
 *
 * Returns:
 *   cl_f32 - Imaginary part b.
 */
static inline cl_f32 cl_c64_imag(cl_c64 z) {
    /*
     * Layout-punning union mapping cl_c64 to cl_f32[2] per C99 6.2.5p13.
     * Fields: z (cl_c64), parts (cl_f32[2]: [0]=real, [1]=imag).
     */
    union {
        cl_c64 z;
        cl_f32 parts[2];
    } u;
    u.z = z;
    return u.parts[1];
}

/*
 * Computes the complex conjugate conj(a + b*i) = a - b*i.
 *
 * Parameters:
 *   z (cl_c64, dimensionless) - Input complex number.
 *
 * Returns:
 *   cl_c64 - Complex conjugate with negated imaginary component.
 */
static inline cl_c64 cl_c64_conj(cl_c64 z) {
    return cl_c64_make(cl_c64_real(z), -cl_c64_imag(z));
}

/*
 * Computes the squared magnitude |z|^2 = Re(z)^2 + Im(z)^2 without a square root.
 *
 * Parameters:
 *   z (cl_c64, dimensionless) - Input complex number.
 *
 * Returns:
 *   cl_f32 - Non-negative squared norm (dimensionless, >= 0 for finite z).
 */
static inline cl_f32 cl_c64_abs2(cl_c64 z) {
    cl_f32 re = cl_c64_real(z);
    cl_f32 im = cl_c64_imag(z);
    return re * re + im * im;
}

/*
 * Losslessly widens a single-precision cl_c64 to a double-precision cl_c128.
 *
 * Parameters:
 *   z (cl_c64, dimensionless) - Single-precision complex number to widen.
 *
 * Returns:
 *   cl_c128 - Equivalent double-precision complex number.
 */
static inline cl_c128 cl_c64_to_c128(cl_c64 z) {
    /*
     * Layout-punning union mapping cl_c128 to cl_f64[2] per C99 6.2.5p13.
     * Fields: z (cl_c128), parts (cl_f64[2]: [0]=real, [1]=imag).
     */
    union {
        cl_c128 z;
        cl_f64  parts[2];
    } u;
    u.parts[0] = (cl_f64)cl_c64_real(z);
    u.parts[1] = (cl_f64)cl_c64_imag(z);
    return u.z;
}

/* ----------------------------------------------------------------------------
 * complex128 (cl_c128 = double _Complex) Inline Accessors & Constructors
 * ---------------------------------------------------------------------------- */

/*
 * Constructs a double-precision complex number z = re + im*i.
 *
 * Parameters:
 *   re (cl_f64, dimensionless) - Real component Re(z).
 *   im (cl_f64, dimensionless) - Imaginary component Im(z).
 *
 * Returns:
 *   cl_c128 - Complex value re + im*i.
 */
static inline cl_c128 cl_c128_make(cl_f64 re, cl_f64 im) {
    /*
     * Layout-punning union mapping cl_c128 to cl_f64[2] per C99 6.2.5p13.
     * Fields: z (cl_c128), parts (cl_f64[2]: [0]=real, [1]=imag).
     */
    union {
        cl_c128 z;
        cl_f64  parts[2];
    } u;
    u.parts[0] = re;
    u.parts[1] = im;
    return u.z;
}

/*
 * Extracts the real component Re(z) of a double-precision complex number.
 *
 * Parameters:
 *   z (cl_c128, dimensionless) - Complex number a + b*i.
 *
 * Returns:
 *   cl_f64 - Real part a.
 */
static inline cl_f64 cl_c128_real(cl_c128 z) {
    /*
     * Layout-punning union mapping cl_c128 to cl_f64[2] per C99 6.2.5p13.
     * Fields: z (cl_c128), parts (cl_f64[2]: [0]=real, [1]=imag).
     */
    union {
        cl_c128 z;
        cl_f64  parts[2];
    } u;
    u.z = z;
    return u.parts[0];
}

/*
 * Extracts the imaginary component Im(z) of a double-precision complex number.
 *
 * Parameters:
 *   z (cl_c128, dimensionless) - Complex number a + b*i.
 *
 * Returns:
 *   cl_f64 - Imaginary part b.
 */
static inline cl_f64 cl_c128_imag(cl_c128 z) {
    /*
     * Layout-punning union mapping cl_c128 to cl_f64[2] per C99 6.2.5p13.
     * Fields: z (cl_c128), parts (cl_f64[2]: [0]=real, [1]=imag).
     */
    union {
        cl_c128 z;
        cl_f64  parts[2];
    } u;
    u.z = z;
    return u.parts[1];
}

/*
 * Computes the complex conjugate conj(a + b*i) = a - b*i.
 *
 * Parameters:
 *   z (cl_c128, dimensionless) - Input complex number.
 *
 * Returns:
 *   cl_c128 - Complex conjugate with negated imaginary component.
 */
static inline cl_c128 cl_c128_conj(cl_c128 z) {
    return cl_c128_make(cl_c128_real(z), -cl_c128_imag(z));
}

/*
 * Computes the squared magnitude |z|^2 = Re(z)^2 + Im(z)^2 without a square root.
 *
 * Parameters:
 *   z (cl_c128, dimensionless) - Input complex number.
 *
 * Returns:
 *   cl_f64 - Non-negative squared norm (dimensionless, >= 0 for finite z).
 */
static inline cl_f64 cl_c128_abs2(cl_c128 z) {
    cl_f64 re = cl_c128_real(z);
    cl_f64 im = cl_c128_imag(z);
    return re * re + im * im;
}

/*
 * Narrows a double-precision cl_c128 to a single-precision cl_c64 by casting
 * both real and imaginary components to cl_f32.
 *
 * Parameters:
 *   z (cl_c128, dimensionless) - Double-precision complex number to narrow.
 *
 * Returns:
 *   cl_c64 - Narrowed single-precision complex number.
 */
static inline cl_c64 cl_c128_to_c64(cl_c128 z) {
    return cl_c64_make((cl_f32)cl_c128_real(z), (cl_f32)cl_c128_imag(z));
}

/* ----------------------------------------------------------------------------
 * Transcendental & Polar Operations (Implemented in cl_complex.c via -lm)
 * ---------------------------------------------------------------------------- */

/* complex64 operations */

/*
 * Computes the Euclidean magnitude |z| = sqrt(Re(z)^2 + Im(z)^2) of a cl_c64.
 *
 * Parameters:
 *   z (cl_c64, dimensionless) - Input complex number.
 *
 * Returns:
 *   cl_f32 - Non-negative modulus |z| (dimensionless).
 */
cl_f32  cl_c64_abs(cl_c64 z);

/*
 * Computes the principal phase angle arg(z) = atan2(Im(z), Re(z)) of a cl_c64.
 *
 * Parameters:
 *   z (cl_c64, dimensionless) - Input complex number.
 *
 * Returns:
 *   cl_f32 - Phase angle in radians, in the closed interval [-pi, pi].
 */
cl_f32  cl_c64_arg(cl_c64 z);

/*
 * Constructs a cl_c64 from polar coordinates:
 *   z = radius * (cos(angle_rad) + i * sin(angle_rad)) = radius * e^(i*angle_rad).
 *
 * Parameters:
 *   radius    (cl_f32, dimensionless) - Radial magnitude (typically >= 0).
 *   angle_rad (cl_f32, radians)       - Phase angle in radians.
 *
 * Returns:
 *   cl_c64 - Complex number in Cartesian form.
 */
cl_c64  cl_c64_from_polar(cl_f32 radius, cl_f32 angle_rad);

/*
 * Computes the complex exponential e^z = e^Re(z) * (cos(Im(z)) + i * sin(Im(z))).
 *
 * Parameters:
 *   z (cl_c64, dimensionless; Im(z) in radians) - Complex exponent.
 *
 * Returns:
 *   cl_c64 - Complex exponential e^z.
 */
cl_c64  cl_c64_exp(cl_c64 z);

/*
 * Computes the principal complex natural logarithm ln(z) = ln(|z|) + i * arg(z),
 * with branch cut along the negative real axis.
 *
 * Parameters:
 *   z (cl_c64, dimensionless) - Input complex number (non-zero for finite result).
 *
 * Returns:
 *   cl_c64 - Principal natural logarithm with Im(ln(z)) in [-pi, pi] radians.
 */
cl_c64  cl_c64_log(cl_c64 z);

/*
 * Computes the principal complex square root sqrt(z) with Re(sqrt(z)) >= 0,
 * with branch cut along the negative real axis.
 *
 * Parameters:
 *   z (cl_c64, dimensionless) - Input complex number.
 *
 * Returns:
 *   cl_c64 - Principal square root of z.
 */
cl_c64  cl_c64_sqrt(cl_c64 z);

/*
 * Computes the principal complex power base^exponent = exp(exponent * ln(base)).
 *
 * Parameters:
 *   base     (cl_c64, dimensionless) - Complex base value.
 *   exponent (cl_c64, dimensionless) - Complex exponent value.
 *
 * Returns:
 *   cl_c64 - Principal value of base raised to exponent.
 */
cl_c64  cl_c64_pow(cl_c64 base, cl_c64 exponent);

/*
 * Computes the complex sine sin(z) = (e^(i*z) - e^(-i*z)) / (2*i).
 *
 * Parameters:
 *   z (cl_c64, complex radians) - Input complex angle.
 *
 * Returns:
 *   cl_c64 - Complex sine of z (dimensionless).
 */
cl_c64  cl_c64_sin(cl_c64 z);

/*
 * Computes the complex cosine cos(z) = (e^(i*z) + e^(-i*z)) / 2.
 *
 * Parameters:
 *   z (cl_c64, complex radians) - Input complex angle.
 *
 * Returns:
 *   cl_c64 - Complex cosine of z (dimensionless).
 */
cl_c64  cl_c64_cos(cl_c64 z);

/*
 * Checks component-wise approximate equality between two cl_c64 values:
 *   |Re(a) - Re(b)| <= eps and |Im(a) - Im(b)| <= eps.
 *
 * Parameters:
 *   a   (cl_c64, dimensionless)     - First complex value.
 *   b   (cl_c64, dimensionless)     - Second complex value.
 *   eps (cl_f32, tolerance epsilon) - Non-negative absolute tolerance (>= 0).
 *
 * Returns:
 *   bool - true if both real and imaginary differences are <= eps, false otherwise.
 */
bool    cl_c64_approx_eq(cl_c64 a, cl_c64 b, cl_f32 eps);

/*
 * Tests whether both real and imaginary components of a cl_c64 are finite
 * (neither NaN nor +/-Inf).
 *
 * Parameters:
 *   z (cl_c64, dimensionless) - Complex value to test.
 *
 * Returns:
 *   bool - true if both Re(z) and Im(z) are finite, false otherwise.
 */
bool    cl_c64_is_finite(cl_c64 z);

/* complex128 operations */

/*
 * Computes the Euclidean magnitude |z| = sqrt(Re(z)^2 + Im(z)^2) of a cl_c128.
 *
 * Parameters:
 *   z (cl_c128, dimensionless) - Input complex number.
 *
 * Returns:
 *   cl_f64 - Non-negative modulus |z| (dimensionless).
 */
cl_f64  cl_c128_abs(cl_c128 z);

/*
 * Computes the principal phase angle arg(z) = atan2(Im(z), Re(z)) of a cl_c128.
 *
 * Parameters:
 *   z (cl_c128, dimensionless) - Input complex number.
 *
 * Returns:
 *   cl_f64 - Phase angle in radians, in the closed interval [-pi, pi].
 */
cl_f64  cl_c128_arg(cl_c128 z);

/*
 * Constructs a cl_c128 from polar coordinates:
 *   z = radius * (cos(angle_rad) + i * sin(angle_rad)) = radius * e^(i*angle_rad).
 *
 * Parameters:
 *   radius    (cl_f64, dimensionless) - Radial magnitude (typically >= 0).
 *   angle_rad (cl_f64, radians)       - Phase angle in radians.
 *
 * Returns:
 *   cl_c128 - Complex number in Cartesian form.
 */
cl_c128 cl_c128_from_polar(cl_f64 radius, cl_f64 angle_rad);

/*
 * Computes the complex exponential e^z = e^Re(z) * (cos(Im(z)) + i * sin(Im(z))).
 *
 * Parameters:
 *   z (cl_c128, dimensionless; Im(z) in radians) - Complex exponent.
 *
 * Returns:
 *   cl_c128 - Complex exponential e^z.
 */
cl_c128 cl_c128_exp(cl_c128 z);

/*
 * Computes the principal complex natural logarithm ln(z) = ln(|z|) + i * arg(z),
 * with branch cut along the negative real axis.
 *
 * Parameters:
 *   z (cl_c128, dimensionless) - Input complex number (non-zero for finite result).
 *
 * Returns:
 *   cl_c128 - Principal natural logarithm with Im(ln(z)) in [-pi, pi] radians.
 */
cl_c128 cl_c128_log(cl_c128 z);

/*
 * Computes the principal complex square root sqrt(z) with Re(sqrt(z)) >= 0,
 * with branch cut along the negative real axis.
 *
 * Parameters:
 *   z (cl_c128, dimensionless) - Input complex number.
 *
 * Returns:
 *   cl_c128 - Principal square root of z.
 */
cl_c128 cl_c128_sqrt(cl_c128 z);

/*
 * Computes the principal complex power base^exponent = exp(exponent * ln(base)).
 *
 * Parameters:
 *   base     (cl_c128, dimensionless) - Complex base value.
 *   exponent (cl_c128, dimensionless) - Complex exponent value.
 *
 * Returns:
 *   cl_c128 - Principal value of base raised to exponent.
 */
cl_c128 cl_c128_pow(cl_c128 base, cl_c128 exponent);

/*
 * Computes the complex sine sin(z) = (e^(i*z) - e^(-i*z)) / (2*i).
 *
 * Parameters:
 *   z (cl_c128, complex radians) - Input complex angle.
 *
 * Returns:
 *   cl_c128 - Complex sine of z (dimensionless).
 */
cl_c128 cl_c128_sin(cl_c128 z);

/*
 * Computes the complex cosine cos(z) = (e^(i*z) + e^(-i*z)) / 2.
 *
 * Parameters:
 *   z (cl_c128, complex radians) - Input complex angle.
 *
 * Returns:
 *   cl_c128 - Complex cosine of z (dimensionless).
 */
cl_c128 cl_c128_cos(cl_c128 z);

/*
 * Checks component-wise approximate equality between two cl_c128 values:
 *   |Re(a) - Re(b)| <= eps and |Im(a) - Im(b)| <= eps.
 *
 * Parameters:
 *   a   (cl_c128, dimensionless)    - First complex value.
 *   b   (cl_c128, dimensionless)    - Second complex value.
 *   eps (cl_f64, tolerance epsilon) - Non-negative absolute tolerance (>= 0).
 *
 * Returns:
 *   bool - true if both real and imaginary differences are <= eps, false otherwise.
 */
bool    cl_c128_approx_eq(cl_c128 a, cl_c128 b, cl_f64 eps);

/*
 * Tests whether both real and imaginary components of a cl_c128 are finite
 * (neither NaN nor +/-Inf).
 *
 * Parameters:
 *   z (cl_c128, dimensionless) - Complex value to test.
 *
 * Returns:
 *   bool - true if both Re(z) and Im(z) are finite, false otherwise.
 */
bool    cl_c128_is_finite(cl_c128 z);

/* ----------------------------------------------------------------------------
 * Quaternion Operations (Cl_Quat128 & Cl_Quat256)
 * ---------------------------------------------------------------------------- */

/*
 * Returns the single-precision multiplicative identity quaternion (0, 0, 0, 1),
 * representing zero rotation.
 *
 * Returns:
 *   Cl_Quat128 - Identity quaternion with x=0, y=0, z=0, w=1.
 */
static inline Cl_Quat128 cl_quat128_identity(void) {
    return (Cl_Quat128){ 0.0f, 0.0f, 0.0f, 1.0f };
}

/*
 * Returns the double-precision multiplicative identity quaternion (0, 0, 0, 1),
 * representing zero rotation.
 *
 * Returns:
 *   Cl_Quat256 - Identity quaternion with x=0, y=0, z=0, w=1.
 */
static inline Cl_Quat256 cl_quat256_identity(void) {
    return (Cl_Quat256){ 0.0, 0.0, 0.0, 1.0 };
}

/*
 * Constructs a single-precision quaternion q = w + x*i + y*j + z*k from explicit components.
 *
 * Parameters:
 *   x (cl_f32, dimensionless) - Imaginary i-component.
 *   y (cl_f32, dimensionless) - Imaginary j-component.
 *   z (cl_f32, dimensionless) - Imaginary k-component.
 *   w (cl_f32, dimensionless) - Real (scalar) component.
 *
 * Returns:
 *   Cl_Quat128 - Constructed quaternion (x, y, z, w).
 */
Cl_Quat128 cl_quat128_make(cl_f32 x, cl_f32 y, cl_f32 z, cl_f32 w);

/*
 * Constructs a unit single-precision rotation quaternion for a rotation around
 * axis (ax, ay, az) by angle_rad radians. The axis is normalized internally; if
 * its length is <= 0, returns cl_quat128_identity().
 *
 * Parameters:
 *   ax        (cl_f32, dimensionless) - Rotation axis X component.
 *   ay        (cl_f32, dimensionless) - Rotation axis Y component.
 *   az        (cl_f32, dimensionless) - Rotation axis Z component.
 *   angle_rad (cl_f32, radians)       - Right-handed rotation angle in radians.
 *
 * Returns:
 *   Cl_Quat128 - Unit rotation quaternion, or identity if the axis is degenerate.
 */
Cl_Quat128 cl_quat128_from_axis_angle(cl_f32 ax, cl_f32 ay, cl_f32 az, cl_f32 angle_rad);

/*
 * Computes the Hamilton product a * b of two single-precision quaternions
 * (non-commutative rotation composition: applies b then a).
 *
 * Parameters:
 *   a (Cl_Quat128, dimensionless) - Left quaternion operand.
 *   b (Cl_Quat128, dimensionless) - Right quaternion operand.
 *
 * Returns:
 *   Cl_Quat128 - Hamilton product a * b.
 */
Cl_Quat128 cl_quat128_mul(Cl_Quat128 a, Cl_Quat128 b);

/*
 * Computes the quaternion conjugate conj(q) = (-q.x, -q.y, -q.z, q.w),
 * which equals the inverse q^(-1) for unit quaternions.
 *
 * Parameters:
 *   q (Cl_Quat128, dimensionless) - Input quaternion.
 *
 * Returns:
 *   Cl_Quat128 - Conjugated quaternion.
 */
Cl_Quat128 cl_quat128_conj(Cl_Quat128 q);

/*
 * Computes the 4D Euclidean inner product a.x*b.x + a.y*b.y + a.z*b.z + a.w*b.w.
 *
 * Parameters:
 *   a (Cl_Quat128, dimensionless) - First quaternion.
 *   b (Cl_Quat128, dimensionless) - Second quaternion.
 *
 * Returns:
 *   cl_f32 - Scalar dot product (dimensionless).
 */
cl_f32     cl_quat128_dot(Cl_Quat128 a, Cl_Quat128 b);

/*
 * Computes the Euclidean norm |q| = sqrt(q.x^2 + q.y^2 + q.z^2 + q.w^2).
 *
 * Parameters:
 *   q (Cl_Quat128, dimensionless) - Input quaternion.
 *
 * Returns:
 *   cl_f32 - Non-negative quaternion length (dimensionless).
 */
cl_f32     cl_quat128_len(Cl_Quat128 q);

/*
 * Normalizes a single-precision quaternion to unit length q / |q|.
 * Returns cl_quat128_identity() if |q| <= 0.
 *
 * Parameters:
 *   q (Cl_Quat128, dimensionless) - Input quaternion.
 *
 * Returns:
 *   Cl_Quat128 - Unit-length quaternion, or identity for zero-length input.
 */
Cl_Quat128 cl_quat128_normalize(Cl_Quat128 q);

/*
 * Performs shortest-path spherical linear interpolation (SLERP) between two unit
 * single-precision quaternions, falling back to normalized LERP when |dot(a, b)| > 0.9995.
 *
 * Parameters:
 *   a (Cl_Quat128, unit quaternion) - Starting orientation (should be unit length).
 *   b (Cl_Quat128, unit quaternion) - Ending orientation (should be unit length).
 *   t (cl_f32, dimensionless)       - Interpolation factor, typically in [0.0, 1.0].
 *
 * Returns:
 *   Cl_Quat128 - Interpolated unit orientation quaternion.
 */
Cl_Quat128 cl_quat128_slerp(Cl_Quat128 a, Cl_Quat128 b, cl_f32 t);

/*
 * Constructs a double-precision quaternion q = w + x*i + y*j + z*k from explicit components.
 *
 * Parameters:
 *   x (cl_f64, dimensionless) - Imaginary i-component.
 *   y (cl_f64, dimensionless) - Imaginary j-component.
 *   z (cl_f64, dimensionless) - Imaginary k-component.
 *   w (cl_f64, dimensionless) - Real (scalar) component.
 *
 * Returns:
 *   Cl_Quat256 - Constructed quaternion (x, y, z, w).
 */
Cl_Quat256 cl_quat256_make(cl_f64 x, cl_f64 y, cl_f64 z, cl_f64 w);

/*
 * Constructs a unit double-precision rotation quaternion for a rotation around
 * axis (ax, ay, az) by angle_rad radians. The axis is normalized internally; if
 * its length is <= 0, returns cl_quat256_identity().
 *
 * Parameters:
 *   ax        (cl_f64, dimensionless) - Rotation axis X component.
 *   ay        (cl_f64, dimensionless) - Rotation axis Y component.
 *   az        (cl_f64, dimensionless) - Rotation axis Z component.
 *   angle_rad (cl_f64, radians)       - Right-handed rotation angle in radians.
 *
 * Returns:
 *   Cl_Quat256 - Unit rotation quaternion, or identity if the axis is degenerate.
 */
Cl_Quat256 cl_quat256_from_axis_angle(cl_f64 ax, cl_f64 ay, cl_f64 az, cl_f64 angle_rad);

/*
 * Computes the Hamilton product a * b of two double-precision quaternions
 * (non-commutative rotation composition: applies b then a).
 *
 * Parameters:
 *   a (Cl_Quat256, dimensionless) - Left quaternion operand.
 *   b (Cl_Quat256, dimensionless) - Right quaternion operand.
 *
 * Returns:
 *   Cl_Quat256 - Hamilton product a * b.
 */
Cl_Quat256 cl_quat256_mul(Cl_Quat256 a, Cl_Quat256 b);

/*
 * Computes the quaternion conjugate conj(q) = (-q.x, -q.y, -q.z, q.w),
 * which equals the inverse q^(-1) for unit quaternions.
 *
 * Parameters:
 *   q (Cl_Quat256, dimensionless) - Input quaternion.
 *
 * Returns:
 *   Cl_Quat256 - Conjugated quaternion.
 */
Cl_Quat256 cl_quat256_conj(Cl_Quat256 q);

/*
 * Computes the 4D Euclidean inner product a.x*b.x + a.y*b.y + a.z*b.z + a.w*b.w.
 *
 * Parameters:
 *   a (Cl_Quat256, dimensionless) - First quaternion.
 *   b (Cl_Quat256, dimensionless) - Second quaternion.
 *
 * Returns:
 *   cl_f64 - Scalar dot product (dimensionless).
 */
cl_f64     cl_quat256_dot(Cl_Quat256 a, Cl_Quat256 b);

/*
 * Computes the Euclidean norm |q| = sqrt(q.x^2 + q.y^2 + q.z^2 + q.w^2).
 *
 * Parameters:
 *   q (Cl_Quat256, dimensionless) - Input quaternion.
 *
 * Returns:
 *   cl_f64 - Non-negative quaternion length (dimensionless).
 */
cl_f64     cl_quat256_len(Cl_Quat256 q);

/*
 * Normalizes a double-precision quaternion to unit length q / |q|.
 * Returns cl_quat256_identity() if |q| <= 0.
 *
 * Parameters:
 *   q (Cl_Quat256, dimensionless) - Input quaternion.
 *
 * Returns:
 *   Cl_Quat256 - Unit-length quaternion, or identity for zero-length input.
 */
Cl_Quat256 cl_quat256_normalize(Cl_Quat256 q);

/*
 * Performs shortest-path spherical linear interpolation (SLERP) between two unit
 * double-precision quaternions, falling back to normalized LERP when |dot(a, b)| > 0.999999.
 *
 * Parameters:
 *   a (Cl_Quat256, unit quaternion) - Starting orientation (should be unit length).
 *   b (Cl_Quat256, unit quaternion) - Ending orientation (should be unit length).
 *   t (cl_f64, dimensionless)       - Interpolation factor, typically in [0.0, 1.0].
 *
 * Returns:
 *   Cl_Quat256 - Interpolated unit orientation quaternion.
 */
Cl_Quat256 cl_quat256_slerp(Cl_Quat256 a, Cl_Quat256 b, cl_f64 t);

#endif /* CL_COMPLEX_H */
