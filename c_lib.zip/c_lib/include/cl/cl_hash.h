/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_hash.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Fast, well-distributed non-cryptographic hashing primitives (FNV-1a 64,
 *   SplitMix64 integer finalizer, and generic key hash/equality callbacks
 *   for Cl_Map).
 * ============================================================================
 */

#ifndef CL_HASH_H
#define CL_HASH_H

#include "cl_types.h"

/*
 * Key hashing callback signature used by Cl_Map to map a key object to a
 * 64-bit hash value.
 *
 * Parameters:
 *   key      (const void *) - Non-NULL pointer to the key object.
 *   key_size (cl_isize)     - Size of the key type (bytes; sizeof(K)).
 *
 * Returns:
 *   (cl_u64) 64-bit non-cryptographic hash of the key.
 */
typedef cl_u64 (*Cl_Hash_Proc)(const void *key, cl_isize key_size);

/*
 * Key equality predicate callback signature used by Cl_Map to resolve hash
 * matches. Must be consistent with the paired Cl_Hash_Proc (equal keys must
 * produce identical hashes).
 *
 * Parameters:
 *   a        (const void *) - Non-NULL pointer to the first key object.
 *   b        (const void *) - Non-NULL pointer to the second key object.
 *   key_size (cl_isize)     - Size of the key type (bytes; sizeof(K)).
 *
 * Returns:
 *   (bool) true if *a and *b represent equal keys, false otherwise.
 */
typedef bool (*Cl_Eq_Proc)(const void *a, const void *b, cl_isize key_size);

/* Core hash algorithms */

/*
 * Computes the standard 64-bit FNV-1a hash of a raw byte buffer using the
 * canonical offset basis 14695981039346656037ULL.
 *
 * Parameters:
 *   data (const void *) - Pointer to input bytes (may be NULL if len <= 0).
 *   len  (cl_isize)     - Input length (bytes).
 *
 * Returns:
 *   (cl_u64) 64-bit FNV-1a hash value (returns the offset basis if data == NULL
 *            or len <= 0).
 */
cl_u64 cl_hash_fnv1a64(const void *data, cl_isize len);

/*
 * Computes a seeded (or incremental/chained) 64-bit FNV-1a hash over a byte
 * buffer starting from an initial 64-bit state seed.
 *
 * Parameters:
 *   data (const void *) - Pointer to input bytes (may be NULL if len <= 0).
 *   len  (cl_isize)     - Input length (bytes).
 *   seed (cl_u64)       - Initial 64-bit hash seed or prior FNV-1a state.
 *
 * Returns:
 *   (cl_u64) Updated 64-bit FNV-1a hash value (returns seed unchanged if
 *            data == NULL or len <= 0).
 */
cl_u64 cl_hash_fnv1a64_seed(const void *data, cl_isize len, cl_u64 seed);

/*
 * Applies the SplitMix64 bijective 64-bit integer avalanche mixer to x,
 * diffusing sequential or structured integer keys across all 64 output bits.
 *
 * Parameters:
 *   x (cl_u64) - 64-bit unsigned integer input.
 *
 * Returns:
 *   (cl_u64) Well-mixed 64-bit hash value.
 */
cl_u64 cl_hash_u64_mix(cl_u64 x);

/*
 * Computes the 64-bit FNV-1a hash of the byte contents referenced by Cl_Str s.
 *
 * Parameters:
 *   s (Cl_Str) - Non-owning string descriptor (s.len bytes at s.data).
 *
 * Returns:
 *   (cl_u64) 64-bit FNV-1a hash of s's byte contents.
 */
cl_u64 cl_hash_str(Cl_Str s);

/*
 * Computes the 64-bit FNV-1a hash of a NUL-terminated C string (excluding the
 * trailing NUL byte).
 *
 * Parameters:
 *   s (const char *) - NUL-terminated C string, or NULL.
 *
 * Returns:
 *   (cl_u64) 64-bit FNV-1a hash of s, or the FNV-1a offset basis if s == NULL.
 */
cl_u64 cl_hash_cstr(const char *s);

/* Ready-to-use Cl_Map key hashers and comparators */

/*
 * Cl_Map key hasher for fixed-size plain-old-data (POD) keys. Hashes key_size
 * contiguous bytes at key with 64-bit FNV-1a. Struct keys must not contain
 * uninitialized padding bytes.
 *
 * Parameters:
 *   key      (const void *) - Pointer to POD key bytes.
 *   key_size (cl_isize)     - Key size (bytes).
 *
 * Returns:
 *   (cl_u64) 64-bit FNV-1a hash of the key bytes.
 */
cl_u64 cl_map_hash_bytes(const void *key, cl_isize key_size);

/*
 * Cl_Map equality comparator for fixed-size plain-old-data (POD) keys.
 * Compares key_size bytes verbatim using cl_mem_eq.
 *
 * Parameters:
 *   a        (const void *) - Pointer to the first POD key.
 *   b        (const void *) - Pointer to the second POD key.
 *   key_size (cl_isize)     - Key size (bytes).
 *
 * Returns:
 *   (bool) true if all key_size bytes match (or key_size <= 0), false otherwise.
 */
bool   cl_map_eq_bytes(const void *a, const void *b, cl_isize key_size);

/*
 * Cl_Map key hasher for Cl_Str keys. Hashes the string's byte contents rather
 * than the Cl_Str struct representation.
 *
 * Parameters:
 *   key      (const void *) - Non-NULL pointer to a Cl_Str key.
 *   key_size (cl_isize)     - Unused (sizeof(Cl_Str) in bytes).
 *
 * Returns:
 *   (cl_u64) 64-bit FNV-1a hash of the string's contents.
 */
cl_u64 cl_map_hash_str(const void *key, cl_isize key_size);

/*
 * Cl_Map equality comparator for Cl_Str keys. Compares string lengths and
 * UTF-8 byte contents.
 *
 * Parameters:
 *   a        (const void *) - Non-NULL pointer to the first Cl_Str key.
 *   b        (const void *) - Non-NULL pointer to the second Cl_Str key.
 *   key_size (cl_isize)     - Unused (sizeof(Cl_Str) in bytes).
 *
 * Returns:
 *   (bool) true if both strings have equal length and identical bytes, false
 *          otherwise.
 */
bool   cl_map_eq_str(const void *a, const void *b, cl_isize key_size);

/*
 * Cl_Map key hasher for NUL-terminated C-string pointer keys (`const char *`).
 * Dereferences *(const char *const *)key and hashes the pointed-to C string.
 *
 * Parameters:
 *   key      (const void *) - Non-NULL pointer to a `const char *` key slot.
 *   key_size (cl_isize)     - Unused (sizeof(const char *) in bytes).
 *
 * Returns:
 *   (cl_u64) 64-bit FNV-1a hash of the C string (or FNV-1a offset basis if the
 *            stored pointer is NULL).
 */
cl_u64 cl_map_hash_cstr(const void *key, cl_isize key_size);

/*
 * Cl_Map equality comparator for NUL-terminated C-string pointer keys
 * (`const char *`). Safely handles identical pointers and NULL values before
 * falling back to strcmp.
 *
 * Parameters:
 *   a        (const void *) - Non-NULL pointer to the first `const char *` slot.
 *   b        (const void *) - Non-NULL pointer to the second `const char *` slot.
 *   key_size (cl_isize)     - Unused (sizeof(const char *) in bytes).
 *
 * Returns:
 *   (bool) true if both pointers are equal (including both NULL) or point to
 *          identical NUL-terminated strings, false otherwise.
 */
bool   cl_map_eq_cstr(const void *a, const void *b, cl_isize key_size);

/*
 * Cl_Map key hasher for cl_u64 keys using SplitMix64 mixing.
 *
 * Parameters:
 *   key      (const void *) - Non-NULL pointer to a cl_u64 key.
 *   key_size (cl_isize)     - Unused (sizeof(cl_u64) in bytes).
 *
 * Returns:
 *   (cl_u64) SplitMix64-mixed 64-bit hash of *(const cl_u64 *)key.
 */
cl_u64 cl_map_hash_u64(const void *key, cl_isize key_size);

/*
 * Cl_Map equality comparator for cl_u64 keys.
 *
 * Parameters:
 *   a        (const void *) - Non-NULL pointer to the first cl_u64 key.
 *   b        (const void *) - Non-NULL pointer to the second cl_u64 key.
 *   key_size (cl_isize)     - Unused (sizeof(cl_u64) in bytes).
 *
 * Returns:
 *   (bool) true if *(const cl_u64 *)a == *(const cl_u64 *)b, false otherwise.
 */
bool   cl_map_eq_u64(const void *a, const void *b, cl_isize key_size);

/*
 * Cl_Map key hasher for cl_i64 keys. Copies the 8 key bytes into a cl_u64 for
 * strict-aliasing safety and mixes them with SplitMix64.
 *
 * Parameters:
 *   key      (const void *) - Non-NULL pointer to a cl_i64 key.
 *   key_size (cl_isize)     - Unused (sizeof(cl_i64) in bytes).
 *
 * Returns:
 *   (cl_u64) SplitMix64-mixed 64-bit hash of the key's bit pattern.
 */
cl_u64 cl_map_hash_i64(const void *key, cl_isize key_size);

/*
 * Cl_Map equality comparator for cl_i64 keys.
 *
 * Parameters:
 *   a        (const void *) - Non-NULL pointer to the first cl_i64 key.
 *   b        (const void *) - Non-NULL pointer to the second cl_i64 key.
 *   key_size (cl_isize)     - Unused (sizeof(cl_i64) in bytes).
 *
 * Returns:
 *   (bool) true if *(const cl_i64 *)a == *(const cl_i64 *)b, false otherwise.
 */
bool   cl_map_eq_i64(const void *a, const void *b, cl_isize key_size);

/*
 * Cl_Map key hasher for cl_i32 keys. Zero-extends the 32-bit pattern via
 * (cl_u64)(cl_u32) and mixes it with SplitMix64.
 *
 * Parameters:
 *   key      (const void *) - Non-NULL pointer to a cl_i32 key.
 *   key_size (cl_isize)     - Unused (sizeof(cl_i32) in bytes).
 *
 * Returns:
 *   (cl_u64) SplitMix64-mixed 64-bit hash of the 32-bit key value.
 */
cl_u64 cl_map_hash_i32(const void *key, cl_isize key_size);

/*
 * Cl_Map equality comparator for cl_i32 keys.
 *
 * Parameters:
 *   a        (const void *) - Non-NULL pointer to the first cl_i32 key.
 *   b        (const void *) - Non-NULL pointer to the second cl_i32 key.
 *   key_size (cl_isize)     - Unused (sizeof(cl_i32) in bytes).
 *
 * Returns:
 *   (bool) true if *(const cl_i32 *)a == *(const cl_i32 *)b, false otherwise.
 */
bool   cl_map_eq_i32(const void *a, const void *b, cl_isize key_size);

#endif /* CL_HASH_H */
