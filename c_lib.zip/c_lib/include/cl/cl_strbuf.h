/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_strbuf.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Mutable, fixed-capacity, ALWAYS NUL-terminated, zero-heap-allocation
 *   String Buffer (`Cl_Str_Buf`) with rich in-place editing primitives:
 *   insert, erase, in-place find/replace, trim, ASCII case conversion,
 *   reverse, and padding.
 *
 * Cl_Str_Buf vs Cl_String_Builder:
 *   - Use `Cl_String_Builder` when constructing arbitrarily large strings
 *     incrementally (append-mostly, dynamic growth via an allocator).
 *   - Use `Cl_Str_Buf` when editing strings IN PLACE inside a fixed stack
 *     or struct `char buf[N]` (e.g., file paths, network headers, real-time
 *     audio/DSP loops, embedded buffers) where ZERO heap allocations and
 *     guaranteed NUL termination are required at every step.
 * ============================================================================
 */

#ifndef CL_STRBUF_H
#define CL_STRBUF_H

#include "cl_string.h"
#include <stdarg.h>

/*
 * Struct: Cl_Str_Buf
 * Purpose:
 *   Fixed-capacity, always NUL-terminated, zero-heap mutable string buffer
 *   wrapping caller-owned storage for safe in-place string editing.
 * Fields:
 *   data (char *): Pointer to caller-owned backing buffer (NUL-terminated at
 *     data[len] whenever cap > 0; may be NULL if cap == 0).
 *   len (cl_isize): Current string length in bytes excluding the trailing NUL
 *     terminator (0 <= len <= cap - 1 when cap > 0).
 *   cap (cl_isize): Total backing buffer capacity in bytes, including the
 *     trailing NUL byte (maximum storable string length is cap - 1 bytes).
 *   truncated (bool): Sticky flag set to true if any operation exceeded
 *     cap - 1 bytes; cleared by cl_strbuf_clear.
 */
typedef struct Cl_Str_Buf {
    char    *data;      /* Caller-owned backing buffer (always NUL-terminated) */
    cl_isize len;       /* Current string length excluding trailing NUL */
    cl_isize cap;       /* Total buffer capacity in bytes (max len = cap - 1) */
    bool     truncated; /* True if any operation exceeded cap - 1 */
} Cl_Str_Buf;

/*
 * Function: cl_strbuf_init
 * Purpose:
 *   Initializes an empty Cl_Str_Buf over a caller-owned char array, writing
 *   backing[0] = '\0' when backing != NULL and cap > 0.
 * Parameters:
 *   backing (char *): Caller-owned backing array, or NULL.
 *   cap (cl_isize): Total buffer capacity in bytes, including the trailing NUL
 *     terminator (<= 0 or NULL backing yields cap = 0).
 * Returns:
 *   Cl_Str_Buf: Initialized empty buffer with len = 0 and truncated = false.
 */
Cl_Str_Buf cl_strbuf_init(char *backing, cl_isize cap);

/*
 * Function: cl_strbuf_from_existing
 * Purpose:
 *   Wraps an existing C string already stored in backing[cap], scanning up to
 *   cap - 1 bytes for the first NUL byte and guaranteeing NUL termination at
 *   backing[len].
 * Parameters:
 *   backing (char *): Caller-owned buffer containing an existing string, or NULL.
 *   cap (cl_isize): Total buffer capacity in bytes, including the trailing NUL.
 * Returns:
 *   Cl_Str_Buf: Buffer initialized with len equal to the bounded length of
 *     the existing string (<= cap - 1 bytes).
 */
Cl_Str_Buf cl_strbuf_from_existing(char *backing, cl_isize cap);

/*
 * Macro: CL_STRBUF_FROM_ARRAY(char_arr)
 * Purpose:
 *   Convenience initializer wrapping a fixed-size stack or struct char array
 *   in an empty, NUL-terminated Cl_Str_Buf.
 * Parameters:
 *   char_arr (char[N]): Actual fixed-size char array (must NOT be a decayed
 *     char * pointer; total capacity N in bytes includes the trailing NUL).
 * Returns:
 *   Cl_Str_Buf: Empty buffer initialized via cl_strbuf_init(char_arr, N).
 */
#define CL_STRBUF_FROM_ARRAY(char_arr) \
    cl_strbuf_init((char_arr), CL_ARRAY_LEN(char_arr))

/*
 * Function: cl_strbuf_max_len
 * Purpose:
 *   Returns the maximum string payload length in bytes that the buffer can
 *   store while reserving 1 byte for the trailing NUL terminator.
 * Parameters:
 *   b (const Cl_Str_Buf *): Target string buffer, or NULL.
 * Returns:
 *   cl_isize: Maximum payload length in bytes (b->cap - 1), or 0 if b is NULL
 *     or b->cap <= 0.
 */
static inline cl_isize cl_strbuf_max_len(const Cl_Str_Buf *b) {
    return (b && b->cap > 0) ? (b->cap - 1) : 0;
}

/*
 * Function: cl_strbuf_remaining
 * Purpose:
 *   Returns the remaining free payload capacity in bytes before reaching
 *   cap - 1 bytes.
 * Parameters:
 *   b (const Cl_Str_Buf *): Target string buffer, or NULL.
 * Returns:
 *   cl_isize: Available payload bytes (b->cap - 1 - b->len), or 0 if b is
 *     NULL or b->cap <= 0.
 */
static inline cl_isize cl_strbuf_remaining(const Cl_Str_Buf *b) {
    return (b && b->cap > 0) ? (b->cap - 1 - b->len) : 0;
}

/*
 * Function: cl_strbuf_as_str
 * Purpose:
 *   Returns an O(1) non-owning Cl_Str view of the buffer's current contents
 *   (excluding the trailing NUL terminator).
 * Parameters:
 *   b (const Cl_Str_Buf *): Source string buffer, or NULL.
 * Returns:
 *   Cl_Str: Non-owning view of b->len bytes, or CL_STR_EMPTY if b is NULL,
 *     unbacked, or empty.
 */
static inline Cl_Str cl_strbuf_as_str(const Cl_Str_Buf *b) {
    if (b == NULL || b->data == NULL || b->len <= 0) {
        return CL_STR_EMPTY;
    }
    return (Cl_Str){ (const cl_u8 *)b->data, b->len };
}

/*
 * Function: cl_strbuf_as_cstr
 * Purpose:
 *   Returns a NUL-terminated C string pointer to the buffer's contents.
 * Parameters:
 *   b (const Cl_Str_Buf *): Source string buffer, or NULL.
 * Returns:
 *   const char *: Pointer to b->data, or "" if b is NULL, b->data is NULL,
 *     or b->cap <= 0.
 */
static inline const char *cl_strbuf_as_cstr(const Cl_Str_Buf *b) {
    if (b == NULL || b->data == NULL || b->cap <= 0) {
        return "";
    }
    return b->data;
}

/*
 * Function: cl_strbuf_clear
 * Purpose:
 *   Resets the buffer to empty (len = 0, truncated = false, data[0] = '\0').
 *   Safe no-op if b is NULL.
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer, or NULL.
 * Returns:
 *   void.
 */
void     cl_strbuf_clear(Cl_Str_Buf *b);

/*
 * Function: cl_strbuf_set
 * Purpose:
 *   Clears b and copies s into it, truncating cleanly at cap - 1 bytes if
 *   necessary while maintaining NUL termination.
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer; must be non-NULL.
 *   s (Cl_Str): Source byte slice to copy.
 * Returns:
 *   bool: true if all bytes of s fit without truncation; false if truncated.
 */
bool     cl_strbuf_set(Cl_Str_Buf *b, Cl_Str s);

/*
 * Function: cl_strbuf_set_cstr
 * Purpose:
 *   Clears b and copies a NUL-terminated C string into it.
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer; must be non-NULL.
 *   cs (const char *): Source NUL-terminated C string, or NULL (clears b).
 * Returns:
 *   bool: true if all bytes fit without truncation; false if truncated.
 */
bool     cl_strbuf_set_cstr(Cl_Str_Buf *b, const char *cs);

/*
 * Function: cl_strbuf_append_char
 * Purpose:
 *   Appends a single character to b if at least 1 byte of payload capacity
 *   remains, keeping the buffer NUL-terminated.
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer; must be non-NULL.
 *   c (char): Character byte to append.
 * Returns:
 *   bool: true if c was appended; false if the buffer is full (sets
 *     b->truncated = true).
 */
bool     cl_strbuf_append_char(Cl_Str_Buf *b, char c);

/*
 * Function: cl_strbuf_append_str
 * Purpose:
 *   Appends as many bytes of s as fit within cap - 1 bytes (safe for
 *   overlapping source views via cl_mem_move) and keeps b NUL-terminated.
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer; must be non-NULL.
 *   s (Cl_Str): Byte slice to append (empty/NULL succeeds immediately).
 * Returns:
 *   bool: true if all bytes of s fit; false if truncated (sets b->truncated).
 */
bool     cl_strbuf_append_str(Cl_Str_Buf *b, Cl_Str s);

/*
 * Function: cl_strbuf_append_cstr
 * Purpose:
 *   Appends a NUL-terminated C string to b without heap allocations.
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer; must be non-NULL.
 *   cs (const char *): Source NUL-terminated C string, or NULL.
 * Returns:
 *   bool: true if all bytes fit; false if truncated (sets b->truncated).
 */
bool     cl_strbuf_append_cstr(Cl_Str_Buf *b, const char *cs);

/*
 * Function: cl_strbuf_append_fmt
 * Purpose:
 *   Appends printf-formatted text directly into the remaining capacity of b
 *   using vsnprintf with zero heap allocations and guaranteed NUL termination.
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer; must be non-NULL.
 *   fmt (const char *): NUL-terminated printf format string.
 *   ... (variadic): Arguments matching fmt.
 * Returns:
 *   bool: true if the entire formatted output fit; false on invalid fmt,
 *     vsnprintf error, or truncation (sets b->truncated = true on overflow).
 */
CL_PRINTF_LIKE(2, 3) bool cl_strbuf_append_fmt(Cl_Str_Buf *b, const char *fmt, ...);

/*
 * Function: cl_strbuf_insert
 * Purpose:
 *   Inserts s at 0-based byte offset idx inside b, shifting existing tail
 *   bytes right in place and truncating any overflow past cap - 1 bytes.
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer; must be non-NULL.
 *   idx (cl_isize): 0-based insertion byte offset; must satisfy 0 <= idx <= b->len.
 *   s (Cl_Str): Byte slice to insert (must not overlap b->data).
 * Returns:
 *   bool: true if all bytes of s and the existing tail fit without truncation;
 *     false if truncated (sets b->truncated = true).
 */
bool     cl_strbuf_insert(Cl_Str_Buf *b, cl_isize idx, Cl_Str s);

/*
 * Function: cl_strbuf_erase
 * Purpose:
 *   Removes up to count bytes starting at 0-based byte offset idx in place,
 *   shifting trailing bytes left and maintaining NUL termination.
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer; must be non-NULL.
 *   idx (cl_isize): 0-based start byte offset; must satisfy 0 <= idx <= b->len
 *     when count > 0.
 *   count (cl_isize): Number of bytes to erase (<= 0 is a no-op; clamped to
 *     b->len - idx if idx + count > b->len).
 * Returns:
 *   void.
 */
void     cl_strbuf_erase(Cl_Str_Buf *b, cl_isize idx, cl_isize count);

/*
 * Function: cl_strbuf_replace_in_place
 * Purpose:
 *   Replaces non-overlapping occurrences of old_s with new_s in place inside b
 *   with zero heap allocations. If a replacement would exceed cap - 1 bytes,
 *   sets b->truncated = true and stops cleanly leaving prior replacements intact.
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer; must be non-NULL.
 *   old_s (Cl_Str): Substring to search for (empty returns 0).
 *   new_s (Cl_Str): Replacement byte slice (must not overlap b->data).
 * Returns:
 *   cl_isize: Number of occurrences replaced (>= 0).
 */
cl_isize cl_strbuf_replace_in_place(Cl_Str_Buf *b, Cl_Str old_s, Cl_Str new_s);

/*
 * Function: cl_strbuf_trim_space_in_place
 * Purpose:
 *   Strips leading and trailing ASCII whitespace (' ', '\t', '\n', '\r',
 *   '\v', '\f') from b in place and updates b->len and NUL termination.
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer; must be non-NULL.
 * Returns:
 *   void.
 */
void     cl_strbuf_trim_space_in_place(Cl_Str_Buf *b);

/*
 * Function: cl_strbuf_to_upper_in_place
 * Purpose:
 *   Converts ASCII lowercase letters ('a'..'z') in b to uppercase ('A'..'Z')
 *   in place; all other bytes remain unchanged.
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer; must be non-NULL.
 * Returns:
 *   void.
 */
void     cl_strbuf_to_upper_in_place(Cl_Str_Buf *b);

/*
 * Function: cl_strbuf_to_lower_in_place
 * Purpose:
 *   Converts ASCII uppercase letters ('A'..'Z') in b to lowercase ('a'..'z')
 *   in place; all other bytes remain unchanged.
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer; must be non-NULL.
 * Returns:
 *   void.
 */
void     cl_strbuf_to_lower_in_place(Cl_Str_Buf *b);

/*
 * Function: cl_strbuf_reverse_in_place
 * Purpose:
 *   Reverses the raw bytes of b in place (bytewise reversal; intended for
 *   ASCII/single-byte data).
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer; must be non-NULL.
 * Returns:
 *   void.
 */
void     cl_strbuf_reverse_in_place(Cl_Str_Buf *b);

/*
 * Function: cl_strbuf_pad_left_in_place
 * Purpose:
 *   Pads b on the left with pad_char up to min(target_len, cap - 1) bytes in
 *   place, shifting existing content right and keeping NUL termination.
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer; must be non-NULL.
 *   target_len (cl_isize): Desired total payload length in bytes (<= b->len
 *     is a no-op returning true).
 *   pad_char (char): Padding character byte to prepend.
 * Returns:
 *   bool: true if target_len <= cap - 1 (no truncation); false if clamped to
 *     cap - 1 (sets b->truncated = true).
 */
bool     cl_strbuf_pad_left_in_place(Cl_Str_Buf *b, cl_isize target_len, char pad_char);

/*
 * Function: cl_strbuf_pad_right_in_place
 * Purpose:
 *   Pads b on the right with pad_char up to min(target_len, cap - 1) bytes in
 *   place while keeping NUL termination.
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer; must be non-NULL.
 *   target_len (cl_isize): Desired total payload length in bytes (<= b->len
 *     is a no-op returning true).
 *   pad_char (char): Padding character byte to append.
 * Returns:
 *   bool: true if target_len <= cap - 1 (no truncation); false if clamped to
 *     cap - 1 (sets b->truncated = true).
 */
bool     cl_strbuf_pad_right_in_place(Cl_Str_Buf *b, cl_isize target_len, char pad_char);

/*
 * Function: cl_strbuf_truncate
 * Purpose:
 *   Shortens b to new_len bytes with bounds checking via
 *   CL_BOUNDS_CHECK_RANGE(0, new_len, b->len) and writes a trailing NUL byte.
 * Parameters:
 *   b (Cl_Str_Buf *): Target string buffer; must be non-NULL.
 *   new_len (cl_isize): New length in bytes; must satisfy 0 <= new_len <= b->len.
 * Returns:
 *   void.
 */
void     cl_strbuf_truncate(Cl_Str_Buf *b, cl_isize new_len);

#endif /* CL_STRBUF_H */
