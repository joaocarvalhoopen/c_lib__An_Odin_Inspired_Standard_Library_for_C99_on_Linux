/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_map.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Type-safe, cache-friendly open-addressing HashMap (`CL_MAP_DEFINE`,
 *   inspired by Odin's `map[K]V` and SwissTable H2 control bytes).
 *
 * Internal Architecture:
 *   - Bucket table stores 8-bit control bytes (`0xFF`=EMPTY, `0xFE`=TOMBSTONE,
 *     `0x00..0x7F`=7-bit H2 hash tag) plus indices into dense parallel arrays.
 *   - Keys, values, and 64-bit hashes are stored densely in indices
 *     `0 .. map.hdr.len - 1`.
 *   - Advantages:
 *     1. 99.2% of probe collisions are rejected by 1-byte H2 tags before
 *        touching `keys[]`.
 *     2. Iteration is a straight sequential scan over dense `keys[i]` and
 *        `values[i]` with zero skipped empty buckets.
 *     3. O(1) expected insert, lookup, and swap-delete.
 *     4. Single shared type-erased engine in cl_map.c (zero code bloat).
 * ============================================================================
 */

#ifndef CL_MAP_H
#define CL_MAP_H

#include "cl_types.h"
#include "cl_assert.h"
#include "cl_mem.h"
#include "cl_alloc.h"
#include "cl_context.h"
#include "cl_hash.h"
#include "cl_defer.h"

/* ----------------------------------------------------------------------------
 * Shared Map Header & Typed Map Generator
 * ---------------------------------------------------------------------------- */

/*
 * Shared type-erased metadata and open-addressing bucket table embedded as the
 * first member (`hdr`) of every CL_MAP_DEFINE map struct. Zero-initialization
 * (`{0}`) is valid; defaults are lazily bound on first mutation.
 *
 * Fields:
 *   ctrl         (cl_u8 *)      - Array of bucket_cap 8-bit control tags:
 *                                 0xFF = EMPTY, 0xFE = TOMBSTONE, 0x00..0x7F =
 *                                 7-bit H2 hash tag of an occupied bucket.
 *   slot_indices (cl_isize *)   - Array of bucket_cap 0-based dense indices
 *                                 into keys[], values[], and hashes[] for
 *                                 occupied buckets (entries).
 *   hashes       (cl_u64 *)     - Array of dense_cap cached 64-bit key hashes
 *                                 parallel to keys[] and values[].
 *   bucket_cap   (cl_isize)     - Allocated bucket count (buckets; 0 or a
 *                                 power of two >= 16).
 *   dense_cap    (cl_isize)     - Allocated capacity of dense keys/values/hashes
 *                                 arrays (entries; dense_cap >= len).
 *   len          (cl_isize)     - Active entry count stored densely in
 *                                 [0, len) (entries; len >= 0).
 *   tombstones   (cl_isize)     - Deleted bucket count awaiting reclamation on
 *                                 rehash or clear (buckets; tombstones >= 0).
 *   allocator    (Cl_Allocator) - Backing allocator (defaults to
 *                                 cl_ctx_allocator() if invalid).
 *   hash_fn      (Cl_Hash_Proc) - Key hash callback (defaults to
 *                                 cl_map_hash_bytes if NULL).
 *   eq_fn        (Cl_Eq_Proc)   - Key equality callback (defaults to
 *                                 cl_map_eq_bytes if NULL).
 */
typedef struct Cl_Map_Header {
    cl_u8        *ctrl;          /* [bucket_cap] Swiss-style H2 control tags */
    cl_isize     *slot_indices;  /* [bucket_cap] Dense entry index for occupied slots */
    cl_u64       *hashes;        /* [dense_cap]  Cached full 64-bit key hashes */
    cl_isize      bucket_cap;    /* Power-of-two bucket count */
    cl_isize      dense_cap;     /* Allocated dense keys/values capacity */
    cl_isize      len;           /* Active entry count */
    cl_isize      tombstones;    /* Deleted slot count (reclaimed on rehash) */
    Cl_Allocator  allocator;     /* Backing allocator (defaults to ctx allocator) */
    Cl_Hash_Proc  hash_fn;       /* Key hash callback (defaults to bytewise FNV-1a) */
    Cl_Eq_Proc    eq_fn;         /* Key eq callback (defaults to bytewise memcmp) */
} Cl_Map_Header;

/*
 * Transient pointer pair passed to raw map engine functions so typed key and
 * value arrays can be resized without strict-aliasing violations on `K **` /
 * `V **` pointers.
 *
 * Fields:
 *   keys   (void *) - Pointer to the dense keys array buffer, or NULL.
 *   values (void *) - Pointer to the dense values array buffer, or NULL.
 */
typedef struct Cl_Map_Dense_Bufs {
    void *keys;
    void *values;
} Cl_Map_Dense_Bufs;

/*
 * Defines a typed open-addressing hash map struct with dense parallel key and
 * value storage. Active entries always occupy dense indices [0, hdr.len).
 *
 * Macro Parameters:
 *   Name (identifier) - Struct tag and typedef name for the map type.
 *   K    (type)       - Key type stored densely in keys[].
 *   V    (type)       - Value type stored densely in values[].
 *
 * Generated Struct Fields:
 *   hdr    (Cl_Map_Header) - Shared bucket table, counts, allocator, and
 *                            hash/equality callbacks.
 *   keys   (K *)           - Dense array of keys (capacity hdr.dense_cap
 *                            entries; active entries in [0, hdr.len)).
 *   values (V *)           - Parallel dense array of values (capacity
 *                            hdr.dense_cap entries; active in [0, hdr.len)).
 */
#define CL_MAP_DEFINE(Name, K, V) \
    typedef struct Name {         \
        Cl_Map_Header hdr;        \
        K            *keys;       \
        V            *values;     \
    } Name

/*
 * Pre-defined typed hash map structs generated via CL_MAP_DEFINE for common
 * key/value combinations:
 *   Cl_Map_Str_I64   (Cl_Str -> cl_i64)   - String to 64-bit signed integer.
 *   Cl_Map_Str_ISize (Cl_Str -> cl_isize) - String to signed size/index.
 *   Cl_Map_Str_F64   (Cl_Str -> cl_f64)   - String to 64-bit float.
 *   Cl_Map_Str_C128  (Cl_Str -> cl_c128)  - String to 128-bit complex double.
 *   Cl_Map_Str_Str   (Cl_Str -> Cl_Str)   - String to string.
 *   Cl_Map_Str_Ptr   (Cl_Str -> void *)   - String to untyped pointer.
 *   Cl_Map_I64_I64   (cl_i64 -> cl_i64)   - 64-bit signed int to 64-bit int.
 *   Cl_Map_U64_Ptr   (cl_u64 -> void *)   - 64-bit unsigned int to pointer.
 *   Cl_Map_I32_I32   (cl_i32 -> cl_i32)   - 32-bit signed int to 32-bit int.
 */
CL_MAP_DEFINE(Cl_Map_Str_I64,   Cl_Str,  cl_i64);
CL_MAP_DEFINE(Cl_Map_Str_ISize, Cl_Str,  cl_isize);
CL_MAP_DEFINE(Cl_Map_Str_F64,   Cl_Str,  cl_f64);
CL_MAP_DEFINE(Cl_Map_Str_C128,  Cl_Str,  cl_c128);
CL_MAP_DEFINE(Cl_Map_Str_Str,   Cl_Str,  Cl_Str);
CL_MAP_DEFINE(Cl_Map_Str_Ptr,   Cl_Str,  void *);
CL_MAP_DEFINE(Cl_Map_I64_I64,   cl_i64,  cl_i64);
CL_MAP_DEFINE(Cl_Map_U64_Ptr,   cl_u64,  void *);
CL_MAP_DEFINE(Cl_Map_I32_I32,   cl_i32,  cl_i32);

/* ----------------------------------------------------------------------------
 * Core Type-Erased Engine Functions (Implemented in cl_map.c)
 * ---------------------------------------------------------------------------- */

/*
 * Zero-initializes a map header and binds its allocator, key hash callback,
 * and key equality callback (defaulting NULL callbacks to bytewise FNV-1a and
 * bytewise equality).
 *
 * Parameters:
 *   hdr     (Cl_Map_Header *) - Non-NULL pointer to the map header.
 *   alloc   (Cl_Allocator)    - Backing allocator (may be zeroed to use
 *                               cl_ctx_allocator() lazily).
 *   hash_fn (Cl_Hash_Proc)    - Key hash callback, or NULL for cl_map_hash_bytes.
 *   eq_fn   (Cl_Eq_Proc)      - Key equality callback, or NULL for cl_map_eq_bytes.
 */
void cl_map_init_hdr(
    Cl_Map_Header *hdr,
    Cl_Allocator alloc,
    Cl_Hash_Proc hash_fn,
    Cl_Eq_Proc eq_fn
);

/*
 * Pre-allocates dense arrays and bucket tables sufficient to store at least
 * min_entries entries while keeping bucket load factor <= 75%
 * (needed_buckets = (min_entries * 4) / 3 + 2, rounded up to a power of two).
 *
 * Parameters:
 *   hdr         (Cl_Map_Header *)     - Non-NULL map header.
 *   bufs        (Cl_Map_Dense_Bufs *) - Non-NULL in/out dense buffer pointers.
 *   min_entries (cl_isize)            - Minimum entry capacity (entries).
 *   key_size    (cl_isize)            - Size of one key (bytes; > 0).
 *   key_align   (cl_isize)            - Power-of-two key alignment (bytes).
 *   val_size    (cl_isize)            - Size of one value (bytes; > 0).
 *   val_align   (cl_isize)            - Power-of-two value alignment (bytes).
 *   loc         (Cl_Source_Loc)       - Caller source location for diagnostics.
 *
 * Returns:
 *   (bool) true if capacity was satisfied (or min_entries <= 0), or false on
 *          byte-size overflow or allocation failure.
 */
bool cl_map_reserve_raw(
    Cl_Map_Header *hdr,
    Cl_Map_Dense_Bufs *bufs,
    cl_isize min_entries,
    cl_isize key_size,
    cl_isize key_align,
    cl_isize val_size,
    cl_isize val_align,
    Cl_Source_Loc loc
);

/*
 * Inserts a new (key, value) entry or overwrites the value of an existing
 * matching key in place. Automatically rehashes buckets when
 * (len + tombstones + 1) * 4 >= bucket_cap * 3 and grows dense arrays when
 * needed. Traps via CL_ENSURE if memory allocation fails.
 *
 * Parameters:
 *   hdr       (Cl_Map_Header *)     - Non-NULL map header.
 *   bufs      (Cl_Map_Dense_Bufs *) - Non-NULL in/out dense buffer pointers;
 *                                     updated if dense arrays reallocate.
 *   key_ptr   (const void *)        - Non-NULL pointer to key bytes to insert.
 *   val_ptr   (const void *)        - Non-NULL pointer to value bytes to store.
 *   key_size  (cl_isize)            - Size of one key (bytes; > 0).
 *   key_align (cl_isize)            - Power-of-two key alignment (bytes).
 *   val_size  (cl_isize)            - Size of one value (bytes; > 0).
 *   val_align (cl_isize)            - Power-of-two value alignment (bytes).
 *   loc       (Cl_Source_Loc)       - Caller source location for diagnostics.
 *
 * Returns:
 *   (bool) true if a new key was inserted (hdr->len incremented by 1), or
 *          false if an existing key was found and its value was overwritten.
 */
bool cl_map_put_raw(
    Cl_Map_Header *hdr,
    Cl_Map_Dense_Bufs *bufs,
    const void *key_ptr,
    const void *val_ptr,
    cl_isize key_size,
    cl_isize key_align,
    cl_isize val_size,
    cl_isize val_align,
    Cl_Source_Loc loc
);

/*
 * Probes the open-addressing bucket table for a key matching *key_ptr using
 * 7-bit H2 tag filtering, cached 64-bit hash verification, and eq_fn.
 *
 * Parameters:
 *   hdr      (const Cl_Map_Header *) - Map header (may be NULL or empty).
 *   keys     (const void *)          - Dense keys buffer (may be NULL if empty).
 *   key_ptr  (const void *)          - Pointer to lookup key (may be NULL).
 *   key_size (cl_isize)              - Size of one key (bytes).
 *
 * Returns:
 *   (cl_isize) 0-based dense entry index in [0, hdr->len) if found, or -1 if
 *              absent or the map/arguments are empty/NULL.
 */
cl_isize cl_map_find_raw(
    const Cl_Map_Header *hdr,
    const void *keys,
    const void *key_ptr,
    cl_isize key_size
);

/*
 * Deletes the entry matching *key_ptr if present. Marks the deleted bucket as
 * a tombstone to preserve open-addressing probe chains, then swap-removes the
 * dense entry with the last entry (hdr->len - 1) and updates the relocated
 * entry's bucket slot_indices reference.
 *
 * Parameters:
 *   hdr      (Cl_Map_Header *) - Map header (may be NULL or empty).
 *   keys     (void *)          - Dense keys buffer.
 *   values   (void *)          - Dense values buffer.
 *   key_ptr  (const void *)    - Pointer to key bytes to delete.
 *   key_size (cl_isize)        - Size of one key (bytes).
 *   val_size (cl_isize)        - Size of one value (bytes).
 *
 * Returns:
 *   (bool) true if the key was present and removed (hdr->len decremented by 1),
 *          or false if absent or the map/arguments are empty/NULL.
 */
bool cl_map_delete_raw(
    Cl_Map_Header *hdr,
    void *keys,
    void *values,
    const void *key_ptr,
    cl_isize key_size,
    cl_isize val_size
);

/*
 * Clears all entries from the map by resetting every bucket control byte to
 * EMPTY and setting hdr->len = 0 and hdr->tombstones = 0, while retaining all
 * allocated bucket and dense buffers for reuse. Safe no-op if hdr == NULL.
 *
 * Parameters:
 *   hdr (Cl_Map_Header *) - Pointer to the map header to clear.
 */
void cl_map_clear_raw(Cl_Map_Header *hdr);

/*
 * Frees all bucket and dense allocations (ctrl, slot_indices, hashes, keys,
 * and values) via cl_alloc_or_ctx(hdr->allocator) and resets header pointers,
 * capacities, len, and tombstones to 0/NULL (preserving allocator, hash_fn,
 * and eq_fn). Safe no-op if hdr == NULL.
 *
 * Parameters:
 *   hdr      (Cl_Map_Header *) - Pointer to the map header.
 *   keys     (void *)          - Dense keys buffer to free, or NULL.
 *   values   (void *)          - Dense values buffer to free, or NULL.
 *   key_size (cl_isize)        - Size of one key (bytes).
 *   val_size (cl_isize)        - Size of one value (bytes).
 *   loc      (Cl_Source_Loc)   - Caller source location for diagnostics.
 */
void cl_map_free_raw(
    Cl_Map_Header *hdr,
    void *keys,
    void *values,
    cl_isize key_size,
    cl_isize val_size,
    Cl_Source_Loc loc
);

/* ----------------------------------------------------------------------------
 * Ergonomic Typed Map Macros
 * ---------------------------------------------------------------------------- */

/*
 * Zero-initializes a typed map struct and initializes its header with an
 * explicit allocator, key hash callback, and key equality callback.
 *
 * Parameters:
 *   m       (Cl_Map_T *)   - Pointer to the map struct to initialize.
 *   alloc   (Cl_Allocator) - Backing allocator handle.
 *   hash_fn (Cl_Hash_Proc) - Key hash callback (NULL selects bytewise FNV-1a).
 *   eq_fn   (Cl_Eq_Proc)   - Key equality callback (NULL selects bytewise eq).
 */
#define CL_MAP_INIT(m, alloc, hash_fn, eq_fn) do { \
    CL_ZERO_STRUCT(m);                             \
    cl_map_init_hdr(&(m)->hdr, (alloc), (hash_fn), (eq_fn)); \
} while (0)

/*
 * Initializes a typed map whose key type is Cl_Str using cl_map_hash_str and
 * cl_map_eq_str.
 *
 * Parameters:
 *   m     (Cl_Map_T *)   - Pointer to the map struct.
 *   alloc (Cl_Allocator) - Backing allocator handle.
 */
#define CL_MAP_INIT_STR(m, alloc)  CL_MAP_INIT((m), (alloc), cl_map_hash_str,   cl_map_eq_str)

/*
 * Initializes a typed map whose key type is `const char *` using
 * cl_map_hash_cstr and cl_map_eq_cstr.
 *
 * Parameters:
 *   m     (Cl_Map_T *)   - Pointer to the map struct.
 *   alloc (Cl_Allocator) - Backing allocator handle.
 */
#define CL_MAP_INIT_CSTR(m, alloc) CL_MAP_INIT((m), (alloc), cl_map_hash_cstr,  cl_map_eq_cstr)

/*
 * Initializes a typed map whose key type is cl_i64 using cl_map_hash_i64 and
 * cl_map_eq_i64.
 *
 * Parameters:
 *   m     (Cl_Map_T *)   - Pointer to the map struct.
 *   alloc (Cl_Allocator) - Backing allocator handle.
 */
#define CL_MAP_INIT_I64(m, alloc)  CL_MAP_INIT((m), (alloc), cl_map_hash_i64,   cl_map_eq_i64)

/*
 * Initializes a typed map whose key type is cl_u64 using cl_map_hash_u64 and
 * cl_map_eq_u64.
 *
 * Parameters:
 *   m     (Cl_Map_T *)   - Pointer to the map struct.
 *   alloc (Cl_Allocator) - Backing allocator handle.
 */
#define CL_MAP_INIT_U64(m, alloc)  CL_MAP_INIT((m), (alloc), cl_map_hash_u64,   cl_map_eq_u64)

/*
 * Initializes a typed map whose key type is cl_i32 using cl_map_hash_i32 and
 * cl_map_eq_i32.
 *
 * Parameters:
 *   m     (Cl_Map_T *)   - Pointer to the map struct.
 *   alloc (Cl_Allocator) - Backing allocator handle.
 */
#define CL_MAP_INIT_I32(m, alloc)  CL_MAP_INIT((m), (alloc), cl_map_hash_i32,   cl_map_eq_i32)

/*
 * Initializes a typed map with fixed-size plain-old-data (POD) keys using
 * bytewise hashing (cl_map_hash_bytes) and bytewise equality (cl_map_eq_bytes).
 *
 * Parameters:
 *   m     (Cl_Map_T *)   - Pointer to the map struct.
 *   alloc (Cl_Allocator) - Backing allocator handle.
 */
#define CL_MAP_INIT_POD(m, alloc)  CL_MAP_INIT((m), (alloc), cl_map_hash_bytes, cl_map_eq_bytes)

/*
 * Returns the number of active key/value entries currently stored in map *m.
 *
 * Parameters:
 *   m (const Cl_Map_T *) - Pointer to the map struct.
 *
 * Returns:
 *   (cl_isize) Active entry count (entries; >= 0).
 */
#define CL_MAP_LEN(m)   ((m)->hdr.len)

/*
 * Removes all entries from map *m while keeping allocated bucket and dense
 * buffers intact for reuse.
 *
 * Parameters:
 *   m (Cl_Map_T *) - Pointer to the map struct.
 */
#define CL_MAP_CLEAR(m) cl_map_clear_raw(&(m)->hdr)

/*
 * Pre-allocates bucket and dense storage in map *m for at least min_entries
 * entries (keeping bucket load factor <= 75%). Traps via CL_ENSURE on OOM.
 *
 * Parameters:
 *   m           (Cl_Map_T *) - Pointer to the map struct.
 *   min_entries (cl_isize)   - Minimum entry capacity to reserve (entries).
 */
#define CL_MAP_RESERVE(m, min_entries) do {                               \
    Cl_Map_Dense_Bufs _cl_mb = { (m)->keys, (m)->values };                \
    bool _cl_ok = cl_map_reserve_raw(                                     \
        &(m)->hdr, &_cl_mb, (cl_isize)(min_entries),                      \
        (cl_isize)sizeof(*(m)->keys),   CL_ALIGNOF_EXPR(*(m)->keys),      \
        (cl_isize)sizeof(*(m)->values), CL_ALIGNOF_EXPR(*(m)->values),    \
        CL_HERE                                                           \
    );                                                                    \
    CL_ENSURE(_cl_ok);                                                    \
    (m)->keys   = _cl_mb.keys;                                            \
    (m)->values = _cl_mb.values;                                          \
} while (0)

/*
 * Frees all bucket and dense allocations owned by map *m and resets m->keys
 * and m->values to NULL.
 *
 * Parameters:
 *   m (Cl_Map_T *) - Pointer to the map struct to free.
 */
#define CL_MAP_FREE(m) do {                                               \
    cl_map_free_raw(                                                      \
        &(m)->hdr, (m)->keys, (m)->values,                                \
        (cl_isize)sizeof(*(m)->keys),                                     \
        (cl_isize)sizeof(*(m)->values),                                   \
        CL_HERE                                                           \
    );                                                                    \
    (m)->keys   = NULL;                                                   \
    (m)->values = NULL;                                                   \
} while (0)

#if CL_HAVE_TYPEOF && CL_HAVE_STMT_EXPR
    /*
     * Inserts (key_expr, val_expr) into map *m or overwrites the existing
     * value if key_expr is already present.
     *
     * Parameters:
     *   m        (Cl_Map_T *) - Pointer to the map struct.
     *   key_expr (K)          - Key expression evaluated once.
     *   val_expr (V)          - Value expression evaluated once.
     *
     * Returns:
     *   (bool) true if a new key was inserted, or false if an existing key's
     *          value was updated.
     */
    #define CL_MAP_PUT(m, key_expr, val_expr) CL_EXTENSION ({             \
        __typeof__(*(m)->keys)   _cl_k  = (key_expr);                     \
        __typeof__(*(m)->values) _cl_v  = (val_expr);                     \
        Cl_Map_Dense_Bufs        _cl_mb = { (m)->keys, (m)->values };     \
        bool _cl_ins = cl_map_put_raw(                                    \
            &(m)->hdr, &_cl_mb, &_cl_k, &_cl_v,                           \
            (cl_isize)sizeof(_cl_k), CL_ALIGNOF_EXPR(_cl_k),              \
            (cl_isize)sizeof(_cl_v), CL_ALIGNOF_EXPR(_cl_v),              \
            CL_HERE                                                       \
        );                                                                \
        (m)->keys   = _cl_mb.keys;                                        \
        (m)->values = _cl_mb.values;                                      \
        _cl_ins;                                                          \
    })

    /*
     * Looks up key_expr in map *m and returns a direct pointer to the stored
     * value slot in m->values[]. The returned pointer may be invalidated by
     * subsequent puts, reserves, deletes, or frees.
     *
     * Parameters:
     *   m        (Cl_Map_T *) - Pointer to the map struct.
     *   key_expr (K)          - Key expression evaluated once.
     *
     * Returns:
     *   (V *) Pointer to the matching value inside m->values, or NULL if
     *         key_expr is not present.
     */
    #define CL_MAP_GET(m, key_expr) CL_EXTENSION ({                       \
        __typeof__(*(m)->keys) _cl_k = (key_expr);                        \
        cl_isize _cl_idx = cl_map_find_raw(                               \
            &(m)->hdr, (m)->keys, &_cl_k, (cl_isize)sizeof(_cl_k)         \
        );                                                                \
        (_cl_idx >= 0) ? (&(m)->values[_cl_idx]) : NULL;                  \
    })

    /*
     * Looks up key_expr in map *m and returns a copy of its associated value,
     * or evaluates and returns fallback_val if key_expr is absent.
     *
     * Parameters:
     *   m            (Cl_Map_T *) - Pointer to the map struct.
     *   key_expr     (K)          - Key expression evaluated once.
     *   fallback_val (V)          - Default value evaluated only when absent.
     *
     * Returns:
     *   (V) Stored value if key_expr is found, otherwise fallback_val.
     */
    #define CL_MAP_GET_OR(m, key_expr, fallback_val) CL_EXTENSION ({      \
        __typeof__(*(m)->keys) _cl_k = (key_expr);                        \
        cl_isize _cl_idx = cl_map_find_raw(                               \
            &(m)->hdr, (m)->keys, &_cl_k, (cl_isize)sizeof(_cl_k)         \
        );                                                                \
        (_cl_idx >= 0) ? (m)->values[_cl_idx] : (fallback_val);           \
    })

    /*
     * Tests whether key_expr exists in map *m.
     *
     * Parameters:
     *   m        (Cl_Map_T *) - Pointer to the map struct.
     *   key_expr (K)          - Key expression evaluated once.
     *
     * Returns:
     *   (bool) true if key_expr is present in *m, false otherwise.
     */
    #define CL_MAP_CONTAINS(m, key_expr) (CL_MAP_GET((m), (key_expr)) != NULL)

    /*
     * Removes key_expr from map *m via O(1) expected swap-delete if present.
     * May relocate the last dense entry into the removed entry's dense slot.
     *
     * Parameters:
     *   m        (Cl_Map_T *) - Pointer to the map struct.
     *   key_expr (K)          - Key expression evaluated once.
     *
     * Returns:
     *   (bool) true if an entry was removed, or false if key_expr was absent.
     */
    #define CL_MAP_DELETE(m, key_expr) CL_EXTENSION ({                    \
        __typeof__(*(m)->keys) _cl_k = (key_expr);                        \
        cl_map_delete_raw(                                                \
            &(m)->hdr, (m)->keys, (m)->values, &_cl_k,                    \
            (cl_isize)sizeof(_cl_k), (cl_isize)sizeof(*(m)->values)       \
        );                                                                \
    })
#endif

/*
 * Expands to a for-loop header scanning every active dense entry index in
 * [0, m->hdr.len) with zero skipped empty buckets. Inspect (m)->keys[idx_var]
 * and (m)->values[idx_var] inside the loop body.
 *
 * Parameters:
 *   idx_var (identifier) - Loop counter variable name declared as cl_isize.
 *   m       (Cl_Map_T *) - Pointer to the map struct to iterate.
 */
#define CL_MAP_FOR_EACH(idx_var, m) \
    for (cl_isize idx_var = 0; idx_var < (m)->hdr.len; idx_var++)

/*
 * Type-erased, strict-aliasing-safe cleanup record used by CL_DEFER_MAP to
 * automatically free any CL_MAP_DEFINE map at scope exit, even after
 * reallocations update its keys/values pointers.
 *
 * Fields:
 *   hdr       (Cl_Map_Header *) - Pointer to the map's embedded header.
 *   keys_slot (void *)          - Address of the map's keys pointer field
 *                                 (`&map.keys`), accessed via cl_mem_copy.
 *   vals_slot (void *)          - Address of the map's values pointer field
 *                                 (`&map.values`), accessed via cl_mem_copy.
 *   key_size  (cl_isize)        - Size of one key (bytes).
 *   val_size  (cl_isize)        - Size of one value (bytes).
 *   loc       (Cl_Source_Loc)   - Source location where CL_DEFER_MAP was placed.
 */
typedef struct Cl_Map_Cleanup_Info {
    Cl_Map_Header *hdr;
    void          *keys_slot;
    void          *vals_slot;
    cl_isize       key_size;
    cl_isize       val_size;
    Cl_Source_Loc  loc;
} Cl_Map_Cleanup_Info;

/*
 * Scope-exit cleanup callback invoked by CL_CLEANUP for CL_DEFER_MAP. Loads
 * the map's current keys and values pointers via cl_mem_copy (avoiding
 * strict-aliasing UB), calls cl_map_free_raw, and resets both pointer slots to
 * NULL.
 *
 * Parameters:
 *   info (Cl_Map_Cleanup_Info *) - Pointer to the cleanup descriptor; safe
 *                                  no-op if info == NULL or info->hdr == NULL.
 */
static inline void cl_map_defer_cleanup_impl(Cl_Map_Cleanup_Info *info) {
    if (info != NULL && info->hdr != NULL) {
        void *kptr = NULL;
        void *vptr = NULL;
        cl_mem_copy(&kptr, info->keys_slot, (cl_isize)sizeof(void *));
        cl_mem_copy(&vptr, info->vals_slot, (cl_isize)sizeof(void *));
        cl_map_free_raw(info->hdr, kptr, vptr, info->key_size, info->val_size, info->loc);
        void *np = NULL;
        cl_mem_copy(info->keys_slot, &np, (cl_isize)sizeof(void *));
        cl_mem_copy(info->vals_slot, &np, (cl_isize)sizeof(void *));
    }
}

#if CL_HAVE_CLEANUP
    /*
     * Registers automatic scope-exit freeing for a local map variable using
     * GCC/Clang __attribute__((cleanup)). Tracks reallocations safely by
     * storing addresses of the variable's hdr, keys, and values fields.
     *
     * Parameters:
     *   map_var (Cl_Map_T lvalue) - Local map variable (by value/lvalue, not a
     *                               pointer) whose lifetime outlives the
     *                               deferred cleanup guard.
     */
    #define CL_DEFER_MAP(map_var)                                         \
        CL_CLEANUP(cl_map_defer_cleanup_impl) Cl_Map_Cleanup_Info CL_UNIQUE(_cl_def_map_) = { \
            &(map_var).hdr,                                               \
            &(map_var).keys,                                              \
            &(map_var).values,                                            \
            (cl_isize)sizeof(*(map_var).keys),                            \
            (cl_isize)sizeof(*(map_var).values),                          \
            CL_HERE                                                       \
        }
#endif

#endif /* CL_MAP_H */
