/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_defer.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Provides Odin-style deterministic scope-exit cleanup (`defer`) in C99 on
 *   Linux across three complementary tiers, avoiding GCC nested-function
 *   trampolines (executable stack) and staying compatible with BOTH GCC and
 *   Clang under `-std=c99 -Wall -Wextra -Wpedantic -Werror`.
 *
 * Three Tiers of Defer:
 *   Tier 1 (Recommended Default - GCC & Clang, Early-Return Safe, LIFO):
 *     Uses `__attribute__((cleanup(fn)))`. Runs automatically in strict reverse
 *     (LIFO) order on normal scope exit, `return`, `break`, `continue`, or
 *     `goto`. Zero runtime overhead and NO executable stack!
 *     Examples:
 *       CL_DEFER_ARENA(arena);
 *       CL_DEFER_TEMP(tmp);
 *       CL_DEFER_SCRATCH(scratch);
 *       CL_DEFER_FREE(alloc, ptr, size);
 *       CL_DEFER_FILE(fp);
 *       CL_DEFER_CTX_PUSH(ctx);
 *       CL_DEFER_FN(my_void_fn, &my_state);
 *
 *   Tier 2 (100% Pure ISO C99 - Structured Scope Blocks):
 *     `CL_DEFER_LOOP(begin, end) { ... }`, `CL_WITH_TEMP(arena) { ... }`.
 *     CAUTION: Do NOT `return`, `break`, or `goto` out of a Tier 2 block
 *     (use `continue` to exit the block early while still running `end`,
 *     or use Tier 1 / Tier 3 when early `return`/`break` is needed).
 *
 *   Tier 3 (100% Pure ISO C99 - Explicit Defer Stack, Early-Return Safe):
 *     `Cl_Defer_Stack` + `CL_DEFER_STACK_PUSH` + `CL_DEFER_STACK_RETURN`.
 *     Works on any ISO C99 compiler without extensions.
 * ============================================================================
 */

#ifndef CL_DEFER_H
#define CL_DEFER_H

#include "cl_config.h"
#include "cl_alloc.h"
#include "cl_arena.h"
#include "cl_virtual_arena.h"
#include "cl_pool.h"
#include "cl_tracking_alloc.h"
#include "cl_context.h"
#include <stdio.h>

/* ----------------------------------------------------------------------------
 * Generic Defer Callback Type (Zero Function-Pointer Casts)
 * ---------------------------------------------------------------------------- */

/*
 * Callback function pointer type executed on scope exit by deferred actions.
 *
 * Parameters:
 *   arg (void *) - User-supplied context pointer passed unchanged to the callback.
 */
typedef void (*Cl_Defer_Proc)(void *arg);

/*
 * Deferred callback invocation record pairing a cleanup procedure with its argument.
 *
 * Fields:
 *   fn  (Cl_Defer_Proc) - Cleanup function to invoke at scope exit (no-op if NULL).
 *   arg (void *)        - Opaque pointer argument forwarded to fn(arg).
 */
typedef struct Cl_Defer_Action {
    Cl_Defer_Proc fn;
    void         *arg;
} Cl_Defer_Action;

/*
 * Scope-exit guard holding allocator metadata to automatically free a heap allocation.
 *
 * Fields:
 *   alloc    (Cl_Allocator)     - Allocator used to release the block via cl_free_loc().
 *   ptr_slot (void **)          - Address of the pointer variable holding the allocation;
 *                                 if *ptr_slot is NULL at scope exit, freeing is skipped.
 *   size     (cl_isize, bytes)  - Size of the allocation in bytes (>= 0).
 *   loc      (Cl_Source_Loc)    - Source location recorded where the defer guard was created.
 */
typedef struct Cl_Defer_Free_Guard {
    Cl_Allocator  alloc;
    void        **ptr_slot;
    cl_isize      size;
    Cl_Source_Loc loc;
} Cl_Defer_Free_Guard;

/* Internal cleanup callbacks (always static inline to avoid unused warnings) */

/*
 * Scope-exit cleanup callback that invokes a->fn(a->arg) if both a and a->fn are non-NULL.
 *
 * Parameters:
 *   a (Cl_Defer_Action *) - Pointer to the local Cl_Defer_Action guard leaving scope.
 */
static inline void cl_defer_run_action(Cl_Defer_Action *a) {
    if (a != NULL && a->fn != NULL) {
        a->fn(a->arg);
    }
}

/*
 * Scope-exit cleanup callback that frees *(g->ptr_slot) using g->alloc and zeroes
 * the pointer slot if g, g->ptr_slot, and *(g->ptr_slot) are all non-NULL.
 *
 * Parameters:
 *   g (Cl_Defer_Free_Guard *) - Pointer to the local Cl_Defer_Free_Guard leaving scope.
 */
static inline void cl_defer_run_free(Cl_Defer_Free_Guard *g) {
    if (g != NULL && g->ptr_slot != NULL && *(g->ptr_slot) != NULL) {
        cl_free_loc(g->alloc, *(g->ptr_slot), g->size, g->loc);
        *(g->ptr_slot) = NULL;
    }
}

/*
 * Scope-exit cleanup callback that destroys a Cl_Arena via cl_arena_destroy(*p).
 *
 * Parameters:
 *   p (Cl_Arena **) - Pointer to the local Cl_Arena pointer guard leaving scope.
 */
static inline void cl_defer_run_arena(Cl_Arena **p) {
    if (p != NULL && *p != NULL) {
        cl_arena_destroy(*p);
    }
}

/*
 * Scope-exit cleanup callback that rewinds a Cl_Arena_Temp checkpoint via cl_arena_temp_end(*t).
 *
 * Parameters:
 *   t (Cl_Arena_Temp *) - Pointer to the local Cl_Arena_Temp guard leaving scope.
 */
static inline void cl_defer_run_arena_temp(Cl_Arena_Temp *t) {
    if (t != NULL && t->arena != NULL) {
        cl_arena_temp_end(*t);
    }
}

/*
 * Scope-exit cleanup callback that destroys a Cl_Virtual_Arena via cl_varena_destroy(*p).
 *
 * Parameters:
 *   p (Cl_Virtual_Arena **) - Pointer to the local Cl_Virtual_Arena pointer guard leaving scope.
 */
static inline void cl_defer_run_varena(Cl_Virtual_Arena **p) {
    if (p != NULL && *p != NULL) {
        cl_varena_destroy(*p);
    }
}

/*
 * Scope-exit cleanup callback that rewinds a Cl_VArena_Temp checkpoint via cl_varena_temp_end(*t).
 *
 * Parameters:
 *   t (Cl_VArena_Temp *) - Pointer to the local Cl_VArena_Temp guard leaving scope.
 */
static inline void cl_defer_run_varena_temp(Cl_VArena_Temp *t) {
    if (t != NULL && t->arena != NULL) {
        cl_varena_temp_end(*t);
    }
}

/*
 * Scope-exit cleanup callback that ends a Cl_Scratch scope via cl_scratch_end(*s).
 *
 * Parameters:
 *   s (Cl_Scratch *) - Pointer to the local Cl_Scratch guard leaving scope.
 */
static inline void cl_defer_run_scratch(Cl_Scratch *s) {
    if (s != NULL && s->temp.arena != NULL) {
        cl_scratch_end(*s);
    }
}

/*
 * Scope-exit cleanup callback that destroys a Cl_Pool via cl_pool_destroy(*p).
 *
 * Parameters:
 *   p (Cl_Pool **) - Pointer to the local Cl_Pool pointer guard leaving scope.
 */
static inline void cl_defer_run_pool(Cl_Pool **p) {
    if (p != NULL && *p != NULL) {
        cl_pool_destroy(*p);
    }
}

/*
 * Scope-exit cleanup callback that destroys a Cl_Tracking_Allocator via cl_tracking_destroy(*p).
 *
 * Parameters:
 *   p (Cl_Tracking_Allocator **) - Pointer to the local Cl_Tracking_Allocator pointer guard.
 */
static inline void cl_defer_run_tracking(Cl_Tracking_Allocator **p) {
    if (p != NULL && *p != NULL) {
        cl_tracking_destroy(*p);
    }
}

/*
 * Scope-exit cleanup callback that pops a pushed Cl_Context via cl_ctx_pop() and
 * clears the pushed flag to 0.
 *
 * Parameters:
 *   pushed (int *) - Pointer to flag (1 if cl_ctx_push succeeded, 0 otherwise).
 */
static inline void cl_defer_run_ctx_pop(int *pushed) {
    if (pushed != NULL && *pushed) {
        cl_ctx_pop();
        *pushed = 0;
    }
}

/*
 * Scope-exit cleanup callback that closes a stdio FILE* via fclose(**fpp) and
 * resets **fpp to NULL if non-NULL.
 *
 * Parameters:
 *   fpp (FILE ***) - Pointer to the local FILE ** guard referencing the user's FILE* variable.
 */
static inline void cl_defer_run_file(FILE ***fpp) {
    if (fpp != NULL && *fpp != NULL && **fpp != NULL) {
        fclose(**fpp);
        **fpp = NULL;
    }
}

/* ----------------------------------------------------------------------------
 * Tier 1: Scope-Exit Defer Macros (GCC & Clang, Early-Return Safe, LIFO)
 * ---------------------------------------------------------------------------- */
#if CL_HAVE_CLEANUP

    /*
     * Schedules fn(arg_ptr) to run automatically at the end of the enclosing scope
     * in strict LIFO order (early-return safe).
     *
     * Parameters:
     *   fn      (Cl_Defer_Proc) - Callback with signature void fn(void *).
     *   arg_ptr (void *)        - Argument pointer passed to fn at scope exit.
     */
    #define CL_DEFER_FN(fn, arg_ptr) \
        CL_CLEANUP(cl_defer_run_action) Cl_Defer_Action CL_UNIQUE(_cl_def_act_) = { (fn), (arg_ptr) }

    /*
     * Variable declaration attribute macro attaching a typed scope-exit cleanup
     * function `void cleanup_fn(T *var_ptr)` to a local variable.
     *
     * Parameters:
     *   cleanup_fn (function identifier) - Cleanup callback taking a pointer to the variable.
     */
    #define CL_DEFER_VAR(cleanup_fn) CL_CLEANUP(cleanup_fn)

    /*
     * Schedules cl_free_loc(alloc_expr, ptr_var, size_expr, CL_HERE) at scope exit.
     * Captures the current value of ptr_var at declaration time (no-op if NULL).
     *
     * Parameters:
     *   alloc_expr (Cl_Allocator)     - Allocator that owns ptr_var.
     *   ptr_var    (void * / T *)     - Pointer to free on scope exit.
     *   size_expr  (cl_isize, bytes)  - Allocation size in bytes (>= 0).
     */
    #define CL_DEFER_FREE(alloc_expr, ptr_var, size_expr)               \
        void *CL_UNIQUE(_cl_def_p_) = (void *)(ptr_var);                \
        CL_CLEANUP(cl_defer_run_free) Cl_Defer_Free_Guard CL_UNIQUE(_cl_def_fg_) = { \
            (alloc_expr), &CL_UNIQUE(_cl_def_p_), (size_expr), CL_HERE  \
        }

    /*
     * Schedules cl_free_loc() referencing a `void *` lvalue directly so ownership
     * can be transferred out of scope by setting void_ptr_lval = NULL before exit.
     *
     * Parameters:
     *   alloc_expr    (Cl_Allocator)     - Allocator that owns the allocation.
     *   void_ptr_lval (void * lvalue)    - Modifiable `void *` variable whose address is tracked.
     *   size_expr     (cl_isize, bytes)  - Allocation size in bytes (>= 0).
     */
    #define CL_DEFER_FREE_SLOT(alloc_expr, void_ptr_lval, size_expr)    \
        CL_CLEANUP(cl_defer_run_free) Cl_Defer_Free_Guard CL_UNIQUE(_cl_def_fgs_) = { \
            (alloc_expr), &(void_ptr_lval), (size_expr), CL_HERE        \
        }

    /*
     * Schedules cl_arena_destroy(&arena_var) automatically at scope exit.
     *
     * Parameters:
     *   arena_var (Cl_Arena lvalue) - Local Cl_Arena variable to destroy on exit.
     */
    #define CL_DEFER_ARENA(arena_var) \
        CL_CLEANUP(cl_defer_run_arena) Cl_Arena *CL_UNIQUE(_cl_def_ar_) = &(arena_var)

    /*
     * Schedules cl_arena_temp_end(temp_var) automatically at scope exit.
     *
     * Parameters:
     *   temp_var (Cl_Arena_Temp) - Arena temporary checkpoint value to rewind on exit.
     */
    #define CL_DEFER_TEMP(temp_var) \
        CL_CLEANUP(cl_defer_run_arena_temp) Cl_Arena_Temp CL_UNIQUE(_cl_def_at_) = (temp_var)

    /*
     * Schedules cl_varena_destroy(&va_var) automatically at scope exit.
     *
     * Parameters:
     *   va_var (Cl_Virtual_Arena lvalue) - Local Cl_Virtual_Arena variable to destroy on exit.
     */
    #define CL_DEFER_VARENA(va_var) \
        CL_CLEANUP(cl_defer_run_varena) Cl_Virtual_Arena *CL_UNIQUE(_cl_def_va_) = &(va_var)

    /*
     * Schedules cl_varena_temp_end(vtemp_var) automatically at scope exit.
     *
     * Parameters:
     *   vtemp_var (Cl_VArena_Temp) - Virtual arena temporary checkpoint to rewind on exit.
     */
    #define CL_DEFER_VTEMP(vtemp_var) \
        CL_CLEANUP(cl_defer_run_varena_temp) Cl_VArena_Temp CL_UNIQUE(_cl_def_vt_) = (vtemp_var)

    /*
     * Schedules cl_scratch_end(scratch_var) automatically at scope exit.
     *
     * Parameters:
     *   scratch_var (Cl_Scratch) - Thread-local scratch arena handle to rewind on exit.
     */
    #define CL_DEFER_SCRATCH(scratch_var) \
        CL_CLEANUP(cl_defer_run_scratch) Cl_Scratch CL_UNIQUE(_cl_def_sc_) = (scratch_var)

    /*
     * Schedules cl_pool_destroy(&pool_var) automatically at scope exit.
     *
     * Parameters:
     *   pool_var (Cl_Pool lvalue) - Local Cl_Pool variable to destroy on exit.
     */
    #define CL_DEFER_POOL(pool_var) \
        CL_CLEANUP(cl_defer_run_pool) Cl_Pool *CL_UNIQUE(_cl_def_pl_) = &(pool_var)

    /*
     * Schedules cl_tracking_destroy(&tracker_var) automatically at scope exit.
     *
     * Parameters:
     *   tracker_var (Cl_Tracking_Allocator lvalue) - Local tracking allocator to destroy on exit.
     */
    #define CL_DEFER_TRACKING(tracker_var) \
        CL_CLEANUP(cl_defer_run_tracking) Cl_Tracking_Allocator *CL_UNIQUE(_cl_def_tr_) = &(tracker_var)

    /*
     * Pushes a Cl_Context onto the thread-local context stack and schedules
     * cl_ctx_pop() at scope exit if pushing succeeded.
     *
     * Parameters:
     *   ctx_expr (Cl_Context) - Context value to push for the remainder of the scope.
     */
    #define CL_DEFER_CTX_PUSH(ctx_expr) \
        CL_CLEANUP(cl_defer_run_ctx_pop) int CL_UNIQUE(_cl_def_ctx_) = cl_ctx_push(ctx_expr) ? 1 : 0

    /*
     * Schedules fclose(fp_var) at scope exit if fp_var is non-NULL, setting fp_var
     * to NULL after closing (also supports canceling close by setting fp_var = NULL).
     *
     * Parameters:
     *   fp_var (FILE * lvalue) - Modifiable FILE * variable to close on scope exit.
     */
    #define CL_DEFER_FILE(fp_var) \
        CL_CLEANUP(cl_defer_run_file) FILE **CL_UNIQUE(_cl_def_fp_) = &(fp_var)

#endif /* CL_HAVE_CLEANUP */

/* ----------------------------------------------------------------------------
 * Tier 2: Pure ISO C99 Structured Defer Blocks (Zero Extensions)
 *
 * CAUTION: Never `return`, `break`, or `goto` out of a Tier 2 block; use
 * `continue` to exit the block early so the cleanup expression still executes!
 * ---------------------------------------------------------------------------- */

/*
 * Pure ISO C99 single-iteration loop wrapper that evaluates begin_expr on entry
 * and end_expr upon normal exit or `continue`. Must not be exited with return/break/goto.
 *
 * Parameters:
 *   begin_expr (C expression) - Setup expression evaluated once before the block body.
 *   end_expr   (C expression) - Teardown expression evaluated once after the block body.
 */
#define CL_DEFER_LOOP(begin_expr, end_expr) \
    for (int CL_UNIQUE(_cl_dl_) = ((begin_expr), 0); !CL_UNIQUE(_cl_dl_); CL_UNIQUE(_cl_dl_) += 1, (end_expr))

/*
 * Pure ISO C99 scoped block that begins a Cl_Arena_Temp checkpoint on arena_ptr
 * and automatically rewinds it at block exit (use `continue` for early exit).
 *
 * Parameters:
 *   arena_ptr (Cl_Arena *) - Non-NULL arena pointer to checkpoint for the block duration.
 */
#define CL_WITH_TEMP(arena_ptr)                                           \
    for (Cl_Arena_Temp CL_UNIQUE(_cl_wt_) = cl_arena_temp_begin(arena_ptr); \
         CL_UNIQUE(_cl_wt_).arena != NULL;                                \
         cl_arena_temp_end(CL_UNIQUE(_cl_wt_)), CL_UNIQUE(_cl_wt_).arena = NULL)

/*
 * Pure ISO C99 scoped block that pushes ctx_expr onto the thread-local context
 * stack and automatically pops it at block exit (skipped if push fails).
 *
 * Parameters:
 *   ctx_expr (Cl_Context) - Context value pushed for the duration of the block.
 */
#define CL_WITH_CTX(ctx_expr)                                             \
    for (int CL_UNIQUE(_cl_wc_) = cl_ctx_push(ctx_expr) ? 1 : 0;          \
         CL_UNIQUE(_cl_wc_);                                              \
         cl_ctx_pop(), CL_UNIQUE(_cl_wc_) = 0)

/* ----------------------------------------------------------------------------
 * Tier 3: Pure ISO C99 Early-Return-Safe Defer Stack
 * ---------------------------------------------------------------------------- */

/*
 * Maximum capacity of a Cl_Defer_Stack (int, action slot count = 32).
 */
#define CL_DEFER_STACK_MAX 32

/*
 * Fixed-capacity LIFO stack of deferred actions for portable early-return-safe
 * cleanup in pure ISO C99 without compiler extensions.
 *
 * Fields:
 *   items (Cl_Defer_Action[CL_DEFER_STACK_MAX]) - Stored deferred callbacks in push order.
 *   count (cl_isize, element count)             - Number of active entries in [0, CL_DEFER_STACK_MAX].
 */
typedef struct Cl_Defer_Stack {
    Cl_Defer_Action items[CL_DEFER_STACK_MAX];
    cl_isize        count;
} Cl_Defer_Stack;

/*
 * Initializes a Cl_Defer_Stack to empty (count = 0).
 *
 * Parameters:
 *   ds (Cl_Defer_Stack *) - Non-NULL pointer to the defer stack to initialize.
 */
static inline void cl_defer_stack_init(Cl_Defer_Stack *ds) {
    ds->count = 0;
}

/*
 * Pushes a deferred cleanup action onto a Cl_Defer_Stack for LIFO execution.
 *
 * Parameters:
 *   ds  (Cl_Defer_Stack *) - Pointer to initialized defer stack (returns false if NULL).
 *   fn  (Cl_Defer_Proc)    - Callback function to run (returns false if NULL).
 *   arg (void *)           - User context pointer forwarded to fn(arg).
 *
 * Returns:
 *   bool - true if the action was pushed, false if ds/fn is NULL or stack is full.
 */
static inline bool cl_defer_stack_push(Cl_Defer_Stack *ds, Cl_Defer_Proc fn, void *arg) {
    if (ds == NULL || fn == NULL || ds->count >= CL_DEFER_STACK_MAX) {
        return false;
    }
    ds->items[ds->count].fn  = fn;
    ds->items[ds->count].arg = arg;
    ds->count += 1;
    return true;
}

/*
 * Executes and drains all queued actions in a Cl_Defer_Stack in reverse (LIFO) order.
 * Safe no-op if ds is NULL or empty.
 *
 * Parameters:
 *   ds (Cl_Defer_Stack *) - Pointer to the defer stack to execute and empty.
 */
static inline void cl_defer_stack_run(Cl_Defer_Stack *ds) {
    if (ds == NULL) {
        return;
    }
    while (ds->count > 0) {
        ds->count -= 1;
        Cl_Defer_Action a = ds->items[ds->count];
        if (a.fn != NULL) {
            a.fn(a.arg);
        }
    }
}

/*
 * Executes all deferred actions on ds_ptr in LIFO order and then returns val from
 * the enclosing non-void function.
 *
 * Parameters:
 *   ds_ptr (Cl_Defer_Stack *) - Pointer to the active defer stack.
 *   val    (return expression) - Value returned after deferred actions complete.
 */
#define CL_DEFER_STACK_RETURN(ds_ptr, val) do { \
    cl_defer_stack_run(ds_ptr);                 \
    return (val);                               \
} while (0)

/*
 * Executes all deferred actions on ds_ptr in LIFO order and then returns from
 * the enclosing void function.
 *
 * Parameters:
 *   ds_ptr (Cl_Defer_Stack *) - Pointer to the active defer stack.
 */
#define CL_DEFER_STACK_RETURN_VOID(ds_ptr) do { \
    cl_defer_stack_run(ds_ptr);                 \
    return;                                     \
} while (0)

#endif /* CL_DEFER_H */
