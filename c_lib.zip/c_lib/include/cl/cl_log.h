/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_log.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Structured, pluggable logging system modeled after Odin's `core:log`.
 *   Supports console (auto-ANSI color via isatty), file, multi-sink fan-out,
 *   and silent nil loggers, integrated directly into `Cl_Context`.
 *
 * Compile-Time Stripping:
 *   Set `-DCL_LOG_MIN_LEVEL=1` (INFO) or `2` (WARN) to compile away lower
 *   log levels completely with zero runtime overhead.
 * ============================================================================
 */

#ifndef CL_LOG_H
#define CL_LOG_H

#include "cl_types.h"
#include <stdarg.h>
#include <stdio.h>

/* ----------------------------------------------------------------------------
 * Log Levels & Formatting Options
 * ---------------------------------------------------------------------------- */

/*
 * Enum: Cl_Log_Level
 * Purpose:
 *   Severity levels for structured logging, ordered from least severe (0) to
 *   most severe (4). Used both for runtime threshold filtering
 *   (Cl_Logger.lowest_level) and compile-time stripping (CL_LOG_MIN_LEVEL).
 * Values:
 *   CL_LOG_LEVEL_DEBUG (0): Verbose diagnostic messages for development.
 *   CL_LOG_LEVEL_INFO  (1): General informational runtime events.
 *   CL_LOG_LEVEL_WARN  (2): Recoverable warnings and unusual conditions.
 *   CL_LOG_LEVEL_ERROR (3): Errors affecting an operation.
 *   CL_LOG_LEVEL_FATAL (4): Critical unrecoverable failures.
 */
typedef enum Cl_Log_Level {
    CL_LOG_LEVEL_DEBUG = 0,
    CL_LOG_LEVEL_INFO  = 1,
    CL_LOG_LEVEL_WARN  = 2,
    CL_LOG_LEVEL_ERROR = 3,
    CL_LOG_LEVEL_FATAL = 4
} Cl_Log_Level;

/*
 * Enum: Anonymous log formatting option bitmask flags (combined into cl_u32)
 * Purpose:
 *   Bitmask flags controlling which metadata fields and ANSI color codes a
 *   stream logger emits alongside each log message.
 * Values:
 *   CL_LOG_OPT_LEVEL (1u << 0): Emit severity tag such as "[INFO ]".
 *   CL_LOG_OPT_TIME (1u << 1): Emit local wall-clock timestamp HH:MM:SS.mmm
 *     (hours, minutes, seconds, milliseconds).
 *   CL_LOG_OPT_SHORT_FILE (1u << 2): Emit source file basename and 1-based
 *     line number ("file.c:line").
 *   CL_LOG_OPT_LONG_FILE (1u << 3): Emit full source file path and 1-based
 *     line number ("path/to/file.c:line"); takes precedence over SHORT_FILE.
 *   CL_LOG_OPT_FUNC (1u << 4): Emit calling function name as "(func)".
 *   CL_LOG_OPT_COLOR (1u << 5): Unconditionally emit ANSI SGR color escapes.
 *   CL_LOG_OPT_AUTO_COLOR (1u << 6): Emit ANSI SGR color escapes only when
 *     isatty(fileno(fp)) reports an interactive terminal.
 */
enum {
    CL_LOG_OPT_LEVEL      = 1u << 0, /* Print [INFO], [WARN], etc. */
    CL_LOG_OPT_TIME       = 1u << 1, /* Print HH:MM:SS.mmm wall timestamp */
    CL_LOG_OPT_SHORT_FILE = 1u << 2, /* Print basename.c:line */
    CL_LOG_OPT_LONG_FILE  = 1u << 3, /* Print full path:line */
    CL_LOG_OPT_FUNC       = 1u << 4, /* Print function name */
    CL_LOG_OPT_COLOR      = 1u << 5, /* Force ANSI terminal colors */
    CL_LOG_OPT_AUTO_COLOR = 1u << 6  /* Enable ANSI colors only if stream is a TTY */
};

/*
 * Macro: CL_LOG_DEFAULT_OPTIONS
 * Purpose:
 *   Default cl_u32 log option bitmask enabling severity level tag, wall-clock
 *   timestamp, short filename:line, and TTY-aware automatic ANSI colors.
 * Expansion:
 *   Bitwise OR of CL_LOG_OPT_LEVEL, CL_LOG_OPT_TIME, CL_LOG_OPT_SHORT_FILE,
 *   and CL_LOG_OPT_AUTO_COLOR (unsigned 32-bit bitmask).
 */
#define CL_LOG_DEFAULT_OPTIONS \
    (CL_LOG_OPT_LEVEL | CL_LOG_OPT_TIME | CL_LOG_OPT_SHORT_FILE | CL_LOG_OPT_AUTO_COLOR)

/* ----------------------------------------------------------------------------
 * Logger Interface (Odin log.Logger)
 * ---------------------------------------------------------------------------- */

/*
 * Typedef: Cl_Log_Proc
 * Purpose:
 *   Callback function pointer type implemented by every Cl_Logger backend to
 *   consume a single formatted log message.
 * Parameters:
 *   logger_data (void *): Backend-specific user state pointer (e.g., FILE *,
 *     Cl_Multi_Logger *, or NULL for default stderr).
 *   level (Cl_Log_Level): Severity level of the message.
 *   text (Cl_Str): Formatted message payload (non-owning UTF-8 byte slice).
 *   options (cl_u32): Log option bitmask (CL_LOG_OPT_* flags).
 *   loc (Cl_Source_Loc): Call-site source file, 1-based line, and function name.
 * Returns:
 *   void.
 */
typedef void (*Cl_Log_Proc)(
    void          *logger_data,
    Cl_Log_Level   level,
    Cl_Str         text,
    cl_u32         options,
    Cl_Source_Loc  loc
);

/*
 * Struct: Cl_Logger
 * Purpose:
 *   Pluggable logger handle modeled after Odin's log.Logger, pairing a
 *   backend callback with state, minimum severity threshold, and formatting
 *   options.
 * Fields:
 *   proc (Cl_Log_Proc): Sink callback invoked for accepted log entries
 *     (NULL means uninitialized / inactive).
 *   data (void *): Opaque sink state passed as logger_data to proc.
 *   lowest_level (Cl_Log_Level): Minimum severity required to emit a message;
 *     entries with level < lowest_level are discarded.
 *   options (cl_u32): Bitmask of CL_LOG_OPT_* formatting flags.
 */
typedef struct Cl_Logger {
    Cl_Log_Proc  proc;
    void        *data;
    Cl_Log_Level lowest_level;
    cl_u32       options;
} Cl_Logger;

/*
 * Macro: CL_MULTI_LOGGER_MAX
 * Purpose:
 *   Maximum number of child Cl_Logger sinks that a single Cl_Multi_Logger
 *   can fan out to simultaneously.
 * Expansion:
 *   Integer constant 8 (sinks).
 */
#define CL_MULTI_LOGGER_MAX 8

/*
 * Struct: Cl_Multi_Logger
 * Purpose:
 *   Backing state for a fan-out logger that forwards each log message to
 *   multiple child Cl_Logger sinks (up to CL_MULTI_LOGGER_MAX).
 * Fields:
 *   sinks (Cl_Logger[CL_MULTI_LOGGER_MAX]): Fixed array of registered child
 *     logger sinks (valid entries occupy indices [0, count)).
 *   count (cl_isize): Number of currently registered child sinks, in
 *     [0, CL_MULTI_LOGGER_MAX].
 */
typedef struct Cl_Multi_Logger {
    Cl_Logger sinks[CL_MULTI_LOGGER_MAX];
    cl_isize  count;
} Cl_Multi_Logger;

/* ----------------------------------------------------------------------------
 * Logger Constructors
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_console_logger
 * Purpose:
 *   Constructs a Cl_Logger writing formatted log lines to standard error
 *   (stderr).
 * Parameters:
 *   lowest_level (Cl_Log_Level): Minimum severity threshold to emit.
 *   options (cl_u32): Log formatting option bitmask (CL_LOG_OPT_* flags).
 * Returns:
 *   Cl_Logger: Configured stderr console logger handle.
 */
Cl_Logger cl_console_logger(Cl_Log_Level lowest_level, cl_u32 options);

/*
 * Function: cl_file_logger
 * Purpose:
 *   Constructs a Cl_Logger writing formatted log lines to an already-open C
 *   FILE stream (caller remains responsible for closing fp). If fp is NULL,
 *   output falls back to stderr.
 * Parameters:
 *   fp (FILE *): Open writable FILE stream, or NULL (falls back to stderr).
 *   lowest_level (Cl_Log_Level): Minimum severity threshold to emit.
 *   options (cl_u32): Log formatting option bitmask (CL_LOG_OPT_* flags).
 * Returns:
 *   Cl_Logger: Configured file stream logger handle.
 */
Cl_Logger cl_file_logger(FILE *fp, Cl_Log_Level lowest_level, cl_u32 options);

/*
 * Function: cl_nil_logger
 * Purpose:
 *   Constructs a silent no-op Cl_Logger that discards all messages (useful
 *   for silencing expected error output during unit tests).
 * Parameters:
 *   None (void).
 * Returns:
 *   Cl_Logger: No-op logger handle.
 */
Cl_Logger cl_nil_logger(void);

/*
 * Function: cl_multi_logger_init
 * Purpose:
 *   Zero-initializes a Cl_Multi_Logger structure with count = 0 sinks.
 *   Safe no-op if ml is NULL.
 * Parameters:
 *   ml (Cl_Multi_Logger *): Multi-logger state to initialize, or NULL.
 * Returns:
 *   void.
 */
void      cl_multi_logger_init(Cl_Multi_Logger *ml);

/*
 * Function: cl_multi_logger_add
 * Purpose:
 *   Appends a child Cl_Logger sink to a Cl_Multi_Logger if fewer than
 *   CL_MULTI_LOGGER_MAX sinks are currently registered.
 * Parameters:
 *   ml (Cl_Multi_Logger *): Target multi-logger state, or NULL.
 *   sink (Cl_Logger): Child logger handle to append.
 * Returns:
 *   bool: true if sink was added; false if ml is NULL or full.
 */
bool      cl_multi_logger_add(Cl_Multi_Logger *ml, Cl_Logger sink);

/*
 * Function: cl_multi_logger
 * Purpose:
 *   Wraps an initialized Cl_Multi_Logger in a Cl_Logger handle that forwards
 *   messages to all registered child sinks. The pointed-to ml must outlive
 *   the returned Cl_Logger.
 * Parameters:
 *   ml (Cl_Multi_Logger *): Backing multi-logger state (must remain valid
 *     while the logger is used).
 *   lowest_level (Cl_Log_Level): Minimum severity threshold for the fan-out
 *     logger itself (each child sink also applies its own lowest_level).
 * Returns:
 *   Cl_Logger: Configured fan-out logger handle.
 */
Cl_Logger cl_multi_logger(Cl_Multi_Logger *ml, Cl_Log_Level lowest_level);

/* ----------------------------------------------------------------------------
 * Active Thread-Local Logger Binding (Synced by Cl_Context)
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_log_set_active
 * Purpose:
 *   Sets the active thread-local Cl_Logger used by cl_log_active_fmt and the
 *   CL_LOG_* macros (also synchronized by Cl_Context).
 * Parameters:
 *   logger (Cl_Logger): Logger handle to make active on the current thread.
 * Returns:
 *   void.
 */
void      cl_log_set_active(Cl_Logger logger);

/*
 * Function: cl_log_get_active
 * Purpose:
 *   Retrieves the active thread-local Cl_Logger. If none has been set yet
 *   (proc == NULL), returns a default stderr console logger at
 *   CL_LOG_LEVEL_DEBUG with CL_LOG_DEFAULT_OPTIONS.
 * Parameters:
 *   None (void).
 * Returns:
 *   Cl_Logger: Currently active thread-local logger handle.
 */
Cl_Logger cl_log_get_active(void);

/*
 * Function: cl_log_write
 * Purpose:
 *   Dispatches a pre-formatted Cl_Str message directly to logger if
 *   logger.proc is non-NULL and level >= logger.lowest_level.
 * Parameters:
 *   logger (Cl_Logger): Target logger handle.
 *   level (Cl_Log_Level): Severity level of the message.
 *   loc (Cl_Source_Loc): Call-site source location metadata.
 *   msg (Cl_Str): Message payload byte slice.
 * Returns:
 *   void.
 */
void cl_log_write(Cl_Logger logger, Cl_Log_Level level, Cl_Source_Loc loc, Cl_Str msg);

/*
 * Function: cl_log_write_fmt
 * Purpose:
 *   Formats a printf-style message (zero-heap stack buffer under 1024 bytes,
 *   malloc fallback for longer messages) and dispatches it to logger if
 *   level >= logger.lowest_level.
 * Parameters:
 *   logger (Cl_Logger): Target logger handle.
 *   level (Cl_Log_Level): Severity level of the message.
 *   loc (Cl_Source_Loc): Call-site source location metadata.
 *   fmt (const char *): NUL-terminated printf format string.
 *   ... (variadic): Arguments matching fmt.
 * Returns:
 *   void.
 */
CL_PRINTF_LIKE(4, 5) void cl_log_write_fmt(
    Cl_Logger logger,
    Cl_Log_Level level,
    Cl_Source_Loc loc,
    const char *fmt,
    ...
);

/*
 * Function: cl_log_active_fmt
 * Purpose:
 *   Formats a printf-style message and dispatches it to the current thread's
 *   active logger (retrieved via cl_log_get_active()).
 * Parameters:
 *   level (Cl_Log_Level): Severity level of the message.
 *   loc (Cl_Source_Loc): Call-site source location metadata.
 *   fmt (const char *): NUL-terminated printf format string.
 *   ... (variadic): Arguments matching fmt.
 * Returns:
 *   void.
 */
CL_PRINTF_LIKE(3, 4) void cl_log_active_fmt(
    Cl_Log_Level level,
    Cl_Source_Loc loc,
    const char *fmt,
    ...
);

/*
 * Function: cl_log_level_name
 * Purpose:
 *   Returns a fixed 5-character NUL-terminated label string for a log level
 *   ("DEBUG", "INFO ", "WARN ", "ERROR", "FATAL", or "?????" if unknown).
 * Parameters:
 *   level (Cl_Log_Level): Severity level value.
 * Returns:
 *   const char *: Static NUL-terminated 5-character severity name string.
 */
const char *cl_log_level_name(Cl_Log_Level level);

/* ----------------------------------------------------------------------------
 * Ergonomic Logging Macros (ISO C99 Variadic, Compile-Time Strippable)
 * ---------------------------------------------------------------------------- */
#if CL_LOG_MIN_LEVEL <= 0
    /*
     * Macro: CL_LOG_DEBUG(...)
     * Purpose:
     *   Logs a formatted message at CL_LOG_LEVEL_DEBUG to the active logger,
     *   automatically capturing CL_HERE source location metadata.
     * Parameters:
     *   ... (const char *fmt, ...): printf-style format string and arguments.
     */
    #define CL_LOG_DEBUG(...) cl_log_active_fmt(CL_LOG_LEVEL_DEBUG, CL_HERE, __VA_ARGS__)
#else
    /*
     * Macro: CL_LOG_DEBUG(...)
     * Purpose:
     *   Compile-time stripped no-op stub when CL_LOG_MIN_LEVEL > 0.
     * Parameters:
     *   ... (ignored): Arguments are discarded without evaluation.
     */
    #define CL_LOG_DEBUG(...) ((void)0)
#endif

#if CL_LOG_MIN_LEVEL <= 1
    /*
     * Macro: CL_LOG_INFO(...)
     * Purpose:
     *   Logs a formatted message at CL_LOG_LEVEL_INFO to the active logger,
     *   automatically capturing CL_HERE source location metadata.
     * Parameters:
     *   ... (const char *fmt, ...): printf-style format string and arguments.
     */
    #define CL_LOG_INFO(...)  cl_log_active_fmt(CL_LOG_LEVEL_INFO,  CL_HERE, __VA_ARGS__)
#else
    /*
     * Macro: CL_LOG_INFO(...)
     * Purpose:
     *   Compile-time stripped no-op stub when CL_LOG_MIN_LEVEL > 1.
     * Parameters:
     *   ... (ignored): Arguments are discarded without evaluation.
     */
    #define CL_LOG_INFO(...)  ((void)0)
#endif

#if CL_LOG_MIN_LEVEL <= 2
    /*
     * Macro: CL_LOG_WARN(...)
     * Purpose:
     *   Logs a formatted message at CL_LOG_LEVEL_WARN to the active logger,
     *   automatically capturing CL_HERE source location metadata.
     * Parameters:
     *   ... (const char *fmt, ...): printf-style format string and arguments.
     */
    #define CL_LOG_WARN(...)  cl_log_active_fmt(CL_LOG_LEVEL_WARN,  CL_HERE, __VA_ARGS__)
#else
    /*
     * Macro: CL_LOG_WARN(...)
     * Purpose:
     *   Compile-time stripped no-op stub when CL_LOG_MIN_LEVEL > 2.
     * Parameters:
     *   ... (ignored): Arguments are discarded without evaluation.
     */
    #define CL_LOG_WARN(...)  ((void)0)
#endif

#if CL_LOG_MIN_LEVEL <= 3
    /*
     * Macro: CL_LOG_ERROR(...)
     * Purpose:
     *   Logs a formatted message at CL_LOG_LEVEL_ERROR to the active logger,
     *   automatically capturing CL_HERE source location metadata.
     * Parameters:
     *   ... (const char *fmt, ...): printf-style format string and arguments.
     */
    #define CL_LOG_ERROR(...) cl_log_active_fmt(CL_LOG_LEVEL_ERROR, CL_HERE, __VA_ARGS__)
#else
    /*
     * Macro: CL_LOG_ERROR(...)
     * Purpose:
     *   Compile-time stripped no-op stub when CL_LOG_MIN_LEVEL > 3.
     * Parameters:
     *   ... (ignored): Arguments are discarded without evaluation.
     */
    #define CL_LOG_ERROR(...) ((void)0)
#endif

#if CL_LOG_MIN_LEVEL <= 4
    /*
     * Macro: CL_LOG_FATAL(...)
     * Purpose:
     *   Logs a formatted message at CL_LOG_LEVEL_FATAL to the active logger,
     *   automatically capturing CL_HERE source location metadata.
     * Parameters:
     *   ... (const char *fmt, ...): printf-style format string and arguments.
     */
    #define CL_LOG_FATAL(...) cl_log_active_fmt(CL_LOG_LEVEL_FATAL, CL_HERE, __VA_ARGS__)
#else
    /*
     * Macro: CL_LOG_FATAL(...)
     * Purpose:
     *   Compile-time stripped no-op stub when CL_LOG_MIN_LEVEL > 4.
     * Parameters:
     *   ... (ignored): Arguments are discarded without evaluation.
     */
    #define CL_LOG_FATAL(...) ((void)0)
#endif

#endif /* CL_LOG_H */
