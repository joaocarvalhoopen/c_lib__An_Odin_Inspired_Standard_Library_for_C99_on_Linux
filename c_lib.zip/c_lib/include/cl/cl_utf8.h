/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_utf8.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Strict RFC 3629 UTF-8 rune decoding, encoding, validation, counting, and
 *   iteration (modeled after Odin's `core:unicode/utf8`).
 *
 * Safety Guarantees:
 *   - Rejects overlong sequences, UTF-16 surrogates (U+D800..U+DFFF),
 *     truncated multi-byte sequences, and code points above U+10FFFF.
 *   - Invalid sequences return CL_RUNE_ERROR (U+FFFD) with width = 1 and
 *     valid = false so decoders always make forward progress without looping.
 * ============================================================================
 */

#ifndef CL_UTF8_H
#define CL_UTF8_H

#include "cl_types.h"
#include "cl_result.h"

/*
 * Macro: CL_RUNE_ERROR
 * Purpose:
 *   Unicode replacement character scalar value (U+FFFD) returned by UTF-8
 *   decoders on invalid byte sequences and substituted by encoders for
 *   invalid Unicode code points.
 * Expansion:
 *   Constant value of type cl_rune equal to 0xFFFD.
 */
#define CL_RUNE_ERROR ((cl_rune)0xFFFD)

/*
 * Macro: CL_RUNE_MAX
 * Purpose:
 *   Maximum valid Unicode scalar value (U+10FFFF) permitted by RFC 3629 UTF-8.
 * Expansion:
 *   Constant value of type cl_rune equal to 0x10FFFF.
 */
#define CL_RUNE_MAX   ((cl_rune)0x10FFFF)

/*
 * Macro: CL_UTF8_MAX_BYTES
 * Purpose:
 *   Maximum number of bytes required to encode any valid Unicode scalar value
 *   in RFC 3629 UTF-8.
 * Expansion:
 *   Integer constant 4 (bytes).
 */
#define CL_UTF8_MAX_BYTES 4

/*
 * Function: cl_utf8_decode_rune
 * Purpose:
 *   Decodes the first RFC 3629 UTF-8 code point at the start of a byte slice.
 *   Strictly rejects overlong encodings, UTF-16 surrogates (U+D800..U+DFFF),
 *   invalid continuation bytes, truncated sequences, and values above U+10FFFF.
 * Parameters:
 *   s (Cl_Str): Input UTF-8 byte slice (data pointer and length in bytes).
 *     NULL data or non-positive length is handled safely.
 * Returns:
 *   Cl_Utf8_Decode: Struct { codepoint (cl_rune), width (cl_isize, bytes),
 *     valid (bool) }. On a valid rune, width is in [1, 4] bytes and valid is
 *     true. On empty/NULL input, returns { 0, 0, false }. On any invalid
 *     sequence, returns { CL_RUNE_ERROR, 1, false } so callers advance by
 *     1 byte without stalling.
 */
Cl_Utf8_Decode cl_utf8_decode_rune(Cl_Str s);

/*
 * Function: cl_utf8_encode_rune
 * Purpose:
 *   Encodes a Unicode scalar value into its RFC 3629 UTF-8 byte sequence.
 *   Invalid runes (negative, > CL_RUNE_MAX, or surrogates U+D800..U+DFFF)
 *   are substituted with CL_RUNE_ERROR (U+FFFD).
 * Parameters:
 *   r (cl_rune): Unicode code point (scalar value) to encode.
 *   out (cl_u8[4]): Caller-provided output buffer of at least 4 bytes; must
 *     be non-NULL.
 * Returns:
 *   cl_isize: Number of UTF-8 bytes written to out, in [1, 4] bytes (3 bytes
 *     when r is invalid and replaced by U+FFFD).
 */
cl_isize cl_utf8_encode_rune(cl_rune r, cl_u8 out[4]);

/*
 * Function: cl_utf8_rune_width
 * Purpose:
 *   Computes the number of bytes required to encode a Unicode code point in
 *   RFC 3629 UTF-8 without writing any output.
 * Parameters:
 *   r (cl_rune): Unicode code point to measure.
 * Returns:
 *   cl_isize: Encoded UTF-8 length in bytes, in [1, 4]: 1 for <= 0x7F,
 *     2 for <= 0x7FF, 3 for <= 0xFFFF, 4 for <= 0x10FFFF, or 3 for invalid
 *     code points (width of the U+FFFD replacement character).
 */
cl_isize cl_utf8_rune_width(cl_rune r);

/*
 * Function: cl_utf8_is_valid_rune
 * Purpose:
 *   Checks whether a code point is a valid Unicode scalar value encodable
 *   in RFC 3629 UTF-8.
 * Parameters:
 *   r (cl_rune): Unicode code point to validate.
 * Returns:
 *   bool: true if 0 <= r <= CL_RUNE_MAX and r is not in the UTF-16 surrogate
 *     range [0xD800, 0xDFFF]; false otherwise.
 */
bool cl_utf8_is_valid_rune(cl_rune r);

/*
 * Function: cl_utf8_valid
 * Purpose:
 *   Validates that every byte sequence across an entire string slice forms
 *   strict RFC 3629 UTF-8.
 * Parameters:
 *   s (Cl_Str): Input byte slice (length in bytes). An empty string is valid.
 * Returns:
 *   bool: true if the entire byte slice consists of valid UTF-8 runes;
 *     false if any malformed or truncated sequence is present.
 */
bool cl_utf8_valid(Cl_Str s);

/*
 * Function: cl_utf8_rune_count
 * Purpose:
 *   Counts the total number of Unicode code points (runes) in a UTF-8 byte
 *   slice. Each invalid byte counts as 1 replacement rune (advancing 1 byte).
 * Parameters:
 *   s (Cl_Str): Input byte slice (length in bytes).
 * Returns:
 *   cl_isize: Total number of runes (>= 0).
 */
cl_isize cl_utf8_rune_count(Cl_Str s);

/*
 * Function: cl_utf8_next
 * Purpose:
 *   Decodes the next UTF-8 rune starting at a 0-based byte offset and
 *   advances the offset cursor past the consumed bytes.
 * Parameters:
 *   s (Cl_Str): Input UTF-8 byte slice (length in bytes).
 *   offset (cl_isize *): Pointer to the current 0-based byte offset into s.
 *     On a valid step, incremented by dec.width bytes (at least 1 byte).
 *     NULL or out-of-range offsets terminate iteration safely.
 * Returns:
 *   Cl_Utf8_Decode: Decoded rune { codepoint (cl_rune), width (cl_isize,
 *     bytes), valid (bool) }, or { 0, 0, false } when offset is NULL, < 0,
 *     or >= s.len.
 */
static inline Cl_Utf8_Decode cl_utf8_next(Cl_Str s, cl_isize *offset) {
    if (offset == NULL || *offset < 0 || *offset >= s.len) {
        return (Cl_Utf8_Decode){ 0, 0, false };
    }
    Cl_Str rem = { s.data + *offset, s.len - *offset };
    Cl_Utf8_Decode dec = cl_utf8_decode_rune(rem);
    *offset += (dec.width > 0) ? dec.width : 1;
    return dec;
}

#endif /* CL_UTF8_H */
