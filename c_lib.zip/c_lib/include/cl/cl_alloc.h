/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_alloc.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Defines the uniform Odin-style allocator interface (`Cl_Allocator`),
 *   built-in `cl_heap_allocator()` and `cl_panic_allocator()`, and ergonomic
 *   allocation macros that automatically capture `CL_HERE` source locations
 *   and zero-initialize memory by default.
 *
 * Why a Uniform Allocator Interface:
 *   Every container (`Cl_DA_*`, `Cl_Map_*`, `Cl_String_Builder`, string
 *   cloning/joining) accepts a `Cl_Allocator`. You can swap Heap -> Arena ->
 *   Virtual Arena -> Pool -> Tracking Allocator without changing a single line
 *   of container or business logic.
 *
 * Contract:
 *   - `CL_ALLOC_ALLOC` and `CL_ALLOC_RESIZE` ALWAYS zero-initialize new bytes.
 *   - `CL_ALLOC_ALLOC_NON_ZEROED` and `CL_ALLOC_RESIZE_NON_ZEROED` skip
 *     zeroing for hot paths where the caller immediately overwrites the buffer.
 *   - `alignment` must be a power of two (defaults to CL_DEFAULT_ALIGNMENT).
 *   - Passing `size == 0` to ALLOC returns NULL cleanly without error.
 *   - Passing `old_memory == NULL` to FREE is a guaranteed safe no-op.
 * ============================================================================
 */

#ifndef CL_ALLOC_H
#define CL_ALLOC_H

#include "cl_types.h"
#include "cl_mem.h"
#include "cl_assert.h"

/* ----------------------------------------------------------------------------
 * Allocator Mode & Interface
 * ---------------------------------------------------------------------------- */

/*
 * Operation mode passed to a Cl_Alloc_Proc dispatch callback.
 *
 * Enumerators:
 *   CL_ALLOC_ALLOC             (0) - Allocate size zero-initialized bytes.
 *   CL_ALLOC_ALLOC_NON_ZEROED  (1) - Allocate size uninitialized bytes.
 *   CL_ALLOC_FREE              (2) - Free old_memory of old_size bytes.
 *   CL_ALLOC_FREE_ALL          (3) - Reset or release all allocations in bulk (arenas/pools).
 *   CL_ALLOC_RESIZE            (4) - Resize old_memory from old_size to size bytes,
 *                                    zero-initializing any newly grown bytes.
 *   CL_ALLOC_RESIZE_NON_ZEROED (5) - Resize old_memory from old_size to size bytes
 *                                    without zero-initializing newly grown bytes.
 */
typedef enum Cl_Alloc_Mode {
    CL_ALLOC_ALLOC = 0,          /* Allocate `size` zero-initialized bytes */
    CL_ALLOC_ALLOC_NON_ZEROED,   /* Allocate `size` uninitialized bytes */
    CL_ALLOC_FREE,               /* Free `old_memory` of `old_size` bytes */
    CL_ALLOC_FREE_ALL,           /* Reset/release all allocations (arenas) */
    CL_ALLOC_RESIZE,             /* Resize `old_memory` to `size`, zero growth */
    CL_ALLOC_RESIZE_NON_ZEROED   /* Resize `old_memory` to `size`, no zeroing */
} Cl_Alloc_Mode;

/*
 * Function pointer type for unified allocator dispatch callbacks.
 *
 * Parameters:
 *   allocator_data (void *)        - Opaque allocator state pointer (may be NULL for stateless allocators).
 *   mode           (Cl_Alloc_Mode) - Requested allocation operation.
 *   size           (cl_isize)      - Requested allocation or new resize length in bytes.
 *   alignment      (cl_isize)      - Power-of-two alignment in bytes (<= 0 defaults to CL_DEFAULT_ALIGNMENT).
 *   old_memory     (void *)        - Existing block pointer for FREE/RESIZE, or NULL.
 *   old_size       (cl_isize)      - Prior block length in bytes for FREE/RESIZE (0 if unknown/unused).
 *   loc            (Cl_Source_Loc) - Caller source location (file, line, function) for diagnostics.
 *
 * Returns:
 *   (void *) Pointer to allocated/resized memory, or NULL on FREE, FREE_ALL, size <= 0, or failure.
 */
typedef void *(*Cl_Alloc_Proc)(
    void          *allocator_data,
    Cl_Alloc_Mode  mode,
    cl_isize       size,
    cl_isize       alignment,
    void          *old_memory,
    cl_isize       old_size,
    Cl_Source_Loc  loc
);

/*
 * Value-type polymorphic allocator handle (16 bytes on 64-bit platforms)
 * combining a dispatch callback with an opaque backing state pointer.
 *
 * Fields:
 *   proc (Cl_Alloc_Proc) - Dispatch function pointer implementing allocation operations (NULL if invalid).
 *   data (void *)        - Opaque pointer to allocator-specific state (e.g., Cl_Arena *, Cl_Pool *).
 */
typedef struct Cl_Allocator {
    Cl_Alloc_Proc proc;
    void         *data;
} Cl_Allocator;

/*
 * Checks whether an allocator handle has a non-NULL dispatch function pointer.
 *
 * Parameters:
 *   a (Cl_Allocator) - Allocator handle to validate.
 *
 * Returns:
 *   (bool) true if a.proc != NULL; false if a is zero-initialized/invalid.
 */
static inline bool cl_allocator_is_valid(Cl_Allocator a) {
    return a.proc != NULL;
}

/* ----------------------------------------------------------------------------
 * Built-In Allocators
 * ---------------------------------------------------------------------------- */

/*
 * Returns the built-in general-purpose libc heap allocator backed by
 * malloc, calloc, posix_memalign, realloc, and free.
 *
 * Returns:
 *   (Cl_Allocator) Stateless allocator handle (data == NULL) using the system heap.
 */
Cl_Allocator cl_heap_allocator(void);

/*
 * Returns a trap-on-allocation sentinel allocator that panics immediately on
 * any allocation, resize, free-all, or non-NULL free attempt in no-alloc scopes.
 *
 * Returns:
 *   (Cl_Allocator) Stateless allocator handle (data == NULL) that asserts on use.
 */
Cl_Allocator cl_panic_allocator(void);

/* ----------------------------------------------------------------------------
 * Low-Level Allocation Functions (Accept Explicit Cl_Source_Loc)
 * ---------------------------------------------------------------------------- */

/*
 * Allocates a zero-initialized, aligned memory block using allocator a.
 *
 * Parameters:
 *   a     (Cl_Allocator)  - Valid allocator handle (a.proc must be non-NULL).
 *   size  (cl_isize)      - Number of bytes to allocate (bytes; <= 0 returns NULL).
 *   align (cl_isize)      - Power-of-two alignment in bytes (<= 0 defaults to CL_DEFAULT_ALIGNMENT).
 *   loc   (Cl_Source_Loc) - Caller source location for tracking and diagnostics.
 *
 * Returns:
 *   (void *) Pointer to at least size zeroed bytes aligned to align, or NULL if size <= 0 or OOM.
 */
void *cl_alloc_aligned_loc(Cl_Allocator a, cl_isize size, cl_isize align, Cl_Source_Loc loc);

/*
 * Allocates an uninitialized, aligned memory block using allocator a.
 *
 * Parameters:
 *   a     (Cl_Allocator)  - Valid allocator handle (a.proc must be non-NULL).
 *   size  (cl_isize)      - Number of bytes to allocate (bytes; <= 0 returns NULL).
 *   align (cl_isize)      - Power-of-two alignment in bytes (<= 0 defaults to CL_DEFAULT_ALIGNMENT).
 *   loc   (Cl_Source_Loc) - Caller source location for tracking and diagnostics.
 *
 * Returns:
 *   (void *) Pointer to at least size uninitialized bytes aligned to align, or NULL if size <= 0 or OOM.
 */
void *cl_alloc_non_zeroed_aligned_loc(Cl_Allocator a, cl_isize size, cl_isize align, Cl_Source_Loc loc);

/*
 * Resizes an existing allocation from old_size to new_size bytes, preserving
 * min(old_size, new_size) bytes and zero-initializing any newly grown tail.
 *
 * Parameters:
 *   a        (Cl_Allocator)  - Valid allocator handle (a.proc must be non-NULL).
 *   old_ptr  (void *)        - Existing allocation pointer, or NULL to perform a fresh allocation.
 *   old_size (cl_isize)      - Previous allocation size in bytes.
 *   new_size (cl_isize)      - Desired new size in bytes (<= 0 frees old_ptr and returns NULL).
 *   align    (cl_isize)      - Power-of-two alignment in bytes.
 *   loc      (Cl_Source_Loc) - Caller source location for tracking and diagnostics.
 *
 * Returns:
 *   (void *) Pointer to the resized block aligned to align, or NULL if freed (new_size <= 0)
 *            or allocation failed (old_ptr remains valid on OOM).
 */
void *cl_resize_aligned_loc(
    Cl_Allocator a,
    void *old_ptr,
    cl_isize old_size,
    cl_isize new_size,
    cl_isize align,
    Cl_Source_Loc loc
);

/*
 * Resizes an existing allocation from old_size to new_size bytes, preserving
 * min(old_size, new_size) bytes without zero-initializing any newly grown tail.
 *
 * Parameters:
 *   a        (Cl_Allocator)  - Valid allocator handle (a.proc must be non-NULL).
 *   old_ptr  (void *)        - Existing allocation pointer, or NULL to perform a fresh allocation.
 *   old_size (cl_isize)      - Previous allocation size in bytes.
 *   new_size (cl_isize)      - Desired new size in bytes (<= 0 frees old_ptr and returns NULL).
 *   align    (cl_isize)      - Power-of-two alignment in bytes.
 *   loc      (Cl_Source_Loc) - Caller source location for tracking and diagnostics.
 *
 * Returns:
 *   (void *) Pointer to the resized block aligned to align, or NULL if freed (new_size <= 0)
 *            or allocation failed (old_ptr remains valid on OOM).
 */
void *cl_resize_non_zeroed_aligned_loc(
    Cl_Allocator a,
    void *old_ptr,
    cl_isize old_size,
    cl_isize new_size,
    cl_isize align,
    Cl_Source_Loc loc
);

/*
 * Frees a single allocation previously obtained from allocator a; guaranteed
 * safe no-op if ptr is NULL.
 *
 * Parameters:
 *   a        (Cl_Allocator)  - Valid allocator handle (a.proc must be non-NULL when ptr != NULL).
 *   ptr      (void *)        - Allocation pointer to release (NULL is a safe no-op).
 *   old_size (cl_isize)      - Original allocation size in bytes (used by tracking/sized allocators; 0 if unknown).
 *   loc      (Cl_Source_Loc) - Caller source location for tracking and diagnostics.
 */
void  cl_free_loc(Cl_Allocator a, void *ptr, cl_isize old_size, Cl_Source_Loc loc);

/*
 * Releases or resets all allocations owned by allocator a in bulk (supported
 * by arenas, pools, and tracking wrappers; no-op on the libc heap allocator).
 *
 * Parameters:
 *   a   (Cl_Allocator)  - Valid allocator handle (a.proc must be non-NULL).
 *   loc (Cl_Source_Loc) - Caller source location for tracking and diagnostics.
 */
void  cl_free_all_loc(Cl_Allocator a, Cl_Source_Loc loc);

/* ----------------------------------------------------------------------------
 * Ergonomic Call-Site Macros (Automatically Inject CL_HERE)
 * ---------------------------------------------------------------------------- */

/*
 * Allocates size zero-initialized bytes with CL_DEFAULT_ALIGNMENT, capturing CL_HERE.
 *
 * Parameters:
 *   a    (Cl_Allocator) - Valid allocator handle.
 *   size (cl_isize)     - Number of bytes to allocate (bytes).
 *
 * Returns:
 *   (void *) Pointer to zeroed memory, or NULL if size <= 0 or OOM.
 */
#define cl_alloc(a, size) \
    cl_alloc_aligned_loc((a), (size), CL_DEFAULT_ALIGNMENT, CL_HERE)

/*
 * Allocates size zero-initialized bytes with explicit power-of-two alignment, capturing CL_HERE.
 *
 * Parameters:
 *   a     (Cl_Allocator) - Valid allocator handle.
 *   size  (cl_isize)     - Number of bytes to allocate (bytes).
 *   align (cl_isize)     - Power-of-two alignment in bytes.
 *
 * Returns:
 *   (void *) Pointer to zeroed aligned memory, or NULL if size <= 0 or OOM.
 */
#define cl_alloc_aligned(a, size, align) \
    cl_alloc_aligned_loc((a), (size), (align), CL_HERE)

/*
 * Allocates size uninitialized bytes with CL_DEFAULT_ALIGNMENT, capturing CL_HERE.
 *
 * Parameters:
 *   a    (Cl_Allocator) - Valid allocator handle.
 *   size (cl_isize)     - Number of bytes to allocate (bytes).
 *
 * Returns:
 *   (void *) Pointer to uninitialized memory, or NULL if size <= 0 or OOM.
 */
#define cl_alloc_non_zeroed(a, size) \
    cl_alloc_non_zeroed_aligned_loc((a), (size), CL_DEFAULT_ALIGNMENT, CL_HERE)

/*
 * Allocates size uninitialized bytes with explicit power-of-two alignment, capturing CL_HERE.
 *
 * Parameters:
 *   a     (Cl_Allocator) - Valid allocator handle.
 *   size  (cl_isize)     - Number of bytes to allocate (bytes).
 *   align (cl_isize)     - Power-of-two alignment in bytes.
 *
 * Returns:
 *   (void *) Pointer to uninitialized aligned memory, or NULL if size <= 0 or OOM.
 */
#define cl_alloc_non_zeroed_aligned(a, size, align) \
    cl_alloc_non_zeroed_aligned_loc((a), (size), (align), CL_HERE)

/*
 * Resizes ptr from old_size to new_size bytes with CL_DEFAULT_ALIGNMENT,
 * zero-initializing any grown tail and capturing CL_HERE.
 *
 * Parameters:
 *   a        (Cl_Allocator) - Valid allocator handle.
 *   ptr      (void *)       - Existing allocation pointer, or NULL.
 *   old_size (cl_isize)     - Previous allocation size in bytes.
 *   new_size (cl_isize)     - Desired new size in bytes.
 *
 * Returns:
 *   (void *) Pointer to resized memory, or NULL if new_size <= 0 or OOM.
 */
#define cl_resize(a, ptr, old_size, new_size) \
    cl_resize_aligned_loc((a), (ptr), (old_size), (new_size), CL_DEFAULT_ALIGNMENT, CL_HERE)

/*
 * Resizes ptr from old_size to new_size bytes with explicit power-of-two alignment,
 * zero-initializing any grown tail and capturing CL_HERE.
 *
 * Parameters:
 *   a        (Cl_Allocator) - Valid allocator handle.
 *   ptr      (void *)       - Existing allocation pointer, or NULL.
 *   old_size (cl_isize)     - Previous allocation size in bytes.
 *   new_size (cl_isize)     - Desired new size in bytes.
 *   align    (cl_isize)     - Power-of-two alignment in bytes.
 *
 * Returns:
 *   (void *) Pointer to resized aligned memory, or NULL if new_size <= 0 or OOM.
 */
#define cl_resize_aligned(a, ptr, old_size, new_size, align) \
    cl_resize_aligned_loc((a), (ptr), (old_size), (new_size), (align), CL_HERE)

/*
 * Resizes ptr from old_size to new_size bytes with CL_DEFAULT_ALIGNMENT without
 * zero-initializing newly grown bytes, capturing CL_HERE.
 *
 * Parameters:
 *   a        (Cl_Allocator) - Valid allocator handle.
 *   ptr      (void *)       - Existing allocation pointer, or NULL.
 *   old_size (cl_isize)     - Previous allocation size in bytes.
 *   new_size (cl_isize)     - Desired new size in bytes.
 *
 * Returns:
 *   (void *) Pointer to resized memory, or NULL if new_size <= 0 or OOM.
 */
#define cl_resize_non_zeroed(a, ptr, old_size, new_size) \
    cl_resize_non_zeroed_aligned_loc((a), (ptr), (old_size), (new_size), CL_DEFAULT_ALIGNMENT, CL_HERE)

/*
 * Resizes ptr from old_size to new_size bytes with explicit power-of-two alignment
 * without zero-initializing newly grown bytes, capturing CL_HERE.
 *
 * Parameters:
 *   a        (Cl_Allocator) - Valid allocator handle.
 *   ptr      (void *)       - Existing allocation pointer, or NULL.
 *   old_size (cl_isize)     - Previous allocation size in bytes.
 *   new_size (cl_isize)     - Desired new size in bytes.
 *   align    (cl_isize)     - Power-of-two alignment in bytes.
 *
 * Returns:
 *   (void *) Pointer to resized aligned memory, or NULL if new_size <= 0 or OOM.
 */
#define cl_resize_non_zeroed_aligned(a, ptr, old_size, new_size, align) \
    cl_resize_non_zeroed_aligned_loc((a), (ptr), (old_size), (new_size), (align), CL_HERE)

/*
 * Frees a single allocation ptr of old_size bytes via allocator a, capturing CL_HERE.
 *
 * Parameters:
 *   a        (Cl_Allocator) - Valid allocator handle.
 *   ptr      (void *)       - Allocation pointer to free (NULL is a safe no-op).
 *   old_size (cl_isize)     - Original allocation size in bytes (0 if unknown).
 */
#define cl_free(a, ptr, old_size) \
    cl_free_loc((a), (ptr), (old_size), CL_HERE)

/*
 * Releases or resets all allocations owned by allocator a, capturing CL_HERE.
 *
 * Parameters:
 *   a (Cl_Allocator) - Valid allocator handle.
 */
#define cl_free_all(a) \
    cl_free_all_loc((a), CL_HERE)

/*
 * Allocates and zero-initializes a single object of type T aligned to CL_ALIGNOF(T),
 * capturing CL_HERE.
 *
 * Parameters:
 *   a (Cl_Allocator) - Valid allocator handle.
 *   T (type)         - Object type to allocate.
 *
 * Returns:
 *   (T *) Pointer to the newly allocated zeroed T, or NULL on OOM.
 */
#define cl_new(a, T) \
    ((T *)cl_alloc_aligned_loc((a), (cl_isize)sizeof(T), CL_ALIGNOF(T), CL_HERE))

/*
 * Allocates a single object of type T aligned to CL_ALIGNOF(T) and initializes it
 * by copying bytes from lvalue `value`, capturing CL_HERE.
 *
 * Parameters:
 *   a     (Cl_Allocator) - Valid allocator handle.
 *   T     (type)         - Object type to allocate.
 *   value (T lvalue)     - Addressable lvalue whose bytes are copied into the new allocation.
 *
 * Returns:
 *   (void *) Pointer to the cloned T object (implicitly convertible to T * in C), or NULL on OOM.
 */
#define cl_new_clone(a, T, value) \
    cl_new_clone_impl((a), (cl_isize)sizeof(T), CL_ALIGNOF(T), &(value), CL_HERE)

/*
 * Allocates a zero-initialized contiguous array of count elements of type T with
 * overflow checking on (count * sizeof(T)) and alignment CL_ALIGNOF(T), capturing CL_HERE.
 *
 * Parameters:
 *   a     (Cl_Allocator) - Valid allocator handle.
 *   T     (type)         - Element type.
 *   count (cl_isize)     - Number of elements to allocate (element count).
 *
 * Returns:
 *   (T *) Pointer to the allocated zeroed array, or NULL if count <= 0, overflow, or OOM.
 */
#define cl_make_array(a, T, count) \
    ((T *)cl_alloc_array_loc((a), (count), (cl_isize)sizeof(T), CL_ALIGNOF(T), true, CL_HERE))

/*
 * Allocates an uninitialized contiguous array of count elements of type T with
 * overflow checking on (count * sizeof(T)) and alignment CL_ALIGNOF(T), capturing CL_HERE.
 *
 * Parameters:
 *   a     (Cl_Allocator) - Valid allocator handle.
 *   T     (type)         - Element type.
 *   count (cl_isize)     - Number of elements to allocate (element count).
 *
 * Returns:
 *   (T *) Pointer to the allocated uninitialized array, or NULL if count <= 0, overflow, or OOM.
 */
#define cl_make_array_non_zeroed(a, T, count) \
    ((T *)cl_alloc_array_loc((a), (count), (cl_isize)sizeof(T), CL_ALIGNOF(T), false, CL_HERE))

/*
 * Frees a typed single-object pointer previously allocated with cl_new() or
 * cl_new_clone(), passing sizeof(*ptr) as old_size and capturing CL_HERE.
 *
 * Parameters:
 *   a   (Cl_Allocator) - Valid allocator handle.
 *   ptr (T *)          - Typed object pointer to free (safe no-op if NULL; evaluated twice).
 */
#define cl_delete(a, ptr) \
    cl_free_loc((a), (ptr), (ptr) ? (cl_isize)sizeof(*(ptr)) : 0, CL_HERE)

/*
 * Allocates a contiguous array of count elements of elem_size bytes each, guarding
 * against signed multiplication overflow in (count * elem_size).
 *
 * Parameters:
 *   a         (Cl_Allocator)  - Valid allocator handle (a.proc must be non-NULL).
 *   count     (cl_isize)      - Number of elements (element count; <= 0 returns NULL).
 *   elem_size (cl_isize)      - Size of one element in bytes (<= 0 returns NULL).
 *   align     (cl_isize)      - Power-of-two alignment in bytes.
 *   zeroed    (bool)          - If true, zero-initialize the allocated array; if false, leave uninitialized.
 *   loc       (Cl_Source_Loc) - Caller source location for tracking and diagnostics.
 *
 * Returns:
 *   (void *) Pointer to the allocated array, or NULL if count <= 0, elem_size <= 0,
 *            (count * elem_size) overflows cl_isize, or allocation fails.
 */
void *cl_alloc_array_loc(
    Cl_Allocator a,
    cl_isize count,
    cl_isize elem_size,
    cl_isize align,
    bool zeroed,
    Cl_Source_Loc loc
);

/*
 * Inline helper backing cl_new_clone(): allocates size aligned bytes without
 * zeroing and copies size bytes from src into the newly allocated storage.
 *
 * Parameters:
 *   a     (Cl_Allocator)  - Valid allocator handle (a.proc must be non-NULL).
 *   size  (cl_isize)      - Object size in bytes.
 *   align (cl_isize)      - Power-of-two alignment in bytes.
 *   src   (const void *)  - Pointer to source object bytes to copy.
 *   loc   (Cl_Source_Loc) - Caller source location for tracking and diagnostics.
 *
 * Returns:
 *   (void *) Pointer to the newly allocated copy, or NULL if size <= 0 or OOM.
 */
static inline void *cl_new_clone_impl(
    Cl_Allocator a,
    cl_isize size,
    cl_isize align,
    const void *src,
    Cl_Source_Loc loc
) {
    void *p = cl_alloc_non_zeroed_aligned_loc(a, size, align, loc);
    if (p != NULL) {
        cl_mem_copy(p, src, size);
    }
    return p;
}

#endif /* CL_ALLOC_H */
