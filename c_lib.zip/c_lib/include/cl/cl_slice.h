/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_slice.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Type-safe Odin-style slices (`{ T *data; cl_isize len; }`) with toggleable
 *   bounds-checked indexing (`CL_SLICE_AT`), bounds-checked sub-slicing
 *   (`CL_SLICE_SUB`), allocation/cloning, and generic slice algorithms
 *   (copy, fill, equal, reverse, sort, binary search).
 *
 * Advantages of Slices over Raw Pointers:
 *   - Length travels with the pointer (eliminates pointer+len mismatch bugs).
 *   - O(1) zero-copy sub-slicing (`s[lo:hi]`).
 *   - Automatic bounds checking in debug builds that compiles away in release.
 * ============================================================================
 */

#ifndef CL_SLICE_H
#define CL_SLICE_H

#include "cl_types.h"
#include "cl_assert.h"
#include "cl_mem.h"
#include "cl_alloc.h"
#include "cl_context.h"

/* ----------------------------------------------------------------------------
 * Typed Slice Generator & Pre-Defined Slices
 * ---------------------------------------------------------------------------- */

/*
 * Defines a typed slice struct representing a non-owning contiguous view of
 * elements of type T.
 *
 * Macro Parameters:
 *   Name (identifier) - Struct tag and typedef name for the generated slice.
 *   T    (type)       - Element type stored in the backing buffer.
 *
 * Generated Struct Fields:
 *   data (T *)      - Pointer to the first element, or NULL when len == 0.
 *   len  (cl_isize) - Number of accessible elements in the slice (elements;
 *                     invariant: len >= 0).
 */
#define CL_SLICE_DEFINE(Name, T) \
    typedef struct Name {        \
        T        *data;          \
        cl_isize  len;           \
    } Name

/*
 * Pre-defined typed slice structs generated via CL_SLICE_DEFINE for common
 * scalar, complex, string, and pointer element types:
 *   Cl_Bytes       (cl_u8)        - Raw byte slice alias.
 *   Cl_Slice_I8    (cl_i8)        - Signed 8-bit integer slice.
 *   Cl_Slice_I16   (cl_i16)       - Signed 16-bit integer slice.
 *   Cl_Slice_I32   (cl_i32)       - Signed 32-bit integer slice.
 *   Cl_Slice_I64   (cl_i64)       - Signed 64-bit integer slice.
 *   Cl_Slice_U8    (cl_u8)        - Unsigned 8-bit integer slice.
 *   Cl_Slice_U16   (cl_u16)       - Unsigned 16-bit integer slice.
 *   Cl_Slice_U32   (cl_u32)       - Unsigned 32-bit integer slice.
 *   Cl_Slice_U64   (cl_u64)       - Unsigned 64-bit integer slice.
 *   Cl_Slice_ISize (cl_isize)     - Signed size/index slice.
 *   Cl_Slice_USize (cl_usize)     - Unsigned size slice.
 *   Cl_Slice_F32   (cl_f32)       - 32-bit IEEE-754 float slice.
 *   Cl_Slice_F64   (cl_f64)       - 64-bit IEEE-754 double slice.
 *   Cl_Slice_C64   (cl_c64)       - 64-bit complex float slice.
 *   Cl_Slice_C128  (cl_c128)      - 128-bit complex double slice.
 *   Cl_Slice_Rune  (cl_rune)      - Unicode code point (UTF-32) slice.
 *   Cl_Slice_Str   (Cl_Str)       - Non-owning UTF-8 string descriptor slice.
 *   Cl_Slice_CStr  (const char *) - NUL-terminated C-string pointer slice.
 *   Cl_Slice_Ptr   (void *)       - Untyped pointer slice.
 */
CL_SLICE_DEFINE(Cl_Bytes,       cl_u8);
CL_SLICE_DEFINE(Cl_Slice_I8,    cl_i8);
CL_SLICE_DEFINE(Cl_Slice_I16,   cl_i16);
CL_SLICE_DEFINE(Cl_Slice_I32,   cl_i32);
CL_SLICE_DEFINE(Cl_Slice_I64,   cl_i64);
CL_SLICE_DEFINE(Cl_Slice_U8,    cl_u8);
CL_SLICE_DEFINE(Cl_Slice_U16,   cl_u16);
CL_SLICE_DEFINE(Cl_Slice_U32,   cl_u32);
CL_SLICE_DEFINE(Cl_Slice_U64,   cl_u64);
CL_SLICE_DEFINE(Cl_Slice_ISize, cl_isize);
CL_SLICE_DEFINE(Cl_Slice_USize, cl_usize);
CL_SLICE_DEFINE(Cl_Slice_F32,   cl_f32);
CL_SLICE_DEFINE(Cl_Slice_F64,   cl_f64);
CL_SLICE_DEFINE(Cl_Slice_C64,   cl_c64);
CL_SLICE_DEFINE(Cl_Slice_C128,  cl_c128);
CL_SLICE_DEFINE(Cl_Slice_Rune,  cl_rune);
CL_SLICE_DEFINE(Cl_Slice_Str,   Cl_Str);
CL_SLICE_DEFINE(Cl_Slice_CStr,  const char *);
CL_SLICE_DEFINE(Cl_Slice_Ptr,   void *);

/* ----------------------------------------------------------------------------
 * Slice Construction, Indexing & Sub-Slicing
 * ---------------------------------------------------------------------------- */

/*
 * Constructs an empty slice compound literal with data == NULL and len == 0.
 *
 * Parameters:
 *   SliceType (type) - Typed slice struct defined with CL_SLICE_DEFINE.
 *
 * Returns:
 *   (SliceType) Empty slice of 0 elements.
 */
#define CL_SLICE_EMPTY(SliceType)             ((SliceType){ NULL, 0 })

/*
 * Constructs a typed slice view over an existing contiguous buffer.
 *
 * Parameters:
 *   SliceType (type)     - Typed slice struct defined with CL_SLICE_DEFINE.
 *   ptr       (T *)      - Pointer to the first element (may be NULL if n == 0).
 *   n         (cl_isize) - Element count (elements; must be >= 0).
 *
 * Returns:
 *   (SliceType) Non-owning slice referencing n elements starting at ptr.
 */
#define CL_SLICE_FROM_PTR(SliceType, ptr, n)  ((SliceType){ (ptr), (cl_isize)(n) })

/*
 * Constructs a typed slice view covering an entire fixed-size C array.
 *
 * Parameters:
 *   SliceType (type) - Typed slice struct defined with CL_SLICE_DEFINE.
 *   arr       (T[N]) - Fixed-size array (must be a real array, not a pointer).
 *
 * Returns:
 *   (SliceType) Non-owning slice of length CL_ARRAY_LEN(arr) elements.
 */
#define CL_SLICE_FROM_ARRAY(SliceType, arr)   ((SliceType){ (arr), CL_ARRAY_LEN(arr) })

/*
 * Accesses the element at a 0-based index with toggleable bounds checking.
 * Evaluates idx once; traps if CL_BOUNDS_CHECK == 1 and idx is outside
 * [0, s.len).
 *
 * Parameters:
 *   s   (SliceType) - Slice value to index into.
 *   idx (cl_isize)  - 0-based element index (elements; 0 <= idx < s.len).
 *
 * Returns:
 *   (T lvalue) Modifiable lvalue reference to s.data[idx].
 */
#define CL_SLICE_AT(s, idx) \
    ((s).data[CL_BOUNDS_CHECK_INDEX((idx), (s).len)])

/*
 * Accesses the first element (0-based index 0) of a non-empty slice with
 * bounds checking.
 *
 * Parameters:
 *   s (SliceType) - Slice value (must satisfy s.len >= 1).
 *
 * Returns:
 *   (T lvalue) Modifiable lvalue reference to s.data[0].
 */
#define CL_SLICE_FIRST(s) CL_SLICE_AT((s), 0)

/*
 * Accesses the last element (0-based index s.len - 1) of a non-empty slice
 * with bounds checking.
 *
 * Parameters:
 *   s (SliceType) - Slice value (must satisfy s.len >= 1).
 *
 * Returns:
 *   (T lvalue) Modifiable lvalue reference to s.data[s.len - 1].
 */
#define CL_SLICE_LAST(s)  CL_SLICE_AT((s), (s).len - 1)

/* Bounds-checked sub-slice: equivalent to Odin's `s[lo:hi]` */
#if CL_HAVE_STMT_EXPR && CL_HAVE_TYPEOF
    /*
     * Creates a zero-copy bounds-checked sub-slice covering the half-open
     * element range [lo, hi). Evaluates s, lo, and hi exactly once. Traps
     * when CL_BOUNDS_CHECK == 1 and !(0 <= lo <= hi <= s.len).
     *
     * Parameters:
     *   s  (SliceType) - Source slice value.
     *   lo (cl_isize)  - Inclusive start 0-based element index (elements).
     *   hi (cl_isize)  - Exclusive end 0-based element index (elements;
     *                    0 <= lo <= hi <= s.len).
     *
     * Returns:
     *   (SliceType) Sub-slice of (hi - lo) elements, with data == NULL if
     *               s.data == NULL or lo == hi.
     */
    #define CL_SLICE_SUB(s, lo, hi) CL_EXTENSION ({                      \
        __typeof__(s) _cl_s  = (s);                                      \
        cl_isize      _cl_lo = (cl_isize)(lo);                           \
        cl_isize      _cl_hi = (cl_isize)(hi);                           \
        CL_BOUNDS_CHECK_RANGE(_cl_lo, _cl_hi, _cl_s.len);                \
        __typeof__(s) _cl_out;                                           \
        _cl_out.data = (_cl_s.data != NULL && _cl_lo < _cl_hi)           \
                           ? (_cl_s.data + _cl_lo)                       \
                           : NULL;                                       \
        _cl_out.len  = _cl_hi - _cl_lo;                                  \
        _cl_out;                                                         \
    })
#else
    /*
     * Portable fallback for creating a bounds-checked zero-copy sub-slice over
     * the half-open element range [lo, hi) on compilers without statement
     * expressions or __typeof__. Arguments may be evaluated multiple times.
     *
     * Parameters:
     *   SliceType (type)      - Typed slice struct type of s.
     *   s         (SliceType) - Source slice value (avoid side effects).
     *   lo        (cl_isize)  - Inclusive start 0-based element index (elements).
     *   hi        (cl_isize)  - Exclusive end 0-based element index (elements;
     *                           0 <= lo <= hi <= s.len).
     *
     * Returns:
     *   (SliceType) Sub-slice of (hi - lo) elements, with data == NULL if
     *               s.data == NULL or lo == hi.
     */
    #define CL_SLICE_SUB_T(SliceType, s, lo, hi) \
        (CL_BOUNDS_CHECK_RANGE((lo), (hi), (s).len), \
         (SliceType){ ((s).data != NULL && (lo) < (hi)) ? ((s).data + (lo)) : NULL, (cl_isize)((hi) - (lo)) })
#endif

/*
 * Expands to a for-loop header iterating over every 0-based element index in
 * slice s in ascending order [0, s.len).
 *
 * Parameters:
 *   idx_var (identifier) - Loop counter variable name declared as cl_isize.
 *   s       (SliceType)  - Slice value to iterate (s.len evaluated each step).
 */
#define CL_SLICE_FOR_EACH(idx_var, s) \
    for (cl_isize idx_var = 0; idx_var < (s).len; idx_var++)

/* ----------------------------------------------------------------------------
 * Slice Allocation & Cloning
 * ---------------------------------------------------------------------------- */

#if CL_HAVE_STMT_EXPR && CL_HAVE_TYPEOF
    /*
     * Allocates a zero-initialized typed slice of count elements with natural
     * element alignment via alloc (falling back to cl_ctx_allocator() when
     * alloc is invalid).
     *
     * Parameters:
     *   SliceType (type)         - Typed slice struct to construct.
     *   alloc     (Cl_Allocator) - Backing allocator handle.
     *   count     (cl_isize)     - Number of elements to allocate (elements).
     *
     * Returns:
     *   (SliceType) Newly allocated slice of count zeroed elements, or
     *               { NULL, 0 } if count <= 0 or allocation fails.
     */
    #define CL_SLICE_MAKE(SliceType, alloc, count) CL_EXTENSION ({       \
        cl_isize _cl_n = (cl_isize)(count);                              \
        SliceType _cl_out = { NULL, 0 };                                 \
        if (_cl_n > 0) {                                                 \
            _cl_out.data = (__typeof__(_cl_out.data))cl_alloc_array_loc( \
                cl_alloc_or_ctx(alloc),                                  \
                _cl_n,                                                   \
                (cl_isize)sizeof(*_cl_out.data),                         \
                CL_ALIGNOF_EXPR(*_cl_out.data),                          \
                true,                                                    \
                CL_HERE                                                  \
            );                                                           \
            _cl_out.len = (_cl_out.data != NULL) ? _cl_n : 0;            \
        }                                                                \
        _cl_out;                                                         \
    })

    /*
     * Allocates a new slice of the same length as src and copies all elements
     * bytewise from src.data into the new buffer.
     *
     * Parameters:
     *   SliceType (type)         - Typed slice struct to construct.
     *   alloc     (Cl_Allocator) - Backing allocator handle (defaults to
     *                              context allocator if invalid).
     *   src       (SliceType)    - Source slice to shallow-copy.
     *
     * Returns:
     *   (SliceType) Newly allocated copy of src, or { NULL, 0 } if src.len <= 0
     *               or allocation fails.
     */
    #define CL_SLICE_CLONE(SliceType, alloc, src) CL_EXTENSION ({        \
        SliceType _cl_src = (src);                                       \
        SliceType _cl_dst = CL_SLICE_MAKE(SliceType, (alloc), _cl_src.len); \
        if (_cl_dst.data != NULL && _cl_src.len > 0) {                   \
            cl_mem_copy(_cl_dst.data, _cl_src.data,                      \
                        _cl_src.len * (cl_isize)sizeof(*_cl_src.data));  \
        }                                                                \
        _cl_dst;                                                         \
    })
#endif

/*
 * Releases the memory backing slice s via alloc (or cl_ctx_allocator() if
 * invalid) and resets s.data to NULL and s.len to 0. Safe no-op if s.data is
 * already NULL.
 *
 * Parameters:
 *   alloc (Cl_Allocator) - Allocator originally used to allocate s.data.
 *   s     (SliceType)    - Modifiable slice lvalue to free and reset.
 */
#define CL_SLICE_FREE(alloc, s) do {                                     \
    if ((s).data != NULL) {                                              \
        cl_free_loc(                                                     \
            cl_alloc_or_ctx(alloc),                                      \
            (s).data,                                                    \
            (s).len * (cl_isize)sizeof(*(s).data),                       \
            CL_HERE                                                      \
        );                                                               \
        (s).data = NULL;                                                 \
        (s).len  = 0;                                                    \
    }                                                                    \
} while (0)

/* ----------------------------------------------------------------------------
 * Raw Generic Slice Algorithms (Implemented in cl_slice.c)
 * ---------------------------------------------------------------------------- */

/*
 * Three-way element comparator callback compatible with libc qsort and
 * cl_slice_bsearch_raw.
 *
 * Parameters:
 *   a (const void *) - Pointer to the first element to compare.
 *   b (const void *) - Pointer to the second element to compare.
 *
 * Returns:
 *   (int) Negative if *a < *b, 0 if *a == *b, or positive if *a > *b.
 */
typedef int (*Cl_Cmp_Proc)(const void *a, const void *b);

/*
 * Copies min(dst_len, src_len) elements from src_data into dst_data using
 * overlap-safe cl_mem_move.
 *
 * Parameters:
 *   dst_data  (void *)       - Destination element buffer (may overlap src).
 *   dst_len   (cl_isize)     - Destination slice length (elements).
 *   src_data  (const void *) - Source element buffer.
 *   src_len   (cl_isize)     - Source slice length (elements).
 *   elem_size (cl_isize)     - Size of a single element (bytes; must be > 0).
 *
 * Returns:
 *   (cl_isize) Number of elements copied (elements), or 0 if any length or
 *              elem_size is <= 0 or either pointer is NULL.
 */
cl_isize cl_slice_copy_raw(
    void *dst_data,
    cl_isize dst_len,
    const void *src_data,
    cl_isize src_len,
    cl_isize elem_size
);

/*
 * Reverses the order of elements in a slice in place in O(len) time.
 * No-op if data == NULL, len <= 1, elem_size <= 0, or temporary heap scratch
 * allocation fails (for elem_size > 256 bytes).
 *
 * Parameters:
 *   data      (void *)   - Pointer to the contiguous element buffer.
 *   len       (cl_isize) - Number of elements in the slice (elements).
 *   elem_size (cl_isize) - Size of a single element (bytes; must be > 0).
 */
void cl_slice_reverse_raw(void *data, cl_isize len, cl_isize elem_size);

/*
 * Compares two plain-old-data (POD) slices for exact bytewise equality.
 * Struct padding bytes are compared verbatim.
 *
 * Parameters:
 *   a_data    (const void *) - First slice element buffer.
 *   a_len     (cl_isize)     - First slice length (elements).
 *   b_data    (const void *) - Second slice element buffer.
 *   b_len     (cl_isize)     - Second slice length (elements).
 *   elem_size (cl_isize)     - Size of a single element (bytes).
 *
 * Returns:
 *   (bool) true if a_len == b_len and either a_len <= 0, elem_size <= 0, or
 *          all (a_len * elem_size) bytes are equal; false otherwise.
 */
bool cl_slice_equal_raw(
    const void *a_data,
    cl_isize a_len,
    const void *b_data,
    cl_isize b_len,
    cl_isize elem_size
);

/*
 * Sorts elements in place according to comparator cmp using libc qsort.
 * Safely no-ops if data == NULL, len <= 1, elem_size <= 0, or cmp == NULL.
 *
 * Parameters:
 *   data      (void *)      - Pointer to the element buffer to sort.
 *   len       (cl_isize)    - Number of elements to sort (elements).
 *   elem_size (cl_isize)    - Size of a single element (bytes; must be > 0).
 *   cmp       (Cl_Cmp_Proc) - Three-way element comparator callback.
 */
void cl_slice_sort_raw(void *data, cl_isize len, cl_isize elem_size, Cl_Cmp_Proc cmp);

/*
 * Performs binary search on a slice sorted in ascending order under cmp.
 *
 * Parameters:
 *   data      (const void *) - Pointer to the sorted element buffer.
 *   len       (cl_isize)     - Number of elements in the slice (elements).
 *   elem_size (cl_isize)     - Size of a single element (bytes; must be > 0).
 *   key       (const void *) - Pointer to the search key element.
 *   cmp       (Cl_Cmp_Proc)  - Comparator matching the slice's sort order.
 *
 * Returns:
 *   (cl_isize) 0-based element index in [0, len) of a matching element, or -1
 *              if not found or any argument is invalid.
 */
cl_isize cl_slice_bsearch_raw(
    const void *data,
    cl_isize len,
    cl_isize elem_size,
    const void *key,
    Cl_Cmp_Proc cmp
);

/* Typed algorithm wrapper macros */

/*
 * Copies min(dst.len, src.len) elements from typed slice src into typed slice
 * dst (overlap-safe). Both slices must share the same element type.
 *
 * Parameters:
 *   dst (SliceType) - Destination slice value.
 *   src (SliceType) - Source slice value.
 *
 * Returns:
 *   (cl_isize) Number of elements copied (elements).
 */
#define CL_SLICE_COPY(dst, src) \
    cl_slice_copy_raw((dst).data, (dst).len, (src).data, (src).len, (cl_isize)sizeof(*(dst).data))

/*
 * Checks bytewise equality of two typed POD slices of the same element type.
 *
 * Parameters:
 *   a (SliceType) - First slice value.
 *   b (SliceType) - Second slice value.
 *
 * Returns:
 *   (bool) true if both slices have equal length and identical byte contents,
 *          false otherwise.
 */
#define CL_SLICE_EQUAL(a, b) \
    cl_slice_equal_raw((a).data, (a).len, (b).data, (b).len, (cl_isize)sizeof(*(a).data))

/*
 * Reverses the elements of typed slice s in place in O(s.len) time.
 *
 * Parameters:
 *   s (SliceType) - Slice value whose elements will be reversed.
 */
#define CL_SLICE_REVERSE(s) \
    cl_slice_reverse_raw((s).data, (s).len, (cl_isize)sizeof(*(s).data))

/*
 * Sorts the elements of typed slice s in place using comparator cmp.
 *
 * Parameters:
 *   s   (SliceType)   - Slice value to sort in place.
 *   cmp (Cl_Cmp_Proc) - Three-way comparator for the slice's element type.
 */
#define CL_SLICE_SORT(s, cmp) \
    cl_slice_sort_raw((s).data, (s).len, (cl_isize)sizeof(*(s).data), (cmp))

/*
 * Binary-searches a sorted typed slice s for the element pointed to by key_ptr.
 *
 * Parameters:
 *   s       (SliceType)    - Sorted slice value (ascending per cmp).
 *   key_ptr (const T *)    - Pointer to the key value to search for.
 *   cmp     (Cl_Cmp_Proc)  - Comparator matching the slice's sort order.
 *
 * Returns:
 *   (cl_isize) 0-based element index in [0, s.len) if found, or -1 if absent.
 */
#define CL_SLICE_BSEARCH(s, key_ptr, cmp) \
    cl_slice_bsearch_raw((s).data, (s).len, (cl_isize)sizeof(*(s).data), (key_ptr), (cmp))

/*
 * Assigns val to every element of slice s across indices [0, s.len).
 * Note: val is evaluated once per element.
 *
 * Parameters:
 *   s   (SliceType) - Destination slice value.
 *   val (T)         - Value assigned to each element.
 */
#define CL_SLICE_FILL(s, val) do {                      \
    for (cl_isize _cl_fi = 0; _cl_fi < (s).len; _cl_fi++) { \
        (s).data[_cl_fi] = (val);                       \
    }                                                   \
} while (0)

/* Built-in standard comparators (ascending order) */

/*
 * Overflow-safe ascending comparator for cl_i32 elements.
 *
 * Parameters:
 *   a (const void *) - Non-NULL pointer to a cl_i32 value.
 *   b (const void *) - Non-NULL pointer to a cl_i32 value.
 *
 * Returns:
 *   (int) -1 if *a < *b, 0 if *a == *b, or +1 if *a > *b.
 */
int cl_cmp_i32(const void *a, const void *b);

/*
 * Overflow-safe ascending comparator for cl_i64 elements.
 *
 * Parameters:
 *   a (const void *) - Non-NULL pointer to a cl_i64 value.
 *   b (const void *) - Non-NULL pointer to a cl_i64 value.
 *
 * Returns:
 *   (int) -1 if *a < *b, 0 if *a == *b, or +1 if *a > *b.
 */
int cl_cmp_i64(const void *a, const void *b);

/*
 * Overflow-safe ascending comparator for cl_u64 elements.
 *
 * Parameters:
 *   a (const void *) - Non-NULL pointer to a cl_u64 value.
 *   b (const void *) - Non-NULL pointer to a cl_u64 value.
 *
 * Returns:
 *   (int) -1 if *a < *b, 0 if *a == *b, or +1 if *a > *b.
 */
int cl_cmp_u64(const void *a, const void *b);

/*
 * Overflow-safe ascending comparator for cl_isize elements.
 *
 * Parameters:
 *   a (const void *) - Non-NULL pointer to a cl_isize value.
 *   b (const void *) - Non-NULL pointer to a cl_isize value.
 *
 * Returns:
 *   (int) -1 if *a < *b, 0 if *a == *b, or +1 if *a > *b.
 */
int cl_cmp_isize(const void *a, const void *b);

/*
 * Ascending comparator for cl_f32 elements. Inputs must not be NaN to preserve
 * strict weak ordering.
 *
 * Parameters:
 *   a (const void *) - Non-NULL pointer to a cl_f32 value.
 *   b (const void *) - Non-NULL pointer to a cl_f32 value.
 *
 * Returns:
 *   (int) -1 if *a < *b, 0 if *a == *b, or +1 if *a > *b.
 */
int cl_cmp_f32(const void *a, const void *b);

/*
 * Ascending comparator for cl_f64 elements. Inputs must not be NaN to preserve
 * strict weak ordering.
 *
 * Parameters:
 *   a (const void *) - Non-NULL pointer to a cl_f64 value.
 *   b (const void *) - Non-NULL pointer to a cl_f64 value.
 *
 * Returns:
 *   (int) -1 if *a < *b, 0 if *a == *b, or +1 if *a > *b.
 */
int cl_cmp_f64(const void *a, const void *b);

/*
 * Ascending lexicographical comparator for Cl_Str elements, comparing unsigned
 * bytes over the shared prefix and breaking ties by byte length.
 *
 * Parameters:
 *   a (const void *) - Non-NULL pointer to a Cl_Str descriptor.
 *   b (const void *) - Non-NULL pointer to a Cl_Str descriptor.
 *
 * Returns:
 *   (int) Negative if *a < *b, 0 if *a == *b, or positive if *a > *b.
 */
int cl_cmp_str(const void *a, const void *b);

#endif /* CL_SLICE_H */
