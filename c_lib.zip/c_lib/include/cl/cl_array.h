/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_array.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Dynamic arrays (`CL_DA_DEFINE`, matching Odin's `[dynamic]T`),
 *   stack-allocated fixed-capacity small arrays (`CL_SMALL_ARRAY_DEFINE`,
 *   Odin's `core:container/small_array`), O(1) circular ring queues
 *   (`CL_QUEUE_DEFINE`, Odin's `core:container/queue`), and dense bit sets
 *   (`Cl_Bit_Set`, Odin's `core:container/bit_array`).
 *
 * Key Design Properties:
 *   - `{0}` zero-initialization is immediately valid for every container.
 *   - If `da.allocator` is unset, the first allocation automatically binds
 *     `cl_ctx_allocator()`.
 *   - All element accesses (`AT`, `POP`, `REMOVE`, `INJECT_AT`) perform
 *     toggleable bounds checking (`CL_BOUNDS_CHECK`).
 *   - Strict-aliasing safe: raw resize helpers return `void *` directly
 *     rather than type-punning `T **` through `void **`.
 * ============================================================================
 */

#ifndef CL_ARRAY_H
#define CL_ARRAY_H

#include "cl_slice.h"
#include "cl_defer.h"

/* ============================================================================
 * 1. Dynamic Array (Odin `[dynamic]T`)
 * ============================================================================ */

/*
 * Defines a growable typed dynamic array struct. Zero-initialization (`{0}`)
 * produces a valid empty dynamic array whose allocator auto-binds to
 * cl_ctx_allocator() upon the first allocation.
 *
 * Macro Parameters:
 *   Name (identifier) - Struct tag and typedef name for the dynamic array.
 *   T    (type)       - Element type stored contiguously in data.
 *
 * Generated Struct Fields:
 *   data      (T *)          - Backing contiguous element buffer, or NULL.
 *   len       (cl_isize)     - Active element count (elements; 0 <= len <= cap).
 *   cap       (cl_isize)     - Allocated capacity (elements; cap >= 0).
 *   allocator (Cl_Allocator) - Allocator owning data; binds context allocator
 *                              lazily if invalid.
 */
#define CL_DA_DEFINE(Name, T) \
    typedef struct Name {     \
        T           *data;    \
        cl_isize     len;     \
        cl_isize     cap;     \
        Cl_Allocator allocator; \
    } Name

/*
 * Pre-defined typed dynamic array structs generated via CL_DA_DEFINE for
 * common primitive, complex, string, and pointer element types:
 *   Cl_DA_I8    (cl_i8)    - Dynamic array of signed 8-bit integers.
 *   Cl_DA_I16   (cl_i16)   - Dynamic array of signed 16-bit integers.
 *   Cl_DA_I32   (cl_i32)   - Dynamic array of signed 32-bit integers.
 *   Cl_DA_I64   (cl_i64)   - Dynamic array of signed 64-bit integers.
 *   Cl_DA_U8    (cl_u8)    - Dynamic array of unsigned 8-bit integers.
 *   Cl_DA_U16   (cl_u16)   - Dynamic array of unsigned 16-bit integers.
 *   Cl_DA_U32   (cl_u32)   - Dynamic array of unsigned 32-bit integers.
 *   Cl_DA_U64   (cl_u64)   - Dynamic array of unsigned 64-bit integers.
 *   Cl_DA_ISize (cl_isize) - Dynamic array of signed sizes/indices.
 *   Cl_DA_USize (cl_usize) - Dynamic array of unsigned sizes.
 *   Cl_DA_F32   (cl_f32)   - Dynamic array of 32-bit floats.
 *   Cl_DA_F64   (cl_f64)   - Dynamic array of 64-bit doubles.
 *   Cl_DA_C64   (cl_c64)   - Dynamic array of 64-bit complex floats.
 *   Cl_DA_C128  (cl_c128)  - Dynamic array of 128-bit complex doubles.
 *   Cl_DA_Rune  (cl_rune)  - Dynamic array of UTF-32 code points.
 *   Cl_DA_Str   (Cl_Str)   - Dynamic array of non-owning UTF-8 strings.
 *   Cl_DA_Ptr   (void *)   - Dynamic array of untyped pointers.
 */
CL_DA_DEFINE(Cl_DA_I8,    cl_i8);
CL_DA_DEFINE(Cl_DA_I16,   cl_i16);
CL_DA_DEFINE(Cl_DA_I32,   cl_i32);
CL_DA_DEFINE(Cl_DA_I64,   cl_i64);
CL_DA_DEFINE(Cl_DA_U8,    cl_u8);
CL_DA_DEFINE(Cl_DA_U16,   cl_u16);
CL_DA_DEFINE(Cl_DA_U32,   cl_u32);
CL_DA_DEFINE(Cl_DA_U64,   cl_u64);
CL_DA_DEFINE(Cl_DA_ISize, cl_isize);
CL_DA_DEFINE(Cl_DA_USize, cl_usize);
CL_DA_DEFINE(Cl_DA_F32,   cl_f32);
CL_DA_DEFINE(Cl_DA_F64,   cl_f64);
CL_DA_DEFINE(Cl_DA_C64,   cl_c64);
CL_DA_DEFINE(Cl_DA_C128,  cl_c128);
CL_DA_DEFINE(Cl_DA_Rune,  cl_rune);
CL_DA_DEFINE(Cl_DA_Str,   Cl_Str);
CL_DA_DEFINE(Cl_DA_Ptr,   void *);

/* Shared type-erased growth/shrink helpers (implemented in cl_array.c) */

/*
 * Ensures a dynamic array buffer can store at least min_cap elements, growing
 * exponentially (starting at 8 elements and doubling) and zero-initializing
 * newly grown memory. Lazily binds *alloc to cl_ctx_allocator() if invalid.
 *
 * Parameters:
 *   old_data   (void *)         - Existing element buffer, or NULL.
 *   cap        (cl_isize *)     - Non-NULL in/out capacity pointer (elements);
 *                                 updated on successful resize.
 *   alloc      (Cl_Allocator *) - Non-NULL in/out allocator pointer.
 *   min_cap    (cl_isize)       - Minimum required capacity (elements).
 *   elem_size  (cl_isize)       - Size of one element (bytes; must be > 0).
 *   elem_align (cl_isize)       - Power-of-two element alignment (bytes).
 *   loc        (Cl_Source_Loc)  - Caller source location for diagnostics.
 *
 * Returns:
 *   (void *) Pointer to the existing or resized buffer, or NULL if byte-size
 *            multiplication overflows or allocation fails (leaving *cap
 *            unchanged).
 */
void *cl_da_reserve_raw(
    void *old_data,
    cl_isize *cap,
    Cl_Allocator *alloc,
    cl_isize min_cap,
    cl_isize elem_size,
    cl_isize elem_align,
    Cl_Source_Loc loc
);

/*
 * Shrinks a dynamic array's backing allocation to match its active length len.
 * Frees old_data and resets *cap to 0 when len <= 0.
 *
 * Parameters:
 *   old_data   (void *)         - Existing element buffer, or NULL.
 *   len        (cl_isize)       - Active element count (elements).
 *   cap        (cl_isize *)     - Non-NULL in/out capacity pointer (elements).
 *   alloc      (Cl_Allocator *) - Non-NULL allocator pointer (falls back to
 *                                 context allocator if invalid).
 *   elem_size  (cl_isize)       - Size of one element (bytes; must be > 0).
 *   elem_align (cl_isize)       - Power-of-two element alignment (bytes).
 *   loc        (Cl_Source_Loc)  - Caller source location for diagnostics.
 *
 * Returns:
 *   (void *) Pointer to the shrunk buffer, NULL if len <= 0 (buffer freed),
 *            or old_data unchanged if old_data == NULL, len >= *cap, or resize
 *            fails.
 */
void *cl_da_shrink_raw(
    void *old_data,
    cl_isize len,
    cl_isize *cap,
    Cl_Allocator *alloc,
    cl_isize elem_size,
    cl_isize elem_align,
    Cl_Source_Loc loc
);

/*
 * Initializes a dynamic array to an empty state (data = NULL, len = 0,
 * cap = 0) bound to an explicit allocator.
 *
 * Parameters:
 *   da    (Cl_DA_T *)    - Pointer to the dynamic array to initialize.
 *   alloc (Cl_Allocator) - Allocator handle to bind to da->allocator.
 */
#define CL_DA_INIT(da, alloc) do {          \
    (da)->data      = NULL;                 \
    (da)->len       = 0;                    \
    (da)->cap       = 0;                    \
    (da)->allocator = (alloc);              \
} while (0)

/*
 * Ensures the dynamic array has capacity for at least min_cap elements,
 * growing exponentially via cl_da_reserve_raw if min_cap > da->cap. Asserts
 * allocation success with CL_ENSURE.
 *
 * Parameters:
 *   da      (Cl_DA_T *) - Pointer to the dynamic array.
 *   min_cap (cl_isize)  - Minimum required capacity (elements).
 */
#define CL_DA_RESERVE(da, min_cap) do {                                   \
    if ((cl_isize)(min_cap) > (da)->cap) {                                \
        void *_cl_nd = cl_da_reserve_raw(                                 \
            (da)->data, &(da)->cap, &(da)->allocator,                     \
            (cl_isize)(min_cap),                                          \
            (cl_isize)sizeof(*(da)->data),                                \
            CL_ALIGNOF_EXPR(*(da)->data),                                 \
            CL_HERE                                                       \
        );                                                                \
        CL_ENSURE(_cl_nd != NULL);                                        \
        (da)->data = _cl_nd;                                              \
    }                                                                     \
} while (0)

/*
 * Initializes a dynamic array with an explicit allocator and immediately
 * reserves space for initial_cap elements when initial_cap > 0.
 *
 * Parameters:
 *   da          (Cl_DA_T *)    - Pointer to the dynamic array to initialize.
 *   alloc       (Cl_Allocator) - Allocator handle to bind.
 *   initial_cap (cl_isize)     - Initial capacity to pre-allocate (elements).
 */
#define CL_DA_INIT_CAP(da, alloc, initial_cap) do { \
    CL_DA_INIT((da), (alloc));                      \
    if ((initial_cap) > 0) {                        \
        CL_DA_RESERVE((da), (initial_cap));         \
    }                                               \
} while (0)

/*
 * Releases the dynamic array's backing buffer via cl_alloc_or_ctx(da->allocator)
 * and resets data = NULL, len = 0, and cap = 0 while preserving da->allocator.
 * Safe no-op when da->data == NULL.
 *
 * Parameters:
 *   da (Cl_DA_T *) - Pointer to the dynamic array to free.
 */
#define CL_DA_FREE(da) do {                                               \
    if ((da)->data != NULL) {                                             \
        cl_free_loc(                                                      \
            cl_alloc_or_ctx((da)->allocator),                             \
            (da)->data,                                                   \
            (da)->cap * (cl_isize)sizeof(*(da)->data),                    \
            CL_HERE                                                       \
        );                                                                \
        (da)->data = NULL;                                                \
        (da)->len  = 0;                                                   \
        (da)->cap  = 0;                                                   \
    }                                                                     \
} while (0)

/*
 * Appends one element to the end of the dynamic array in O(1) amortized time,
 * growing the backing buffer if needed and incrementing da->len by 1.
 *
 * Parameters:
 *   da  (Cl_DA_T *) - Pointer to the dynamic array.
 *   val (T)         - Element value to append.
 */
#define CL_DA_PUSH(da, val) do {                                          \
    CL_DA_RESERVE((da), (da)->len + 1);                                   \
    (da)->data[(da)->len] = (val);                                        \
    (da)->len += 1;                                                       \
} while (0)

/*
 * Appends count contiguous elements from ptr to the end of the dynamic array.
 * No-op if count <= 0. ptr must not alias da->data because reservation may
 * reallocate the buffer.
 *
 * Parameters:
 *   da    (Cl_DA_T *) - Pointer to the destination dynamic array.
 *   ptr   (const T *) - Pointer to contiguous source elements.
 *   count (cl_isize)  - Number of elements to append (elements).
 */
#define CL_DA_APPEND_MANY(da, ptr, count) do {                            \
    cl_isize _cl_cnt = (cl_isize)(count);                                 \
    if (_cl_cnt > 0) {                                                    \
        CL_DA_RESERVE((da), (da)->len + _cl_cnt);                         \
        cl_mem_copy(                                                      \
            (da)->data + (da)->len,                                       \
            (ptr),                                                        \
            _cl_cnt * (cl_isize)sizeof(*(da)->data)                       \
        );                                                                \
        (da)->len += _cl_cnt;                                             \
    }                                                                     \
} while (0)

/*
 * Appends all elements of a typed slice to the end of the dynamic array.
 * slice.data must not alias da->data.
 *
 * Parameters:
 *   da    (Cl_DA_T *)  - Pointer to the destination dynamic array.
 *   slice (SliceType)  - Source slice whose element type matches *da.
 */
#define CL_DA_APPEND_SLICE(da, slice) \
    CL_DA_APPEND_MANY((da), (slice).data, (slice).len)

/*
 * Accesses the element at a 0-based index in the dynamic array with toggleable
 * bounds checking. Traps when CL_BOUNDS_CHECK == 1 and idx is outside
 * [0, da->len).
 *
 * Parameters:
 *   da  (Cl_DA_T *) - Pointer to the dynamic array.
 *   idx (cl_isize)  - 0-based element index (elements; 0 <= idx < da->len).
 *
 * Returns:
 *   (T lvalue) Modifiable lvalue reference to da->data[idx].
 */
#define CL_DA_AT(da, idx) \
    ((da)->data[CL_BOUNDS_CHECK_INDEX((idx), (da)->len)])

/*
 * Accesses the first element (0-based index 0) of a non-empty dynamic array
 * with bounds checking.
 *
 * Parameters:
 *   da (Cl_DA_T *) - Pointer to the dynamic array (must have da->len >= 1).
 *
 * Returns:
 *   (T lvalue) Modifiable lvalue reference to da->data[0].
 */
#define CL_DA_FIRST(da) CL_DA_AT((da), 0)

/*
 * Accesses the last element (0-based index da->len - 1) of a non-empty dynamic
 * array with bounds checking.
 *
 * Parameters:
 *   da (Cl_DA_T *) - Pointer to the dynamic array (must have da->len >= 1).
 *
 * Returns:
 *   (T lvalue) Modifiable lvalue reference to da->data[da->len - 1].
 */
#define CL_DA_LAST(da)  CL_DA_AT((da), (da)->len - 1)

/* Pop and return last element (bounds-checked: traps if empty when CL_BOUNDS_CHECK=1) */
#if CL_HAVE_STMT_EXPR
    /*
     * Removes and returns the last element of the dynamic array. Traps when
     * CL_BOUNDS_CHECK == 1 and da->len == 0.
     *
     * Parameters:
     *   da (Cl_DA_T *) - Pointer to a non-empty dynamic array (da->len >= 1).
     *
     * Returns:
     *   (T) Copy of the removed last element.
     */
    #define CL_DA_POP(da) CL_EXTENSION ({                                 \
        (void)CL_BOUNDS_CHECK_INDEX((da)->len - 1, (da)->len);            \
        (da)->len -= 1;                                                   \
        (da)->data[(da)->len];                                            \
    })
#endif

/*
 * Removes the last element of the dynamic array into *out_ptr if non-empty.
 * Leaves *out_ptr unmodified if the array is empty.
 *
 * Parameters:
 *   da      (Cl_DA_T *) - Pointer to the dynamic array.
 *   out_ptr (T *)       - Non-NULL destination pointer for the popped element.
 *
 * Returns:
 *   (bool) true if an element was popped into *out_ptr, false if da->len == 0.
 */
#define CL_DA_POP_SAFE(da, out_ptr)                                       \
    (((da)->len > 0)                                                      \
        ? ((da)->len -= 1, *(out_ptr) = (da)->data[(da)->len], true)      \
        : false)

/*
 * Inserts val at 0-based index idx in O(da->len - idx) time, shifting existing
 * elements in [idx, da->len) right by 1 slot. Bounds-checked against
 * 0 <= idx <= da->len.
 *
 * Parameters:
 *   da  (Cl_DA_T *) - Pointer to the dynamic array.
 *   idx (cl_isize)  - 0-based insertion index (elements; 0 <= idx <= da->len).
 *   val (T)         - Element value to insert.
 */
#define CL_DA_INJECT_AT(da, idx, val) do {                                \
    cl_isize _cl_idx = (cl_isize)(idx);                                   \
    CL_BOUNDS_CHECK_RANGE(_cl_idx, _cl_idx, (da)->len);                   \
    CL_DA_RESERVE((da), (da)->len + 1);                                   \
    if (_cl_idx < (da)->len) {                                            \
        cl_mem_move(                                                      \
            (da)->data + _cl_idx + 1,                                     \
            (da)->data + _cl_idx,                                         \
            ((da)->len - _cl_idx) * (cl_isize)sizeof(*(da)->data)         \
        );                                                                \
    }                                                                     \
    (da)->data[_cl_idx] = (val);                                          \
    (da)->len += 1;                                                       \
} while (0)

/*
 * Removes the element at 0-based index idx in O(da->len - idx) time while
 * preserving the relative order of all remaining elements.
 *
 * Parameters:
 *   da  (Cl_DA_T *) - Pointer to the dynamic array.
 *   idx (cl_isize)  - 0-based element index (elements; 0 <= idx < da->len).
 */
#define CL_DA_ORDERED_REMOVE(da, idx) do {                                \
    cl_isize _cl_idx = CL_BOUNDS_CHECK_INDEX((idx), (da)->len);           \
    if (_cl_idx < (da)->len - 1) {                                        \
        cl_mem_move(                                                      \
            (da)->data + _cl_idx,                                         \
            (da)->data + _cl_idx + 1,                                     \
            ((da)->len - _cl_idx - 1) * (cl_isize)sizeof(*(da)->data)     \
        );                                                                \
    }                                                                     \
    (da)->len -= 1;                                                       \
} while (0)

/*
 * Removes the element at 0-based index idx in O(1) time by overwriting slot
 * idx with the last element and decrementing da->len (does not preserve order).
 *
 * Parameters:
 *   da  (Cl_DA_T *) - Pointer to the dynamic array.
 *   idx (cl_isize)  - 0-based element index (elements; 0 <= idx < da->len).
 */
#define CL_DA_UNORDERED_REMOVE(da, idx) do {                              \
    cl_isize _cl_idx = CL_BOUNDS_CHECK_INDEX((idx), (da)->len);           \
    (da)->len -= 1;                                                       \
    if (_cl_idx < (da)->len) {                                            \
        (da)->data[_cl_idx] = (da)->data[(da)->len];                      \
    }                                                                     \
} while (0)

/*
 * Sets the dynamic array's logical length to new_len elements. When growing,
 * reserves sufficient capacity and zeroes newly exposed elements [len, new_len).
 * When shrinking, retains the existing backing capacity.
 *
 * Parameters:
 *   da      (Cl_DA_T *) - Pointer to the dynamic array.
 *   new_len (cl_isize)  - Target logical length (elements; must be >= 0).
 */
#define CL_DA_RESIZE(da, new_len) do {                                    \
    cl_isize _cl_nl = (cl_isize)(new_len);                                \
    CL_ASSERT(_cl_nl >= 0);                                               \
    if (_cl_nl > (da)->len) {                                             \
        CL_DA_RESERVE((da), _cl_nl);                                      \
        cl_mem_zero(                                                      \
            (da)->data + (da)->len,                                       \
            (_cl_nl - (da)->len) * (cl_isize)sizeof(*(da)->data)          \
        );                                                                \
    }                                                                     \
    (da)->len = _cl_nl;                                                   \
} while (0)

/*
 * Shrinks the dynamic array's backing allocation to match da->len elements via
 * cl_da_shrink_raw (freeing the buffer if da->len <= 0).
 *
 * Parameters:
 *   da (Cl_DA_T *) - Pointer to the dynamic array.
 */
#define CL_DA_SHRINK(da) do {                                             \
    (da)->data = cl_da_shrink_raw(                                        \
        (da)->data, (da)->len, &(da)->cap, &(da)->allocator,              \
        (cl_isize)sizeof(*(da)->data),                                    \
        CL_ALIGNOF_EXPR(*(da)->data),                                     \
        CL_HERE                                                           \
    );                                                                    \
} while (0)

/*
 * Resets the dynamic array's active element count to 0 while keeping its
 * allocated buffer and capacity for reuse.
 *
 * Parameters:
 *   da (Cl_DA_T *) - Pointer to the dynamic array.
 *
 * Returns:
 *   (cl_isize) 0 (result of the assignment expression).
 */
#define CL_DA_CLEAR(da) ((da)->len = 0)

/*
 * Creates an O(1) zero-copy typed slice view over the active elements of a
 * dynamic array. The returned slice is invalidated if the array reallocates or
 * is freed.
 *
 * Parameters:
 *   SliceType (type)      - Typed slice struct matching the element type of da.
 *   da        (Cl_DA_T *) - Pointer to the dynamic array.
 *
 * Returns:
 *   (SliceType) Non-owning slice { da->data, da->len }.
 */
#define CL_DA_AS_SLICE(SliceType, da) ((SliceType){ (da)->data, (da)->len })

/*
 * Sorts all active elements [0, da->len) of the dynamic array in place using
 * cl_slice_sort_raw.
 *
 * Parameters:
 *   da  (Cl_DA_T *)   - Pointer to the dynamic array to sort.
 *   cmp (Cl_Cmp_Proc) - Three-way comparator for the array's element type.
 */
#define CL_DA_SORT(da, cmp) \
    cl_slice_sort_raw((da)->data, (da)->len, (cl_isize)sizeof(*(da)->data), (cmp))

/*
 * Expands to a for-loop header iterating over every 0-based element index in
 * the dynamic array in ascending order [0, da->len).
 *
 * Parameters:
 *   idx_var (identifier) - Loop counter variable name declared as cl_isize.
 *   da      (Cl_DA_T *)  - Pointer to the dynamic array to iterate.
 */
#define CL_DA_FOR_EACH(idx_var, da) \
    for (cl_isize idx_var = 0; idx_var < (da)->len; idx_var++)

/*
 * Type-erased, strict-aliasing-safe cleanup record used by CL_DEFER_DA to
 * automatically release any CL_DA_DEFINE dynamic array at scope exit, even
 * after reallocations change the array's data pointer.
 *
 * Fields:
 *   base      (void *)         - Address of the dynamic array's data pointer
 *                                field (`&da.data`), accessed via cl_mem_copy.
 *   cap_ptr   (cl_isize *)     - Pointer to the dynamic array's cap field
 *                                (elements).
 *   len_ptr   (cl_isize *)     - Pointer to the dynamic array's len field
 *                                (elements).
 *   alloc_ptr (Cl_Allocator *) - Pointer to the dynamic array's allocator field.
 *   elem_size (cl_isize)       - Size of one array element (bytes).
 *   loc       (Cl_Source_Loc)  - Source location where CL_DEFER_DA was placed.
 */
typedef struct Cl_DA_Cleanup_Info {
    void         *base;
    cl_isize     *cap_ptr;
    cl_isize     *len_ptr;
    Cl_Allocator *alloc_ptr;
    cl_isize      elem_size;
    Cl_Source_Loc loc;
} Cl_DA_Cleanup_Info;

/*
 * Scope-exit cleanup callback invoked by CL_CLEANUP for CL_DEFER_DA. Reads the
 * current backing pointer via cl_mem_copy (avoiding strict-aliasing UB), frees
 * (*info->cap_ptr) * info->elem_size bytes if non-NULL, and resets the array's
 * data, len, and cap fields to 0/NULL.
 *
 * Parameters:
 *   info (Cl_DA_Cleanup_Info *) - Pointer to the cleanup descriptor; safe
 *                                 no-op if info == NULL or info->base == NULL.
 */
static inline void cl_da_defer_cleanup_impl(Cl_DA_Cleanup_Info *info) {
    if (info != NULL && info->base != NULL) {
        void *data_ptr = NULL;
        cl_mem_copy(&data_ptr, info->base, (cl_isize)sizeof(void *));
        if (data_ptr != NULL) {
            cl_free_loc(
                cl_alloc_or_ctx(*info->alloc_ptr),
                data_ptr,
                (*info->cap_ptr) * info->elem_size,
                info->loc
            );
            void *null_ptr = NULL;
            cl_mem_copy(info->base, &null_ptr, (cl_isize)sizeof(void *));
            *info->len_ptr = 0;
            *info->cap_ptr = 0;
        }
    }
}

#if CL_HAVE_CLEANUP
    /*
     * Registers automatic scope-exit freeing for a local dynamic array variable
     * using GCC/Clang __attribute__((cleanup)). Tracks reallocations because it
     * stores pointers to the variable's fields rather than its initial buffer.
     *
     * Parameters:
     *   da_var (Cl_DA_T lvalue) - Local dynamic array variable (by value/lvalue,
     *                             not a pointer) whose lifetime outlives the
     *                             deferred cleanup guard.
     */
    #define CL_DEFER_DA(da_var)                                           \
        CL_CLEANUP(cl_da_defer_cleanup_impl) Cl_DA_Cleanup_Info CL_UNIQUE(_cl_def_da_) = { \
            &(da_var).data,                                               \
            &(da_var).cap,                                                \
            &(da_var).len,                                                \
            &(da_var).allocator,                                          \
            (cl_isize)sizeof(*(da_var).data),                             \
            CL_HERE                                                       \
        }
#endif

/* ============================================================================
 * 2. Fixed-Capacity Stack Small Array (Odin `core:container/small_array`)
 * ============================================================================ */

/*
 * Defines a fixed-capacity, inline-storage small array struct that requires no
 * heap allocation. Zero-initialization (`{0}`) yields a valid empty array.
 *
 * Macro Parameters:
 *   Name (identifier) - Struct tag and typedef name for the small array.
 *   T    (type)       - Element type stored inline.
 *   CAP  (cl_isize)   - Compile-time maximum capacity (elements; must be > 0).
 *
 * Generated Struct Fields:
 *   data (T[CAP])   - Inline contiguous element storage of CAP elements.
 *   len  (cl_isize) - Active element count (elements; 0 <= len <= CAP).
 */
#define CL_SMALL_ARRAY_DEFINE(Name, T, CAP) \
    typedef struct Name {                   \
        T        data[(CAP)];               \
        cl_isize len;                       \
    } Name

/*
 * Returns the compile-time fixed capacity of a small array.
 *
 * Parameters:
 *   sa (Cl_Small_Array_T *) - Pointer to the small array.
 *
 * Returns:
 *   (cl_isize) Fixed inline capacity (elements).
 */
#define CL_SA_CAP(sa)     CL_ARRAY_LEN((sa)->data)

/*
 * Resets a small array's active length to 0 elements.
 *
 * Parameters:
 *   sa (Cl_Small_Array_T *) - Pointer to the small array.
 *
 * Returns:
 *   (cl_isize) 0 (result of the assignment expression).
 */
#define CL_SA_CLEAR(sa)   ((sa)->len = 0)

/*
 * Accesses the element at 0-based index idx in a small array with toggleable
 * bounds checking. Traps when CL_BOUNDS_CHECK == 1 and idx is outside
 * [0, sa->len).
 *
 * Parameters:
 *   sa  (Cl_Small_Array_T *) - Pointer to the small array.
 *   idx (cl_isize)           - 0-based element index (elements; 0 <= idx < sa->len).
 *
 * Returns:
 *   (T lvalue) Modifiable lvalue reference to sa->data[idx].
 */
#define CL_SA_AT(sa, idx) ((sa)->data[CL_BOUNDS_CHECK_INDEX((idx), (sa)->len)])

/*
 * Appends val to a small array if free capacity remains (sa->len < CL_SA_CAP(sa)).
 *
 * Parameters:
 *   sa  (Cl_Small_Array_T *) - Pointer to the small array.
 *   val (T)                  - Element value to append.
 *
 * Returns:
 *   (bool) true if val was appended, or false if the small array is full
 *          (leaving *sa unmodified).
 */
#define CL_SA_PUSH(sa, val)                                               \
    (((sa)->len < CL_SA_CAP(sa))                                          \
        ? ((sa)->data[(sa)->len] = (val), (sa)->len += 1, true)           \
        : false)

/*
 * Removes the last element of a small array into *out_ptr if non-empty.
 *
 * Parameters:
 *   sa      (Cl_Small_Array_T *) - Pointer to the small array.
 *   out_ptr (T *)                - Non-NULL destination for the popped value.
 *
 * Returns:
 *   (bool) true if an element was popped into *out_ptr, or false if sa->len == 0
 *          (leaving *out_ptr unmodified).
 */
#define CL_SA_POP_SAFE(sa, out_ptr)                                       \
    (((sa)->len > 0)                                                      \
        ? ((sa)->len -= 1, *(out_ptr) = (sa)->data[(sa)->len], true)      \
        : false)

/*
 * Removes the element at 0-based index idx in O(1) time by moving the last
 * element into slot idx and decrementing sa->len (does not preserve order).
 *
 * Parameters:
 *   sa  (Cl_Small_Array_T *) - Pointer to the small array.
 *   idx (cl_isize)           - 0-based element index (elements; 0 <= idx < sa->len).
 */
#define CL_SA_UNORDERED_REMOVE(sa, idx) do {                              \
    cl_isize _cl_idx = CL_BOUNDS_CHECK_INDEX((idx), (sa)->len);           \
    (sa)->len -= 1;                                                       \
    if (_cl_idx < (sa)->len) {                                            \
        (sa)->data[_cl_idx] = (sa)->data[(sa)->len];                      \
    }                                                                     \
} while (0)

/*
 * Creates an O(1) zero-copy typed slice view over the active elements of a
 * small array.
 *
 * Parameters:
 *   SliceType (type)               - Typed slice struct matching *sa's element type.
 *   sa        (Cl_Small_Array_T *) - Pointer to the small array.
 *
 * Returns:
 *   (SliceType) Non-owning slice { sa->data, sa->len }.
 */
#define CL_SA_AS_SLICE(SliceType, sa) ((SliceType){ (sa)->data, (sa)->len })

/* ============================================================================
 * 3. Circular Ring Queue / Deque (Odin `core:container/queue`)
 * ============================================================================ */

/*
 * Defines a growable circular ring queue / double-ended queue (deque) struct
 * with power-of-two capacity for O(1) bitwise-masked front and back operations.
 * Zero-initialization (`{0}`) yields a valid empty queue.
 *
 * Macro Parameters:
 *   Name (identifier) - Struct tag and typedef name for the queue.
 *   T    (type)       - Element type stored in the ring buffer.
 *
 * Generated Struct Fields:
 *   data      (T *)          - Backing circular buffer of cap elements, or NULL.
 *   head      (cl_isize)     - 0-based physical buffer index of the logical
 *                              front element (elements; 0 <= head < cap when
 *                              cap > 0).
 *   len       (cl_isize)     - Active element count (elements; 0 <= len <= cap).
 *   cap       (cl_isize)     - Allocated ring capacity (elements; always 0 or a
 *                              power of two >= 8).
 *   allocator (Cl_Allocator) - Allocator owning data; lazily binds context
 *                              allocator if invalid.
 */
#define CL_QUEUE_DEFINE(Name, T) \
    typedef struct Name {        \
        T           *data;       \
        cl_isize     head;       \
        cl_isize     len;        \
        cl_isize     cap;        \
        Cl_Allocator allocator;  \
    } Name

/*
 * Pre-defined circular ring queue / deque types generated via CL_QUEUE_DEFINE:
 *   Cl_Queue_I64   (cl_i64)   - Ring queue of signed 64-bit integers.
 *   Cl_Queue_ISize (cl_isize) - Ring queue of signed sizes/indices.
 *   Cl_Queue_Str   (Cl_Str)   - Ring queue of non-owning UTF-8 strings.
 *   Cl_Queue_Ptr   (void *)   - Ring queue of untyped pointers.
 */
CL_QUEUE_DEFINE(Cl_Queue_I64,   cl_i64);
CL_QUEUE_DEFINE(Cl_Queue_ISize, cl_isize);
CL_QUEUE_DEFINE(Cl_Queue_Str,   Cl_Str);
CL_QUEUE_DEFINE(Cl_Queue_Ptr,   void *);

/* Shared ring-buffer linearizing resize helper (implemented in cl_array.c) */

/*
 * Doubles a circular ring queue's power-of-two capacity (initializing to 8
 * elements when *cap == 0), linearizes existing wrapped elements into indices
 * [0, len) of the new buffer, frees old_data, and sets *head = 0. Lazily binds
 * *alloc to cl_ctx_allocator() if invalid.
 *
 * Parameters:
 *   old_data   (void *)         - Existing ring buffer, or NULL.
 *   head       (cl_isize *)     - Non-NULL in/out physical front index
 *                                 (elements); reset to 0 on success.
 *   len        (cl_isize)       - Active element count (elements).
 *   cap        (cl_isize *)     - Non-NULL in/out power-of-two capacity
 *                                 (elements); doubled (or set to 8) on success.
 *   alloc      (Cl_Allocator *) - Non-NULL in/out allocator pointer.
 *   elem_size  (cl_isize)       - Size of one element (bytes; must be > 0).
 *   elem_align (cl_isize)       - Power-of-two element alignment (bytes).
 *   loc        (Cl_Source_Loc)  - Caller source location for diagnostics.
 *
 * Returns:
 *   (void *) Pointer to the newly allocated linearized buffer, or NULL on
 *            byte-size overflow or allocation failure (leaving *head, *cap,
 *            and old_data intact).
 */
void *cl_queue_grow_raw(
    void *old_data,
    cl_isize *head,
    cl_isize len,
    cl_isize *cap,
    Cl_Allocator *alloc,
    cl_isize elem_size,
    cl_isize elem_align,
    Cl_Source_Loc loc
);

/*
 * Initializes a circular ring queue to an empty state (data = NULL, head = 0,
 * len = 0, cap = 0) with an explicit allocator.
 *
 * Parameters:
 *   q     (Cl_Queue_T *) - Pointer to the queue to initialize.
 *   alloc (Cl_Allocator) - Allocator handle to bind to q->allocator.
 */
#define CL_QUEUE_INIT(q, alloc) do { \
    (q)->data      = NULL;           \
    (q)->head      = 0;              \
    (q)->len       = 0;              \
    (q)->cap       = 0;              \
    (q)->allocator = (alloc);        \
} while (0)

/*
 * Releases the queue's ring buffer via cl_alloc_or_ctx(q->allocator) and resets
 * data = NULL, head = 0, len = 0, and cap = 0 while preserving q->allocator.
 * Safe no-op when q->data == NULL.
 *
 * Parameters:
 *   q (Cl_Queue_T *) - Pointer to the queue to free.
 */
#define CL_QUEUE_FREE(q) do {                                             \
    if ((q)->data != NULL) {                                              \
        cl_free_loc(                                                      \
            cl_alloc_or_ctx((q)->allocator),                              \
            (q)->data,                                                    \
            (q)->cap * (cl_isize)sizeof(*(q)->data),                      \
            CL_HERE                                                       \
        );                                                                \
        (q)->data = NULL;                                                 \
        (q)->head = 0;                                                    \
        (q)->len  = 0;                                                    \
        (q)->cap  = 0;                                                    \
    }                                                                     \
} while (0)

/*
 * Resets the queue's head and active element count to 0 while keeping the
 * allocated ring buffer and capacity for reuse.
 *
 * Parameters:
 *   q (Cl_Queue_T *) - Pointer to the queue to clear.
 */
#define CL_QUEUE_CLEAR(q) do { (q)->head = 0; (q)->len = 0; } while (0)

/*
 * Ensures room for at least one additional element (q->len < q->cap), growing
 * and linearizing the ring buffer via cl_queue_grow_raw if full. Asserts
 * allocation success with CL_ENSURE.
 *
 * Parameters:
 *   q (Cl_Queue_T *) - Pointer to the queue.
 */
#define CL_QUEUE_RESERVE_ONE(q) do {                                      \
    if ((q)->len >= (q)->cap) {                                           \
        void *_cl_qd = cl_queue_grow_raw(                                 \
            (q)->data, &(q)->head, (q)->len, &(q)->cap, &(q)->allocator,  \
            (cl_isize)sizeof(*(q)->data),                                 \
            CL_ALIGNOF_EXPR(*(q)->data),                                  \
            CL_HERE                                                       \
        );                                                                \
        CL_ENSURE(_cl_qd != NULL);                                        \
        (q)->data = _cl_qd;                                               \
    }                                                                     \
} while (0)

/*
 * Enqueues val at the logical back of the deque in O(1) amortized time.
 *
 * Parameters:
 *   q   (Cl_Queue_T *) - Pointer to the queue.
 *   val (T)            - Element value to push at the back.
 */
#define CL_QUEUE_PUSH_BACK(q, val) do {                                   \
    CL_QUEUE_RESERVE_ONE(q);                                              \
    cl_isize _cl_tail = ((q)->head + (q)->len) & ((q)->cap - 1);          \
    (q)->data[_cl_tail] = (val);                                          \
    (q)->len += 1;                                                        \
} while (0)

/*
 * Enqueues val at the logical front of the deque in O(1) amortized time.
 *
 * Parameters:
 *   q   (Cl_Queue_T *) - Pointer to the queue.
 *   val (T)            - Element value to push at the front.
 */
#define CL_QUEUE_PUSH_FRONT(q, val) do {                                  \
    CL_QUEUE_RESERVE_ONE(q);                                              \
    (q)->head = ((q)->head - 1) & ((q)->cap - 1);                         \
    (q)->data[(q)->head] = (val);                                         \
    (q)->len += 1;                                                        \
} while (0)

/*
 * Dequeues the logical front element into *out_ptr in O(1) time if non-empty.
 *
 * Parameters:
 *   q       (Cl_Queue_T *) - Pointer to the queue.
 *   out_ptr (T *)          - Non-NULL destination pointer for the front element.
 *
 * Returns:
 *   (bool) true if an element was dequeued into *out_ptr, or false if q->len == 0
 *          (leaving *out_ptr unmodified).
 */
#define CL_QUEUE_POP_FRONT_SAFE(q, out_ptr)                               \
    (((q)->len > 0)                                                       \
        ? (*(out_ptr) = (q)->data[(q)->head],                             \
           (q)->head = ((q)->head + 1) & ((q)->cap - 1),                  \
           (q)->len -= 1, true)                                           \
        : false)

/*
 * Dequeues the logical back element into *out_ptr in O(1) time if non-empty.
 *
 * Parameters:
 *   q       (Cl_Queue_T *) - Pointer to the queue.
 *   out_ptr (T *)          - Non-NULL destination pointer for the back element.
 *
 * Returns:
 *   (bool) true if an element was dequeued into *out_ptr, or false if q->len == 0
 *          (leaving *out_ptr unmodified).
 */
#define CL_QUEUE_POP_BACK_SAFE(q, out_ptr)                                \
    (((q)->len > 0)                                                       \
        ? ((q)->len -= 1,                                                 \
           *(out_ptr) = (q)->data[((q)->head + (q)->len) & ((q)->cap - 1)], \
           true)                                                          \
        : false)

/*
 * Accesses the element at logical 0-based offset idx from the front of the
 * queue with toggleable bounds checking, wrapping around the power-of-two ring
 * buffer via bitmasking.
 *
 * Parameters:
 *   q   (Cl_Queue_T *) - Pointer to the queue.
 *   idx (cl_isize)     - 0-based logical element index from front (elements;
 *                        0 <= idx < q->len).
 *
 * Returns:
 *   (T lvalue) Modifiable lvalue reference to the element at logical index idx.
 */
#define CL_QUEUE_AT(q, idx) \
    ((q)->data[((q)->head + CL_BOUNDS_CHECK_INDEX((idx), (q)->len)) & ((q)->cap - 1)])

/* ============================================================================
 * 4. Dense Bit Set (Odin `core:container/bit_array`)
 * ============================================================================ */

/*
 * Fixed-capacity dense bit set packed into contiguous 64-bit unsigned words.
 * Bit i resides at bit position (i & 63) of words[i >> 6].
 *
 * Fields:
 *   words     (cl_u64 *)     - Backing array of word_cap 64-bit words, or NULL.
 *   bit_cap   (cl_isize)     - Usable bit capacity (bits; valid 0-based bit
 *                              indices are [0, bit_cap)).
 *   word_cap  (cl_isize)     - Allocated 64-bit word count (words; equal to
 *                              (bit_cap + 63) / 64).
 *   allocator (Cl_Allocator) - Allocator owning words.
 */
typedef struct Cl_Bit_Set {
    cl_u64      *words;
    cl_isize     bit_cap;
    cl_isize     word_cap;
    Cl_Allocator allocator;
} Cl_Bit_Set;

/*
 * Allocates and zero-initializes a dense bit set capable of storing bit_count
 * bits using alloc (or cl_ctx_allocator() if invalid).
 *
 * Parameters:
 *   bs        (Cl_Bit_Set *) - Non-NULL pointer to the bit set to initialize.
 *   bit_count (cl_isize)     - Number of addressable bits (bits; must be > 0).
 *   alloc     (Cl_Allocator) - Backing allocator handle.
 *
 * Returns:
 *   (bool) true if allocation succeeded and *bs is ready for use; false if
 *          bit_count <= 0 or allocation failed (leaving *bs zeroed).
 */
bool     cl_bitset_init(Cl_Bit_Set *bs, cl_isize bit_count, Cl_Allocator alloc);

/*
 * Releases the word buffer owned by *bs and zeroes the struct. Safe no-op if
 * bs == NULL.
 *
 * Parameters:
 *   bs (Cl_Bit_Set *) - Pointer to the bit set to destroy.
 */
void     cl_bitset_destroy(Cl_Bit_Set *bs);

/*
 * Clears every bit in *bs to 0 without releasing its allocated word buffer.
 * Safe no-op if bs == NULL or bs->words == NULL.
 *
 * Parameters:
 *   bs (Cl_Bit_Set *) - Pointer to the bit set to clear.
 */
void     cl_bitset_clear_all(Cl_Bit_Set *bs);

/*
 * Sets the bit at 0-based bit index bit_idx to 1 with toggleable bounds
 * checking against [0, bs->bit_cap).
 *
 * Parameters:
 *   bs      (Cl_Bit_Set *) - Non-NULL initialized bit set.
 *   bit_idx (cl_isize)     - 0-based bit index (bits; 0 <= bit_idx < bs->bit_cap).
 */
void     cl_bitset_set(Cl_Bit_Set *bs, cl_isize bit_idx);

/*
 * Clears the bit at 0-based bit index bit_idx to 0 with toggleable bounds
 * checking against [0, bs->bit_cap).
 *
 * Parameters:
 *   bs      (Cl_Bit_Set *) - Non-NULL initialized bit set.
 *   bit_idx (cl_isize)     - 0-based bit index (bits; 0 <= bit_idx < bs->bit_cap).
 */
void     cl_bitset_clear(Cl_Bit_Set *bs, cl_isize bit_idx);

/*
 * Flips (XORs with 1) the bit at 0-based bit index bit_idx with toggleable
 * bounds checking against [0, bs->bit_cap).
 *
 * Parameters:
 *   bs      (Cl_Bit_Set *) - Non-NULL initialized bit set.
 *   bit_idx (cl_isize)     - 0-based bit index (bits; 0 <= bit_idx < bs->bit_cap).
 */
void     cl_bitset_toggle(Cl_Bit_Set *bs, cl_isize bit_idx);

/*
 * Tests whether the bit at 0-based bit index bit_idx is set to 1 with
 * toggleable bounds checking against [0, bs->bit_cap).
 *
 * Parameters:
 *   bs      (const Cl_Bit_Set *) - Non-NULL initialized bit set.
 *   bit_idx (cl_isize)           - 0-based bit index (bits;
 *                                  0 <= bit_idx < bs->bit_cap).
 *
 * Returns:
 *   (bool) true if bit bit_idx is 1, false if 0.
 */
bool     cl_bitset_test(const Cl_Bit_Set *bs, cl_isize bit_idx);

/*
 * Counts the total number of 1-bits (Hamming weight) across all words of *bs.
 *
 * Parameters:
 *   bs (const Cl_Bit_Set *) - Pointer to the bit set (may be NULL).
 *
 * Returns:
 *   (cl_isize) Total count of set bits (bits), or 0 if bs == NULL or
 *              bs->words == NULL.
 */
cl_isize cl_bitset_count_ones(const Cl_Bit_Set *bs);

/*
 * Computes the in-place bitwise union (dst |= src) across
 * min(dst->word_cap, src->word_cap) 64-bit words.
 *
 * Parameters:
 *   dst (Cl_Bit_Set *)       - Non-NULL destination bit set modified in place.
 *   src (const Cl_Bit_Set *) - Non-NULL source bit set.
 */
void     cl_bitset_union_in_place(Cl_Bit_Set *dst, const Cl_Bit_Set *src);

/*
 * Computes the in-place bitwise intersection (dst &= src) across
 * min(dst->word_cap, src->word_cap) 64-bit words and zeroes any trailing words
 * in dst beyond src->word_cap.
 *
 * Parameters:
 *   dst (Cl_Bit_Set *)       - Non-NULL destination bit set modified in place.
 *   src (const Cl_Bit_Set *) - Non-NULL source bit set.
 */
void     cl_bitset_intersect_in_place(Cl_Bit_Set *dst, const Cl_Bit_Set *src);

#endif /* CL_ARRAY_H */
