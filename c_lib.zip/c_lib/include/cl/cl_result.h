/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_result.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Idiomatic multiple return values and error propagation in ISO C99,
 *   modeled after Odin's `(value, ok)` / `(value, err)` tuples and its
 *   `or_return`, `or_else`, `or_break`, and `or_continue` operators.
 *
 * Why This Pattern Works Great in C99 on Linux x86_64:
 *   The SysV x86_64 ABI returns small structs (<= 16 bytes, e.g.,
 *   { i64 value; bool ok; } or { void *value; Cl_Error err; }) directly in
 *   CPU registers (RAX + RDX), matching Odin's zero-overhead multiple returns.
 *
 * Usage Example:
 *   Cl_Opt_I64 parse_port(Cl_Str s) {
 *       cl_i64 v;
 *       CL_OPT_OR_RETURN(v, cl_str_parse_i64(s, 10), Cl_Opt_I64);
 *       if (v < 1 || v > 65535) return CL_NONE(Cl_Opt_I64);
 *       return CL_SOME(Cl_Opt_I64, v);
 *   }
 * ============================================================================
 */

#ifndef CL_RESULT_H
#define CL_RESULT_H

#include "cl_types.h"
#include "cl_assert.h"

/* ----------------------------------------------------------------------------
 * Standard Library Error Codes (Zero Means Success, Just Like Odin)
 * ---------------------------------------------------------------------------- */

/*
 * Standard c_lib error enumeration where 0 (CL_ERR_NONE) indicates success and
 * non-zero values identify specific failure categories.
 *
 * Values:
 *   CL_ERR_NONE             (0) - Operation succeeded with no error.
 *   CL_ERR_INVALID_ARG      (1) - Invalid argument value or NULL pointer supplied.
 *   CL_ERR_OUT_OF_MEMORY    (2) - Memory allocation or reservation failed.
 *   CL_ERR_OUT_OF_BOUNDS    (3) - Index, offset, or range exceeded valid bounds.
 *   CL_ERR_NOT_FOUND        (4) - Requested key, item, or filesystem path was not found.
 *   CL_ERR_ALREADY_EXISTS   (5) - Target key, entry, or file already exists.
 *   CL_ERR_BUFFER_TOO_SMALL (6) - Caller-provided output buffer lacked required byte capacity.
 *   CL_ERR_PARSE_FAILED     (7) - Input text or binary data failed syntax/format parsing.
 *   CL_ERR_OVERFLOW         (8) - Arithmetic or integer conversion overflow occurred.
 *   CL_ERR_IO_OPEN          (9) - Failed to open a file or descriptor.
 *   CL_ERR_IO_READ          (10) - Failed while reading from a file or descriptor.
 *   CL_ERR_IO_WRITE         (11) - Failed while writing or flushing a file or descriptor.
 *   CL_ERR_IO_STAT          (12) - Failed to query file metadata (stat/fstat).
 *   CL_ERR_PERMISSION       (13) - Operation denied due to insufficient OS permissions.
 *   CL_ERR_UNSUPPORTED      (14) - Operation or feature is unsupported on this target/allocator.
 *   CL_ERR_UNKNOWN          (15) - Unclassified or unexpected error.
 */
typedef enum Cl_Error {
    CL_ERR_NONE = 0,
    CL_ERR_INVALID_ARG,
    CL_ERR_OUT_OF_MEMORY,
    CL_ERR_OUT_OF_BOUNDS,
    CL_ERR_NOT_FOUND,
    CL_ERR_ALREADY_EXISTS,
    CL_ERR_BUFFER_TOO_SMALL,
    CL_ERR_PARSE_FAILED,
    CL_ERR_OVERFLOW,
    CL_ERR_IO_OPEN,
    CL_ERR_IO_READ,
    CL_ERR_IO_WRITE,
    CL_ERR_IO_STAT,
    CL_ERR_PERMISSION,
    CL_ERR_UNSUPPORTED,
    CL_ERR_UNKNOWN
} Cl_Error;

/*
 * Converts a Cl_Error code into a static, human-readable NUL-terminated string name.
 *
 * Parameters:
 *   err (Cl_Error) - Error code to format.
 *
 * Returns:
 *   const char * - Static NUL-terminated ASCII identifier (e.g., "NONE", "OUT_OF_MEMORY",
 *                  or "UNKNOWN" for unrecognized values).
 */
static inline const char *cl_error_name(Cl_Error err) {
    switch (err) {
        case CL_ERR_NONE:             return "NONE";
        case CL_ERR_INVALID_ARG:      return "INVALID_ARG";
        case CL_ERR_OUT_OF_MEMORY:    return "OUT_OF_MEMORY";
        case CL_ERR_OUT_OF_BOUNDS:    return "OUT_OF_BOUNDS";
        case CL_ERR_NOT_FOUND:        return "NOT_FOUND";
        case CL_ERR_ALREADY_EXISTS:   return "ALREADY_EXISTS";
        case CL_ERR_BUFFER_TOO_SMALL: return "BUFFER_TOO_SMALL";
        case CL_ERR_PARSE_FAILED:     return "PARSE_FAILED";
        case CL_ERR_OVERFLOW:         return "OVERFLOW";
        case CL_ERR_IO_OPEN:          return "IO_OPEN";
        case CL_ERR_IO_READ:          return "IO_READ";
        case CL_ERR_IO_WRITE:         return "IO_WRITE";
        case CL_ERR_IO_STAT:          return "IO_STAT";
        case CL_ERR_PERMISSION:       return "PERMISSION";
        case CL_ERR_UNSUPPORTED:      return "UNSUPPORTED";
        default:                      return "UNKNOWN";
    }
}

/* ----------------------------------------------------------------------------
 * Multiple-Return Struct Generators
 * ---------------------------------------------------------------------------- */

/*
 * Defines an optional return struct typedef `{ T value; bool ok; }` modeling
 * Odin's `(T, bool)` / `Maybe(T)` multiple-return pattern.
 *
 * Parameters:
 *   Name (identifier) - Struct tag and typedef name to declare.
 *   T    (C type)     - Payload value type stored in field `value`.
 */
#define CL_OPT_DEFINE(Name, T) \
    typedef struct Name {      \
        T    value;            \
        bool ok;               \
    } Name

/*
 * Defines a result return struct typedef `{ T value; E err; }` modeling Odin's
 * `(T, E)` multiple-return pattern where `err == 0` signifies success.
 *
 * Parameters:
 *   Name (identifier) - Struct tag and typedef name to declare.
 *   T    (C type)     - Success payload type stored in field `value`.
 *   E    (C type)     - Error code type stored in field `err` (0 = success).
 */
#define CL_RES_DEFINE(Name, T, E) \
    typedef struct Name {         \
        T value;                  \
        E err;                    \
    } Name

/*
 * Defines a generic 2-element return tuple struct typedef `{ A first; B second; }`.
 *
 * Parameters:
 *   Name (identifier) - Struct tag and typedef name to declare.
 *   A    (C type)     - Type of field `first`.
 *   B    (C type)     - Type of field `second`.
 */
#define CL_PAIR_DEFINE(Name, A, B) \
    typedef struct Name {          \
        A first;                   \
        B second;                  \
    } Name

/*
 * Defines a generic 3-element return tuple struct typedef `{ A first; B second; C third; }`.
 *
 * Parameters:
 *   Name (identifier) - Struct tag and typedef name to declare.
 *   A    (C type)     - Type of field `first`.
 *   B    (C type)     - Type of field `second`.
 *   C    (C type)     - Type of field `third`.
 */
#define CL_TUPLE3_DEFINE(Name, A, B, C) \
    typedef struct Name {               \
        A first;                        \
        B second;                       \
        C third;                        \
    } Name

/* Constructors for Optional & Result values */

/*
 * Constructs a present optional compound literal with value = val and ok = true.
 *
 * Parameters:
 *   OptType (C struct type) - Optional type declared via CL_OPT_DEFINE.
 *   val     (expression)    - Present payload value compatible with OptType.value.
 *
 * Returns:
 *   OptType - Initialized optional struct with ok == true.
 */
#define CL_SOME(OptType, val) ((OptType){ (val), true })

/*
 * Initial aggregate-initializer definition of CL_NONE (immediately superseded below
 * by the designated-initializer version that works uniformly for scalar and struct T).
 *
 * Parameters:
 *   OptType (C struct type) - Optional type declared via CL_OPT_DEFINE.
 *
 * Returns:
 *   OptType - Empty optional struct with ok == false.
 */
#define CL_NONE(OptType)      ((OptType){ {0}, false })

#undef CL_NONE
/*
 * Constructs an absent optional compound literal with ok = false and zero-initialized
 * value using C99 designated initialization (compatible with both scalar and struct T).
 *
 * Parameters:
 *   OptType (C struct type) - Optional type declared via CL_OPT_DEFINE.
 *
 * Returns:
 *   OptType - Empty optional struct with ok == false.
 */
#define CL_NONE(OptType)      ((OptType){ .ok = false })

/*
 * Constructs a successful result compound literal with value = val and err = 0.
 *
 * Parameters:
 *   ResType (C struct type) - Result type declared via CL_RES_DEFINE.
 *   val     (expression)    - Success payload value compatible with ResType.value.
 *
 * Returns:
 *   ResType - Initialized result struct with err == 0.
 */
#define CL_OK(ResType, val)   ((ResType){ .value = (val), .err = 0 })

/*
 * Constructs a failed result compound literal with err = e and zero-initialized value.
 *
 * Parameters:
 *   ResType (C struct type) - Result type declared via CL_RES_DEFINE.
 *   e       (error value)   - Non-zero error value compatible with ResType.err.
 *
 * Returns:
 *   ResType - Initialized failed result struct with err == e.
 */
#define CL_ERR(ResType, e)    ((ResType){ .err = (e) })

/* ----------------------------------------------------------------------------
 * Pre-Defined Common Optional & Result Types
 * ---------------------------------------------------------------------------- */

/* Optional boolean return type: struct Cl_Opt_Bool { bool value; bool ok; }. */
CL_OPT_DEFINE(Cl_Opt_Bool,  bool);

/* Optional signed 32-bit integer return type: struct Cl_Opt_I32 { cl_i32 value; bool ok; }. */
CL_OPT_DEFINE(Cl_Opt_I32,   cl_i32);

/* Optional signed 64-bit integer return type: struct Cl_Opt_I64 { cl_i64 value; bool ok; }. */
CL_OPT_DEFINE(Cl_Opt_I64,   cl_i64);

/* Optional unsigned 32-bit integer return type: struct Cl_Opt_U32 { cl_u32 value; bool ok; }. */
CL_OPT_DEFINE(Cl_Opt_U32,   cl_u32);

/* Optional unsigned 64-bit integer return type: struct Cl_Opt_U64 { cl_u64 value; bool ok; }. */
CL_OPT_DEFINE(Cl_Opt_U64,   cl_u64);

/* Optional signed size/index return type: struct Cl_Opt_ISize { cl_isize value; bool ok; }. */
CL_OPT_DEFINE(Cl_Opt_ISize, cl_isize);

/* Optional unsigned size return type: struct Cl_Opt_USize { cl_usize value; bool ok; }. */
CL_OPT_DEFINE(Cl_Opt_USize, cl_usize);

/* Optional 32-bit float return type: struct Cl_Opt_F32 { cl_f32 value; bool ok; }. */
CL_OPT_DEFINE(Cl_Opt_F32,   cl_f32);

/* Optional 64-bit float return type: struct Cl_Opt_F64 { cl_f64 value; bool ok; }. */
CL_OPT_DEFINE(Cl_Opt_F64,   cl_f64);

/* Optional single-precision complex return type: struct Cl_Opt_C64 { cl_c64 value; bool ok; }. */
CL_OPT_DEFINE(Cl_Opt_C64,   cl_c64);

/* Optional double-precision complex return type: struct Cl_Opt_C128 { cl_c128 value; bool ok; }. */
CL_OPT_DEFINE(Cl_Opt_C128,  cl_c128);

/* Optional Unicode code point return type: struct Cl_Opt_Rune { cl_rune value; bool ok; }. */
CL_OPT_DEFINE(Cl_Opt_Rune,  cl_rune);

/* Optional string view return type: struct Cl_Opt_Str { Cl_Str value; bool ok; }. */
CL_OPT_DEFINE(Cl_Opt_Str,   Cl_Str);

/* Optional untyped pointer return type: struct Cl_Opt_Ptr { void *value; bool ok; }. */
CL_OPT_DEFINE(Cl_Opt_Ptr,   void *);

/* Signed 64-bit integer result type: struct Cl_Res_I64 { cl_i64 value; Cl_Error err; }. */
CL_RES_DEFINE(Cl_Res_I64,   cl_i64,   Cl_Error);

/* Signed size/index result type: struct Cl_Res_ISize { cl_isize value; Cl_Error err; }. */
CL_RES_DEFINE(Cl_Res_ISize, cl_isize, Cl_Error);

/* 64-bit float result type: struct Cl_Res_F64 { cl_f64 value; Cl_Error err; }. */
CL_RES_DEFINE(Cl_Res_F64,   cl_f64,   Cl_Error);

/* String view result type: struct Cl_Res_Str { Cl_Str value; Cl_Error err; }. */
CL_RES_DEFINE(Cl_Res_Str,   Cl_Str,   Cl_Error);

/* Untyped pointer result type: struct Cl_Res_Ptr { void *value; Cl_Error err; }. */
CL_RES_DEFINE(Cl_Res_Ptr,   void *,   Cl_Error);

/*
 * Specialized 3-value return struct for string splitting/cutting operations such as
 * cl_str_cut(s, sep) -> (before, after, found).
 *
 * Fields:
 *   before (Cl_Str) - Substring view before the separator (or entire input if not found).
 *   after  (Cl_Str) - Substring view after the separator (or empty view if not found).
 *   found  (bool)   - true if the separator was found, false otherwise.
 */
typedef struct Cl_Str_Cut {
    Cl_Str before;
    Cl_Str after;
    bool   found;
} Cl_Str_Cut;

/*
 * Specialized return struct for single-rune UTF-8 decoding -> (codepoint, width, valid).
 *
 * Fields:
 *   codepoint (cl_rune, UTF-32 code point) - Decoded Unicode scalar value, or U+FFFD on invalid UTF-8.
 *   width     (cl_isize, bytes)            - Consumed byte width: 1..4 on valid rune, 0 on empty input,
 *                                            or 1 (with codepoint = 0xFFFD) on invalid byte sequence.
 *   valid     (bool)                       - true if a valid UTF-8 sequence was decoded, false otherwise.
 */
typedef struct Cl_Utf8_Decode {
    cl_rune  codepoint;
    cl_isize width;
    bool     valid;
} Cl_Utf8_Decode;

/* ----------------------------------------------------------------------------
 * Error / Optional Propagation Macros (Odin `or_return`, `or_else`, `or_break`)
 * ---------------------------------------------------------------------------- */

#if CL_HAVE_TYPEOF
    /*
     * Unpacks res_expr into out_val on success (err == 0), or immediately returns
     * CL_ERR(RetResType, err) from the enclosing function preserving the error code.
     *
     * Parameters:
     *   out_val    (modifiable lvalue) - Destination variable receiving res_expr.value.
     *   res_expr   (result struct)     - Expression yielding a struct with `.value` and `.err` (evaluated once).
     *   RetResType (C struct type)     - Enclosing function's result return type.
     */
    #define CL_OR_RETURN(out_val, res_expr, RetResType) do { \
        CL_EXTENSION __typeof__(res_expr) _cl_r = (res_expr); \
        if (CL_UNLIKELY(_cl_r.err != 0)) {                   \
            return CL_ERR(RetResType, _cl_r.err);            \
        }                                                    \
        (out_val) = _cl_r.value;                             \
    } while (0)

    /*
     * Unpacks res_expr into out_val on success (err == 0), or immediately returns
     * res_expr.err directly from an enclosing function whose return type is Cl_Error.
     *
     * Parameters:
     *   out_val  (modifiable lvalue) - Destination variable receiving res_expr.value.
     *   res_expr (result struct)     - Expression yielding a struct with `.value` and `.err` (evaluated once).
     */
    #define CL_OR_RETURN_ERR(out_val, res_expr) do {         \
        CL_EXTENSION __typeof__(res_expr) _cl_r = (res_expr); \
        if (CL_UNLIKELY(_cl_r.err != 0)) {                   \
            return _cl_r.err;                                \
        }                                                    \
        (out_val) = _cl_r.value;                             \
    } while (0)

    /*
     * Unpacks opt_expr into out_val if ok == true, or immediately returns
     * CL_NONE(RetOptType) from the enclosing function.
     *
     * Parameters:
     *   out_val    (modifiable lvalue) - Destination variable receiving opt_expr.value.
     *   opt_expr   (optional struct)   - Expression yielding a struct with `.value` and `.ok` (evaluated once).
     *   RetOptType (C struct type)     - Enclosing function's optional return type.
     */
    #define CL_OPT_OR_RETURN(out_val, opt_expr, RetOptType) do { \
        CL_EXTENSION __typeof__(opt_expr) _cl_o = (opt_expr);    \
        if (CL_UNLIKELY(!_cl_o.ok)) {                            \
            return CL_NONE(RetOptType);                          \
        }                                                        \
        (out_val) = _cl_o.value;                                 \
    } while (0)

    /*
     * Unpacks opt_expr into out_val if ok == true, or executes `break` to exit
     * the enclosing loop/switch statement.
     *
     * Parameters:
     *   out_val  (modifiable lvalue) - Destination variable receiving opt_expr.value.
     *   opt_expr (optional struct)   - Expression yielding a struct with `.value` and `.ok` (evaluated once).
     */
    #define CL_OPT_OR_BREAK(out_val, opt_expr)               \
        CL_EXTENSION __typeof__(opt_expr) CL_UNIQUE(_cl_ob_) = (opt_expr); \
        if (CL_UNLIKELY(!CL_UNIQUE(_cl_ob_).ok)) break;      \
        (out_val) = CL_UNIQUE(_cl_ob_).value

    /*
     * Unpacks opt_expr into out_val if ok == true, or executes `continue` to advance
     * to the next iteration of the enclosing loop.
     *
     * Parameters:
     *   out_val  (modifiable lvalue) - Destination variable receiving opt_expr.value.
     *   opt_expr (optional struct)   - Expression yielding a struct with `.value` and `.ok` (evaluated once).
     */
    #define CL_OPT_OR_CONTINUE(out_val, opt_expr)            \
        CL_EXTENSION __typeof__(opt_expr) CL_UNIQUE(_cl_oc_) = (opt_expr); \
        if (CL_UNLIKELY(!CL_UNIQUE(_cl_oc_).ok)) continue;   \
        (out_val) = CL_UNIQUE(_cl_oc_).value

    /*
     * Expression macro that evaluates opt_expr once and yields opt_expr.value if
     * ok == true, or lazily evaluates and yields fallback if ok == false.
     *
     * Parameters:
     *   opt_expr (optional struct) - Expression yielding a struct with `.value` and `.ok`.
     *   fallback (expression)      - Fallback value compatible with opt_expr.value (evaluated only if !ok).
     *
     * Returns:
     *   Type of opt_expr.value - Unwrapped value or fallback.
     */
    #define CL_OR_ELSE(opt_expr, fallback) CL_EXTENSION ({   \
        __typeof__(opt_expr) _cl_o = (opt_expr);             \
        _cl_o.ok ? _cl_o.value : (fallback);                 \
    })

    /*
     * Expression macro that evaluates res_expr once and yields res_expr.value if
     * err == 0, or lazily evaluates and yields fallback if err != 0.
     *
     * Parameters:
     *   res_expr (result struct) - Expression yielding a struct with `.value` and `.err`.
     *   fallback (expression)    - Fallback value compatible with res_expr.value (evaluated only if err != 0).
     *
     * Returns:
     *   Type of res_expr.value - Unwrapped value or fallback.
     */
    #define CL_RES_OR_ELSE(res_expr, fallback) CL_EXTENSION ({ \
        __typeof__(res_expr) _cl_r = (res_expr);               \
        (_cl_r.err == 0) ? _cl_r.value : (fallback);           \
    })

    /*
     * Expression macro that evaluates opt_expr once and returns opt_expr.value,
     * or immediately invokes cl_assert_fail("UNWRAP FAILED", ...) if ok == false.
     *
     * Parameters:
     *   opt_expr (optional struct) - Expression yielding a struct with `.value` and `.ok`.
     *
     * Returns:
     *   Type of opt_expr.value - Present unwrapped payload value.
     */
    #define CL_OPT_OR_PANIC(opt_expr) CL_EXTENSION ({        \
        __typeof__(opt_expr) _cl_o = (opt_expr);             \
        if (CL_UNLIKELY(!_cl_o.ok)) {                        \
            cl_assert_fail("UNWRAP FAILED", #opt_expr " returned ok=false", CL_HERE); \
        }                                                    \
        _cl_o.value;                                         \
    })

    /*
     * Expression macro that evaluates res_expr once and returns res_expr.value,
     * or immediately invokes cl_assert_fail_fmt("UNWRAP FAILED", ...) printing
     * cl_error_name(err) and the numeric error code if err != 0.
     *
     * Parameters:
     *   res_expr (result struct) - Expression yielding a struct with `.value` and Cl_Error `.err`.
     *
     * Returns:
     *   Type of res_expr.value - Successful unwrapped payload value.
     */
    #define CL_RES_OR_PANIC(res_expr) CL_EXTENSION ({        \
        __typeof__(res_expr) _cl_r = (res_expr);             \
        if (CL_UNLIKELY(_cl_r.err != 0)) {                   \
            cl_assert_fail_fmt("UNWRAP FAILED", CL_HERE,     \
                "%s failed with error %s (%d)",              \
                #res_expr, cl_error_name(_cl_r.err), (int)_cl_r.err); \
        }                                                    \
        _cl_r.value;                                         \
    })
#endif

/*
 * Pure ISO C99 explicit-type fallback for CL_OR_RETURN that works without __typeof__.
 * Unpacks res_expr into out_val if err == 0, or returns CL_ERR(RetResType, err).
 *
 * Parameters:
 *   ResType    (C struct type)     - Concrete result struct type of res_expr.
 *   out_val    (modifiable lvalue) - Destination variable receiving res_expr.value.
 *   res_expr   (ResType value)     - Result expression evaluated once.
 *   RetResType (C struct type)     - Enclosing function's result return type.
 */
#define CL_OR_RETURN_T(ResType, out_val, res_expr, RetResType) do { \
    ResType _cl_r = (res_expr);                                     \
    if (CL_UNLIKELY(_cl_r.err != 0)) {                              \
        return CL_ERR(RetResType, _cl_r.err);                       \
    }                                                               \
    (out_val) = _cl_r.value;                                        \
} while (0)

/*
 * Evaluates an error-returning expression once and immediately returns the error
 * from the enclosing Cl_Error-returning function if it is not CL_ERR_NONE.
 *
 * Parameters:
 *   err_expr (Cl_Error expression) - Expression producing a Cl_Error status code.
 */
#define CL_TRY_ERR(err_expr) do {         \
    Cl_Error _cl_e = (err_expr);          \
    if (CL_UNLIKELY(_cl_e != CL_ERR_NONE)) { \
        return _cl_e;                     \
    }                                     \
} while (0)

#endif /* CL_RESULT_H */
