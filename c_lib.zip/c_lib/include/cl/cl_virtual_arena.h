/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_virtual_arena.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Linux virtual-memory growing arena (`Cl_Virtual_Arena`), inspired by
 *   Odin's `core:mem/virtual` Arena.
 *
 * How It Works:
 *   1. `cl_varena_init` reserves a large contiguous virtual address range
 *      (e.g., 64 MiB or 1 GiB) with `mmap(..., PROT_NONE, MAP_PRIVATE |
 *      MAP_ANONYMOUS)` costing ZERO physical RAM.
 *   2. As allocations occur, physical pages are committed on demand in
 *      page-aligned chunks via `mprotect(..., PROT_READ | PROT_WRITE)`.
 *   3. Because the virtual base address never moves, pointers into the arena
 *      NEVER invalidate as the arena grows (unlike realloc-based growth!).
 *
 * When to Use Cl_Virtual_Arena:
 *   - Long-lived arenas whose final size is unknown ahead of time (ASTs,
 *     level geometry, graphs, dynamic parser trees, large signal buffers).
 *   - When pointer stability is required alongside O(1) arena allocation.
 * ============================================================================
 */

#ifndef CL_VIRTUAL_ARENA_H
#define CL_VIRTUAL_ARENA_H

#include "cl_alloc.h"

/* ----------------------------------------------------------------------------
 * Virtual Memory Growing Arena
 * ---------------------------------------------------------------------------- */

/*
 * Linux virtual-memory bump allocator descriptor backed by a contiguous
 * mmap reservation whose pages are committed on demand via mprotect().
 *
 * Fields:
 *   base         (cl_u8 *)  - Base virtual address of the mmap-reserved address range.
 *   reserved     (cl_isize) - Total reserved virtual address span in page-aligned bytes.
 *   committed    (cl_isize) - Currently committed read/write bytes from base (page-aligned bytes).
 *   commit_chunk (cl_isize) - Granularity in page-aligned bytes for each mprotect() commit step.
 *   page_size    (cl_isize) - Operating system memory page size in bytes (typically 4096 on Linux).
 *   offset       (cl_isize) - Current bump allocation offset from base in bytes.
 *   prev_offset  (cl_isize) - Byte offset of the most recent allocation (for in-place resize).
 *   peak_used    (cl_isize) - High-water mark of maximum offset reached in bytes.
 */
typedef struct Cl_Virtual_Arena {
    cl_u8   *base;          /* Start of mmap-reserved virtual address space */
    cl_isize reserved;      /* Total reserved virtual bytes (page-aligned) */
    cl_isize committed;     /* Currently committed readable/writable bytes */
    cl_isize commit_chunk;  /* Granularity of each mprotect commit step */
    cl_isize page_size;     /* OS page size (typically 4096 bytes on Linux) */
    cl_isize offset;        /* Current bump offset */
    cl_isize prev_offset;   /* Offset of most recent allocation */
    cl_isize peak_used;     /* High-water mark in bytes */
} Cl_Virtual_Arena;

/*
 * Saved bump-pointer checkpoint for O(1) LIFO rewind of a Cl_Virtual_Arena.
 *
 * Fields:
 *   arena             (Cl_Virtual_Arena *) - Target virtual arena captured at begin.
 *   saved_offset      (cl_isize)           - Arena offset in bytes at checkpoint creation.
 *   saved_prev_offset (cl_isize)           - Arena prev_offset in bytes at checkpoint creation.
 */
typedef struct Cl_VArena_Temp {
    Cl_Virtual_Arena *arena;
    cl_isize          saved_offset;
    cl_isize          saved_prev_offset;
} Cl_VArena_Temp;

/*
 * Reserves a contiguous virtual address range with mmap(..., PROT_NONE) without
 * committing physical pages; both sizes are rounded upward to the OS page size.
 *
 * Parameters:
 *   va           (Cl_Virtual_Arena *) - Virtual arena descriptor to initialize; must be non-NULL.
 *   reserve_size (cl_isize)           - Virtual address capacity in bytes (<= 0 defaults to 64 MiB).
 *   commit_chunk (cl_isize)           - Commit increment in bytes (<= 0 defaults to 64 KiB;
 *                                       clamped to reserve_size after page alignment).
 *
 * Returns:
 *   (bool) true if mmap succeeded and va is initialized; false if mmap failed.
 */
bool cl_varena_init(Cl_Virtual_Arena *va, cl_isize reserve_size, cl_isize commit_chunk);

/*
 * Unpoisons committed memory under ASan, releases the entire reserved virtual
 * range via munmap(), and zeroes the Cl_Virtual_Arena descriptor; safe no-op if NULL.
 *
 * Parameters:
 *   va (Cl_Virtual_Arena *) - Virtual arena to destroy (may be NULL).
 */
void cl_varena_destroy(Cl_Virtual_Arena *va);

/*
 * Resets the bump offset and prev_offset to 0 in O(1), invalidating all prior
 * pointers into va. Optionally decommits physical pages back to the OS via
 * madvise(MADV_DONTNEED) and mprotect(PROT_NONE) while keeping the reservation.
 *
 * Parameters:
 *   va             (Cl_Virtual_Arena *) - Virtual arena to reset (safe no-op if NULL or unmapped).
 *   decommit_pages (bool)               - If true, release committed physical pages and reset
 *                                         committed to 0; if false, keep pages committed and
 *                                         re-poison them under ASan (and scrub with 0xDD in debug).
 */
void cl_varena_reset(Cl_Virtual_Arena *va, bool decommit_pages);

/*
 * Returns a polymorphic Cl_Allocator view backed by this Cl_Virtual_Arena.
 *
 * Parameters:
 *   va (Cl_Virtual_Arena *) - Initialized virtual arena; must be non-NULL and outlive the handle.
 *
 * Returns:
 *   (Cl_Allocator) Allocator handle dispatching operations into va.
 */
Cl_Allocator cl_varena_allocator(Cl_Virtual_Arena *va);

/*
 * Captures the current bump offset and prev_offset of va for later O(1) rewind.
 *
 * Parameters:
 *   va (Cl_Virtual_Arena *) - Virtual arena to checkpoint; must be non-NULL.
 *
 * Returns:
 *   (Cl_VArena_Temp) Saved checkpoint handle to pass to cl_varena_temp_end().
 */
Cl_VArena_Temp cl_varena_temp_begin(Cl_Virtual_Arena *va);

/*
 * Rewinds a Cl_Virtual_Arena back to a saved checkpoint in O(1), scrubbing
 * rewound bytes with CL_MEM_POISON_FREED in debug builds and poisoning them under ASan.
 *
 * Parameters:
 *   temp (Cl_VArena_Temp) - Checkpoint from cl_varena_temp_begin()
 *                           (safe no-op if temp.arena is NULL; must unwind in LIFO order).
 */
void           cl_varena_temp_end(Cl_VArena_Temp temp);

/*
 * Queries the operating system virtual memory page size via sysconf(_SC_PAGESIZE).
 *
 * Returns:
 *   (cl_isize) OS page size in bytes (falls back to 4096 bytes if sysconf fails).
 */
cl_isize cl_os_page_size(void);

#endif /* CL_VIRTUAL_ARENA_H */
