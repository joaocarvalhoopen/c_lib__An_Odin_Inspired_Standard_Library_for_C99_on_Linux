/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_context.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Thread-local implicit Context system modeled directly after Odin's
 *   `context` (`base:runtime`), plus conflict-free dual scratch arenas for
 *   O(1) temporary allocations.
 *
 * Why This Matters:
 *   - Swap the active allocator (e.g., to a Tracking Allocator in tests or a
 *     Frame Arena in a render loop) for an entire call subtree with a single
 *     `cl_ctx_push` / `cl_ctx_pop` pair.
 *   - Swap the active logger (e.g., `cl_nil_logger()` in tests or a file
 *     logger in a background worker) cleanly per scope/thread.
 *   - Use `cl_ctx_temp_allocator()` / `cl_scratch_begin()` for short-lived
 *     allocations (C-string conversions, formatted messages, scratch arrays)
 *     and wipe them all in O(1) at frame/request end with `cl_ctx_temp_reset()`.
 * ============================================================================
 */

#ifndef CL_CONTEXT_H
#define CL_CONTEXT_H

#include "cl_alloc.h"
#include "cl_arena.h"
#include "cl_virtual_arena.h"
#include "cl_log.h"
#include "cl_assert.h"

/*
 * Maximum depth (32 frames) of the per-thread Cl_Context stack managed by
 * cl_ctx_push() and cl_ctx_pop().
 */
#define CL_CONTEXT_STACK_MAX 32

/* ----------------------------------------------------------------------------
 * Thread-Local Context Descriptor (Odin `runtime.Context`)
 * ---------------------------------------------------------------------------- */

/*
 * Thread-local implicit execution context holding the active allocator,
 * temporary scratch allocator, structured logger, assertion callback, and
 * user-defined context payload.
 *
 * Fields:
 *   allocator      (Cl_Allocator)   - Default general-purpose allocator for this scope.
 *   temp_allocator (Cl_Allocator)   - Short-lived scratch/temp allocator (default: TLS virtual arena 0).
 *   logger         (Cl_Logger)      - Active structured logger synchronized with cl_log.
 *   assert_proc    (Cl_Assert_Proc) - Active assertion/panic handler synchronized with cl_assert.
 *   user_ptr       (void *)         - Optional caller-defined context pointer.
 *   user_index     (cl_isize)       - Optional caller-defined context integer.
 */
typedef struct Cl_Context {
    Cl_Allocator   allocator;      /* Default general-purpose allocator */
    Cl_Allocator   temp_allocator; /* Thread-local scratch/temp allocator */
    Cl_Logger      logger;         /* Active structured logger */
    Cl_Assert_Proc assert_proc;    /* Active assertion/panic callback */
    void          *user_ptr;       /* User-defined context pointer */
    cl_isize       user_index;     /* User-defined context integer */
} Cl_Context;

/*
 * Constructs a fresh default Cl_Context initialized with cl_heap_allocator(),
 * the current thread's primary scratch virtual arena as temp_allocator, the
 * default console logger at CL_LOG_LEVEL_DEBUG, and cl_default_assert_proc.
 *
 * Returns:
 *   (Cl_Context) Newly populated default context value for the calling thread.
 */
Cl_Context cl_ctx_default(void);

/*
 * Returns a mutable pointer to the active (top-of-stack) Cl_Context on the
 * calling thread, lazily initializing the thread-local stack if needed.
 *
 * Returns:
 *   (Cl_Context *) Non-NULL pointer to the active thread-local Cl_Context.
 */
Cl_Context *cl_ctx_current(void);

/*
 * Pushes a new context frame onto the calling thread's context stack and
 * synchronizes the active logger and assert handler. Any zero/NULL fields
 * (allocator, temp_allocator, logger, assert_proc) inherit from the prior top.
 *
 * Parameters:
 *   ctx (Cl_Context) - Context frame to push; zeroed subsystem fields inherit from current context.
 *
 * Returns:
 *   (bool) true if pushed; false if the stack has reached CL_CONTEXT_STACK_MAX.
 */
bool cl_ctx_push(Cl_Context ctx);

/*
 * Pops the top context frame on the calling thread and restores the previous
 * frame's logger and assert callback. Safe no-op if only the root frame remains.
 */
void cl_ctx_pop(void);

/*
 * Returns the active default allocator from the calling thread's current context.
 *
 * Returns:
 *   (Cl_Allocator) Active general-purpose Cl_Allocator handle.
 */
Cl_Allocator cl_ctx_allocator(void);

/*
 * Returns the active temporary/scratch allocator from the calling thread's
 * current context.
 *
 * Returns:
 *   (Cl_Allocator) Active temporary Cl_Allocator handle.
 */
Cl_Allocator cl_ctx_temp_allocator(void);

/*
 * Returns the active structured logger from the calling thread's current context.
 *
 * Returns:
 *   (Cl_Logger) Active Cl_Logger handle.
 */
Cl_Logger    cl_ctx_logger(void);

/*
 * Resolves an optional caller-provided allocator: returns a if valid
 * (a.proc != NULL), otherwise falls back to cl_ctx_allocator().
 *
 * Parameters:
 *   a (Cl_Allocator) - Candidate allocator handle (may be zero-initialized).
 *
 * Returns:
 *   (Cl_Allocator) Valid allocator handle (either a or the thread's active context allocator).
 */
static inline Cl_Allocator cl_alloc_or_ctx(Cl_Allocator a) {
    return cl_allocator_is_valid(a) ? a : cl_ctx_allocator();
}

/*
 * Resets the calling thread's active temp_allocator in O(1) by invoking
 * cl_free_all() on cl_ctx_current()->temp_allocator.
 */
void cl_ctx_temp_reset(void);

/* ----------------------------------------------------------------------------
 * Conflict-Free Dual Scratch Arenas
 *
 * When a function allocates its return value into a caller-supplied allocator
 * `dst_alloc` AND also needs temporary scratch memory internally, passing
 * `&dst_alloc` as a conflict guarantees the returned scratch arena will NEVER
 * alias `dst_alloc`.
 * ---------------------------------------------------------------------------- */

/*
 * Scoped handle to a thread-local scratch virtual arena paired with its saved
 * rewind checkpoint.
 *
 * Fields:
 *   temp      (Cl_VArena_Temp) - Saved virtual-arena checkpoint restored by cl_scratch_end().
 *   allocator (Cl_Allocator)   - Allocator view backed by the selected scratch virtual arena.
 */
typedef struct Cl_Scratch {
    Cl_VArena_Temp temp;
    Cl_Allocator   allocator;
} Cl_Scratch;

/*
 * Acquires a thread-local scratch virtual arena (choosing between two 8 MiB
 * TLS virtual arenas) whose backing arena does not alias any allocator listed
 * in conflicts, and captures a rewind checkpoint.
 *
 * Parameters:
 *   conflicts      (const Cl_Allocator *) - Array of allocator handles to avoid aliasing
 *                                           (may be NULL when conflict_count == 0).
 *   conflict_count (cl_isize)             - Number of entries in conflicts (element count;
 *                                           at most 1 distinct scratch arena can be avoided
 *                                           since there are 2 TLS scratch arenas).
 *
 * Returns:
 *   (Cl_Scratch) Scratch handle pairing a checkpoint and conflict-free Cl_Allocator.
 */
Cl_Scratch cl_scratch_begin(const Cl_Allocator *conflicts, cl_isize conflict_count);

/*
 * Rewinds the scratch arena captured in scratch back to its saved checkpoint
 * in O(1) via cl_varena_temp_end().
 *
 * Parameters:
 *   scratch (Cl_Scratch) - Scratch handle previously returned by cl_scratch_begin().
 */
void cl_scratch_end(Cl_Scratch scratch);

/*
 * Releases the calling thread's two mmap-backed TLS scratch virtual arenas and
 * resets thread-local context initialization state (optional before thread exit).
 */
void cl_ctx_thread_shutdown(void);

#endif /* CL_CONTEXT_H */
