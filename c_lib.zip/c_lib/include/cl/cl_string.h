/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_string.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Complete Odin-style string manipulation and parsing suite (`core:strings`
 *   + `core:strconv`) built around `Cl_Str` (`{ const cl_u8 *data; cl_isize len; }`).
 *
 * Categories:
 *   1. Construction & C-String Conversions (`cl_str_from_cstr`, `cl_str_to_cstr`,
 *      `cl_str_to_cstr_temp`, `cl_str_to_cstr_buf`, `cl_str_clone`).
 *   2. Zero-Allocation Views & Queries (indexing, sub-slicing, eq/cmp,
 *      prefix/suffix/contains/index/count, `cl_str_cut`, trimming).
 *   3. Zero-Allocation Iterators (`split_iter`, `split_lines_iter`, `fields_iter`).
 *   4. Allocating Transformations (`split`, `join`, `concat`, `repeat`,
 *      `replace_all`, `replace_n`, `to_lower`, `to_upper`, `reverse_utf8`,
 *      `pad_left`, `pad_right`).
 *   5. Strict Value Parsing (`parse_i64`, `parse_u64`, `parse_f64`, `parse_bool`,
 *      `parse_c64`, `parse_c128`).
 * ============================================================================
 */

#ifndef CL_STRING_H
#define CL_STRING_H

#include "cl_types.h"
#include "cl_slice.h"
#include "cl_result.h"
#include "cl_alloc.h"
#include "cl_context.h"
#include "cl_utf8.h"
#include "cl_complex.h"

/*
 * Struct: Cl_CStr_Buf_Res
 * Purpose:
 *   Result descriptor returned by cl_str_to_cstr_buf when copying a Cl_Str
 *   into a caller-owned fixed-capacity char buffer.
 * Fields:
 *   written (cl_isize): Number of source bytes copied into the buffer,
 *     excluding the trailing NUL terminator (bytes, >= 0).
 *   truncated (bool): True if the buffer capacity (bytes, including NUL) was
 *     too small to hold the full string; false if all bytes fit.
 */
typedef struct Cl_CStr_Buf_Res {
    cl_isize written;   /* Number of bytes copied (excluding trailing NUL) */
    bool     truncated; /* True if buf_cap was too small for the full string */
} Cl_CStr_Buf_Res;

/* ----------------------------------------------------------------------------
 * 1. Construction & C-String Conversions
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_str_from_cstr
 * Purpose:
 *   Wraps a NUL-terminated C string in a non-owning Cl_Str view in O(n) time
 *   using strlen. Safe to call with NULL.
 * Parameters:
 *   cs (const char *): Pointer to a NUL-terminated C string, or NULL.
 * Returns:
 *   Cl_Str: Non-owning view referencing cs with len equal to strlen(cs) in
 *     bytes, or CL_STR_EMPTY if cs is NULL.
 */
Cl_Str cl_str_from_cstr(const char *cs);

/*
 * Function: cl_str_from_parts
 * Purpose:
 *   Wraps a raw byte pointer and explicit byte length in a non-owning Cl_Str
 *   view in O(1) time without scanning for NUL bytes.
 * Parameters:
 *   data (const void *): Pointer to the first byte of the buffer, or NULL.
 *   len (cl_isize): Length of the byte slice in bytes. Values <= 0 yield an
 *     empty view.
 * Returns:
 *   Cl_Str: Non-owning view { (const cl_u8 *)data, len }, or CL_STR_EMPTY if
 *     data is NULL or len <= 0.
 */
static inline Cl_Str cl_str_from_parts(const void *data, cl_isize len) {
    if (data == NULL || len <= 0) {
        return CL_STR_EMPTY;
    }
    return (Cl_Str){ (const cl_u8 *)data, len };
}

/*
 * Function: cl_str_to_cstr
 * Purpose:
 *   Allocates a NUL-terminated copy of s (s.len + 1 bytes) using the given
 *   allocator. Free the result with cl_cstr_free(cs, s.len, alloc).
 * Parameters:
 *   s (Cl_Str): Source byte slice (length in bytes).
 *   alloc (Cl_Allocator): Allocator to use; falls back to cl_ctx_allocator()
 *     when invalid/zero-initialized.
 * Returns:
 *   char *: Pointer to a newly allocated NUL-terminated string of s.len + 1
 *     bytes, or NULL on allocation failure.
 */
char *cl_str_to_cstr(Cl_Str s, Cl_Allocator alloc);

/*
 * Function: cl_str_to_cstr_temp
 * Purpose:
 *   Allocates a NUL-terminated copy of s in the current thread-local temporary
 *   allocator (cl_ctx_temp_allocator()).
 * Parameters:
 *   s (Cl_Str): Source byte slice (length in bytes).
 * Returns:
 *   char *: Pointer to a temp-allocated NUL-terminated C string of s.len + 1
 *     bytes, or NULL on allocation failure.
 */
char *cl_str_to_cstr_temp(Cl_Str s);

/*
 * Function: cl_str_to_cstr_buf
 * Purpose:
 *   Copies s into a caller-provided fixed char buffer with guaranteed NUL
 *   termination (whenever buf != NULL and buf_cap > 0), performing no heap
 *   allocations.
 * Parameters:
 *   s (Cl_Str): Source byte slice (length in bytes).
 *   buf (char *): Destination buffer, or NULL.
 *   buf_cap (cl_isize): Total capacity of buf in bytes, including space for
 *     the trailing NUL terminator.
 * Returns:
 *   Cl_CStr_Buf_Res: Struct with written (bytes copied, excluding NUL, <=
 *     buf_cap - 1) and truncated (true if s.len > buf_cap - 1 or buf is
 *     unusable while s.len > 0).
 */
Cl_CStr_Buf_Res cl_str_to_cstr_buf(Cl_Str s, char *buf, cl_isize buf_cap);

/*
 * Function: cl_str_clone
 * Purpose:
 *   Allocates an exact-length (s.len bytes, not NUL-terminated) copy of s
 *   using alloc. Free the result with cl_str_free(cloned, alloc).
 * Parameters:
 *   s (Cl_Str): Source byte slice (length in bytes).
 *   alloc (Cl_Allocator): Allocator to use; falls back to cl_ctx_allocator()
 *     when invalid/zero-initialized.
 * Returns:
 *   Cl_Str: Newly allocated byte slice of s.len bytes, or CL_STR_EMPTY if s
 *     is empty/NULL or allocation fails.
 */
Cl_Str cl_str_clone(Cl_Str s, Cl_Allocator alloc);

/*
 * Function: cl_str_clone_from_cstr
 * Purpose:
 *   Clones a NUL-terminated C string into a newly allocated Cl_Str of exact
 *   length strlen(cs) bytes (without a trailing NUL).
 * Parameters:
 *   cs (const char *): Source NUL-terminated C string, or NULL.
 *   alloc (Cl_Allocator): Allocator to use; falls back to cl_ctx_allocator()
 *     when invalid/zero-initialized.
 * Returns:
 *   Cl_Str: Newly allocated Cl_Str copy, or CL_STR_EMPTY if cs is NULL/empty
 *     or allocation fails.
 */
Cl_Str cl_str_clone_from_cstr(const char *cs, Cl_Allocator alloc);

/*
 * Function: cl_str_free
 * Purpose:
 *   Frees the backing buffer of a Cl_Str previously returned by cl_str_clone
 *   or another allocating string function. Safe no-op on empty/NULL strings.
 * Parameters:
 *   s (Cl_Str): Owned string slice whose s.len bytes will be released.
 *   alloc (Cl_Allocator): Same allocator used to allocate s (or zero-init for
 *     cl_ctx_allocator()).
 * Returns:
 *   void.
 */
void cl_str_free(Cl_Str s, Cl_Allocator alloc);

/*
 * Function: cl_cstr_free
 * Purpose:
 *   Frees a NUL-terminated C string previously returned by cl_str_to_cstr.
 *   Safe no-op if cs is NULL.
 * Parameters:
 *   cs (char *): Pointer to the allocated NUL-terminated C string, or NULL.
 *   str_len (cl_isize): Byte length of the string excluding NUL (>= 0), or a
 *     negative value to compute the length via strlen(cs). Total freed size
 *     is str_len + 1 bytes.
 *   alloc (Cl_Allocator): Same allocator used to allocate cs (or zero-init for
 *     cl_ctx_allocator()).
 * Returns:
 *   void.
 */
void cl_cstr_free(char *cs, cl_isize str_len, Cl_Allocator alloc);

/* ----------------------------------------------------------------------------
 * 2. Zero-Allocation Indexing, Slicing, Comparisons & Searches
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_str_at
 * Purpose:
 *   Returns the byte at a 0-based byte index with bounds checking via
 *   CL_BOUNDS_CHECK_INDEX.
 * Parameters:
 *   s (Cl_Str): Source byte slice (length in bytes).
 *   idx (cl_isize): 0-based byte offset; must satisfy 0 <= idx < s.len.
 * Returns:
 *   cl_u8: Raw byte value at s.data[idx].
 */
static inline cl_u8 cl_str_at(Cl_Str s, cl_isize idx) {
    cl_isize i = CL_BOUNDS_CHECK_INDEX(idx, s.len);
    return s.data[i];
}

/*
 * Function: cl_str_slice
 * Purpose:
 *   Creates a bounds-checked, zero-copy sub-string view covering the half-open
 *   byte range [lo, hi) of s.
 * Parameters:
 *   s (Cl_Str): Source byte slice (length in bytes).
 *   lo (cl_isize): Inclusive 0-based start byte offset; must satisfy
 *     0 <= lo <= hi <= s.len.
 *   hi (cl_isize): Exclusive 0-based end byte offset; must satisfy
 *     lo <= hi <= s.len.
 * Returns:
 *   Cl_Str: Zero-copy view of length (hi - lo) bytes, or CL_STR_EMPTY if
 *     lo == hi or s.data == NULL.
 */
static inline Cl_Str cl_str_slice(Cl_Str s, cl_isize lo, cl_isize hi) {
    CL_BOUNDS_CHECK_RANGE(lo, hi, s.len);
    if (lo == hi || s.data == NULL) {
        return CL_STR_EMPTY;
    }
    return (Cl_Str){ s.data + lo, hi - lo };
}

/*
 * Function: cl_str_eq
 * Purpose:
 *   Checks exact byte-for-byte equality between two Cl_Str views.
 * Parameters:
 *   a (Cl_Str): First byte slice.
 *   b (Cl_Str): Second byte slice.
 * Returns:
 *   bool: true if a.len == b.len and every byte matches; false otherwise.
 */
bool     cl_str_eq(Cl_Str a, Cl_Str b);

/*
 * Function: cl_str_eq_fold
 * Purpose:
 *   Checks ASCII case-insensitive equality between two Cl_Str views (folds
 *   'A'..'Z' to 'a'..'z'; non-ASCII bytes are compared verbatim).
 * Parameters:
 *   a (Cl_Str): First byte slice.
 *   b (Cl_Str): Second byte slice.
 * Returns:
 *   bool: true if a and b have equal byte lengths and match under ASCII
 *     case folding; false otherwise.
 */
bool     cl_str_eq_fold(Cl_Str a, Cl_Str b); /* ASCII case-insensitive equality */

/*
 * Function: cl_str_cmp
 * Purpose:
 *   Performs lexicographical unsigned-byte comparison between two Cl_Str views.
 * Parameters:
 *   a (Cl_Str): First byte slice.
 *   b (Cl_Str): Second byte slice.
 * Returns:
 *   int: -1 if a < b, 0 if a == b, or +1 if a > b.
 */
int      cl_str_cmp(Cl_Str a, Cl_Str b);     /* Lexicographical compare (-1, 0, +1) */

/*
 * Function: cl_str_has_prefix
 * Purpose:
 *   Tests whether s starts with the exact byte sequence prefix.
 * Parameters:
 *   s (Cl_Str): Haystack string slice.
 *   prefix (Cl_Str): Prefix byte sequence to test (empty prefix always matches).
 * Returns:
 *   bool: true if prefix.len <= 0 or s begins with prefix; false otherwise.
 */
bool     cl_str_has_prefix(Cl_Str s, Cl_Str prefix);

/*
 * Function: cl_str_has_suffix
 * Purpose:
 *   Tests whether s ends with the exact byte sequence suffix.
 * Parameters:
 *   s (Cl_Str): Haystack string slice.
 *   suffix (Cl_Str): Suffix byte sequence to test (empty suffix always matches).
 * Returns:
 *   bool: true if suffix.len <= 0 or s ends with suffix; false otherwise.
 */
bool     cl_str_has_suffix(Cl_Str s, Cl_Str suffix);

/*
 * Function: cl_str_contains
 * Purpose:
 *   Tests whether substr occurs anywhere within s.
 * Parameters:
 *   s (Cl_Str): Haystack string slice.
 *   substr (Cl_Str): Needle byte sequence to search for.
 * Returns:
 *   bool: true if substr is found in s (always true for empty substr);
 *     false otherwise.
 */
bool     cl_str_contains(Cl_Str s, Cl_Str substr);

/*
 * Function: cl_str_contains_any
 * Purpose:
 *   Tests whether s contains at least one byte that appears in chars.
 * Parameters:
 *   s (Cl_Str): Haystack string slice.
 *   chars (Cl_Str): Set of target byte values to look for.
 * Returns:
 *   bool: true if any byte of s is present in chars; false if none match or
 *     either slice is empty.
 */
bool     cl_str_contains_any(Cl_Str s, Cl_Str chars);

/*
 * Function: cl_str_index
 * Purpose:
 *   Finds the first occurrence of substr in s.
 * Parameters:
 *   s (Cl_Str): Haystack string slice (length in bytes).
 *   substr (Cl_Str): Needle byte slice (length in bytes).
 * Returns:
 *   cl_isize: 0-based byte offset in [0, s.len) of the first match, 0 if
 *     substr is empty, or -1 if not found.
 */
cl_isize cl_str_index(Cl_Str s, Cl_Str substr);

/*
 * Function: cl_str_last_index
 * Purpose:
 *   Finds the last occurrence of substr in s.
 * Parameters:
 *   s (Cl_Str): Haystack string slice (length in bytes).
 *   substr (Cl_Str): Needle byte slice (length in bytes).
 * Returns:
 *   cl_isize: 0-based byte offset in [0, s.len) of the last match, s.len if
 *     substr is empty, or -1 if not found.
 */
cl_isize cl_str_last_index(Cl_Str s, Cl_Str substr);

/*
 * Function: cl_str_index_byte
 * Purpose:
 *   Finds the first occurrence of a single byte value in s.
 * Parameters:
 *   s (Cl_Str): Haystack string slice (length in bytes).
 *   byte_val (cl_u8): Target byte value to search for.
 * Returns:
 *   cl_isize: 0-based byte offset in [0, s.len) of the first match, or -1 if
 *     byte_val does not occur in s.
 */
cl_isize cl_str_index_byte(Cl_Str s, cl_u8 byte_val);

/*
 * Function: cl_str_last_index_byte
 * Purpose:
 *   Finds the last occurrence of a single byte value in s.
 * Parameters:
 *   s (Cl_Str): Haystack string slice (length in bytes).
 *   byte_val (cl_u8): Target byte value to search for.
 * Returns:
 *   cl_isize: 0-based byte offset in [0, s.len) of the last match, or -1 if
 *     byte_val does not occur in s.
 */
cl_isize cl_str_last_index_byte(Cl_Str s, cl_u8 byte_val);

/*
 * Function: cl_str_index_any
 * Purpose:
 *   Finds the first byte in s that matches any byte in chars.
 * Parameters:
 *   s (Cl_Str): Haystack string slice (length in bytes).
 *   chars (Cl_Str): Set of bytes to match against.
 * Returns:
 *   cl_isize: 0-based byte offset in [0, s.len) of the first matching byte,
 *     or -1 if no byte in chars appears in s.
 */
cl_isize cl_str_index_any(Cl_Str s, Cl_Str chars);

/*
 * Function: cl_str_count
 * Purpose:
 *   Counts the number of non-overlapping occurrences of substr in s.
 * Parameters:
 *   s (Cl_Str): Haystack string slice (length in bytes).
 *   substr (Cl_Str): Substring to count (if empty, returns s.len + 1).
 * Returns:
 *   cl_isize: Count of non-overlapping occurrences (>= 0).
 */
cl_isize cl_str_count(Cl_Str s, Cl_Str substr);

/*
 * Function: cl_str_cut
 * Purpose:
 *   Splits s around the first occurrence of sep into zero-copy views
 *   { before, after, found } (modeled after Odin's strings.cut).
 * Parameters:
 *   s (Cl_Str): Input byte slice to split.
 *   sep (Cl_Str): Separator byte sequence.
 * Returns:
 *   Cl_Str_Cut: Struct { before (Cl_Str), after (Cl_Str), found (bool) }.
 *     When sep is found, before and after exclude sep and found is true.
 *     When sep is not found, returns { s, CL_STR_EMPTY, false }.
 */
Cl_Str_Cut cl_str_cut(Cl_Str s, Cl_Str sep);

/*
 * Function: cl_str_trim_left_space
 * Purpose:
 *   Returns a zero-copy view of s with leading ASCII whitespace bytes
 *   (' ', '\t', '\n', '\r', '\v', '\f') removed.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 * Returns:
 *   Cl_Str: Sub-view of s without leading ASCII whitespace, or CL_STR_EMPTY.
 */
Cl_Str cl_str_trim_left_space(Cl_Str s);

/*
 * Function: cl_str_trim_right_space
 * Purpose:
 *   Returns a zero-copy view of s with trailing ASCII whitespace bytes
 *   (' ', '\t', '\n', '\r', '\v', '\f') removed.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 * Returns:
 *   Cl_Str: Sub-view of s without trailing ASCII whitespace, or CL_STR_EMPTY.
 */
Cl_Str cl_str_trim_right_space(Cl_Str s);

/*
 * Function: cl_str_trim_space
 * Purpose:
 *   Returns a zero-copy view of s with both leading and trailing ASCII
 *   whitespace bytes removed.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 * Returns:
 *   Cl_Str: Trimmed sub-view of s, or CL_STR_EMPTY.
 */
Cl_Str cl_str_trim_space(Cl_Str s);

/*
 * Function: cl_str_trim_left_cutset
 * Purpose:
 *   Returns a zero-copy view of s with all leading bytes contained in cutset
 *   removed.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 *   cutset (Cl_Str): Set of byte values to strip from the start of s.
 * Returns:
 *   Cl_Str: Trimmed sub-view of s, or CL_STR_EMPTY.
 */
Cl_Str cl_str_trim_left_cutset(Cl_Str s, Cl_Str cutset);

/*
 * Function: cl_str_trim_right_cutset
 * Purpose:
 *   Returns a zero-copy view of s with all trailing bytes contained in cutset
 *   removed.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 *   cutset (Cl_Str): Set of byte values to strip from the end of s.
 * Returns:
 *   Cl_Str: Trimmed sub-view of s, or CL_STR_EMPTY.
 */
Cl_Str cl_str_trim_right_cutset(Cl_Str s, Cl_Str cutset);

/*
 * Function: cl_str_trim_cutset
 * Purpose:
 *   Returns a zero-copy view of s with all leading and trailing bytes
 *   contained in cutset removed.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 *   cutset (Cl_Str): Set of byte values to strip from both ends of s.
 * Returns:
 *   Cl_Str: Trimmed sub-view of s, or CL_STR_EMPTY.
 */
Cl_Str cl_str_trim_cutset(Cl_Str s, Cl_Str cutset);

/*
 * Function: cl_str_trim_prefix
 * Purpose:
 *   Returns a zero-copy view of s with a single leading occurrence of prefix
 *   removed if present; otherwise returns s unchanged.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 *   prefix (Cl_Str): Prefix byte sequence to remove once.
 * Returns:
 *   Cl_Str: Sub-view of s starting at byte offset prefix.len if s starts with
 *     prefix, or s unchanged otherwise.
 */
Cl_Str cl_str_trim_prefix(Cl_Str s, Cl_Str prefix);

/*
 * Function: cl_str_trim_suffix
 * Purpose:
 *   Returns a zero-copy view of s with a single trailing occurrence of suffix
 *   removed if present; otherwise returns s unchanged.
 * Parameters:
 *   s (Cl_Str): Input byte slice.
 *   suffix (Cl_Str): Suffix byte sequence to remove once.
 * Returns:
 *   Cl_Str: Sub-view of s of length (s.len - suffix.len) bytes if s ends with
 *     suffix, or s unchanged otherwise.
 */
Cl_Str cl_str_trim_suffix(Cl_Str s, Cl_Str suffix);

/* ----------------------------------------------------------------------------
 * 3. Zero-Allocation Split Iterators (Odin `split_iterator` Family)
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_str_split_iter
 * Purpose:
 *   Zero-allocation stateful iterator that yields the next sep-delimited
 *   sub-view from *rest and advances *rest past the separator. When sep is
 *   empty, yields 1 byte per call until exhausted.
 * Parameters:
 *   rest (Cl_Str *): In/out cursor pointing to the unconsumed remainder of
 *     the string; set to CL_STR_EMPTY once exhausted. Safe if NULL.
 *   sep (Cl_Str): Delimiter byte sequence.
 * Returns:
 *   Cl_Opt_Str: CL_SOME(piece) with the next zero-copy segment, or CL_NONE
 *     when no segments remain (or rest is NULL/exhausted).
 */
Cl_Opt_Str cl_str_split_iter(Cl_Str *rest, Cl_Str sep);

/*
 * Function: cl_str_split_lines_iter
 * Purpose:
 *   Zero-allocation stateful iterator that yields the next line from *rest,
 *   recognizing both '\n' and '\r\n' line endings and stripping them from the
 *   returned view.
 * Parameters:
 *   rest (Cl_Str *): In/out cursor pointing to the remaining unconsumed bytes;
 *     updated in place on each call. Safe if NULL.
 * Returns:
 *   Cl_Opt_Str: CL_SOME(line) with the next line view without line endings,
 *     or CL_NONE when *rest is empty or NULL.
 */
Cl_Opt_Str cl_str_split_lines_iter(Cl_Str *rest);

/*
 * Function: cl_str_fields_iter
 * Purpose:
 *   Zero-allocation stateful iterator that skips leading ASCII whitespace and
 *   yields the next maximal non-whitespace token from *rest.
 * Parameters:
 *   rest (Cl_Str *): In/out cursor pointing to the remaining unconsumed bytes;
 *     updated in place on each call. Safe if NULL.
 * Returns:
 *   Cl_Opt_Str: CL_SOME(token) for the next non-empty whitespace-delimited
 *     token, or CL_NONE when no tokens remain or rest is NULL.
 */
Cl_Opt_Str cl_str_fields_iter(Cl_Str *rest);

/* ----------------------------------------------------------------------------
 * 4. Allocating String Transformations (Explicit Cl_Allocator)
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_str_split
 * Purpose:
 *   Splits s by sep into a newly allocated slice of zero-copy Cl_Str views
 *   pointing into s. Free the returned slice with CL_SLICE_FREE(alloc, out).
 * Parameters:
 *   s (Cl_Str): Input byte slice to split (must outlive the returned views).
 *   sep (Cl_Str): Delimiter byte sequence.
 *   alloc (Cl_Allocator): Allocator for the slice array; defaults to
 *     cl_ctx_allocator() when invalid.
 * Returns:
 *   Cl_Slice_Str: Allocated slice of Cl_Str views (exact length == allocated
 *     element count), or an empty slice if s has no parts or allocation fails.
 */
Cl_Slice_Str cl_str_split(Cl_Str s, Cl_Str sep, Cl_Allocator alloc);

/*
 * Function: cl_str_split_lines
 * Purpose:
 *   Splits s into lines (handling '\n' and '\r\n', stripping line endings) and
 *   returns a newly allocated slice of zero-copy Cl_Str views into s.
 * Parameters:
 *   s (Cl_Str): Input byte slice (must outlive the returned views).
 *   alloc (Cl_Allocator): Allocator for the slice array; defaults to
 *     cl_ctx_allocator() when invalid.
 * Returns:
 *   Cl_Slice_Str: Allocated slice of line views, or an empty slice if s is
 *     empty or allocation fails.
 */
Cl_Slice_Str cl_str_split_lines(Cl_Str s, Cl_Allocator alloc);

/*
 * Function: cl_str_fields
 * Purpose:
 *   Splits s on runs of ASCII whitespace into a newly allocated slice of
 *   non-empty zero-copy Cl_Str token views into s.
 * Parameters:
 *   s (Cl_Str): Input byte slice (must outlive the returned views).
 *   alloc (Cl_Allocator): Allocator for the slice array; defaults to
 *     cl_ctx_allocator() when invalid.
 * Returns:
 *   Cl_Slice_Str: Allocated slice of token views, or an empty slice if s
 *     contains only whitespace or allocation fails.
 */
Cl_Slice_Str cl_str_fields(Cl_Str s, Cl_Allocator alloc);

/*
 * Function: cl_str_join
 * Purpose:
 *   Concatenates all elements of parts with sep inserted between adjacent
 *   elements into a newly allocated Cl_Str.
 * Parameters:
 *   parts (Cl_Slice_Str): Slice of Cl_Str elements to join.
 *   sep (Cl_Str): Separator byte sequence inserted between adjacent parts.
 *   alloc (Cl_Allocator): Allocator for the output bytes; defaults to
 *     cl_ctx_allocator() when invalid.
 * Returns:
 *   Cl_Str: Newly allocated joined string (free with cl_str_free), or
 *     CL_STR_EMPTY if total byte length is 0 or allocation fails.
 */
Cl_Str cl_str_join(Cl_Slice_Str parts, Cl_Str sep, Cl_Allocator alloc);

/*
 * Function: cl_str_concat
 * Purpose:
 *   Concatenates all elements of parts back-to-back (without any separator)
 *   into a newly allocated Cl_Str.
 * Parameters:
 *   parts (Cl_Slice_Str): Slice of Cl_Str elements to concatenate.
 *   alloc (Cl_Allocator): Allocator for the output bytes; defaults to
 *     cl_ctx_allocator() when invalid.
 * Returns:
 *   Cl_Str: Newly allocated concatenated string (free with cl_str_free), or
 *     CL_STR_EMPTY if total byte length is 0 or allocation fails.
 */
Cl_Str cl_str_concat(Cl_Slice_Str parts, Cl_Allocator alloc);

/*
 * Function: cl_str_repeat
 * Purpose:
 *   Allocates a new Cl_Str consisting of s repeated count times, checking for
 *   signed byte-length overflow before allocating.
 * Parameters:
 *   s (Cl_Str): Pattern byte slice to repeat.
 *   count (cl_isize): Number of repetitions (count <= 0 yields CL_STR_EMPTY).
 *   alloc (Cl_Allocator): Allocator for the output bytes; defaults to
 *     cl_ctx_allocator() when invalid.
 * Returns:
 *   Cl_Str: Newly allocated string of s.len * count bytes, or CL_STR_EMPTY on
 *     empty input, non-positive count, overflow, or allocation failure.
 */
Cl_Str cl_str_repeat(Cl_Str s, cl_isize count, Cl_Allocator alloc);

/*
 * Function: cl_str_replace_n
 * Purpose:
 *   Returns a newly allocated copy of s with up to max_n non-overlapping
 *   occurrences of old_s replaced by new_s.
 * Parameters:
 *   s (Cl_Str): Source byte slice.
 *   old_s (Cl_Str): Substring to search for (if empty, returns a clone of s).
 *   new_s (Cl_Str): Replacement byte sequence (may be empty to delete matches).
 *   max_n (cl_isize): Maximum number of replacements to perform; pass < 0 to
 *     replace all occurrences, or 0 to return an unmodified clone of s.
 *   alloc (Cl_Allocator): Allocator for the output bytes; defaults to
 *     cl_ctx_allocator() when invalid.
 * Returns:
 *   Cl_Str: Newly allocated resulting string (free with cl_str_free), or
 *     CL_STR_EMPTY if the resulting length is 0 or allocation fails.
 */
Cl_Str cl_str_replace_n(Cl_Str s, Cl_Str old_s, Cl_Str new_s, cl_isize max_n, Cl_Allocator alloc);

/*
 * Function: cl_str_replace_all
 * Purpose:
 *   Returns a newly allocated copy of s with every non-overlapping occurrence
 *   of old_s replaced by new_s.
 * Parameters:
 *   s (Cl_Str): Source byte slice.
 *   old_s (Cl_Str): Substring to replace.
 *   new_s (Cl_Str): Replacement byte sequence.
 *   alloc (Cl_Allocator): Allocator for the output bytes; defaults to
 *     cl_ctx_allocator() when invalid.
 * Returns:
 *   Cl_Str: Newly allocated resulting string (free with cl_str_free), or
 *     CL_STR_EMPTY if the result is empty or allocation fails.
 */
Cl_Str cl_str_replace_all(Cl_Str s, Cl_Str old_s, Cl_Str new_s, Cl_Allocator alloc);

/*
 * Function: cl_str_to_lower
 * Purpose:
 *   Returns a newly allocated copy of s with ASCII uppercase bytes ('A'..'Z')
 *   converted to lowercase ('a'..'z'); other bytes are copied unchanged.
 * Parameters:
 *   s (Cl_Str): Source byte slice.
 *   alloc (Cl_Allocator): Allocator for the output bytes; defaults to
 *     cl_ctx_allocator() when invalid.
 * Returns:
 *   Cl_Str: Newly allocated lowercased string of s.len bytes, or CL_STR_EMPTY
 *     if s is empty or allocation fails.
 */
Cl_Str cl_str_to_lower(Cl_Str s, Cl_Allocator alloc);

/*
 * Function: cl_str_to_upper
 * Purpose:
 *   Returns a newly allocated copy of s with ASCII lowercase bytes ('a'..'z')
 *   converted to uppercase ('A'..'Z'); other bytes are copied unchanged.
 * Parameters:
 *   s (Cl_Str): Source byte slice.
 *   alloc (Cl_Allocator): Allocator for the output bytes; defaults to
 *     cl_ctx_allocator() when invalid.
 * Returns:
 *   Cl_Str: Newly allocated uppercased string of s.len bytes, or CL_STR_EMPTY
 *     if s is empty or allocation fails.
 */
Cl_Str cl_str_to_upper(Cl_Str s, Cl_Allocator alloc);

/*
 * Function: cl_str_reverse_utf8
 * Purpose:
 *   Returns a newly allocated copy of s with its UTF-8 runes reversed in order
 *   while preserving the internal byte order of each multi-byte rune.
 * Parameters:
 *   s (Cl_Str): Source UTF-8 byte slice.
 *   alloc (Cl_Allocator): Allocator for the output bytes; defaults to
 *     cl_ctx_allocator() when invalid.
 * Returns:
 *   Cl_Str: Newly allocated rune-reversed string of s.len bytes, or
 *     CL_STR_EMPTY if s is empty or allocation fails.
 */
Cl_Str cl_str_reverse_utf8(Cl_Str s, Cl_Allocator alloc);

/*
 * Function: cl_str_pad_left
 * Purpose:
 *   Returns a newly allocated copy of s left-padded with pad_byte up to
 *   target_len bytes. If target_len <= s.len, returns a clone of s.
 * Parameters:
 *   s (Cl_Str): Source byte slice.
 *   target_len (cl_isize): Desired total length in bytes.
 *   pad_byte (cl_u8): Byte value used to fill the leading padding.
 *   alloc (Cl_Allocator): Allocator for the output bytes; defaults to
 *     cl_ctx_allocator() when invalid.
 * Returns:
 *   Cl_Str: Newly allocated string of max(s.len, target_len) bytes, or
 *     CL_STR_EMPTY if empty or allocation fails.
 */
Cl_Str cl_str_pad_left(Cl_Str s, cl_isize target_len, cl_u8 pad_byte, Cl_Allocator alloc);

/*
 * Function: cl_str_pad_right
 * Purpose:
 *   Returns a newly allocated copy of s right-padded with pad_byte up to
 *   target_len bytes. If target_len <= s.len, returns a clone of s.
 * Parameters:
 *   s (Cl_Str): Source byte slice.
 *   target_len (cl_isize): Desired total length in bytes.
 *   pad_byte (cl_u8): Byte value used to fill the trailing padding.
 *   alloc (Cl_Allocator): Allocator for the output bytes; defaults to
 *     cl_ctx_allocator() when invalid.
 * Returns:
 *   Cl_Str: Newly allocated string of max(s.len, target_len) bytes, or
 *     CL_STR_EMPTY if empty or allocation fails.
 */
Cl_Str cl_str_pad_right(Cl_Str s, cl_isize target_len, cl_u8 pad_byte, Cl_Allocator alloc);

/* ----------------------------------------------------------------------------
 * 5. Strict Value Parsing (Odin `core:strconv`)
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_str_parse_i64
 * Purpose:
 *   Strictly parses a signed 64-bit integer from s after trimming surrounding
 *   ASCII whitespace. Supports optional '+'/'-' sign, Odin-style '_' digit
 *   separators, and rejects invalid characters or signed 64-bit overflow.
 * Parameters:
 *   s (Cl_Str): Input text slice.
 *   base (int): Radix in [2, 36], or 0 to auto-detect prefix (0x/0X hex,
 *     0b/0B binary, 0o/0O octal, otherwise base 10).
 * Returns:
 *   Cl_Opt_I64: CL_SOME(value) on valid parse, or CL_NONE on invalid syntax,
 *     unsupported base, or overflow outside [INT64_MIN, INT64_MAX].
 */
CL_NODISCARD Cl_Opt_I64  cl_str_parse_i64(Cl_Str s, int base);

/*
 * Function: cl_str_parse_u64
 * Purpose:
 *   Strictly parses an unsigned 64-bit integer from s after trimming
 *   surrounding ASCII whitespace. Supports optional leading '+' (rejects '-'),
 *   Odin-style '_' digit separators, and rejects invalid characters or
 *   unsigned 64-bit overflow.
 * Parameters:
 *   s (Cl_Str): Input text slice.
 *   base (int): Radix in [2, 36], or 0 to auto-detect prefix (0x/0X hex,
 *     0b/0B binary, 0o/0O octal, otherwise base 10).
 * Returns:
 *   Cl_Opt_U64: CL_SOME(value) on valid parse, or CL_NONE on invalid syntax,
 *     negative sign, unsupported base, or overflow above UINT64_MAX.
 */
CL_NODISCARD Cl_Opt_U64  cl_str_parse_u64(Cl_Str s, int base);

/*
 * Function: cl_str_parse_f64
 * Purpose:
 *   Strictly parses an IEEE-754 64-bit floating-point number from s after
 *   trimming surrounding ASCII whitespace. Rejects trailing non-numeric
 *   characters, ERANGE overflow/underflow, and trimmed inputs >= 128 bytes.
 * Parameters:
 *   s (Cl_Str): Input text slice (trimmed length must be in [1, 127] bytes).
 * Returns:
 *   Cl_Opt_F64: CL_SOME(value) on valid parse, or CL_NONE on failure.
 */
CL_NODISCARD Cl_Opt_F64  cl_str_parse_f64(Cl_Str s);

/*
 * Function: cl_str_parse_bool
 * Purpose:
 *   Strictly parses a boolean token from s after trimming surrounding ASCII
 *   whitespace. Accepts "true", "1", "yes" (true) and "false", "0", "no"
 *   (false) case-insensitively.
 * Parameters:
 *   s (Cl_Str): Input text slice.
 * Returns:
 *   Cl_Opt_Bool: CL_SOME(true/false) on recognized token, or CL_NONE otherwise.
 */
CL_NODISCARD Cl_Opt_Bool cl_str_parse_bool(Cl_Str s);

/*
 * Function: cl_str_parse_c64
 * Purpose:
 *   Strictly parses a single-precision complex number (cl_c64) from plain text
 *   in formats such as "3+4i", "3 - 4i", "-2.5+0.5j", "4.2", "-7i", "i",
 *   "-i", or "(3.0, -4.0)".
 * Parameters:
 *   s (Cl_Str): Input text slice.
 * Returns:
 *   Cl_Opt_C64: CL_SOME(value) converted to cl_c64 on success, or CL_NONE if
 *     parsing fails.
 */
CL_NODISCARD Cl_Opt_C64  cl_str_parse_c64(Cl_Str s);

/*
 * Function: cl_str_parse_c128
 * Purpose:
 *   Strictly parses a double-precision complex number (cl_c128) from plain
 *   text in formats such as "3+4i", "3 - 4i", "-2.5+0.5j", "4.2", "-7i", "i",
 *   "-i", or "(3.0, -4.0)" (compact form without spaces must be < 160 bytes).
 * Parameters:
 *   s (Cl_Str): Input text slice.
 * Returns:
 *   Cl_Opt_C128: CL_SOME(value) on valid complex parse, or CL_NONE on failure.
 */
CL_NODISCARD Cl_Opt_C128 cl_str_parse_c128(Cl_Str s);

#endif /* CL_STRING_H */
