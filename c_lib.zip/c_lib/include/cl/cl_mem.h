/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_mem.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Low-level memory primitives: alignment calculations, integer overflow
 *   checks, UBSan-safe zero-length-guarded memory copy/move/set/compare,
 *   safe NUL-terminated C-string copy helpers, and AddressSanitizer manual
 *   memory poisoning hooks for custom allocators (arenas and pools).
 * ============================================================================
 */

#ifndef CL_MEM_H
#define CL_MEM_H

#include "cl_types.h"
#include "cl_assert.h"

#if CL_ASAN_ENABLED
    #include <sanitizer/asan_interface.h>

    /*
     * Marks a memory region as poisoned (inaccessible) under AddressSanitizer
     * so reads or writes to unused/freed custom-allocator memory trigger an error.
     *
     * Parameters:
     *   addr (const void *) - Start address of the region to poison.
     *   size (cl_usize)     - Region length in bytes.
     */
    #define CL_ASAN_POISON(addr, size)   ASAN_POISON_MEMORY_REGION((addr), (size))

    /*
     * Marks a previously poisoned memory region as addressable again under
     * AddressSanitizer before custom-allocator memory is handed to a caller.
     *
     * Parameters:
     *   addr (const void *) - Start address of the region to unpoison.
     *   size (cl_usize)     - Region length in bytes.
     */
    #define CL_ASAN_UNPOISON(addr, size) ASAN_UNPOISON_MEMORY_REGION((addr), (size))
#else
    /*
     * No-op fallback for CL_ASAN_POISON when AddressSanitizer is disabled.
     *
     * Parameters:
     *   addr (const void *) - Ignored start address of the memory region.
     *   size (cl_usize)     - Ignored region length in bytes.
     */
    #define CL_ASAN_POISON(addr, size)   ((void)(addr), (void)(size))

    /*
     * No-op fallback for CL_ASAN_UNPOISON when AddressSanitizer is disabled.
     *
     * Parameters:
     *   addr (const void *) - Ignored start address of the memory region.
     *   size (cl_usize)     - Ignored region length in bytes.
     */
    #define CL_ASAN_UNPOISON(addr, size) ((void)(addr), (void)(size))
#endif

/*
 * Debug poison byte pattern (unsigned int / cl_u8, value 0xCD) written into
 * newly allocated non-zeroed memory regions to expose reads of uninitialized data.
 */
#define CL_MEM_POISON_ALLOC_UNINIT 0xCDu

/*
 * Debug poison byte pattern (unsigned int / cl_u8, value 0xDD) written over
 * freed or rewound memory regions to expose use-after-free bugs.
 */
#define CL_MEM_POISON_FREED        0xDDu

/*
 * Guard redzone byte pattern (unsigned int / cl_u8, value 0xFD) painted before
 * and after tracked allocations to detect buffer underflows and overflows.
 */
#define CL_MEM_POISON_REDZONE      0xFDu

/* ----------------------------------------------------------------------------
 * Alignment & Overflow Helpers
 * ---------------------------------------------------------------------------- */

/*
 * Tests whether a signed integer is a strictly positive power of two using
 * the bitmask identity (x > 0) && ((x & (x - 1)) == 0).
 *
 * Parameters:
 *   x (cl_isize) - Value to test (typically an alignment in bytes).
 *
 * Returns:
 *   (bool) true if x > 0 and x is a power of two (1, 2, 4, 8, ...); false otherwise.
 */
static inline bool cl_is_power_of_two(cl_isize x) {
    return (x > 0) && ((x & (x - 1)) == 0);
}

/*
 * Rounds an unsigned address or byte offset upward to the next multiple of
 * a power-of-two alignment via (addr + (align - 1)) & ~(align - 1).
 *
 * Parameters:
 *   addr  (cl_uintptr) - Virtual address or byte offset to align (bytes).
 *   align (cl_isize)   - Alignment boundary in bytes; must be > 0 and a power of two.
 *
 * Returns:
 *   (cl_uintptr) Aligned address or offset in bytes (>= addr unless wrapping).
 */
static inline cl_uintptr cl_align_forward_uintptr(cl_uintptr addr, cl_isize align) {
    CL_ASSERT(cl_is_power_of_two(align));
    cl_uintptr a = (cl_uintptr)align;
    return (addr + (a - 1u)) & ~(a - 1u);
}

/*
 * Rounds a non-negative signed byte size or offset upward to the next multiple
 * of a power-of-two alignment via (size + (align - 1)) & ~(align - 1).
 *
 * Parameters:
 *   size  (cl_isize) - Byte size or offset to align; must be >= 0.
 *   align (cl_isize) - Alignment boundary in bytes; must be > 0 and a power of two.
 *
 * Returns:
 *   (cl_isize) Aligned size or offset in bytes (>= size).
 */
static inline cl_isize cl_align_forward_isize(cl_isize size, cl_isize align) {
    CL_ASSERT(size >= 0 && cl_is_power_of_two(align));
    cl_usize s = (cl_usize)size;
    cl_usize a = (cl_usize)align;
    return (cl_isize)((s + (a - 1u)) & ~(a - 1u));
}

/*
 * Computes the number of padding bytes needed so that (addr + padding) is
 * aligned to the next multiple of align.
 *
 * Parameters:
 *   addr  (cl_uintptr) - Virtual address or byte offset to pad (bytes).
 *   align (cl_isize)   - Alignment boundary in bytes; must be > 0 and a power of two.
 *
 * Returns:
 *   (cl_isize) Padding length in bytes, in the range [0, align - 1].
 */
static inline cl_isize cl_align_padding(cl_uintptr addr, cl_isize align) {
    CL_ASSERT(cl_is_power_of_two(align));
    cl_uintptr aligned = cl_align_forward_uintptr(addr, align);
    return (cl_isize)(aligned - addr);
}

/*
 * Performs checked multiplication of two non-negative signed sizes (a * b),
 * detecting negative inputs or signed PTRDIFF_MAX overflow before multiplying.
 *
 * Parameters:
 *   a   (cl_isize)   - First factor (e.g., element count); must be >= 0.
 *   b   (cl_isize)   - Second factor (e.g., element size in bytes); must be >= 0.
 *   out (cl_isize *) - Output pointer receiving (a * b) on success; must be non-NULL
 *                      when a >= 0 and b >= 0 and no overflow occurs.
 *
 * Returns:
 *   (bool) true if a < 0, b < 0, or a * b > PTRDIFF_MAX (overflow, *out unchanged);
 *          false on success (*out set to a * b).
 */
static inline bool cl_mul_overflow_isize(cl_isize a, cl_isize b, cl_isize *out) {
    if (a < 0 || b < 0) {
        return true;
    }
    if (a == 0 || b == 0) {
        *out = 0;
        return false;
    }
    if (a > (PTRDIFF_MAX / b)) {
        return true;
    }
    *out = a * b;
    return false;
}

/* ----------------------------------------------------------------------------
 * UBSan-Safe Memory Operations
 *
 * In C99/UBSan, passing NULL with length 0 to memcpy/memmove/memset/memcmp
 * is undefined behavior. These wrappers guard `size <= 0` so empty slices
 * and zero-initialized containers never trigger UB.
 * ---------------------------------------------------------------------------- */

/*
 * Zero-initializes a memory region, safely acting as a no-op if dst is NULL
 * or size <= 0.
 *
 * Parameters:
 *   dst  (void *)   - Destination buffer pointer (may be NULL).
 *   size (cl_isize) - Number of bytes to set to 0x00 (bytes; <= 0 is a no-op).
 */
void   cl_mem_zero(void *dst, cl_isize size);

/*
 * Fills a memory region with a repeated byte value, safely acting as a no-op
 * if dst is NULL or size <= 0.
 *
 * Parameters:
 *   dst      (void *)   - Destination buffer pointer (may be NULL).
 *   byte_val (cl_u8)    - Fill byte value in the range 0x00..0xFF.
 *   size     (cl_isize) - Number of bytes to fill (bytes; <= 0 is a no-op).
 */
void   cl_mem_set(void *dst, cl_u8 byte_val, cl_isize size);

/*
 * Copies non-overlapping bytes from src to dst, safely acting as a no-op if
 * size <= 0, dst is NULL, src is NULL, or dst == src.
 *
 * Parameters:
 *   dst  (void *)       - Destination buffer pointer (must not overlap src).
 *   src  (const void *) - Source buffer pointer (must not overlap dst).
 *   size (cl_isize)     - Number of bytes to copy (bytes; <= 0 is a no-op).
 */
void   cl_mem_copy(void *dst, const void *src, cl_isize size);

/*
 * Copies possibly overlapping bytes from src to dst, safely acting as a no-op
 * if size <= 0, dst is NULL, src is NULL, or dst == src.
 *
 * Parameters:
 *   dst  (void *)       - Destination buffer pointer (may overlap src).
 *   src  (const void *) - Source buffer pointer (may overlap dst).
 *   size (cl_isize)     - Number of bytes to move (bytes; <= 0 is a no-op).
 */
void   cl_mem_move(void *dst, const void *src, cl_isize size);

/*
 * Lexicographically compares two memory regions byte-by-byte as unsigned bytes.
 * Returns 0 without dereferencing when size <= 0 or a == b.
 *
 * Parameters:
 *   a    (const void *) - First memory buffer (must be non-NULL when size > 0 and a != b).
 *   b    (const void *) - Second memory buffer (must be non-NULL when size > 0 and a != b).
 *   size (cl_isize)     - Number of bytes to compare (bytes).
 *
 * Returns:
 *   (int) < 0 if a < b, 0 if equal (or size <= 0 or a == b), > 0 if a > b.
 */
int    cl_mem_cmp(const void *a, const void *b, cl_isize size);

/*
 * Tests whether two memory regions contain identical byte sequences.
 *
 * Parameters:
 *   a    (const void *) - First memory buffer (must be non-NULL when size > 0 and a != b).
 *   b    (const void *) - Second memory buffer (must be non-NULL when size > 0 and a != b).
 *   size (cl_isize)     - Number of bytes to compare (bytes).
 *
 * Returns:
 *   (bool) true if the first size bytes match (or size <= 0 or a == b); false otherwise.
 */
bool   cl_mem_eq(const void *a, const void *b, cl_isize size);

/*
 * Zero-initializes the entire object pointed to by ptr using sizeof(*ptr) bytes.
 *
 * Parameters:
 *   ptr (T *) - Pointer to a typed struct or variable to clear; safe no-op if NULL.
 */
#define CL_ZERO_STRUCT(ptr) cl_mem_zero((ptr), (cl_isize)sizeof(*(ptr)))

/* ----------------------------------------------------------------------------
 * Safe Bounded C-String Copy/Concat Helpers (Always NUL-Terminates if cap > 0)
 *
 * Returns the length of the source string that was attempted (like strlcpy),
 * allowing callers to detect truncation via `ret >= dst_cap`.
 * ---------------------------------------------------------------------------- */

/*
 * Copies a NUL-terminated C string into a bounded destination buffer, always
 * NUL-terminating dst when dst != NULL and dst_cap > 0 (strlcpy semantics).
 *
 * Parameters:
 *   dst     (char *)       - Destination character buffer (may be NULL).
 *   dst_cap (cl_isize)     - Total capacity of dst in bytes, including NUL terminator.
 *   src     (const char *) - NUL-terminated source C string (NULL treated as empty string).
 *
 * Returns:
 *   (cl_isize) Length of src in bytes excluding NUL (0 if src is NULL);
 *              truncation occurred if the returned value >= dst_cap.
 */
cl_isize cl_cstr_copy_n(char *dst, cl_isize dst_cap, const char *src);

/*
 * Appends a NUL-terminated C string onto an existing NUL-terminated string in a
 * bounded buffer, always NUL-terminating when space allows (strlcat semantics).
 *
 * Parameters:
 *   dst     (char *)       - Destination buffer containing a NUL-terminated C string (may be NULL).
 *   dst_cap (cl_isize)     - Total capacity of dst in bytes, including NUL terminator.
 *   src     (const char *) - NUL-terminated source C string to append (NULL appends nothing).
 *
 * Returns:
 *   (cl_isize) Total length in bytes (excluding NUL) of the string it tried to create
 *              (initial length of dst clamped to dst_cap, plus strlen(src));
 *              truncation occurred if the returned value >= dst_cap.
 */
cl_isize cl_cstr_cat_n(char *dst, cl_isize dst_cap, const char *src);

#endif /* CL_MEM_H */
