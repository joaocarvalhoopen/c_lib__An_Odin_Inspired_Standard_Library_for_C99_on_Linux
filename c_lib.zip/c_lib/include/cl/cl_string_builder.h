/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_string_builder.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Odin-style growable and fixed-buffer String Builder (`Cl_String_Builder`,
 *   modeled after Odin's `core:strings.Builder`), plus `cl_aprintf`,
 *   `cl_tprintf` (temp-allocated formatting), and `cl_bprintf`.
 *
 * Modes of Operation:
 *   1. Dynamic mode (`cl_sb_init` / `{0}` zero-init):
 *      Grows exponentially using `sb.allocator` (defaults to `cl_ctx_allocator()`).
 *   2. Fixed-buffer mode (`cl_sb_init_buffer`):
 *      Writes directly into a caller-owned stack/static buffer with ZERO heap
 *      allocations; sets `sb.truncated = true` if capacity is exceeded.
 * ============================================================================
 */

#ifndef CL_STRING_BUILDER_H
#define CL_STRING_BUILDER_H

#include "cl_string.h"
#include "cl_defer.h"
#include <stdarg.h>

/*
 * Struct: Cl_String_Builder
 * Purpose:
 *   Growable or fixed-capacity byte/string builder modeled after Odin's
 *   core:strings.Builder. Zero-initialization ({0}) creates a valid dynamic
 *   builder backed by cl_ctx_allocator() on first write.
 * Fields:
 *   data (cl_u8 *): Pointer to the backing byte buffer (allocator-owned in
 *     dynamic mode or caller-owned in fixed-buffer mode; may be NULL when
 *     cap == 0).
 *   len (cl_isize): Current number of payload bytes written (>= 0, bytes).
 *   cap (cl_isize): Total backing buffer capacity in bytes (>= len).
 *   allocator (Cl_Allocator): Allocator used for dynamic growth and destroy;
 *     defaults to cl_ctx_allocator() if invalid/zero-initialized.
 *   fixed_buffer (bool): True if backed by a caller buffer (disables resizing
 *     and freeing); false for dynamically allocated storage.
 *   truncated (bool): Set to true in fixed-buffer mode if any write or NUL
 *     termination runs out of capacity.
 */
typedef struct Cl_String_Builder {
    cl_u8       *data;
    cl_isize     len;
    cl_isize     cap;
    Cl_Allocator allocator;
    bool         fixed_buffer; /* True when backed by caller buffer (never reallocs/frees) */
    bool         truncated;    /* Set true if fixed_buffer ran out of space */
} Cl_String_Builder;

/* ----------------------------------------------------------------------------
 * Lifecycle
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_sb_init
 * Purpose:
 *   Initializes a dynamic Cl_String_Builder with zero initial capacity and
 *   binds it to alloc.
 * Parameters:
 *   sb (Cl_String_Builder *): Builder to initialize; must be non-NULL.
 *   alloc (Cl_Allocator): Allocator for future buffer growth (zero-init uses
 *     cl_ctx_allocator() on first reserve).
 * Returns:
 *   void.
 */
void cl_sb_init(Cl_String_Builder *sb, Cl_Allocator alloc);

/*
 * Function: cl_sb_init_cap
 * Purpose:
 *   Initializes a dynamic Cl_String_Builder and pre-allocates at least
 *   initial_cap bytes of capacity.
 * Parameters:
 *   sb (Cl_String_Builder *): Builder to initialize; must be non-NULL.
 *   alloc (Cl_Allocator): Allocator to use (zero-init defaults to context).
 *   initial_cap (cl_isize): Minimum initial capacity in bytes (<= 0 allocates
 *     nothing and succeeds immediately).
 * Returns:
 *   bool: true if initialization and reservation succeeded; false on OOM.
 */
bool cl_sb_init_cap(Cl_String_Builder *sb, Cl_Allocator alloc, cl_isize initial_cap);

/*
 * Function: cl_sb_init_buffer
 * Purpose:
 *   Initializes a fixed-buffer Cl_String_Builder over caller-owned memory
 *   with zero heap allocations. Writes beyond cap bytes set sb->truncated.
 * Parameters:
 *   sb (Cl_String_Builder *): Builder to initialize; must be non-NULL.
 *   buf (void *): Caller-owned backing buffer, or NULL (sets cap = 0).
 *   cap (cl_isize): Backing buffer capacity in bytes (<= 0 sets cap = 0).
 * Returns:
 *   void.
 */
void cl_sb_init_buffer(Cl_String_Builder *sb, void *buf, cl_isize cap);

/*
 * Function: cl_sb_destroy
 * Purpose:
 *   Frees the backing buffer (in dynamic mode only) and zeroes *sb. Safe to
 *   call on NULL, fixed-buffer builders, or already-destroyed builders.
 * Parameters:
 *   sb (Cl_String_Builder *): Builder to destroy, or NULL.
 * Returns:
 *   void.
 */
void cl_sb_destroy(Cl_String_Builder *sb);

/*
 * Function: cl_sb_reset
 * Purpose:
 *   Resets sb->len to 0 bytes and clears sb->truncated while keeping the
 *   existing allocated or fixed backing buffer for reuse. Safe if NULL.
 * Parameters:
 *   sb (Cl_String_Builder *): Builder to reset, or NULL.
 * Returns:
 *   void.
 */
void cl_sb_reset(Cl_String_Builder *sb);

/*
 * Function: cl_sb_reserve
 * Purpose:
 *   Ensures the builder has capacity for at least min_cap total bytes, growing
 *   exponentially (starting at 64 bytes) in dynamic mode. Always returns false
 *   if min_cap > sb->cap in fixed-buffer mode.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   min_cap (cl_isize): Minimum required total capacity in bytes.
 * Returns:
 *   bool: true if sb->cap >= min_cap on return; false on fixed-buffer limit
 *     or allocation failure.
 */
bool cl_sb_reserve(Cl_String_Builder *sb, cl_isize min_cap);

/* ----------------------------------------------------------------------------
 * Writing Operations (Return Number of Bytes Written)
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_sb_write_byte
 * Purpose:
 *   Appends a single raw byte to the builder.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   byte_val (cl_u8): Byte value to append.
 * Returns:
 *   cl_isize: 1 (byte written) on success, or 0 if out of space / OOM.
 */
cl_isize cl_sb_write_byte(Cl_String_Builder *sb, cl_u8 byte_val);

/*
 * Function: cl_sb_write_bytes
 * Purpose:
 *   Appends len raw bytes from data to the builder. In fixed-buffer mode,
 *   writes as many bytes as fit and sets sb->truncated = true if short.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   data (const void *): Source bytes to copy (NULL returns 0).
 *   len (cl_isize): Number of bytes to append (<= 0 returns 0).
 * Returns:
 *   cl_isize: Number of bytes actually written (>= 0, bytes).
 */
cl_isize cl_sb_write_bytes(Cl_String_Builder *sb, const void *data, cl_isize len);

/*
 * Function: cl_sb_write_str
 * Purpose:
 *   Appends all bytes of a Cl_Str view to the builder.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   s (Cl_Str): Source byte slice (length in bytes).
 * Returns:
 *   cl_isize: Number of bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_str(Cl_String_Builder *sb, Cl_Str s);

/*
 * Function: cl_sb_write_cstr
 * Purpose:
 *   Appends a NUL-terminated C string (excluding its NUL byte) to the builder.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   cs (const char *): NUL-terminated C string, or NULL (returns 0).
 * Returns:
 *   cl_isize: Number of bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_cstr(Cl_String_Builder *sb, const char *cs);

/*
 * Function: cl_sb_write_rune
 * Purpose:
 *   Encodes a Unicode code point as RFC 3629 UTF-8 (replacing invalid runes
 *   with U+FFFD) and appends the encoded bytes to the builder.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   r (cl_rune): Unicode code point to encode and append.
 * Returns:
 *   cl_isize: Number of UTF-8 bytes written (typically 1..4, or less on
 *     fixed-buffer truncation / OOM).
 */
cl_isize cl_sb_write_rune(Cl_String_Builder *sb, cl_rune r);

/*
 * Function: cl_sb_write_repeat
 * Purpose:
 *   Appends s repeated count times, pre-reserving total bytes in dynamic mode
 *   when no signed overflow occurs.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   s (Cl_Str): Pattern byte slice to repeat.
 *   count (cl_isize): Number of repetitions (<= 0 writes 0 bytes).
 * Returns:
 *   cl_isize: Total number of bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_repeat(Cl_String_Builder *sb, Cl_Str s, cl_isize count);

/*
 * Function: cl_sb_write_i64
 * Purpose:
 *   Formats a signed 64-bit integer in base 10 and appends it to the builder.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   v (cl_i64): Signed 64-bit integer value.
 * Returns:
 *   cl_isize: Number of ASCII bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_i64(Cl_String_Builder *sb, cl_i64 v);

/*
 * Function: cl_sb_write_u64
 * Purpose:
 *   Formats an unsigned 64-bit integer in base 10 and appends it to the builder.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   v (cl_u64): Unsigned 64-bit integer value.
 * Returns:
 *   cl_isize: Number of ASCII bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_u64(Cl_String_Builder *sb, cl_u64 v);

/*
 * Function: cl_sb_write_hex
 * Purpose:
 *   Formats an unsigned 64-bit integer in hexadecimal with a "0x" prefix and
 *   appends it to the builder.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   v (cl_u64): Unsigned 64-bit integer value.
 *   uppercase (bool): True to use uppercase hex digits ('A'..'F', "0x%llX");
 *     false for lowercase ('a'..'f', "0x%llx").
 * Returns:
 *   cl_isize: Number of ASCII bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_hex(Cl_String_Builder *sb, cl_u64 v, bool uppercase);

/*
 * Function: cl_sb_write_f64
 * Purpose:
 *   Formats a 64-bit IEEE-754 floating-point value and appends it to sb.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   v (cl_f64): Double-precision floating-point value.
 *   precision (int): Number of fractional decimal digits for fixed "%.*f"
 *     formatting (>= 0), or < 0 to use compact general "%g" formatting.
 * Returns:
 *   cl_isize: Number of ASCII bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_f64(Cl_String_Builder *sb, cl_f64 v, int precision);

/*
 * Function: cl_sb_write_bool
 * Purpose:
 *   Appends the ASCII string "true" or "false" corresponding to v.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   v (bool): Boolean value to format.
 * Returns:
 *   cl_isize: Number of bytes written (4 for "true", 5 for "false", or fewer
 *     on truncation / OOM).
 */
cl_isize cl_sb_write_bool(Cl_String_Builder *sb, bool v);

/*
 * Function: cl_sb_write_c64
 * Purpose:
 *   Formats a single-precision complex number as "re + imi" or "re - |im|i"
 *   and appends it to the builder.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   z (cl_c64): Single-precision complex value.
 *   precision (int): Fractional decimal digits (>= 0 for "%.*f"), or < 0 for
 *     compact "%g" formatting.
 * Returns:
 *   cl_isize: Number of ASCII bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_c64(Cl_String_Builder *sb, cl_c64 z, int precision);

/*
 * Function: cl_sb_write_c128
 * Purpose:
 *   Formats a double-precision complex number as "re + imi" or "re - |im|i"
 *   and appends it to the builder.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   z (cl_c128): Double-precision complex value.
 *   precision (int): Fractional decimal digits (>= 0 for "%.*f"), or < 0 for
 *     compact "%g" formatting.
 * Returns:
 *   cl_isize: Number of ASCII bytes written (>= 0, bytes).
 */
cl_isize cl_sb_write_c128(Cl_String_Builder *sb, cl_c128 z, int precision);

/*
 * Function: cl_sb_write_fmt
 * Purpose:
 *   Formats a printf-style string with variadic arguments and appends the
 *   result to the builder.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   fmt (const char *): NUL-terminated printf format string (NULL returns 0).
 *   ... (variadic): Arguments matching fmt conversion specifiers.
 * Returns:
 *   cl_isize: Number of bytes written to sb (>= 0, bytes).
 */
CL_PRINTF_LIKE(2, 3) cl_isize cl_sb_write_fmt(Cl_String_Builder *sb, const char *fmt, ...);

/*
 * Function: cl_sb_write_vfmt
 * Purpose:
 *   Formats a printf-style string using an existing va_list and appends the
 *   result to the builder.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   fmt (const char *): NUL-terminated printf format string (NULL returns 0).
 *   args (va_list): Variadic argument list matching fmt.
 * Returns:
 *   cl_isize: Number of bytes written to sb (>= 0, bytes).
 */
cl_isize cl_sb_write_vfmt(Cl_String_Builder *sb, const char *fmt, va_list args);

/*
 * Function: cl_sb_pop_byte
 * Purpose:
 *   Removes the last byte from the builder if non-empty and optionally stores
 *   it in *out_byte.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder, or NULL.
 *   out_byte (cl_u8 *): Optional output pointer receiving the removed byte
 *     (may be NULL).
 * Returns:
 *   bool: true if a byte was popped; false if sb is NULL or empty.
 */
bool cl_sb_pop_byte(Cl_String_Builder *sb, cl_u8 *out_byte);

/*
 * Function: cl_sb_truncate
 * Purpose:
 *   Shortens the builder length to new_len bytes with bounds checking via
 *   CL_BOUNDS_CHECK_RANGE(0, new_len, sb->len).
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder; must be non-NULL.
 *   new_len (cl_isize): New length in bytes; must satisfy 0 <= new_len <= sb->len.
 * Returns:
 *   void.
 */
void cl_sb_truncate(Cl_String_Builder *sb, cl_isize new_len);

/* ----------------------------------------------------------------------------
 * Views & Export
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_sb_to_str
 * Purpose:
 *   Returns an O(1) non-owning Cl_Str view referencing the builder's current
 *   bytes (valid until the next mutation or destroy of sb).
 * Parameters:
 *   sb (const Cl_String_Builder *): Source builder, or NULL.
 * Returns:
 *   Cl_Str: Non-owning view of sb->len bytes, or CL_STR_EMPTY if sb is NULL
 *     or empty.
 */
Cl_Str cl_sb_to_str(const Cl_String_Builder *sb);

/*
 * Function: cl_sb_to_cstr
 * Purpose:
 *   Writes a trailing NUL byte at sb->data[sb->len] (reserving 1 byte in
 *   dynamic mode, or clamping sb->len to sb->cap - 1 and setting sb->truncated
 *   if full in fixed-buffer mode) and returns a C string pointer valid until
 *   the next builder mutation.
 * Parameters:
 *   sb (Cl_String_Builder *): Target builder, or NULL.
 * Returns:
 *   const char *: Pointer to a NUL-terminated string, or "" if sb is NULL,
 *     unallocated/empty, or reservation fails.
 */
const char *cl_sb_to_cstr(Cl_String_Builder *sb);

/*
 * Function: cl_sb_clone_str
 * Purpose:
 *   Clones the builder's current byte contents into a newly allocated
 *   independent Cl_Str owned by the caller (free with cl_str_free).
 * Parameters:
 *   sb (const Cl_String_Builder *): Source builder, or NULL.
 *   alloc (Cl_Allocator): Allocator for the cloned string (defaults to context).
 * Returns:
 *   Cl_Str: Newly allocated copy of sb->len bytes, or CL_STR_EMPTY if empty
 *     or allocation fails.
 */
Cl_Str cl_sb_clone_str(const Cl_String_Builder *sb, Cl_Allocator alloc);

/* ----------------------------------------------------------------------------
 * Odin `fmt`-Style Formatting Helpers
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_aprintf
 * Purpose:
 *   Formats a printf-style string into a newly allocated exact-length Cl_Str
 *   using alloc. Caller owns the result and frees it with cl_str_free.
 * Parameters:
 *   alloc (Cl_Allocator): Allocator for the output string (defaults to context).
 *   fmt (const char *): NUL-terminated printf format string (NULL returns empty).
 *   ... (variadic): Arguments matching fmt.
 * Returns:
 *   Cl_Str: Newly allocated formatted byte slice, or CL_STR_EMPTY on empty
 *     output, error, or OOM.
 */
CL_PRINTF_LIKE(2, 3) Cl_Str cl_aprintf(Cl_Allocator alloc, const char *fmt, ...);

/*
 * Function: cl_tprintf
 * Purpose:
 *   Formats a printf-style string into the thread-local temporary allocator
 *   (cl_ctx_temp_allocator()), matching Odin's fmt.tprintf.
 * Parameters:
 *   fmt (const char *): NUL-terminated printf format string (NULL returns empty).
 *   ... (variadic): Arguments matching fmt.
 * Returns:
 *   Cl_Str: Temp-allocated formatted byte slice, or CL_STR_EMPTY on error/OOM.
 */
CL_PRINTF_LIKE(1, 2) Cl_Str cl_tprintf(const char *fmt, ...);

/*
 * Function: cl_bprintf
 * Purpose:
 *   Formats a printf-style string directly into a caller-provided fixed char
 *   buffer with guaranteed NUL termination and zero heap allocations.
 * Parameters:
 *   buf (char *): Destination buffer (NULL returns CL_STR_EMPTY).
 *   buf_cap (cl_isize): Total buffer capacity in bytes, including space for
 *     the trailing NUL terminator (<= 0 returns CL_STR_EMPTY).
 *   fmt (const char *): NUL-terminated printf format string.
 *   ... (variadic): Arguments matching fmt.
 * Returns:
 *   Cl_Str: Non-owning view into buf covering up to min(formatted_len,
 *     buf_cap - 1) bytes, or CL_STR_EMPTY on error or empty output.
 */
CL_PRINTF_LIKE(3, 4) Cl_Str cl_bprintf(char *buf, cl_isize buf_cap, const char *fmt, ...);

/* ----------------------------------------------------------------------------
 * Scope-Exit Defer Helper
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_defer_run_sb
 * Purpose:
 *   Cleanup callback invoked automatically at scope exit by CL_DEFER_SB to
 *   destroy the referenced Cl_String_Builder.
 * Parameters:
 *   p (Cl_String_Builder **): Pointer to a pointer to the Cl_String_Builder
 *     variable going out of scope. Safe if p or *p is NULL.
 * Returns:
 *   void.
 */
static inline void cl_defer_run_sb(Cl_String_Builder **p) {
    if (p != NULL && *p != NULL) {
        cl_sb_destroy(*p);
    }
}

#if CL_HAVE_CLEANUP
    /*
     * Macro: CL_DEFER_SB(sb_var)
     * Purpose:
     *   Registers a compiler cleanup guard (when CL_HAVE_CLEANUP is enabled)
     *   that automatically calls cl_sb_destroy(&sb_var) upon exiting the
     *   enclosing lexical scope.
     * Parameters:
     *   sb_var (Cl_String_Builder): Lvalue Cl_String_Builder variable whose
     *     address is taken and destroyed at scope exit.
     */
    #define CL_DEFER_SB(sb_var) \
        CL_CLEANUP(cl_defer_run_sb) Cl_String_Builder *CL_UNIQUE(_cl_def_sb_) = &(sb_var)
#endif

#endif /* CL_STRING_BUILDER_H */
