/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_os.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Minimal Linux filesystem API strictly focused on whole-file read/write
 *   operations (modeled after Odin's `os.read_entire_file` and
 *   `os.write_entire_file`), plus atomic whole-file writes, environment
 *   lookup, POSIX fd defer guard, and monotonic high-resolution time /
 *   stopwatch utilities.
 *
 * Filesystem Scope (Intentional Minimalism):
 *   Only whole-file read/write primitives are provided (no streaming FILE
 *   abstractions, directory walkers, or permission/symlink trees):
 *     - cl_os_read_entire_file / _str / _cstr   (works on regular files & /proc)
 *     - cl_os_write_entire_file / _str / _cstr  (single-call whole-file write)
 *     - cl_os_write_entire_file_atomic          (write temp + fsync + rename)
 * ============================================================================
 */

#ifndef CL_OS_H
#define CL_OS_H

#include "cl_types.h"
#include "cl_result.h"
#include "cl_slice.h"
#include "cl_alloc.h"
#include "cl_string.h"
#include "cl_defer.h"

/*
 * Struct: Cl_Res_Bytes (defined via CL_RES_DEFINE)
 * Purpose:
 *   Result tuple carrying either a newly allocated byte slice or a Cl_Error
 *   code (err == CL_ERR_NONE indicates success).
 * Fields:
 *   value (Cl_Bytes): Byte slice { cl_u8 *data; cl_isize len (bytes) } valid
 *     when err == CL_ERR_NONE.
 *   err (Cl_Error): Error code (CL_ERR_NONE on success).
 */
CL_RES_DEFINE(Cl_Res_Bytes, Cl_Bytes, Cl_Error);

/* ----------------------------------------------------------------------------
 * Whole-File Filesystem Operations (Allocator-Aware, Multiple-Return Errors)
 * ---------------------------------------------------------------------------- */

/*
 * Function: cl_os_read_entire_file
 * Purpose:
 *   Reads an entire file into a newly allocated Cl_Bytes slice from alloc.
 *   Uses a single exact-size allocation for regular files with positive size
 *   and falls back to chunked streaming reads for Linux virtual files (such
 *   as /proc or /sys entries) or pipes whose fstat size is 0.
 * Parameters:
 *   path (Cl_Str): Filesystem path as a UTF-8 byte slice (need not be
 *     NUL-terminated).
 *   alloc (Cl_Allocator): Allocator for the returned byte slice (falls back
 *     to cl_ctx_allocator() when invalid). Free with CL_SLICE_FREE(alloc, res.value).
 * Returns:
 *   Cl_Res_Bytes: CL_OK(bytes) with exact allocated byte count (empty slice
 *     for 0-byte files), or CL_ERR(err) on open/stat/read/OOM failure.
 */
CL_NODISCARD Cl_Res_Bytes cl_os_read_entire_file(Cl_Str path, Cl_Allocator alloc);

/*
 * Function: cl_os_read_entire_file_str
 * Purpose:
 *   Reads an entire file into a newly allocated Cl_Str (exact byte length,
 *   not NUL-terminated) from alloc. Free with cl_str_free(res.value, alloc).
 * Parameters:
 *   path (Cl_Str): Filesystem path byte slice.
 *   alloc (Cl_Allocator): Allocator for the returned string (defaults to context).
 * Returns:
 *   Cl_Res_Str: CL_OK(str) containing the file bytes, or CL_ERR(err) on error.
 */
CL_NODISCARD Cl_Res_Str   cl_os_read_entire_file_str(Cl_Str path, Cl_Allocator alloc);

/*
 * Function: cl_os_read_entire_file_cstr
 * Purpose:
 *   Convenience wrapper around cl_os_read_entire_file accepting a
 *   NUL-terminated C string path.
 * Parameters:
 *   path (const char *): NUL-terminated filesystem path, or NULL.
 *   alloc (Cl_Allocator): Allocator for the returned byte slice (defaults to context).
 * Returns:
 *   Cl_Res_Bytes: CL_OK(bytes) on success, or CL_ERR(err) on failure.
 */
CL_NODISCARD Cl_Res_Bytes cl_os_read_entire_file_cstr(const char *path, Cl_Allocator alloc);

/*
 * Function: cl_os_write_entire_file
 * Purpose:
 *   Creates or truncates the file at path (POSIX mode 0644) and writes all
 *   bytes of data in a retry loop handling short writes and EINTR.
 * Parameters:
 *   path (Cl_Str): Destination filesystem path byte slice.
 *   data (Cl_Bytes): Byte slice to write (length in bytes).
 * Returns:
 *   Cl_Error: CL_ERR_NONE on success, or a mapped error code (e.g.
 *     CL_ERR_PERMISSION, CL_ERR_IO_OPEN, CL_ERR_IO_WRITE, CL_ERR_OUT_OF_MEMORY).
 */
CL_NODISCARD Cl_Error     cl_os_write_entire_file(Cl_Str path, Cl_Bytes data);

/*
 * Function: cl_os_write_entire_file_str
 * Purpose:
 *   Creates or truncates path and writes all bytes of a Cl_Str to it.
 * Parameters:
 *   path (Cl_Str): Destination filesystem path byte slice.
 *   text (Cl_Str): UTF-8 / byte slice to write (length in bytes).
 * Returns:
 *   Cl_Error: CL_ERR_NONE on success, or a Cl_Error failure code.
 */
CL_NODISCARD Cl_Error     cl_os_write_entire_file_str(Cl_Str path, Cl_Str text);

/*
 * Function: cl_os_write_entire_file_cstr
 * Purpose:
 *   Convenience wrapper around cl_os_write_entire_file taking a NUL-terminated
 *   C string path.
 * Parameters:
 *   path (const char *): NUL-terminated destination path, or NULL.
 *   data (Cl_Bytes): Byte slice to write (length in bytes).
 * Returns:
 *   Cl_Error: CL_ERR_NONE on success, or a Cl_Error failure code.
 */
CL_NODISCARD Cl_Error     cl_os_write_entire_file_cstr(const char *path, Cl_Bytes data);

/*
 * Function: cl_os_write_entire_file_atomic
 * Purpose:
 *   Crash-safe atomic whole-file write on Linux: writes data to a sibling
 *   temporary file ("<path>.tmp.<pid>"), flushes file data to disk via
 *   fsync(), closes the descriptor, and atomically replaces path via rename().
 *   Cleans up the temporary file on error so readers never observe partial data.
 * Parameters:
 *   path (Cl_Str): Destination filesystem path byte slice.
 *   data (Cl_Bytes): Byte slice to write (length in bytes).
 * Returns:
 *   Cl_Error: CL_ERR_NONE on success, or a Cl_Error failure code.
 */
CL_NODISCARD Cl_Error     cl_os_write_entire_file_atomic(Cl_Str path, Cl_Bytes data);

/*
 * Function: cl_os_file_exists
 * Purpose:
 *   Checks whether a filesystem entry at path exists and can be stat()'d.
 * Parameters:
 *   path (Cl_Str): Filesystem path byte slice.
 * Returns:
 *   bool: true if stat(path) succeeds; false if missing, inaccessible, or OOM.
 */
bool                      cl_os_file_exists(Cl_Str path);

/*
 * Function: cl_os_file_size
 * Purpose:
 *   Queries the byte size of a file at path using POSIX stat().
 * Parameters:
 *   path (Cl_Str): Filesystem path byte slice.
 * Returns:
 *   Cl_Res_ISize: CL_OK(size_bytes) with st_size in bytes (>= 0), or
 *     CL_ERR(err) on stat or scratch allocation failure.
 */
CL_NODISCARD Cl_Res_ISize cl_os_file_size(Cl_Str path);

/*
 * Function: cl_os_remove_file
 * Purpose:
 *   Removes (unlinks) the file at path using POSIX unlink().
 * Parameters:
 *   path (Cl_Str): Filesystem path byte slice.
 * Returns:
 *   Cl_Error: CL_ERR_NONE on success, or a mapped Cl_Error code on failure.
 */
Cl_Error                  cl_os_remove_file(Cl_Str path);

/*
 * Function: cl_os_env_get
 * Purpose:
 *   Looks up a process environment variable via getenv() and returns its value
 *   as a non-owning Cl_Str view pointing into the process environment.
 * Parameters:
 *   name (Cl_Str): Environment variable name byte slice.
 * Returns:
 *   Cl_Opt_Str: CL_SOME(value_view) if defined, or CL_NONE if unset or OOM.
 */
Cl_Opt_Str cl_os_env_get(Cl_Str name);

/*
 * Function: cl_os_close_fd
 * Purpose:
 *   Idempotently closes a POSIX file descriptor if fd is non-NULL and *fd >= 0,
 *   then sets *fd = -1 to prevent double-close bugs.
 * Parameters:
 *   fd (int *): Pointer to a POSIX file descriptor variable, or NULL.
 * Returns:
 *   void.
 */
void cl_os_close_fd(int *fd);

/*
 * Function: cl_defer_run_fd
 * Purpose:
 *   Cleanup callback invoked automatically at scope exit by CL_DEFER_FD to
 *   close the referenced POSIX file descriptor.
 * Parameters:
 *   fdp (int **): Pointer to a pointer to the int file descriptor variable
 *     leaving scope. Safe if fdp or *fdp is NULL.
 * Returns:
 *   void.
 */
static inline void cl_defer_run_fd(int **fdp) {
    if (fdp != NULL && *fdp != NULL) {
        cl_os_close_fd(*fdp);
    }
}

#if CL_HAVE_CLEANUP
    /*
     * Macro: CL_DEFER_FD(fd_var)
     * Purpose:
     *   Registers a compiler cleanup guard (when CL_HAVE_CLEANUP is enabled)
     *   that calls cl_os_close_fd(&fd_var) upon exiting the enclosing scope.
     * Parameters:
     *   fd_var (int): Lvalue POSIX file descriptor variable whose address is
     *     captured and closed automatically on scope exit (if >= 0).
     */
    #define CL_DEFER_FD(fd_var) \
        CL_CLEANUP(cl_defer_run_fd) int *CL_UNIQUE(_cl_def_fd_) = &(fd_var)
#endif

/* ----------------------------------------------------------------------------
 * Monotonic Time & Stopwatch (Odin `core:time`)
 * ---------------------------------------------------------------------------- */

/*
 * Macro: CL_TIME_NS_PER_US
 * Purpose:
 *   Number of nanoseconds in one microsecond (1000 ns/us).
 * Expansion:
 *   Constant of type cl_i64 equal to 1000.
 */
#define CL_TIME_NS_PER_US  ((cl_i64)1000)

/*
 * Macro: CL_TIME_NS_PER_MS
 * Purpose:
 *   Number of nanoseconds in one millisecond (1,000,000 ns/ms).
 * Expansion:
 *   Constant of type cl_i64 equal to 1000000.
 */
#define CL_TIME_NS_PER_MS  ((cl_i64)1000000)

/*
 * Macro: CL_TIME_NS_PER_SEC
 * Purpose:
 *   Number of nanoseconds in one second (1,000,000,000 ns/s).
 * Expansion:
 *   Constant of type cl_i64 equal to 1000000000.
 */
#define CL_TIME_NS_PER_SEC ((cl_i64)1000000000)

/*
 * Function: cl_time_now_ns
 * Purpose:
 *   Reads the Linux CLOCK_MONOTONIC clock and returns a monotonic timestamp
 *   in nanoseconds that is unaffected by wall-clock or NTP adjustments.
 * Parameters:
 *   None (void).
 * Returns:
 *   cl_i64: Monotonic timestamp in nanoseconds (tv_sec * 1e9 + tv_nsec), or
 *     0 if clock_gettime fails.
 */
cl_i64 cl_time_now_ns(void);

/*
 * Function: cl_time_sleep_ms
 * Purpose:
 *   Suspends the calling thread for at least milliseconds using POSIX
 *   nanosleep(), automatically resuming with the remaining duration on EINTR.
 * Parameters:
 *   milliseconds (cl_i64): Sleep duration in milliseconds (<= 0 returns
 *     immediately as a no-op).
 * Returns:
 *   void.
 */
void   cl_time_sleep_ms(cl_i64 milliseconds);

/*
 * Struct: Cl_Stopwatch
 * Purpose:
 *   Start/stop/reset monotonic timer accumulating elapsed time across one or
 *   more intervals in nanoseconds. Zero-initialization ({0}) creates a valid
 *   stopped stopwatch with 0 elapsed nanoseconds.
 * Fields:
 *   start_ns (cl_i64): Monotonic timestamp in nanoseconds captured when the
 *     current running interval started.
 *   accumulated_ns (cl_i64): Total nanoseconds accumulated across completed
 *     start/stop intervals (>= 0, nanoseconds).
 *   running (bool): True while the stopwatch is actively measuring time;
 *     false when stopped.
 */
typedef struct Cl_Stopwatch {
    cl_i64 start_ns;
    cl_i64 accumulated_ns;
    bool   running;
} Cl_Stopwatch;

/*
 * Function: cl_stopwatch_start
 * Purpose:
 *   Starts or resumes the stopwatch if not already running (idempotent when
 *   already running).
 * Parameters:
 *   sw (Cl_Stopwatch *): Target stopwatch; must be non-NULL.
 * Returns:
 *   void.
 */
void   cl_stopwatch_start(Cl_Stopwatch *sw);

/*
 * Function: cl_stopwatch_stop
 * Purpose:
 *   Stops the stopwatch if running and adds (cl_time_now_ns() - sw->start_ns)
 *   nanoseconds to sw->accumulated_ns (no-op if already stopped).
 * Parameters:
 *   sw (Cl_Stopwatch *): Target stopwatch; must be non-NULL.
 * Returns:
 *   void.
 */
void   cl_stopwatch_stop(Cl_Stopwatch *sw);

/*
 * Function: cl_stopwatch_reset
 * Purpose:
 *   Stops the stopwatch and resets start_ns and accumulated_ns to 0 ns.
 * Parameters:
 *   sw (Cl_Stopwatch *): Target stopwatch; must be non-NULL.
 * Returns:
 *   void.
 */
void   cl_stopwatch_reset(Cl_Stopwatch *sw);

/*
 * Function: cl_stopwatch_elapsed_ns
 * Purpose:
 *   Returns total elapsed time measured by sw in nanoseconds, including the
 *   currently active interval if sw->running is true.
 * Parameters:
 *   sw (const Cl_Stopwatch *): Target stopwatch; must be non-NULL.
 * Returns:
 *   cl_i64: Elapsed duration in nanoseconds.
 */
cl_i64 cl_stopwatch_elapsed_ns(const Cl_Stopwatch *sw);

/*
 * Function: cl_stopwatch_elapsed_us
 * Purpose:
 *   Returns total elapsed time measured by sw in microseconds
 *   (elapsed_ns / 1000.0).
 * Parameters:
 *   sw (const Cl_Stopwatch *): Target stopwatch; must be non-NULL.
 * Returns:
 *   cl_f64: Elapsed duration in microseconds.
 */
cl_f64 cl_stopwatch_elapsed_us(const Cl_Stopwatch *sw);

/*
 * Function: cl_stopwatch_elapsed_ms
 * Purpose:
 *   Returns total elapsed time measured by sw in milliseconds
 *   (elapsed_ns / 1000000.0).
 * Parameters:
 *   sw (const Cl_Stopwatch *): Target stopwatch; must be non-NULL.
 * Returns:
 *   cl_f64: Elapsed duration in milliseconds.
 */
cl_f64 cl_stopwatch_elapsed_ms(const Cl_Stopwatch *sw);

/*
 * Function: cl_stopwatch_elapsed_sec
 * Purpose:
 *   Returns total elapsed time measured by sw in seconds
 *   (elapsed_ns / 1000000000.0).
 * Parameters:
 *   sw (const Cl_Stopwatch *): Target stopwatch; must be non-NULL.
 * Returns:
 *   cl_f64: Elapsed duration in seconds.
 */
cl_f64 cl_stopwatch_elapsed_sec(const Cl_Stopwatch *sw);

#endif /* CL_OS_H */
