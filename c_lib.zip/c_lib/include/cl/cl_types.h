/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_types.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Defines explicit fixed-width scalar types, native C99 complex types
 *   (cl_c64 / complex64 and cl_c128 / complex128), quaternions, source
 *   location metadata (Cl_Source_Loc), the fundamental Odin-style string
 *   descriptor (Cl_Str), byte-order (endian) helpers, and value utilities.
 *
 * Design Notes:
 *   - Signed sizes (cl_isize / ptrdiff_t) are used for lengths, capacities,
 *     and indices, matching Odin's `int` convention. Signed sizes prevent
 *     unsigned underflow bugs (such as `len - 1` wrapping to SIZE_MAX when
 *     `len == 0`) and make reverse loops safe and natural.
 *   - cl_c64 and cl_c128 use ISO C99 native `_Complex` types rather than
 *     manual structs so `+`, `-`, `*`, `/` work natively while guaranteeing
 *     the exact binary layout of `float[2]` and `double[2]` per C99 6.2.5p13.
 *   - We intentionally do NOT include `<complex.h>` in public headers to
 *     avoid polluting user code with the single-letter macro `I`.
 * ============================================================================
 */

#ifndef CL_TYPES_H
#define CL_TYPES_H

#include "cl_config.h"
#include <float.h>
#include <inttypes.h>
#include <limits.h>

/* ----------------------------------------------------------------------------
 * Concise printf Cast Helpers
 *
 * Shorthand cast macros for printing 64-bit integers (`cl_i64`, `cl_u64`) or
 * `cl_isize` portably with `%lld` / `%llu` across 32-bit and 64-bit ABIs:
 *   printf("count = %lld, id = %llu\n", (CL_LL)count, (CL_ULL)id);
 * ---------------------------------------------------------------------------- */

/*
 * Type cast helper macro expanding to signed `long long` for `%lld` printf formatting.
 */
#define CL_LL  long long

/*
 * Type cast helper macro expanding to `unsigned long long` for `%llu` printf formatting.
 */
#define CL_ULL unsigned long long

/* ----------------------------------------------------------------------------
 * Scalar Primitive Types (Odin-Style Explicit Widths)
 * ---------------------------------------------------------------------------- */

/* Signed 8-bit two's-complement integer (range [-128, 127], width 8 bits / 1 byte). */
typedef int8_t    cl_i8;

/* Signed 16-bit two's-complement integer (range [-32768, 32767], width 16 bits / 2 bytes). */
typedef int16_t   cl_i16;

/* Signed 32-bit two's-complement integer (width 32 bits / 4 bytes). */
typedef int32_t   cl_i32;

/* Signed 64-bit two's-complement integer (width 64 bits / 8 bytes). */
typedef int64_t   cl_i64;

/* Unsigned 8-bit integer (range [0, 255], width 8 bits / 1 byte). */
typedef uint8_t   cl_u8;

/* Unsigned 16-bit integer (range [0, 65535], width 16 bits / 2 bytes). */
typedef uint16_t  cl_u16;

/* Unsigned 32-bit integer (width 32 bits / 4 bytes). */
typedef uint32_t  cl_u32;

/* Unsigned 64-bit integer (width 64 bits / 8 bytes). */
typedef uint64_t  cl_u64;

/* Signed pointer-width integer used for indices, lengths, capacities, and byte sizes (Odin `int`). */
typedef ptrdiff_t cl_isize;

/* Unsigned pointer-width integer used for C ABI size interop (Odin `uint`, bytes or counts). */
typedef size_t    cl_usize;

/* Unsigned integer wide enough to hold a converted object pointer address. */
typedef uintptr_t cl_uintptr;

/* IEEE-754 single-precision 32-bit binary floating-point scalar (4 bytes). */
typedef float     cl_f32;

/* IEEE-754 double-precision 64-bit binary floating-point scalar (8 bytes). */
typedef double    cl_f64;

/* Compact 8-bit (1-byte) boolean storage type (0 = false, non-zero = true). */
typedef uint8_t   cl_b8;

/* 32-bit (4-byte) boolean storage type for struct alignment and SIMD masks (0 = false, non-zero = true). */
typedef uint32_t  cl_b32;

/* Semantic raw 8-bit memory byte (1 byte, range [0, 255]). */
typedef uint8_t   cl_byte;

/* Unicode scalar value / code point stored in a signed 32-bit integer (UTF-32, range [0, 0x10FFFF]). */
typedef int32_t   cl_rune;

/* Untyped generic memory pointer equivalent to Odin's `rawptr` (`void *`). */
typedef void     *cl_rawptr;

/* ----------------------------------------------------------------------------
 * Complex Numbers (ISO C99 Native _Complex)
 *
 * Binary layout guaranteed by ISO C99 Section 6.2.5p13:
 *   cl_c64  (complex64)  == float[2]  { real, imag } (8 bytes, align 4)
 *   cl_c128 (complex128) == double[2] { real, imag } (16 bytes, align 8)
 * ---------------------------------------------------------------------------- */

/* Single-precision complex number z = a + b*i (two cl_f32 parts, 8 bytes total, dimensionless). */
typedef float  _Complex cl_c64;

/* Double-precision complex number z = a + b*i (two cl_f64 parts, 16 bytes total, dimensionless). */
typedef double _Complex cl_c128;

/* Verify cl_c64 occupies exactly 8 bytes (two cl_f32 values). */
CL_STATIC_ASSERT(sizeof(cl_c64)  == 2 * sizeof(cl_f32), cl_c64_size_is_8);

/* Verify cl_c128 occupies exactly 16 bytes (two cl_f64 values). */
CL_STATIC_ASSERT(sizeof(cl_c128) == 2 * sizeof(cl_f64), cl_c128_size_is_16);

/* ----------------------------------------------------------------------------
 * Quaternions (Odin quaternion128 & quaternion256)
 *
 * Stored in (x, y, z, w) order where:
 *   q = w + x*i + y*j + z*k
 * ---------------------------------------------------------------------------- */

/*
 * Single-precision quaternion representing q = w + x*i + y*j + z*k (16 bytes total).
 *
 * Fields:
 *   x (cl_f32, dimensionless) - Imaginary i-component.
 *   y (cl_f32, dimensionless) - Imaginary j-component.
 *   z (cl_f32, dimensionless) - Imaginary k-component.
 *   w (cl_f32, dimensionless) - Real (scalar) component.
 */
typedef struct Cl_Quat128 {
    cl_f32 x;
    cl_f32 y;
    cl_f32 z;
    cl_f32 w;
} Cl_Quat128;

/*
 * Double-precision quaternion representing q = w + x*i + y*j + z*k (32 bytes total).
 *
 * Fields:
 *   x (cl_f64, dimensionless) - Imaginary i-component.
 *   y (cl_f64, dimensionless) - Imaginary j-component.
 *   z (cl_f64, dimensionless) - Imaginary k-component.
 *   w (cl_f64, dimensionless) - Real (scalar) component.
 */
typedef struct Cl_Quat256 {
    cl_f64 x;
    cl_f64 y;
    cl_f64 z;
    cl_f64 w;
} Cl_Quat256;

/* Verify Cl_Quat128 has packed 16-byte binary layout (four cl_f32 fields). */
CL_STATIC_ASSERT(sizeof(Cl_Quat128) == 16, cl_quat128_size_is_16);

/* Verify Cl_Quat256 has packed 32-byte binary layout (four cl_f64 fields). */
CL_STATIC_ASSERT(sizeof(Cl_Quat256) == 32, cl_quat256_size_is_32);

/* ----------------------------------------------------------------------------
 * Source Location Metadata (Odin `#caller_location` Equivalent)
 *
 * Automatically captured at call sites by macros using CL_HERE.
 * Passed into allocators, assertions, loggers, and tracking diagnostics.
 * ---------------------------------------------------------------------------- */

/*
 * Source code call-site location metadata captured by CL_HERE for diagnostics.
 *
 * Fields:
 *   file (const char *)        - NUL-terminated source file path (__FILE__), or NULL if unknown.
 *   line (cl_i32, line number) - 1-based source line number (__LINE__).
 *   func (const char *)        - NUL-terminated enclosing function name (__func__), or NULL if unknown.
 */
typedef struct Cl_Source_Loc {
    const char *file;
    cl_i32      line;
    const char *func;
} Cl_Source_Loc;

/*
 * Constructs a Cl_Source_Loc compound literal capturing the current file, 1-based
 * line number, and enclosing function name at the expansion site.
 *
 * Returns:
 *   Cl_Source_Loc - Source location value for the current line.
 */
#define CL_HERE ((Cl_Source_Loc){ __FILE__, (cl_i32)__LINE__, __func__ })

/* ----------------------------------------------------------------------------
 * Fundamental Odin-Style String Descriptor (Non-Owning Byte Slice View)
 *
 * Invariants:
 *   - `data` points to `len` UTF-8 bytes; NOT required to be NUL-terminated.
 *   - `len >= 0`. An empty string has `len == 0` (`data` may be NULL).
 *   - Copying a Cl_Str copies only 16 bytes (pointer + length) in O(1).
 *   - Full string manipulation functions live in <cl/cl_string.h>.
 * ---------------------------------------------------------------------------- */

/*
 * Non-owning UTF-8 byte slice string view (pointer + signed byte length).
 *
 * Fields:
 *   data (const cl_u8 *)   - Pointer to UTF-8 bytes (not required to be NUL-terminated;
 *                            may be NULL when len == 0).
 *   len  (cl_isize, bytes) - Byte length of the string view; must be >= 0.
 */
typedef struct Cl_Str {
    const cl_u8 *data;
    cl_isize     len;
} Cl_Str;

/*
 * Brace-enclosed static initializer for a global or static const Cl_Str built from
 * a compile-time C string literal.
 *
 * Parameters:
 *   lit (C string literal) - Must be a string literal (enforced by "" concatenation).
 */
#define CL_STR_STATIC(lit) \
    { (const cl_u8 *)("" lit), (cl_isize)(sizeof(lit) - 1) }

/*
 * Constructs a Cl_Str compound literal from a compile-time C string literal in O(1)
 * without calling strlen().
 *
 * Parameters:
 *   lit (C string literal) - Must be a string literal (enforced by "" concatenation).
 *
 * Returns:
 *   Cl_Str - Non-owning view over lit with len = sizeof(lit) - 1 bytes.
 */
#define CL_STR(lit) \
    ((Cl_Str){ (const cl_u8 *)("" lit), (cl_isize)(sizeof(lit) - 1) })

/*
 * Empty Cl_Str compound literal with data = NULL and len = 0 bytes.
 *
 * Returns:
 *   Cl_Str - Empty string view.
 */
#define CL_STR_EMPTY ((Cl_Str){ NULL, 0 })

/*
 * printf format specifier string for printing a Cl_Str paired with CL_STR_ARG(str).
 * Expands to "%.*s" so non-NUL-terminated string views print safely.
 */
#define CL_STR_FMT      "%.*s"

/*
 * Expands a Cl_Str into the (int length, const char *data) argument pair required
 * by CL_STR_FMT ("%.*s"). Safely substitutes "" if str.data is NULL.
 *
 * Parameters:
 *   str (Cl_Str) - String view to format (evaluated twice; avoid side effects).
 */
#define CL_STR_ARG(str) (int)((str).len), (const char *)((str).data ? (const char *)(str).data : "")

/* ----------------------------------------------------------------------------
 * Common Byte Size Units
 * ---------------------------------------------------------------------------- */

/*
 * Converts kibibytes (KiB) to bytes: n * 1024.
 *
 * Parameters:
 *   n (integral expression, KiB) - Number of kibibytes (1 KiB = 1024 bytes).
 *
 * Returns:
 *   cl_isize - Equivalent size in bytes.
 */
#define CL_KB(n) ((cl_isize)(n) * (cl_isize)1024)

/*
 * Converts mebibytes (MiB) to bytes: n * 1024^2.
 *
 * Parameters:
 *   n (integral expression, MiB) - Number of mebibytes (1 MiB = 1048576 bytes).
 *
 * Returns:
 *   cl_isize - Equivalent size in bytes.
 */
#define CL_MB(n) (CL_KB(n) * (cl_isize)1024)

/*
 * Converts gibibytes (GiB) to bytes: n * 1024^3.
 *
 * Parameters:
 *   n (integral expression, GiB) - Number of gibibytes (1 GiB = 1073741824 bytes).
 *
 * Returns:
 *   cl_isize - Equivalent size in bytes.
 */
#define CL_GB(n) (CL_MB(n) * (cl_isize)1024)

/* ----------------------------------------------------------------------------
 * Numeric Utilities (Single-Evaluation When __typeof__ Is Available)
 * ---------------------------------------------------------------------------- */
#if CL_HAVE_TYPEOF && CL_HAVE_STMT_EXPR
    /*
     * Returns the smaller of two comparable values, evaluating each argument once.
     *
     * Parameters:
     *   a (arithmetic expression) - First value to compare.
     *   b (arithmetic expression) - Second value to compare (compatible type with a).
     *
     * Returns:
     *   Common arithmetic type of a and b - Minimum of a and b.
     */
    #define CL_MIN(a, b) CL_EXTENSION ({ \
        __typeof__(a) _cl_a = (a);       \
        __typeof__(b) _cl_b = (b);       \
        (_cl_a < _cl_b) ? _cl_a : _cl_b; \
    })

    /*
     * Returns the larger of two comparable values, evaluating each argument once.
     *
     * Parameters:
     *   a (arithmetic expression) - First value to compare.
     *   b (arithmetic expression) - Second value to compare (compatible type with a).
     *
     * Returns:
     *   Common arithmetic type of a and b - Maximum of a and b.
     */
    #define CL_MAX(a, b) CL_EXTENSION ({ \
        __typeof__(a) _cl_a = (a);       \
        __typeof__(b) _cl_b = (b);       \
        (_cl_a > _cl_b) ? _cl_a : _cl_b; \
    })

    /*
     * Clamps x to the closed interval [lo, hi], evaluating each argument once.
     *
     * Parameters:
     *   x  (arithmetic expression) - Value to clamp.
     *   lo (arithmetic expression) - Inclusive lower bound; must satisfy lo <= hi.
     *   hi (arithmetic expression) - Inclusive upper bound; must satisfy hi >= lo.
     *
     * Returns:
     *   Common arithmetic type - lo if x < lo, hi if x > hi, otherwise x.
     */
    #define CL_CLAMP(x, lo, hi) CL_EXTENSION ({ \
        __typeof__(x) _cl_x  = (x);             \
        __typeof__(lo) _cl_lo = (lo);           \
        __typeof__(hi) _cl_hi = (hi);           \
        (_cl_x < _cl_lo) ? _cl_lo : ((_cl_x > _cl_hi) ? _cl_hi : _cl_x); \
    })

    /*
     * Swaps the values of two lvalues of identical type using __typeof__.
     *
     * Parameters:
     *   a (modifiable lvalue) - First object to swap.
     *   b (modifiable lvalue) - Second object to swap (same type as a).
     */
    #define CL_SWAP(a, b) do {     \
        CL_EXTENSION __typeof__(a) _cl_tmp = (a); \
        (a) = (b);                 \
        (b) = _cl_tmp;             \
    } while (0)
#else
    /*
     * Portable fallback returning the smaller of two values (may evaluate arguments twice).
     *
     * Parameters:
     *   a (arithmetic expression) - First value (avoid side effects).
     *   b (arithmetic expression) - Second value (avoid side effects).
     *
     * Returns:
     *   Common arithmetic type - Minimum of a and b.
     */
    #define CL_MIN(a, b)        (((a) < (b)) ? (a) : (b))

    /*
     * Portable fallback returning the larger of two values (may evaluate arguments twice).
     *
     * Parameters:
     *   a (arithmetic expression) - First value (avoid side effects).
     *   b (arithmetic expression) - Second value (avoid side effects).
     *
     * Returns:
     *   Common arithmetic type - Maximum of a and b.
     */
    #define CL_MAX(a, b)        (((a) > (b)) ? (a) : (b))

    /*
     * Portable fallback clamping x to [lo, hi] (may evaluate arguments multiple times).
     *
     * Parameters:
     *   x  (arithmetic expression) - Value to clamp (avoid side effects).
     *   lo (arithmetic expression) - Inclusive lower bound; must satisfy lo <= hi.
     *   hi (arithmetic expression) - Inclusive upper bound; must satisfy hi >= lo.
     *
     * Returns:
     *   Common arithmetic type - Clamped value in [lo, hi].
     */
    #define CL_CLAMP(x, lo, hi) (CL_MIN(CL_MAX((x), (lo)), (hi)))

    /*
     * Portable C99 fallback swapping two lvalues of explicit type T.
     *
     * Parameters:
     *   T (C type name)       - Type of both lvalues a and b.
     *   a (modifiable lvalue) - First object of type T.
     *   b (modifiable lvalue) - Second object of type T.
     */
    #define CL_SWAP_T(T, a, b)  do { T _cl_tmp = (a); (a) = (b); (b) = _cl_tmp; } while (0)
#endif

/* ----------------------------------------------------------------------------
 * Byte-Swap & Explicit Endianness Encoding/Decoding (Odin core:encoding/endian)
 *
 * These functions are alignment-safe and independent of host CPU endianness.
 * ---------------------------------------------------------------------------- */

/*
 * Reverses the byte order of an unsigned 16-bit integer (2 bytes).
 *
 * Parameters:
 *   v (cl_u16, 16-bit integer) - Input value to byte-swap.
 *
 * Returns:
 *   cl_u16 - Value with its 2 bytes reversed.
 */
static inline cl_u16 cl_bswap16(cl_u16 v) {
    return (cl_u16)((v >> 8) | (v << 8));
}

/*
 * Reverses the byte order of an unsigned 32-bit integer (4 bytes).
 *
 * Parameters:
 *   v (cl_u32, 32-bit integer) - Input value to byte-swap.
 *
 * Returns:
 *   cl_u32 - Value with its 4 bytes reversed.
 */
static inline cl_u32 cl_bswap32(cl_u32 v) {
    return ((v & 0x000000FFu) << 24) |
           ((v & 0x0000FF00u) << 8)  |
           ((v & 0x00FF0000u) >> 8)  |
           ((v & 0xFF000000u) >> 24);
}

/*
 * Reverses the byte order of an unsigned 64-bit integer (8 bytes).
 *
 * Parameters:
 *   v (cl_u64, 64-bit integer) - Input value to byte-swap.
 *
 * Returns:
 *   cl_u64 - Value with its 8 bytes reversed.
 */
static inline cl_u64 cl_bswap64(cl_u64 v) {
    return ((v & 0x00000000000000FFull) << 56) |
           ((v & 0x000000000000FF00ull) << 40) |
           ((v & 0x0000000000FF0000ull) << 24) |
           ((v & 0x00000000FF000000ull) << 8)  |
           ((v & 0x000000FF00000000ull) >> 8)  |
           ((v & 0x0000FF0000000000ull) >> 24) |
           ((v & 0x00FF000000000000ull) >> 40) |
           ((v & 0xFF00000000000000ull) >> 56);
}

/*
 * Decodes an unsigned 16-bit integer from 2 little-endian bytes (alignment-safe).
 *
 * Parameters:
 *   p (const cl_u8 *) - Non-NULL pointer to at least 2 readable bytes.
 *
 * Returns:
 *   cl_u16 - Host-order 16-bit unsigned integer decoded from p[0..1].
 */
static inline cl_u16 cl_read_u16_le(const cl_u8 *p) {
    return (cl_u16)((cl_u16)p[0] | ((cl_u16)p[1] << 8));
}

/*
 * Decodes an unsigned 16-bit integer from 2 big-endian bytes (alignment-safe).
 *
 * Parameters:
 *   p (const cl_u8 *) - Non-NULL pointer to at least 2 readable bytes.
 *
 * Returns:
 *   cl_u16 - Host-order 16-bit unsigned integer decoded from p[0..1].
 */
static inline cl_u16 cl_read_u16_be(const cl_u8 *p) {
    return (cl_u16)(((cl_u16)p[0] << 8) | (cl_u16)p[1]);
}

/*
 * Decodes an unsigned 32-bit integer from 4 little-endian bytes (alignment-safe).
 *
 * Parameters:
 *   p (const cl_u8 *) - Non-NULL pointer to at least 4 readable bytes.
 *
 * Returns:
 *   cl_u32 - Host-order 32-bit unsigned integer decoded from p[0..3].
 */
static inline cl_u32 cl_read_u32_le(const cl_u8 *p) {
    return ((cl_u32)p[0])       |
           ((cl_u32)p[1] << 8)  |
           ((cl_u32)p[2] << 16) |
           ((cl_u32)p[3] << 24);
}

/*
 * Decodes an unsigned 32-bit integer from 4 big-endian bytes (alignment-safe).
 *
 * Parameters:
 *   p (const cl_u8 *) - Non-NULL pointer to at least 4 readable bytes.
 *
 * Returns:
 *   cl_u32 - Host-order 32-bit unsigned integer decoded from p[0..3].
 */
static inline cl_u32 cl_read_u32_be(const cl_u8 *p) {
    return ((cl_u32)p[0] << 24) |
           ((cl_u32)p[1] << 16) |
           ((cl_u32)p[2] << 8)  |
           ((cl_u32)p[3]);
}

/*
 * Decodes an unsigned 64-bit integer from 8 little-endian bytes (alignment-safe).
 *
 * Parameters:
 *   p (const cl_u8 *) - Non-NULL pointer to at least 8 readable bytes.
 *
 * Returns:
 *   cl_u64 - Host-order 64-bit unsigned integer decoded from p[0..7].
 */
static inline cl_u64 cl_read_u64_le(const cl_u8 *p) {
    return ((cl_u64)p[0])       |
           ((cl_u64)p[1] << 8)  |
           ((cl_u64)p[2] << 16) |
           ((cl_u64)p[3] << 24) |
           ((cl_u64)p[4] << 32) |
           ((cl_u64)p[5] << 40) |
           ((cl_u64)p[6] << 48) |
           ((cl_u64)p[7] << 56);
}

/*
 * Decodes an unsigned 64-bit integer from 8 big-endian bytes (alignment-safe).
 *
 * Parameters:
 *   p (const cl_u8 *) - Non-NULL pointer to at least 8 readable bytes.
 *
 * Returns:
 *   cl_u64 - Host-order 64-bit unsigned integer decoded from p[0..7].
 */
static inline cl_u64 cl_read_u64_be(const cl_u8 *p) {
    return ((cl_u64)p[0] << 56) |
           ((cl_u64)p[1] << 48) |
           ((cl_u64)p[2] << 40) |
           ((cl_u64)p[3] << 32) |
           ((cl_u64)p[4] << 24) |
           ((cl_u64)p[5] << 16) |
           ((cl_u64)p[6] << 8)  |
           ((cl_u64)p[7]);
}

/*
 * Encodes an unsigned 16-bit integer into 2 little-endian bytes (alignment-safe).
 *
 * Parameters:
 *   p (cl_u8 *)                - Non-NULL destination buffer with at least 2 writable bytes.
 *   v (cl_u16, 16-bit integer) - Host-order value to encode into p[0..1].
 */
static inline void cl_write_u16_le(cl_u8 *p, cl_u16 v) {
    p[0] = (cl_u8)(v & 0xFFu);
    p[1] = (cl_u8)((v >> 8) & 0xFFu);
}

/*
 * Encodes an unsigned 16-bit integer into 2 big-endian bytes (alignment-safe).
 *
 * Parameters:
 *   p (cl_u8 *)                - Non-NULL destination buffer with at least 2 writable bytes.
 *   v (cl_u16, 16-bit integer) - Host-order value to encode into p[0..1].
 */
static inline void cl_write_u16_be(cl_u8 *p, cl_u16 v) {
    p[0] = (cl_u8)((v >> 8) & 0xFFu);
    p[1] = (cl_u8)(v & 0xFFu);
}

/*
 * Encodes an unsigned 32-bit integer into 4 little-endian bytes (alignment-safe).
 *
 * Parameters:
 *   p (cl_u8 *)                - Non-NULL destination buffer with at least 4 writable bytes.
 *   v (cl_u32, 32-bit integer) - Host-order value to encode into p[0..3].
 */
static inline void cl_write_u32_le(cl_u8 *p, cl_u32 v) {
    p[0] = (cl_u8)(v & 0xFFu);
    p[1] = (cl_u8)((v >> 8) & 0xFFu);
    p[2] = (cl_u8)((v >> 16) & 0xFFu);
    p[3] = (cl_u8)((v >> 24) & 0xFFu);
}

/*
 * Encodes an unsigned 32-bit integer into 4 big-endian bytes (alignment-safe).
 *
 * Parameters:
 *   p (cl_u8 *)                - Non-NULL destination buffer with at least 4 writable bytes.
 *   v (cl_u32, 32-bit integer) - Host-order value to encode into p[0..3].
 */
static inline void cl_write_u32_be(cl_u8 *p, cl_u32 v) {
    p[0] = (cl_u8)((v >> 24) & 0xFFu);
    p[1] = (cl_u8)((v >> 16) & 0xFFu);
    p[2] = (cl_u8)((v >> 8) & 0xFFu);
    p[3] = (cl_u8)(v & 0xFFu);
}

/*
 * Encodes an unsigned 64-bit integer into 8 little-endian bytes (alignment-safe).
 *
 * Parameters:
 *   p (cl_u8 *)                - Non-NULL destination buffer with at least 8 writable bytes.
 *   v (cl_u64, 64-bit integer) - Host-order value to encode into p[0..7].
 */
static inline void cl_write_u64_le(cl_u8 *p, cl_u64 v) {
    p[0] = (cl_u8)(v & 0xFFu);
    p[1] = (cl_u8)((v >> 8) & 0xFFu);
    p[2] = (cl_u8)((v >> 16) & 0xFFu);
    p[3] = (cl_u8)((v >> 24) & 0xFFu);
    p[4] = (cl_u8)((v >> 32) & 0xFFu);
    p[5] = (cl_u8)((v >> 40) & 0xFFu);
    p[6] = (cl_u8)((v >> 48) & 0xFFu);
    p[7] = (cl_u8)((v >> 56) & 0xFFu);
}

/*
 * Encodes an unsigned 64-bit integer into 8 big-endian bytes (alignment-safe).
 *
 * Parameters:
 *   p (cl_u8 *)                - Non-NULL destination buffer with at least 8 writable bytes.
 *   v (cl_u64, 64-bit integer) - Host-order value to encode into p[0..7].
 */
static inline void cl_write_u64_be(cl_u8 *p, cl_u64 v) {
    p[0] = (cl_u8)((v >> 56) & 0xFFu);
    p[1] = (cl_u8)((v >> 48) & 0xFFu);
    p[2] = (cl_u8)((v >> 40) & 0xFFu);
    p[3] = (cl_u8)((v >> 32) & 0xFFu);
    p[4] = (cl_u8)((v >> 24) & 0xFFu);
    p[5] = (cl_u8)((v >> 16) & 0xFFu);
    p[6] = (cl_u8)((v >> 8) & 0xFFu);
    p[7] = (cl_u8)(v & 0xFFu);
}

#endif /* CL_TYPES_H */
