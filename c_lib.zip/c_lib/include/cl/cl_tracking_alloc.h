/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_tracking_alloc.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Development-time memory safety & leak detector (`Cl_Tracking_Allocator`),
 *   inspired by Odin's `mem.Tracking_Allocator` and extended with guard
 *   redzones, poison bytes, bad-pointer validation, and double-free history.
 *
 * Detects Automatically (Even Without External Tools):
 *   1. Memory Leaks            - Exact file:line:func, byte size, and sequence ID.
 *   2. Double Frees            - Reports original alloc site, 1st free, & 2nd free.
 *   3. Bad / Wild / Interior   - Catches freeing stack, garbage, or offset pointers
 *      Pointer Frees             without corrupting the underlying heap.
 *   4. Buffer Under/Overflows  - 16-byte front & back 0xFD guard redzones checked
 *                                on resize, free, and explicit integrity scans.
 *   5. Uninit & Use-After-Free - Fills non-zeroed allocs with 0xCD and freed
 *                                memory with 0xDD before release.
 *   6. Live Pointer Validation - `cl_tracking_validate_ptr(t, ptr, len)` verifies
 *                                liveness, bounds, and dangling-pointer status.
 * ============================================================================
 */

#ifndef CL_TRACKING_ALLOC_H
#define CL_TRACKING_ALLOC_H

#include "cl_alloc.h"
#include <stdio.h>

/*
 * Width in bytes (16 bytes) of both the front guard redzone and the back guard
 * redzone painted with CL_MEM_POISON_REDZONE around each tracked allocation.
 */
#define CL_TRACKING_REDZONE_SIZE 16

/*
 * Fixed capacity (256 entries) of the recently-freed ring buffer used to detect
 * double frees and dangling pointers.
 */
#define CL_TRACKING_HISTORY_CAP  256

/*
 * Fixed capacity (64 events) of the recorded memory-safety error log stored
 * inside Cl_Tracking_Allocator.
 */
#define CL_TRACKING_ERRORS_CAP   64

/*
 * Metadata record describing one currently active tracked allocation.
 *
 * Fields:
 *   user_ptr  (void *)        - Pointer returned to the caller (after front redzone if enabled).
 *   raw_ptr   (void *)        - Underlying block pointer obtained from the backing allocator.
 *   size      (cl_isize)      - Caller-requested payload size in bytes.
 *   raw_size  (cl_isize)      - Total backing allocation size in bytes including redzones/padding.
 *   alignment (cl_isize)      - Effective power-of-two alignment in bytes (>= CL_DEFAULT_ALIGNMENT).
 *   seq_id    (cl_u64)        - Monotonically increasing 1-based allocation sequence identifier.
 *   loc       (Cl_Source_Loc) - Source location (file, line, function) of the allocation call site.
 */
typedef struct Cl_Alloc_Entry {
    void         *user_ptr;   /* Pointer handed back to caller */
    void         *raw_ptr;    /* Underlying pointer from backing allocator */
    cl_isize      size;       /* Caller-requested byte size */
    cl_isize      raw_size;   /* Total backing size including front/back redzones */
    cl_isize      alignment;  /* Effective alignment */
    cl_u64        seq_id;     /* Monotonic allocation sequence ID */
    Cl_Source_Loc loc;        /* Allocation call site */
} Cl_Alloc_Entry;

/*
 * Metadata record of a recently freed allocation stored in the free-history
 * ring buffer for double-free and use-after-free diagnostics.
 *
 * Fields:
 *   user_ptr  (void *)        - Former caller-facing pointer that was freed.
 *   size      (cl_isize)      - Original caller-requested allocation size in bytes.
 *   alloc_loc (Cl_Source_Loc) - Original allocation call site.
 *   free_loc  (Cl_Source_Loc) - Call site where the block was freed.
 *   seq_id    (cl_u64)        - Monotonic sequence ID assigned when the block was allocated.
 */
typedef struct Cl_Free_Record {
    void         *user_ptr;
    cl_isize      size;
    Cl_Source_Loc alloc_loc;
    Cl_Source_Loc free_loc;
    cl_u64        seq_id;
} Cl_Free_Record;

/*
 * Classification of memory safety violations detected by Cl_Tracking_Allocator.
 *
 * Enumerators:
 *   CL_MEM_ERR_NONE              (0) - No error.
 *   CL_MEM_ERR_DOUBLE_FREE       (1) - Pointer found in recent free history was freed again.
 *   CL_MEM_ERR_BAD_FREE_UNKNOWN  (2) - Pointer not active, not interior, and not in free history.
 *   CL_MEM_ERR_BAD_FREE_INTERIOR (3) - Pointer lies strictly inside an active allocation.
 *   CL_MEM_ERR_REDZONE_UNDERFLOW (4) - Front guard redzone before user_ptr was overwritten.
 *   CL_MEM_ERR_REDZONE_OVERFLOW  (5) - Back guard redzone after (user_ptr + size) was overwritten.
 *   CL_MEM_ERR_SIZE_MISMATCH     (6) - Non-zero old_size passed to free disagreed with recorded size.
 */
typedef enum Cl_Mem_Error_Kind {
    CL_MEM_ERR_NONE = 0,
    CL_MEM_ERR_DOUBLE_FREE,
    CL_MEM_ERR_BAD_FREE_UNKNOWN,
    CL_MEM_ERR_BAD_FREE_INTERIOR,
    CL_MEM_ERR_REDZONE_UNDERFLOW,
    CL_MEM_ERR_REDZONE_OVERFLOW,
    CL_MEM_ERR_SIZE_MISMATCH
} Cl_Mem_Error_Kind;

/*
 * Recorded memory safety violation event captured in Cl_Tracking_Allocator.errors.
 *
 * Fields:
 *   kind           (Cl_Mem_Error_Kind) - Category of detected violation.
 *   ptr            (void *)            - Offending or affected user pointer.
 *   expected_size  (cl_isize)          - Recorded original allocation size in bytes (0 if unknown).
 *   actual_size    (cl_isize)          - Caller-supplied size in bytes at the event site (0 if unused).
 *   event_loc      (Cl_Source_Loc)     - Call site where the violation was detected.
 *   orig_alloc_loc (Cl_Source_Loc)     - Original allocation call site (zeroed if unknown).
 *   prev_free_loc  (Cl_Source_Loc)     - First free call site for double-free events (zeroed otherwise).
 */
typedef struct Cl_Mem_Error_Event {
    Cl_Mem_Error_Kind kind;
    void             *ptr;
    cl_isize          expected_size;
    cl_isize          actual_size;
    Cl_Source_Loc     event_loc;
    Cl_Source_Loc     orig_alloc_loc;
    Cl_Source_Loc     prev_free_loc;
} Cl_Mem_Error_Event;

/*
 * Pointer liveness and bounds classification returned by cl_tracking_validate_ptr().
 *
 * Enumerators:
 *   CL_PTR_VALID         (0) - Pointer lies in a live block and [ptr, ptr + access_size) is in bounds.
 *   CL_PTR_NULL          (1) - Pointer is NULL.
 *   CL_PTR_OUT_OF_BOUNDS (2) - Pointer starts in a live block, but access_size extends past block end.
 *   CL_PTR_FREED         (3) - Pointer matches an entry in the recently-freed history (dangling).
 *   CL_PTR_UNKNOWN       (4) - Pointer is not tracked (stack, static, wild, or other allocator).
 */
typedef enum Cl_Ptr_Status {
    CL_PTR_VALID = 0,     /* Points to live block and [ptr, ptr+len) is in bounds */
    CL_PTR_NULL,          /* Pointer is NULL */
    CL_PTR_OUT_OF_BOUNDS, /* Inside live block, but requested length overflows it */
    CL_PTR_FREED,         /* Recently freed (dangling / use-after-free) */
    CL_PTR_UNKNOWN        /* Not tracked (stack, static, wild, or other allocator) */
} Cl_Ptr_Status;

/*
 * State descriptor for the development-time memory safety and leak-tracking
 * wrapper allocator.
 *
 * Fields:
 *   backing               (Cl_Allocator)       - Underlying allocator delegated to for raw storage.
 *   panic_on_error        (bool)               - If true, immediately abort via cl_assert_fail_fmt on error.
 *   enable_redzones       (bool)               - If true (default), surround allocations with 0xFD redzones.
 *   slots                 (Cl_Alloc_Entry *)   - Open-addressed hash table entries (managed via libc calloc/free).
 *   slot_states           (cl_u8 *)            - Per-slot state array (0=empty, 1=occupied, 2=tombstone).
 *   slot_cap              (cl_isize)           - Allocated hash table capacity (power-of-two slot count).
 *   active_count          (cl_isize)           - Number of currently live (unfreed) allocations (block count).
 *   tombstone_count       (cl_isize)           - Number of tombstone slots currently in the hash table.
 *   next_seq_id           (cl_u64)             - Counter incremented to produce each allocation's seq_id.
 *   total_alloc_count     (cl_isize)           - Cumulative count of successful allocations.
 *   total_free_count      (cl_isize)           - Cumulative count of freed blocks.
 *   total_bytes_allocated (cl_isize)           - Cumulative sum of all requested allocation sizes in bytes.
 *   current_bytes         (cl_isize)           - Total live caller-requested bytes currently allocated.
 *   peak_bytes            (cl_isize)           - Maximum value ever reached by current_bytes in bytes.
 *   double_free_count     (cl_isize)           - Count of detected double-free violations.
 *   bad_free_count        (cl_isize)           - Count of detected unknown/interior bad-free violations.
 *   redzone_corruptions   (cl_isize)           - Count of detected front/back redzone corruption events.
 *   size_mismatch_count   (cl_isize)           - Count of detected free old_size mismatches.
 *   free_history          (Cl_Free_Record[])   - Ring buffer of up to CL_TRACKING_HISTORY_CAP freed blocks.
 *   free_history_head     (cl_isize)           - Next write index into free_history [0, CL_TRACKING_HISTORY_CAP).
 *   free_history_count    (cl_isize)           - Valid entry count in free_history [0, CL_TRACKING_HISTORY_CAP].
 *   errors                (Cl_Mem_Error_Event[]) - Log of the first CL_TRACKING_ERRORS_CAP safety violations.
 *   error_count           (cl_isize)           - Number of recorded entries in errors [0, CL_TRACKING_ERRORS_CAP].
 *   mutex                 (void *)             - Opaque heap-allocated pthread_mutex_t* when thread safety is on.
 */
typedef struct Cl_Tracking_Allocator {
    Cl_Allocator       backing;
    bool               panic_on_error;       /* If true, trap immediately on bad free/overflow */
    bool               enable_redzones;      /* Default: true */

    /* Internal open-addressed hash table of active Cl_Alloc_Entry slots */
    Cl_Alloc_Entry    *slots;
    cl_u8             *slot_states;          /* 0=empty, 1=occupied, 2=tombstone */
    cl_isize           slot_cap;
    cl_isize           active_count;
    cl_isize           tombstone_count;

    /* Aggregate statistics */
    cl_u64             next_seq_id;
    cl_isize           total_alloc_count;
    cl_isize           total_free_count;
    cl_isize           total_bytes_allocated;
    cl_isize           current_bytes;
    cl_isize           peak_bytes;

    /* Detected error counters */
    cl_isize           double_free_count;
    cl_isize           bad_free_count;
    cl_isize           redzone_corruptions;
    cl_isize           size_mismatch_count;

    /* Recently freed ring buffer */
    Cl_Free_Record     free_history[CL_TRACKING_HISTORY_CAP];
    cl_isize           free_history_head;
    cl_isize           free_history_count;

    /* Recorded error log */
    Cl_Mem_Error_Event errors[CL_TRACKING_ERRORS_CAP];
    cl_isize           error_count;

    /* Opaque mutex handle for thread safety (managed internally in .c) */
    void              *mutex;
} Cl_Tracking_Allocator;

/*
 * Initializes a Cl_Tracking_Allocator wrapping backing with enable_redzones = true,
 * panic_on_error = false, and an internal mutex when CL_ENABLE_THREAD_SAFETY is enabled.
 *
 * Parameters:
 *   t       (Cl_Tracking_Allocator *) - Tracker struct to initialize; must be non-NULL.
 *   backing (Cl_Allocator)            - Valid underlying allocator (backing.proc must be non-NULL).
 */
void cl_tracking_init(Cl_Tracking_Allocator *t, Cl_Allocator backing);

/*
 * Releases the tracker's internal hash table arrays and mutex and zeroes the
 * descriptor. Does NOT automatically free leaked user allocations in backing.
 *
 * Parameters:
 *   t (Cl_Tracking_Allocator *) - Tracker to destroy (safe no-op if NULL).
 */
void cl_tracking_destroy(Cl_Tracking_Allocator *t);

/*
 * Returns a polymorphic Cl_Allocator view backed by this tracking allocator.
 *
 * Parameters:
 *   t (Cl_Tracking_Allocator *) - Initialized tracker; must be non-NULL and outlive the handle.
 *
 * Returns:
 *   (Cl_Allocator) Allocator handle dispatching tracked operations through t.
 */
Cl_Allocator cl_tracking_allocator(Cl_Tracking_Allocator *t);

/*
 * Scans all currently active allocations in t for front or back redzone
 * corruption, recording any detected violations in t->errors.
 *
 * Parameters:
 *   t   (Cl_Tracking_Allocator *) - Tracker to inspect (returns 0 if NULL).
 *   loc (Cl_Source_Loc)           - Call site recorded as event_loc for any detected corruption.
 *
 * Returns:
 *   (cl_isize) Number of active allocations with corrupted redzones found during this scan (block count).
 */
cl_isize cl_tracking_check_integrity(Cl_Tracking_Allocator *t, Cl_Source_Loc loc);

/*
 * Validates whether ptr points into a live tracked allocation with at least
 * access_size readable/writable bytes remaining before the end of that block.
 *
 * Parameters:
 *   t           (const Cl_Tracking_Allocator *) - Tracker to query (NULL yields CL_PTR_UNKNOWN).
 *   ptr         (const void *)                  - Pointer to validate (NULL yields CL_PTR_NULL).
 *   access_size (cl_isize)                      - Planned access span in bytes (<= 0 treated as 0 bytes).
 *
 * Returns:
 *   (Cl_Ptr_Status) Classification of ptr: CL_PTR_VALID, CL_PTR_NULL, CL_PTR_OUT_OF_BOUNDS,
 *                   CL_PTR_FREED, or CL_PTR_UNKNOWN.
 */
Cl_Ptr_Status cl_tracking_validate_ptr(
    const Cl_Tracking_Allocator *t,
    const void *ptr,
    cl_isize access_size
);

/*
 * Checks whether the tracker has zero live leaks and zero recorded safety
 * error counts (double frees, bad frees, redzone corruptions, size mismatches).
 *
 * Parameters:
 *   t (const Cl_Tracking_Allocator *) - Tracker to check (NULL returns true).
 *
 * Returns:
 *   (bool) true if no leaks and no safety errors were observed; false otherwise.
 */
bool cl_tracking_is_clean(const Cl_Tracking_Allocator *t);

/*
 * Prints a formatted summary of allocation statistics, leaked blocks with call
 * sites, and recorded safety violations to stream out (defaults to stderr).
 *
 * Parameters:
 *   t   (const Cl_Tracking_Allocator *) - Tracker to report (safe no-op if NULL).
 *   out (FILE *)                        - Destination stdio stream (NULL defaults to stderr).
 */
void cl_tracking_print_report(const Cl_Tracking_Allocator *t, FILE *out);

/*
 * Returns a static human-readable ASCII name for a Cl_Mem_Error_Kind enumerator.
 *
 * Parameters:
 *   kind (Cl_Mem_Error_Kind) - Memory error classification value.
 *
 * Returns:
 *   (const char *) NUL-terminated static string (e.g., "DOUBLE_FREE", or "UNKNOWN").
 */
const char *cl_mem_error_kind_name(Cl_Mem_Error_Kind kind);

/*
 * Returns a static human-readable ASCII name for a Cl_Ptr_Status enumerator.
 *
 * Parameters:
 *   status (Cl_Ptr_Status) - Pointer validation status value.
 *
 * Returns:
 *   (const char *) NUL-terminated static string (e.g., "VALID", "FREED (DANGLING)", or "UNKNOWN").
 */
const char *cl_ptr_status_name(Cl_Ptr_Status status);

#endif /* CL_TRACKING_ALLOC_H */
