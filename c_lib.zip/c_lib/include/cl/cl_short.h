/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_short.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Optional opt-in Odin-style short type and macro aliases without the
 *   `cl_` / `Cl_` prefix. Include this header directly or define
 *   `CL_SHORT_NAMES` before including `<cl/cl.h>`.
 *
 * Warning:
 *   Only include this in `.c` files or application headers where unprefixed
 *   names like `u8`, `i64`, `c64`, `c128`, `complex64`, `complex128`, `Str`,
 *   `Arena`, `Allocator`, etc. will not conflict with third-party headers.
 * ============================================================================
 */

#ifndef CL_SHORT_H
#define CL_SHORT_H

#include "cl.h"

/* Scalar & complex aliases */

/* Short alias for cl_i8 (signed 8-bit integer, 1 byte). */
typedef cl_i8      i8;

/* Short alias for cl_i16 (signed 16-bit integer, 2 bytes). */
typedef cl_i16     i16;

/* Short alias for cl_i32 (signed 32-bit integer, 4 bytes). */
typedef cl_i32     i32;

/* Short alias for cl_i64 (signed 64-bit integer, 8 bytes). */
typedef cl_i64     i64;

/* Short alias for cl_u8 (unsigned 8-bit integer, 1 byte). */
typedef cl_u8      u8;

/* Short alias for cl_u16 (unsigned 16-bit integer, 2 bytes). */
typedef cl_u16     u16;

/* Short alias for cl_u32 (unsigned 32-bit integer, 4 bytes). */
typedef cl_u32     u32;

/* Short alias for cl_u64 (unsigned 64-bit integer, 8 bytes). */
typedef cl_u64     u64;

/* Short alias for cl_isize (signed pointer-width index/length/byte count). */
typedef cl_isize   isize;

/* Short alias for cl_usize (unsigned pointer-width C ABI size/count). */
typedef cl_usize   usize;

/* Short alias for cl_uintptr (pointer-sized unsigned integer address). */
typedef cl_uintptr uintptr;

/* Short alias for cl_f32 (IEEE-754 32-bit single-precision float, 4 bytes). */
typedef cl_f32     f32;

/* Short alias for cl_f64 (IEEE-754 64-bit double-precision float, 8 bytes). */
typedef cl_f64     f64;

/* Short alias for cl_b8 (1-byte boolean storage). */
typedef cl_b8      b8;

/* Short alias for cl_b32 (4-byte boolean storage). */
typedef cl_b32     b32;

/* Short alias for cl_byte (semantic raw 8-bit byte). */
typedef cl_byte    byte;

/* Short alias for cl_rune (UTF-32 Unicode scalar code point, 32-bit signed). */
typedef cl_rune    rune;

/* Short alias for cl_rawptr (untyped memory pointer, void *). */
typedef cl_rawptr  rawptr;

/* Short alias for cl_c64 (single-precision complex number z = a + b*i, 8 bytes). */
typedef cl_c64     c64;

/* Short alias for cl_c128 (double-precision complex number z = a + b*i, 16 bytes). */
typedef cl_c128    c128;

/* Odin-style alias for cl_c64 (single-precision complex number, 8 bytes). */
typedef cl_c64     complex64;

/* Odin-style alias for cl_c128 (double-precision complex number, 16 bytes). */
typedef cl_c128    complex128;

/* Short alias for Cl_Quat128 (single-precision quaternion q = w + x*i + y*j + z*k, 16 bytes). */
typedef Cl_Quat128 Quat128;

/* Short alias for Cl_Quat256 (double-precision quaternion q = w + x*i + y*j + z*k, 32 bytes). */
typedef Cl_Quat256 Quat256;

/* Core struct aliases */

/* Short alias for Cl_Source_Loc (call-site file, line number, and function name). */
typedef Cl_Source_Loc         Source_Loc;

/* Short alias for Cl_Str (non-owning UTF-8 byte slice string view). */
typedef Cl_Str                Str;

/* Short alias for Cl_Bytes (mutable cl_u8 byte slice). */
typedef Cl_Bytes              Bytes;

/* Short alias for Cl_Error (standard library error code enum, 0 = none). */
typedef Cl_Error              Error;

/* Short alias for Cl_Allocator (polymorphic allocator interface). */
typedef Cl_Allocator          Allocator;

/* Short alias for Cl_Arena (linear bump allocator over backing blocks). */
typedef Cl_Arena              Arena;

/* Short alias for Cl_Arena_Temp (temporary rewind checkpoint for Cl_Arena). */
typedef Cl_Arena_Temp         Arena_Temp;

/* Short alias for Cl_Virtual_Arena (mmap-backed virtual memory bump allocator). */
typedef Cl_Virtual_Arena      Virtual_Arena;

/* Short alias for Cl_VArena_Temp (temporary rewind checkpoint for Cl_Virtual_Arena). */
typedef Cl_VArena_Temp        VArena_Temp;

/* Short alias for Cl_Pool (fixed-block free-list pool allocator). */
typedef Cl_Pool               Pool;

/* Short alias for Cl_Tracking_Allocator (leak/error diagnostic allocator wrapper). */
typedef Cl_Tracking_Allocator Tracking_Allocator;

/* Short alias for Cl_Context (thread-local implicit allocator/logger/assert context). */
typedef Cl_Context            Context;

/* Short alias for Cl_Scratch (thread-local scratch arena checkpoint). */
typedef Cl_Scratch            Scratch;

/* Short alias for Cl_Logger (polymorphic logging interface). */
typedef Cl_Logger             Logger;

/* Short alias for Cl_Multi_Logger (fan-out logger forwarding to multiple sinks). */
typedef Cl_Multi_Logger       Multi_Logger;

/* Short alias for Cl_String_Builder (dynamically growing UTF-8 string builder). */
typedef Cl_String_Builder     String_Builder;

/* Short alias for Cl_Str_Buf (fixed-capacity stack-friendly string buffer). */
typedef Cl_Str_Buf            Str_Buf;

/* Short alias for Cl_Bit_Set (compact dense bitset container). */
typedef Cl_Bit_Set            Bit_Set;

/* Short alias for Cl_Stopwatch (monotonic high-resolution elapsed timer). */
typedef Cl_Stopwatch          Stopwatch;

/* Ergonomic short macros */

/*
 * Short alias for CL_STR(lit): constructs a Str compound literal from a C string literal.
 *
 * Parameters:
 *   lit (C string literal) - Compile-time string literal.
 *
 * Returns:
 *   Str - Non-owning view over lit with length sizeof(lit) - 1 bytes.
 */
#define STR(lit)      CL_STR(lit)

/*
 * Short alias for CL_STR_EMPTY: empty Str compound literal (data = NULL, len = 0 bytes).
 */
#define STR_EMPTY     CL_STR_EMPTY

/*
 * Short alias for CL_STR_FMT: printf format string "%.*s" for printing Str values.
 */
#define STR_FMT       CL_STR_FMT

/*
 * Short alias for CL_STR_ARG(s): expands a Str into (int len, const char *data) for STR_FMT.
 *
 * Parameters:
 *   s (Str) - String view to pass to printf-family functions.
 */
#define STR_ARG(s)    CL_STR_ARG(s)

/*
 * Short alias for CL_KB(n): converts kibibytes (KiB) to bytes (n * 1024).
 *
 * Parameters:
 *   n (integral expression, KiB) - Number of kibibytes.
 *
 * Returns:
 *   isize - Equivalent size in bytes.
 */
#define KB(n)         CL_KB(n)

/*
 * Short alias for CL_MB(n): converts mebibytes (MiB) to bytes (n * 1024^2).
 *
 * Parameters:
 *   n (integral expression, MiB) - Number of mebibytes.
 *
 * Returns:
 *   isize - Equivalent size in bytes.
 */
#define MB(n)         CL_MB(n)

/*
 * Short alias for CL_GB(n): converts gibibytes (GiB) to bytes (n * 1024^3).
 *
 * Parameters:
 *   n (integral expression, GiB) - Number of gibibytes.
 *
 * Returns:
 *   isize - Equivalent size in bytes.
 */
#define GB(n)         CL_GB(n)

/*
 * Short alias for CL_ARRAY_LEN(a): computes the element count of a fixed-size C array.
 *
 * Parameters:
 *   a (T[N] array expression) - Fixed-size array (must not be a pointer).
 *
 * Returns:
 *   ptrdiff_t - Number of elements in a (element count).
 */
#define ARRAY_LEN(a)  CL_ARRAY_LEN(a)

#endif /* CL_SHORT_H */
