/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_arena.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Fixed-capacity linear bump allocator (`Cl_Arena`) with O(1) allocation,
 *   O(1) in-place resize of the most recent allocation, O(1) bulk reset
 *   (`cl_arena_reset`), scoped checkpoint/rewind (`Cl_Arena_Temp`), and
 *   AddressSanitizer manual poisoning of unused/rewound regions.
 *
 * When to Use Cl_Arena:
 *   - Frame-based / request-based / phase-based memory with known upper bound.
 *   - Fast stack-backed or static-backed temporary workspaces (zero syscalls).
 *   - Eliminates individual `free()` calls and memory fragmentation.
 *
 * Trade-offs:
 *   - Cannot free individual allocations (only bulk reset or LIFO rewind).
 *   - Fixed capacity: returns NULL if exhausted (use Cl_Virtual_Arena when
 *     you need large reserve-on-init / commit-on-demand growth).
 * ============================================================================
 */

#ifndef CL_ARENA_H
#define CL_ARENA_H

#include "cl_alloc.h"

/* ----------------------------------------------------------------------------
 * Fixed-Capacity Linear Arena
 * ---------------------------------------------------------------------------- */

/*
 * Fixed-capacity linear bump allocator descriptor supporting O(1) allocation,
 * O(1) in-place resize of the top allocation, bulk reset, and LIFO checkpoints.
 *
 * Fields:
 *   base          (cl_u8 *)      - Base pointer to the contiguous backing memory buffer.
 *   cap           (cl_isize)     - Total buffer capacity in bytes.
 *   offset        (cl_isize)     - Current bump allocation offset from base in bytes.
 *   prev_offset   (cl_isize)     - Byte offset of the most recent allocation (for in-place resize).
 *   peak_used     (cl_isize)     - High-water mark of maximum offset reached in bytes.
 *   temp_count    (cl_isize)     - Number of currently active Cl_Arena_Temp checkpoints.
 *   backing_alloc (Cl_Allocator) - Owning allocator used to free base in cl_arena_destroy(),
 *                                  or invalid (proc == NULL) for caller-owned buffers.
 */
typedef struct Cl_Arena {
    cl_u8       *base;            /* Backing memory buffer */
    cl_isize     cap;             /* Total capacity in bytes */
    cl_isize     offset;          /* Current bump pointer offset */
    cl_isize     prev_offset;     /* Offset of most recent allocation (for in-place resize) */
    cl_isize     peak_used;       /* High-water mark in bytes */
    cl_isize     temp_count;      /* Number of currently active Cl_Arena_Temp scopes */
    Cl_Allocator backing_alloc;   /* Non-NULL if Cl_Arena owns `base` and must free it */
} Cl_Arena;

/*
 * Saved bump-pointer checkpoint used to rewind a Cl_Arena in O(1) LIFO order.
 *
 * Fields:
 *   arena             (Cl_Arena *) - Target arena captured by cl_arena_temp_begin().
 *   saved_offset      (cl_isize)   - Arena offset in bytes at checkpoint creation.
 *   saved_prev_offset (cl_isize)   - Arena prev_offset in bytes at checkpoint creation.
 */
typedef struct Cl_Arena_Temp {
    Cl_Arena *arena;
    cl_isize  saved_offset;
    cl_isize  saved_prev_offset;
} Cl_Arena_Temp;

/*
 * Initializes a Cl_Arena over a caller-owned memory buffer (stack, static, or
 * heap) without taking ownership; poisons the buffer under AddressSanitizer.
 *
 * Parameters:
 *   arena  (Cl_Arena *) - Arena struct to initialize; must be non-NULL.
 *   buffer (void *)     - Backing buffer pointer; must be non-NULL.
 *   cap    (cl_isize)   - Capacity of buffer in bytes; must be > 0.
 */
void cl_arena_init_buffer(Cl_Arena *arena, void *buffer, cl_isize cap);

/*
 * Initializes a Cl_Arena by allocating an owned backing buffer of cap bytes
 * from backing with CL_DEFAULT_ALIGNMENT; poisons the buffer under ASan.
 *
 * Parameters:
 *   arena   (Cl_Arena *)   - Arena struct to initialize; must be non-NULL.
 *   cap     (cl_isize)     - Desired arena capacity in bytes; must be > 0.
 *   backing (Cl_Allocator) - Valid allocator used to allocate and later free the buffer.
 *
 * Returns:
 *   (bool) true on success; false if backing allocation fails (OOM).
 */
bool cl_arena_init_alloc(Cl_Arena *arena, cl_isize cap, Cl_Allocator backing);

/*
 * Unpoisons the arena's backing buffer, frees it via backing_alloc if owned,
 * and zeroes the Cl_Arena descriptor; safe no-op if arena is NULL.
 *
 * Parameters:
 *   arena (Cl_Arena *) - Arena to destroy (may be NULL).
 */
void cl_arena_destroy(Cl_Arena *arena);

/*
 * Resets the arena bump offset, prev_offset, and temp_count to 0 in O(1),
 * invalidating all prior allocations and re-poisoning the region under ASan.
 * In debug builds, scrubs previously used bytes with CL_MEM_POISON_FREED.
 *
 * Parameters:
 *   arena (Cl_Arena *) - Arena to reset (safe no-op if NULL or uninitialized).
 */
void cl_arena_reset(Cl_Arena *arena);

/*
 * Returns a polymorphic Cl_Allocator view backed by the given Cl_Arena.
 *
 * Parameters:
 *   arena (Cl_Arena *) - Initialized arena; must be non-NULL and outlive the returned handle.
 *
 * Returns:
 *   (Cl_Allocator) Allocator handle dispatching operations into arena.
 */
Cl_Allocator cl_arena_allocator(Cl_Arena *arena);

/*
 * Begins a scoped temporary checkpoint on arena and increments temp_count.
 * All subsequent allocations can be bulk-rewound in O(1) via cl_arena_temp_end().
 *
 * Parameters:
 *   arena (Cl_Arena *) - Arena to checkpoint; must be non-NULL.
 *
 * Returns:
 *   (Cl_Arena_Temp) Saved checkpoint recording current offset and prev_offset.
 */
Cl_Arena_Temp cl_arena_temp_begin(Cl_Arena *arena);

/*
 * Rewinds an arena back to a saved checkpoint in O(1), scrubbing rewound bytes
 * with CL_MEM_POISON_FREED in debug builds and poisoning them under ASan.
 *
 * Parameters:
 *   temp (Cl_Arena_Temp) - Checkpoint returned by cl_arena_temp_begin()
 *                          (safe no-op if temp.arena is NULL; must unwind in LIFO order).
 */
void cl_arena_temp_end(Cl_Arena_Temp temp);

/*
 * Queries the remaining unallocated space in the arena (cap - offset).
 *
 * Parameters:
 *   arena (const Cl_Arena *) - Arena to inspect (may be NULL).
 *
 * Returns:
 *   (cl_isize) Remaining free capacity in bytes, or 0 if arena is NULL.
 */
static inline cl_isize cl_arena_remaining(const Cl_Arena *arena) {
    return arena ? (arena->cap - arena->offset) : 0;
}

/*
 * Queries the number of bytes currently consumed in the arena (offset).
 *
 * Parameters:
 *   arena (const Cl_Arena *) - Arena to inspect (may be NULL).
 *
 * Returns:
 *   (cl_isize) Currently used bytes, or 0 if arena is NULL.
 */
static inline cl_isize cl_arena_used(const Cl_Arena *arena) {
    return arena ? arena->offset : 0;
}

#endif /* CL_ARENA_H */
