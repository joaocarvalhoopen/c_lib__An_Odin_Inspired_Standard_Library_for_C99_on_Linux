/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_pool.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   O(1) fixed-size block pool allocator (`Cl_Pool`) using an intrusive
 *   free list. Supports arbitrary individual alloc/free in O(1) with zero
 *   fragmentation and optional AddressSanitizer poisoning of freed chunks.
 *
 * When to Use Cl_Pool:
 *   - Game entities, AST/graph nodes, network packets, or worker tasks that
 *     all share a fixed maximum struct size and have arbitrary lifetimes.
 *
 * Trade-offs:
 *   - Allocations larger than `chunk_size` fail (return NULL).
 *   - Cannot resize an allocation beyond `chunk_size`.
 * ============================================================================
 */

#ifndef CL_POOL_H
#define CL_POOL_H

#include "cl_alloc.h"

/*
 * Intrusive singly-linked free-list node overlaid in place inside each
 * unoccupied pool chunk.
 *
 * Fields:
 *   next (struct Cl_Pool_Node *) - Pointer to the next free chunk, or NULL at list tail.
 */
typedef struct Cl_Pool_Node {
    struct Cl_Pool_Node *next;
} Cl_Pool_Node;

/*
 * O(1) fixed-size block pool allocator descriptor using an intrusive free list.
 *
 * Fields:
 *   base          (cl_u8 *)        - Aligned base pointer of the contiguous chunk storage array.
 *   cap_bytes     (cl_isize)       - Total usable pool storage in bytes (chunk_count * chunk_size).
 *   chunk_size    (cl_isize)       - Stride of each chunk slot in bytes (>= sizeof(Cl_Pool_Node),
 *                                    rounded up to chunk_align).
 *   chunk_count   (cl_isize)       - Total number of fixed-size slots in the pool (chunk count).
 *   used_count    (cl_isize)       - Number of currently allocated slots (chunk count).
 *   free_head     (Cl_Pool_Node *) - Head of the intrusive free list, or NULL when pool is full.
 *   backing_alloc (Cl_Allocator)   - Owning allocator used to free base in cl_pool_destroy(),
 *                                    or invalid (proc == NULL) for caller-owned buffers.
 */
typedef struct Cl_Pool {
    cl_u8        *base;          /* Backing buffer */
    cl_isize      cap_bytes;     /* Total buffer capacity in bytes */
    cl_isize      chunk_size;    /* Aligned size of each slot (>= sizeof(void*)) */
    cl_isize      chunk_count;   /* Total number of slots */
    cl_isize      used_count;    /* Number of currently allocated slots */
    Cl_Pool_Node *free_head;     /* Head of intrusive free list */
    Cl_Allocator  backing_alloc; /* Non-NULL if pool owns `base` */
} Cl_Pool;

/*
 * Initializes a Cl_Pool over a caller-provided memory buffer without taking
 * ownership. Aligns buffer forward to chunk_align and slices it into equal
 * slots of aligned chunk_size bytes.
 *
 * Parameters:
 *   pool        (Cl_Pool *) - Pool descriptor to initialize; must be non-NULL.
 *   buffer      (void *)    - Backing buffer pointer (NULL causes false return).
 *   buffer_size (cl_isize)  - Total size of buffer in bytes (<= 0 causes false return).
 *   chunk_size  (cl_isize)  - Minimum payload size per chunk in bytes (> 0; clamped up to
 *                             sizeof(Cl_Pool_Node) and rounded up to chunk_align).
 *   chunk_align (cl_isize)  - Power-of-two chunk alignment in bytes (<= 0 defaults to
 *                             CL_DEFAULT_ALIGNMENT; clamped up to sizeof(void *)).
 *
 * Returns:
 *   (bool) true if at least one chunk fits and the pool is initialized; false otherwise.
 */
bool cl_pool_init_buffer(
    Cl_Pool *pool,
    void *buffer,
    cl_isize buffer_size,
    cl_isize chunk_size,
    cl_isize chunk_align
);

/*
 * Initializes a Cl_Pool by allocating chunk_count aligned slots from backing.
 * Guards against multiplication overflow when computing (chunk_count * aligned_chunk).
 *
 * Parameters:
 *   pool        (Cl_Pool *)    - Pool descriptor to initialize; must be non-NULL.
 *   chunk_count (cl_isize)     - Number of fixed-size chunks to allocate (chunk count; > 0).
 *   chunk_size  (cl_isize)     - Minimum payload size per chunk in bytes (> 0; clamped up to
 *                                sizeof(Cl_Pool_Node) and rounded up to chunk_align).
 *   chunk_align (cl_isize)     - Power-of-two chunk alignment in bytes (<= 0 defaults to
 *                                CL_DEFAULT_ALIGNMENT; clamped up to sizeof(void *)).
 *   backing     (Cl_Allocator) - Allocator used to allocate and later free the backing buffer.
 *
 * Returns:
 *   (bool) true on success; false on invalid sizes, size overflow, or backing OOM.
 */
bool cl_pool_init_alloc(
    Cl_Pool *pool,
    cl_isize chunk_count,
    cl_isize chunk_size,
    cl_isize chunk_align,
    Cl_Allocator backing
);

/*
 * Unpoisons the pool storage under ASan, frees the backing buffer via
 * backing_alloc if owned, and zeroes the Cl_Pool descriptor; safe no-op if NULL.
 *
 * Parameters:
 *   pool (Cl_Pool *) - Pool to destroy (may be NULL).
 */
void cl_pool_destroy(Cl_Pool *pool);

/*
 * Resets all slots in the pool back onto the free list in O(chunk_count),
 * invalidating all active pointers and re-poisoning unoccupied slots under ASan.
 *
 * Parameters:
 *   pool (Cl_Pool *) - Pool to reset (safe no-op if NULL or uninitialized).
 */
void cl_pool_free_all(Cl_Pool *pool);

/*
 * Pops one chunk from the pool free list in O(1), unpoisons it under ASan,
 * and zero-initializes all chunk_size bytes.
 *
 * Parameters:
 *   pool (Cl_Pool *) - Target pool (may be NULL).
 *
 * Returns:
 *   (void *) Pointer to a zero-initialized aligned chunk of pool->chunk_size bytes,
 *            or NULL if pool is NULL or exhausted.
 */
void *cl_pool_alloc(Cl_Pool *pool);

/*
 * Returns a previously allocated chunk pointer back to the pool free list in O(1),
 * validating bounds and chunk alignment, scrubbing bytes with 0xDD in debug builds,
 * and poisoning the slot under ASan.
 *
 * Parameters:
 *   pool (Cl_Pool *) - Owning pool (safe no-op if NULL).
 *   ptr  (void *)    - Chunk pointer previously returned by this pool (safe no-op if NULL;
 *                      must lie within [base, base + cap_bytes) on a chunk_size boundary).
 */
void cl_pool_free(Cl_Pool *pool, void *ptr);

/*
 * Returns a polymorphic Cl_Allocator view backed by this Cl_Pool.
 * Allocations larger than chunk_size fail and return NULL.
 *
 * Parameters:
 *   pool (Cl_Pool *) - Initialized pool; must be non-NULL and outlive the returned handle.
 *
 * Returns:
 *   (Cl_Allocator) Allocator handle dispatching operations into pool.
 */
Cl_Allocator cl_pool_allocator(Cl_Pool *pool);

#endif /* CL_POOL_H */
