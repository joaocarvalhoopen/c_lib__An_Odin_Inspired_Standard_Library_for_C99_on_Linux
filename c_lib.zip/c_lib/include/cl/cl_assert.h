/*
 * ============================================================================
 * c_lib - Odin-Inspired C99 Standard Library for Linux
 * File: cl_assert.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Assertions, panics, unimplemented/unreachable guards, and toggleable
 *   development-time bounds checking powered by GCC/Clang primitives
 *   (__builtin_expect for branch prediction, __builtin_trap for exact
 *   debugger halts, and Linux glibc backtrace() for stack traces).
 *
 * Bounds Checking Control:
 *   - Enabled by default in debug builds (CL_BOUNDS_CHECK == 1).
 *   - Compiles away to zero instructions in release builds when NDEBUG is
 *     defined or -DCL_BOUNDS_CHECK=0 is passed.
 *   - Can be explicitly kept ON in optimized builds via -DCL_BOUNDS_CHECK=1.
 * ============================================================================
 */

#ifndef CL_ASSERT_H
#define CL_ASSERT_H

#include "cl_types.h"
#include <stdarg.h>

/* ----------------------------------------------------------------------------
 * Assertion Handler Callback (Odin runtime.Assertion_Failure_Proc)
 * ---------------------------------------------------------------------------- */

/*
 * Function pointer type for custom assertion, panic, and bounds-check failure
 * handlers (matching Odin's runtime.Assertion_Failure_Proc).
 *
 * Parameters:
 *   prefix  (const char *)  - NUL-terminated failure category label (e.g., "PANIC"), or NULL.
 *   message (const char *)  - NUL-terminated failure expression or formatted detail string, or NULL.
 *   loc     (Cl_Source_Loc) - Source file, 1-based line number, and function of the failure site.
 */
typedef void (*Cl_Assert_Proc)(const char *prefix, const char *message, Cl_Source_Loc loc);

/*
 * Default non-returning assertion handler: prints formatted diagnostics and a Linux
 * glibc backtrace to stderr, then halts via CL_TRAP() (when CL_BOUNDS_CHECK_TRAP != 0)
 * or abort().
 *
 * Parameters:
 *   prefix  (const char *)  - NUL-terminated failure category label (defaults to "FATAL" if NULL).
 *   message (const char *)  - NUL-terminated failure detail string (defaults to "(no message)" if NULL).
 *   loc     (Cl_Source_Loc) - Source location of the failing check.
 */
CL_NORETURN void cl_default_assert_proc(const char *prefix, const char *message, Cl_Source_Loc loc);

/*
 * Installs a thread-local assertion failure handler for the calling thread
 * (used by Cl_Context). Passing NULL restores cl_default_assert_proc.
 *
 * Parameters:
 *   proc (Cl_Assert_Proc) - Callback to invoke on assertion failure, or NULL for default.
 */
void           cl_assert_set_proc(Cl_Assert_Proc proc);

/*
 * Queries the active thread-local assertion failure handler for the calling thread.
 *
 * Returns:
 *   Cl_Assert_Proc - Currently installed handler, or cl_default_assert_proc if none is set.
 */
Cl_Assert_Proc cl_assert_get_proc(void);

/*
 * Captures and prints up to 64 call-stack frames to stderr using Linux glibc
 * backtrace() / backtrace_symbols_fd(). Acts as a no-op when CL_ENABLE_BACKTRACE == 0.
 *
 * Parameters:
 *   skip_frames (int, stack frame count) - Number of innermost stack frames to omit;
 *                                          negative values are clamped to 0.
 */
void cl_print_backtrace(int skip_frames);

/*
 * Low-level non-returning failure dispatcher that invokes the active assertion
 * handler with an unformatted expression/message string, then calls abort() if
 * the handler returns. Marked CL_NOINLINE to keep hot paths compact.
 *
 * Parameters:
 *   prefix (const char *)  - NUL-terminated category label (e.g., "ASSERTION FAILED").
 *   expr   (const char *)  - NUL-terminated stringified failing expression or detail text.
 *   loc    (Cl_Source_Loc) - Source location of the failure.
 */
CL_NOINLINE CL_NORETURN void cl_assert_fail(const char *prefix, const char *expr, Cl_Source_Loc loc);

/*
 * Low-level non-returning failure dispatcher that formats a printf-style message
 * into a 1024-byte stack buffer, invokes the active assertion handler, and calls
 * abort() if the handler returns.
 *
 * Parameters:
 *   prefix (const char *)  - NUL-terminated category label (e.g., "PANIC").
 *   loc    (Cl_Source_Loc) - Source location of the failure.
 *   fmt    (const char *)  - Non-NULL printf-style format string.
 *   ...    (variadic args) - Arguments matching format specifiers in fmt.
 */
CL_NOINLINE CL_NORETURN CL_PRINTF_LIKE(3, 4) void cl_assert_fail_fmt(
    const char *prefix,
    Cl_Source_Loc loc,
    const char *fmt,
    ...
);

/*
 * Low-level non-returning dispatcher for single-element bounds-check failures
 * when index is outside [0, len). Formats diagnostics and invokes the active handler.
 *
 * Parameters:
 *   index (cl_isize, 0-based index)  - Out-of-bounds element index that failed validation.
 *   len   (cl_isize, element count)  - Container length defining valid range [0, len).
 *   expr  (const char *)             - NUL-terminated expression text (or NULL).
 *   loc   (Cl_Source_Loc)            - Source location of the bounds check.
 */
CL_NOINLINE CL_NORETURN void cl_bounds_check_index_fail(
    cl_isize index,
    cl_isize len,
    const char *expr,
    Cl_Source_Loc loc
);

/*
 * Low-level non-returning dispatcher for half-open sub-slice range [lo, hi) failures
 * when lo < 0, hi < lo, or hi > len. Formats diagnostics and invokes the active handler.
 *
 * Parameters:
 *   lo   (cl_isize, 0-based index) - Inclusive start index of the requested range.
 *   hi   (cl_isize, 0-based index) - Exclusive end index of the requested range.
 *   len  (cl_isize, element count) - Container length defining valid bounds [0, len].
 *   expr (const char *)            - NUL-terminated range expression text (or NULL).
 *   loc  (Cl_Source_Loc)           - Source location of the bounds check.
 */
CL_NOINLINE CL_NORETURN void cl_bounds_check_range_fail(
    cl_isize lo,
    cl_isize hi,
    cl_isize len,
    const char *expr,
    Cl_Source_Loc loc
);

/* ----------------------------------------------------------------------------
 * Runtime Assertions & Panics
 *
 * CL_ENSURE / CL_PANIC / CL_UNIMPLEMENTED remain active even in release builds.
 * CL_ASSERT / CL_ASSERT_MSG are active in debug builds (when NDEBUG is absent).
 * ---------------------------------------------------------------------------- */

/*
 * Always-active runtime invariant check (remains enabled even when NDEBUG is defined).
 * Triggers cl_assert_fail("ENSURE FAILED", ...) if cond evaluates to false (0).
 *
 * Parameters:
 *   cond (scalar expression) - Boolean invariant expression expected to be non-zero.
 */
#define CL_ENSURE(cond) do {                                   \
    if (CL_UNLIKELY(!(cond))) {                                \
        cl_assert_fail("ENSURE FAILED", #cond, CL_HERE);       \
    }                                                          \
} while (0)

/*
 * Always-active runtime invariant check with a printf-style diagnostic message
 * (remains enabled even when NDEBUG is defined).
 *
 * Parameters:
 *   cond (scalar expression) - Boolean invariant expression expected to be non-zero.
 *   ...  (fmt, args...)      - printf format string followed by optional arguments.
 */
#define CL_ENSURE_MSG(cond, ...) do {                          \
    if (CL_UNLIKELY(!(cond))) {                                \
        cl_assert_fail_fmt("ENSURE FAILED", CL_HERE, __VA_ARGS__); \
    }                                                          \
} while (0)

/*
 * Unconditionally aborts execution with a formatted printf-style panic message
 * and current call-site location. Always active in both debug and release builds.
 *
 * Parameters:
 *   ... (fmt, args...) - printf format string followed by optional arguments.
 */
#define CL_PANIC(...) \
    cl_assert_fail_fmt("PANIC", CL_HERE, __VA_ARGS__)

/*
 * Marks an unimplemented code path; unconditionally fails at runtime with
 * category "UNIMPLEMENTED" in both debug and release builds.
 */
#define CL_UNIMPLEMENTED() \
    cl_assert_fail("UNIMPLEMENTED", "not yet implemented", CL_HERE)

#ifdef NDEBUG
    /*
     * Debug-only assertion compiled out to a no-op under NDEBUG.
     *
     * Parameters:
     *   cond (scalar expression) - Unevaluated condition when NDEBUG is defined.
     */
    #define CL_ASSERT(cond)          ((void)0)

    /*
     * Debug-only formatted assertion compiled out to a no-op under NDEBUG.
     *
     * Parameters:
     *   cond (scalar expression) - Unevaluated condition when NDEBUG is defined.
     *   ...  (fmt, args...)      - Unevaluated format string and arguments.
     */
    #define CL_ASSERT_MSG(cond, ...) ((void)0)

    /*
     * Marks a control-flow path as unreachable; expands to CL_UNREACHABLE_HW()
     * optimizer hint under NDEBUG (undefined behavior if ever reached).
     */
    #define CL_UNREACHABLE()         CL_UNREACHABLE_HW()
#else
    /*
     * Debug-only runtime assertion; triggers cl_assert_fail("ASSERTION FAILED", ...)
     * if cond evaluates to false (0).
     *
     * Parameters:
     *   cond (scalar expression) - Condition expected to be non-zero.
     */
    #define CL_ASSERT(cond) do {                               \
        if (CL_UNLIKELY(!(cond))) {                            \
            cl_assert_fail("ASSERTION FAILED", #cond, CL_HERE); \
        }                                                      \
    } while (0)

    /*
     * Debug-only runtime assertion with printf-style formatted diagnostic message.
     *
     * Parameters:
     *   cond (scalar expression) - Condition expected to be non-zero.
     *   ...  (fmt, args...)      - printf format string followed by optional arguments.
     */
    #define CL_ASSERT_MSG(cond, ...) do {                      \
        if (CL_UNLIKELY(!(cond))) {                            \
            cl_assert_fail_fmt("ASSERTION FAILED", CL_HERE, __VA_ARGS__); \
        }                                                      \
    } while (0)

    /*
     * Marks a control-flow path as unreachable; traps via cl_assert_fail("UNREACHABLE", ...)
     * in debug builds if execution ever reaches this statement.
     */
    #define CL_UNREACHABLE() \
        cl_assert_fail("UNREACHABLE", "reached unreachable code path", CL_HERE)
#endif

/* ----------------------------------------------------------------------------
 * Toggleable Bounds Checking Macros
 *
 * When CL_BOUNDS_CHECK == 1:
 *   Validates 0 <= idx < len (and 0 <= lo <= hi <= len for sub-slices) using
 *   GCC/Clang branch prediction (__builtin_expect). Traps on violation.
 * When CL_BOUNDS_CHECK == 0:
 *   Compiles away to ((void)0) with zero runtime instructions.
 * ---------------------------------------------------------------------------- */

#if CL_BOUNDS_CHECK
    /*
     * Validates that a 0-based index satisfies 0 <= idx < len, calling
     * cl_bounds_check_index_fail() on out-of-bounds access.
     *
     * Parameters:
     *   idx  (cl_isize, 0-based index) - Element index to validate.
     *   len  (cl_isize, element count) - Container length; valid indices are [0, len).
     *   expr (const char *)            - NUL-terminated expression label for diagnostics.
     *   loc  (Cl_Source_Loc)           - Call-site source location.
     *
     * Returns:
     *   cl_isize - The validated 0-based index idx.
     */
    static inline cl_isize cl_check_index_inline(
        cl_isize idx,
        cl_isize len,
        const char *expr,
        Cl_Source_Loc loc
    ) {
        if (CL_UNLIKELY(idx < 0 || idx >= len)) {
            cl_bounds_check_index_fail(idx, len, expr, loc);
        }
        return idx;
    }

    /*
     * Validates that a half-open sub-slice range [lo, hi) satisfies 0 <= lo <= hi <= len,
     * calling cl_bounds_check_range_fail() on violation.
     *
     * Parameters:
     *   lo   (cl_isize, 0-based index) - Inclusive start index.
     *   hi   (cl_isize, 0-based index) - Exclusive end index.
     *   len  (cl_isize, element count) - Container length defining valid bounds [0, len].
     *   expr (const char *)            - NUL-terminated range label for diagnostics.
     *   loc  (Cl_Source_Loc)           - Call-site source location.
     */
    static inline void cl_check_range_inline(
        cl_isize lo,
        cl_isize hi,
        cl_isize len,
        const char *expr,
        Cl_Source_Loc loc
    ) {
        if (CL_UNLIKELY(lo < 0 || hi < lo || hi > len)) {
            cl_bounds_check_range_fail(lo, hi, len, expr, loc);
        }
    }

    /*
     * Checks 0 <= idx < len at runtime (when CL_BOUNDS_CHECK == 1) and evaluates
     * to the validated index as cl_isize.
     *
     * Parameters:
     *   idx (integral expression, 0-based index) - Index to validate.
     *   len (integral expression, element count) - Container length.
     *
     * Returns:
     *   cl_isize - Validated 0-based index idx.
     */
    #define CL_BOUNDS_CHECK_INDEX(idx, len) \
        cl_check_index_inline((cl_isize)(idx), (cl_isize)(len), #idx " in [0, " #len ")", CL_HERE)

    /*
     * Checks 0 <= lo <= hi <= len for a half-open slice range [lo, hi) at runtime
     * (when CL_BOUNDS_CHECK == 1).
     *
     * Parameters:
     *   lo  (integral expression, 0-based index) - Inclusive start index.
     *   hi  (integral expression, 0-based index) - Exclusive end index.
     *   len (integral expression, element count) - Container length.
     */
    #define CL_BOUNDS_CHECK_RANGE(lo, hi, len) \
        cl_check_range_inline((cl_isize)(lo), (cl_isize)(hi), (cl_isize)(len), "[" #lo ":" #hi "] in [0, " #len "]", CL_HERE)
#else
    /*
     * Disabled bounds-check fallback (CL_BOUNDS_CHECK == 0): casts idx to cl_isize
     * with zero runtime check overhead.
     *
     * Parameters:
     *   idx (integral expression, 0-based index) - Element index passed through unchecked.
     *   len (integral expression, element count) - Unused length argument.
     *
     * Returns:
     *   cl_isize - Unchecked index cast to cl_isize.
     */
    #define CL_BOUNDS_CHECK_INDEX(idx, len)    ((cl_isize)(idx))

    /*
     * Disabled range bounds-check fallback (CL_BOUNDS_CHECK == 0): compiles to a no-op.
     *
     * Parameters:
     *   lo  (integral expression, 0-based index) - Unused start index.
     *   hi  (integral expression, 0-based index) - Unused end index.
     *   len (integral expression, element count) - Unused container length.
     */
    #define CL_BOUNDS_CHECK_RANGE(lo, hi, len) ((void)0)
#endif

#endif /* CL_ASSERT_H */
