/*
 * ============================================================================
 * c_lib_unit_tests - Suite 7: HashMap (Dense Arrays + Swiss H2 Control Bytes)
 * File: test_hashmap.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 * ============================================================================
 */

#include "cl_test.h"

typedef struct Coord_Key {
    cl_i32 x;
    cl_i32 y;
} Coord_Key;

CL_MAP_DEFINE(Map_Coord_F64, Coord_Key, cl_f64);

/* Deliberate bad-hasher test: forces 100% hash collisions to stress probe chains */
static cl_u64 colliding_hash(const void *key, cl_isize key_size) {
    CL_UNUSED_VAR(key);
    CL_UNUSED_VAR(key_size);
    return 0x123456789ABCDEF0ull;
}

static void test_hashmap_str_keys_and_value_equality(Cl_Test_State *t) {
    Cl_Map_Str_I64 m = {0};
    CL_MAP_INIT_STR(&m, cl_ctx_allocator());
    CL_DEFER_MAP(m);

    CL_TEST_CHECK(t, CL_MAP_PUT(&m, CL_STR("alpha"), 1));
    CL_TEST_CHECK(t, CL_MAP_PUT(&m, CL_STR("beta"),  2));
    CL_TEST_CHECK(t, CL_MAP_PUT(&m, CL_STR("gamma"), 3));
    /* Overwrite returns false (not newly inserted) */
    CL_TEST_CHECK(t, !CL_MAP_PUT(&m, CL_STR("beta"), 200));
    CL_TEST_EQ_I64(t, CL_MAP_LEN(&m), 3);

    /* Lookup using a DIFFERENT memory buffer containing identical bytes */
    char stack_key[] = "beta";
    Cl_Str dynamic_view = cl_str_from_cstr(stack_key);
    cl_i64 *val = CL_MAP_GET(&m, dynamic_view);
    CL_TEST_CHECK(t, val != NULL && *val == 200);
    CL_TEST_EQ_I64(t, CL_MAP_GET_OR(&m, CL_STR("missing"), -99), -99);
    CL_TEST_CHECK(t, CL_MAP_CONTAINS(&m, CL_STR("alpha")));
    CL_TEST_CHECK(t, !CL_MAP_CONTAINS(&m, CL_STR("delta")));

    /* Delete middle element and verify remaining elements stay reachable */
    CL_TEST_CHECK(t, CL_MAP_DELETE(&m, CL_STR("alpha")));
    CL_TEST_CHECK(t, !CL_MAP_DELETE(&m, CL_STR("alpha")));
    CL_TEST_EQ_I64(t, CL_MAP_LEN(&m), 2);
    CL_TEST_CHECK(t, CL_MAP_GET(&m, CL_STR("alpha")) == NULL);
    CL_TEST_EQ_I64(t, *CL_MAP_GET(&m, CL_STR("beta")), 200);
    CL_TEST_EQ_I64(t, *CL_MAP_GET(&m, CL_STR("gamma")), 3);

    /* Dense iteration sums all values */
    cl_i64 sum = 0;
    CL_MAP_FOR_EACH(i, &m) {
        sum += m.values[i];
    }
    CL_TEST_EQ_I64(t, sum, 203);
}

static void test_hashmap_large_rehash_and_tombstones(Cl_Test_State *t) {
    Cl_Map_I64_I64 m = {0};
    CL_MAP_INIT_I64(&m, cl_ctx_allocator());
    CL_DEFER_MAP(m);

    /* Insert 2000 entries -> forces multiple rehashes */
    for (cl_i64 i = 0; i < 2000; i++) {
        CL_TEST_CHECK(t, CL_MAP_PUT(&m, i, i * i));
    }
    CL_TEST_EQ_I64(t, CL_MAP_LEN(&m), 2000);

    /* Delete all even keys (1000 tombstones + dense swap-removes) */
    for (cl_i64 i = 0; i < 2000; i += 2) {
        CL_TEST_CHECK(t, CL_MAP_DELETE(&m, i));
    }
    CL_TEST_EQ_I64(t, CL_MAP_LEN(&m), 1000);

    /* Verify odd keys intact and even keys gone */
    for (cl_i64 i = 0; i < 2000; i++) {
        cl_i64 *v = CL_MAP_GET(&m, i);
        if (i % 2 == 0) {
            CL_TEST_CHECK(t, v == NULL);
        } else {
            CL_TEST_CHECK(t, v != NULL && *v == i * i);
        }
    }

    /* Re-insert even keys -> exercises tombstone reclamation & rehash */
    for (cl_i64 i = 0; i < 2000; i += 2) {
        CL_TEST_CHECK(t, CL_MAP_PUT(&m, i, i + 1));
    }
    CL_TEST_EQ_I64(t, CL_MAP_LEN(&m), 2000);
    for (cl_i64 i = 0; i < 2000; i += 2) {
        cl_i64 *v = CL_MAP_GET(&m, i);
        CL_TEST_CHECK(t, v != NULL && *v == i + 1);
    }

    CL_MAP_CLEAR(&m);
    CL_TEST_EQ_I64(t, CL_MAP_LEN(&m), 0);
    CL_TEST_CHECK(t, CL_MAP_GET(&m, 1) == NULL);
}

static void test_hashmap_total_collision_and_pod_struct_keys(Cl_Test_State *t) {
    /* Stress probe chains & swap-delete under 100% hash collision */
    Cl_Map_I64_I64 cm = {0};
    CL_MAP_INIT(&cm, cl_ctx_allocator(), colliding_hash, cl_map_eq_i64);
    CL_DEFER_MAP(cm);

    for (cl_i64 i = 0; i < 64; i++) {
        CL_TEST_CHECK(t, CL_MAP_PUT(&cm, i, i * 10));
    }
    for (cl_i64 i = 0; i < 64; i += 3) {
        CL_TEST_CHECK(t, CL_MAP_DELETE(&cm, i));
    }
    for (cl_i64 i = 0; i < 64; i++) {
        cl_i64 *v = CL_MAP_GET(&cm, i);
        if (i % 3 == 0) {
            CL_TEST_CHECK(t, v == NULL);
        } else {
            CL_TEST_CHECK(t, v != NULL && *v == i * 10);
        }
    }

    /* Zero-initialized POD struct key map (no explicit INIT required!) */
    Map_Coord_F64 pm = {0};
    CL_DEFER_MAP(pm);
    CL_MAP_PUT(&pm, ((Coord_Key){ 3, 4 }), 5.0);
    CL_MAP_PUT(&pm, ((Coord_Key){ -1, 2 }), 2.236);
    cl_f64 *d = CL_MAP_GET(&pm, ((Coord_Key){ 3, 4 }));
    CL_TEST_CHECK(t, d != NULL);
    CL_TEST_NEAR_F64(t, *d, 5.0, 1e-12);

    /* Complex128 values inside string-keyed map */
    Cl_Map_Str_C128 zmap = {0};
    CL_MAP_INIT_STR(&zmap, cl_ctx_allocator());
    CL_DEFER_MAP(zmap);
    CL_MAP_PUT(&zmap, CL_STR("impedance"), cl_c128_make(50.0, -12.5));
    cl_c128 *zp = CL_MAP_GET(&zmap, CL_STR("impedance"));
    CL_TEST_CHECK(t, zp != NULL);
    CL_TEST_NEAR_C128(t, *zp, cl_c128_make(50.0, -12.5), 1e-12);
}

void suite_hashmap(Cl_Test_State *t) {
    CL_RUN_TEST(t, test_hashmap_str_keys_and_value_equality);
    CL_RUN_TEST(t, test_hashmap_large_rehash_and_tombstones);
    CL_RUN_TEST(t, test_hashmap_total_collision_and_pod_struct_keys);
}
