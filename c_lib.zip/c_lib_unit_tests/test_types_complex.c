/*
 * ============================================================================
 * c_lib_unit_tests - Suite 1: Types, Endian, Complex64/128 & Quaternions
 * File: test_types_complex.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 * ============================================================================
 */

#include "cl_test.h"

static void test_scalar_widths_and_endian(Cl_Test_State *t) {
    CL_TEST_EQ_I64(t, sizeof(cl_i8),  1);
    CL_TEST_EQ_I64(t, sizeof(cl_i16), 2);
    CL_TEST_EQ_I64(t, sizeof(cl_i32), 4);
    CL_TEST_EQ_I64(t, sizeof(cl_i64), 8);
    CL_TEST_EQ_I64(t, sizeof(cl_u8),  1);
    CL_TEST_EQ_I64(t, sizeof(cl_u16), 2);
    CL_TEST_EQ_I64(t, sizeof(cl_u32), 4);
    CL_TEST_EQ_I64(t, sizeof(cl_u64), 8);
    CL_TEST_EQ_I64(t, sizeof(cl_f32), 4);
    CL_TEST_EQ_I64(t, sizeof(cl_f64), 8);
    CL_TEST_EQ_I64(t, sizeof(cl_c64), 8);
    CL_TEST_EQ_I64(t, sizeof(cl_c128), 16);

    cl_u8 buf[8];
    cl_write_u16_le(buf, 0x1234u);
    CL_TEST_EQ_U64(t, buf[0], 0x34u);
    CL_TEST_EQ_U64(t, buf[1], 0x12u);
    CL_TEST_EQ_U64(t, cl_read_u16_le(buf), 0x1234u);

    cl_write_u16_be(buf, 0x1234u);
    CL_TEST_EQ_U64(t, buf[0], 0x12u);
    CL_TEST_EQ_U64(t, buf[1], 0x34u);
    CL_TEST_EQ_U64(t, cl_read_u16_be(buf), 0x1234u);

    cl_write_u32_le(buf, 0xDEADBEEFu);
    CL_TEST_EQ_U64(t, cl_read_u32_le(buf), 0xDEADBEEFu);
    CL_TEST_EQ_U64(t, cl_bswap32(0x12345678u), 0x78563412u);

    cl_write_u64_be(buf, 0x0102030405060708ull);
    CL_TEST_EQ_U64(t, buf[0], 0x01u);
    CL_TEST_EQ_U64(t, buf[7], 0x08u);
    CL_TEST_EQ_U64(t, cl_read_u64_be(buf), 0x0102030405060708ull);
    CL_TEST_EQ_U64(t, cl_bswap64(0x0102030405060708ull), 0x0807060504030201ull);

    /* Min/Max/Clamp/Swap */
    int a = 10, b = 25;
    CL_TEST_EQ_I64(t, CL_MIN(a, b), 10);
    CL_TEST_EQ_I64(t, CL_MAX(a, b), 25);
    CL_TEST_EQ_I64(t, CL_CLAMP(50, 0, 20), 20);
    CL_TEST_EQ_I64(t, CL_CLAMP(-5, 0, 20), 0);
    CL_SWAP(a, b);
    CL_TEST_EQ_I64(t, a, 25);
    CL_TEST_EQ_I64(t, b, 10);

    /* Shorthand printf cast macros CL_LL / CL_ULL and <inttypes.h> */
    char fmt_buf[64];
    cl_i64 s64 = -123456789012LL;
    cl_u64 u64 = 123456789012ULL;
    snprintf(fmt_buf, sizeof(fmt_buf), "%lld:%llu", (CL_LL)s64, (CL_ULL)u64);
    CL_TEST_EQ_STR(t, cl_str_from_cstr(fmt_buf), CL_STR("-123456789012:123456789012"));
    snprintf(fmt_buf, sizeof(fmt_buf), "%" PRId64 ":%" PRIu64, s64, u64);
    CL_TEST_EQ_STR(t, cl_str_from_cstr(fmt_buf), CL_STR("-123456789012:123456789012"));
}

static void test_complex64_math(Cl_Test_State *t) {
    cl_c64 a = cl_c64_make(3.0f, 4.0f);
    cl_c64 b = cl_c64_make(1.0f, -2.0f);

    /* Native C99 arithmetic operators: +, -, *, / */
    CL_TEST_NEAR_C64(t, a + b, cl_c64_make(4.0f, 2.0f), 1e-6f);
    CL_TEST_NEAR_C64(t, a - b, cl_c64_make(2.0f, 6.0f), 1e-6f);
    /* (3 + 4i) * (1 - 2i) = 3 - 6i + 4i - 8i^2 = 11 - 2i */
    CL_TEST_NEAR_C64(t, a * b, cl_c64_make(11.0f, -2.0f), 1e-5f);
    /* (11 - 2i) / (1 - 2i) = 3 + 4i */
    CL_TEST_NEAR_C64(t, (a * b) / b, a, 1e-5f);

    CL_TEST_NEAR_F64(t, cl_c64_abs(a), 5.0, 1e-6);
    CL_TEST_NEAR_F64(t, cl_c64_abs2(a), 25.0, 1e-6);
    CL_TEST_NEAR_C64(t, cl_c64_conj(a), cl_c64_make(3.0f, -4.0f), 1e-6f);

    /* Polar form and Euler identity: e^(i*pi) + 1 = 0 */
    cl_c64 p = cl_c64_from_polar(5.0f, cl_c64_arg(a));
    CL_TEST_NEAR_C64(t, p, a, 1e-5f);
    cl_c64 euler = cl_c64_exp(cl_c64_make(0.0f, CL_PI_F32)) + cl_c64_make(1.0f, 0.0f);
    CL_TEST_NEAR_C64(t, euler, cl_c64_make(0.0f, 0.0f), 1e-5f);

    /* sqrt(-1) = i */
    CL_TEST_NEAR_C64(t, cl_c64_sqrt(cl_c64_make(-1.0f, 0.0f)), cl_c64_make(0.0f, 1.0f), 1e-6f);
    CL_TEST_CHECK(t, cl_c64_is_finite(a));

    /* Verify C99 binary layout matches float[2] for FFTW/BLAS/Odin interop */
    cl_f32 raw[2];
    cl_mem_copy(raw, &a, (cl_isize)sizeof(raw));
    CL_TEST_NEAR_F64(t, raw[0], 3.0, 1e-6);
    CL_TEST_NEAR_F64(t, raw[1], 4.0, 1e-6);
}

static void test_complex128_math(Cl_Test_State *t) {
    cl_c128 z = cl_c128_make(1.5, -2.5);
    cl_c128 w = cl_c128_make(-0.5, 4.0);

    /* (1.5 - 2.5i) * (-0.5 + 4i) = -0.75 + 6i + 1.25i + 10 = 9.25 + 7.25i */
    CL_TEST_NEAR_C128(t, z * w, cl_c128_make(9.25, 7.25), 1e-12);
    CL_TEST_NEAR_C128(t, (z * w) / w, z, 1e-12);

    /* Euler identity in double precision: e^(i*pi) + 1 = 0 */
    cl_c128 euler = cl_c128_exp(cl_c128_make(0.0, CL_PI_F64)) + cl_c128_make(1.0, 0.0);
    CL_TEST_NEAR_C128(t, euler, cl_c128_make(0.0, 0.0), 1e-12);

    /* log(exp(z)) == z (for Im(z) in (-pi, pi)) */
    CL_TEST_NEAR_C128(t, cl_c128_log(cl_c128_exp(z)), z, 1e-12);

    /* sin(z)^2 + cos(z)^2 == 1 */
    cl_c128 sz = cl_c128_sin(z);
    cl_c128 cz = cl_c128_cos(z);
    CL_TEST_NEAR_C128(t, sz * sz + cz * cz, cl_c128_make(1.0, 0.0), 1e-12);

    /* (1 + i)^2 = 2i */
    cl_c128 base = cl_c128_make(1.0, 1.0);
    CL_TEST_NEAR_C128(t, cl_c128_pow(base, cl_c128_make(2.0, 0.0)), cl_c128_make(0.0, 2.0), 1e-12);

    /* Narrowing / widening conversions */
    cl_c64 narrowed = cl_c128_to_c64(z);
    CL_TEST_NEAR_C128(t, cl_c64_to_c128(narrowed), z, 1e-6);
}

static void test_quaternions(Cl_Test_State *t) {
    /* Two 90-degree rotations around Z equal one 180-degree rotation around Z */
    Cl_Quat128 q90  = cl_quat128_from_axis_angle(0.0f, 0.0f, 1.0f, CL_PI_F32 * 0.5f);
    Cl_Quat128 q180 = cl_quat128_mul(q90, q90);
    CL_TEST_NEAR_F64(t, q180.z, 1.0, 1e-5);
    CL_TEST_NEAR_F64(t, q180.w, 0.0, 1e-5);

    /* q * conj(q) == identity for unit quaternion */
    Cl_Quat256 dq = cl_quat256_from_axis_angle(1.0, 2.0, 3.0, 1.2345);
    Cl_Quat256 id = cl_quat256_mul(dq, cl_quat256_conj(dq));
    CL_TEST_NEAR_F64(t, id.x, 0.0, 1e-12);
    CL_TEST_NEAR_F64(t, id.y, 0.0, 1e-12);
    CL_TEST_NEAR_F64(t, id.z, 0.0, 1e-12);
    CL_TEST_NEAR_F64(t, id.w, 1.0, 1e-12);

    /* SLERP midpoint between identity and 90 deg is 45 deg */
    Cl_Quat256 a = cl_quat256_identity();
    Cl_Quat256 b = cl_quat256_from_axis_angle(0.0, 1.0, 0.0, CL_PI_F64 * 0.5);
    Cl_Quat256 mid = cl_quat256_slerp(a, b, 0.5);
    Cl_Quat256 exp_mid = cl_quat256_from_axis_angle(0.0, 1.0, 0.0, CL_PI_F64 * 0.25);
    CL_TEST_NEAR_F64(t, mid.y, exp_mid.y, 1e-12);
    CL_TEST_NEAR_F64(t, mid.w, exp_mid.w, 1e-12);
}

void suite_types_complex(Cl_Test_State *t) {
    CL_RUN_TEST(t, test_scalar_widths_and_endian);
    CL_RUN_TEST(t, test_complex64_math);
    CL_RUN_TEST(t, test_complex128_math);
    CL_RUN_TEST(t, test_quaternions);
}
