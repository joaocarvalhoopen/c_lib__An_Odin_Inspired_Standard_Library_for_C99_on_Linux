/*
 * ============================================================================
 * c_lib_unit_tests - Suite 5: Defer Tiers & Multiple Return Values
 * File: test_defer_result.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 * ============================================================================
 */

#include "cl_test.h"

typedef struct Defer_Log {
    int order[8];
    int count;
} Defer_Log;

typedef struct Defer_Item {
    Defer_Log *log;
    int        id;
} Defer_Item;

static void record_defer(void *arg) {
    Defer_Item *it = (Defer_Item *)arg;
    if (it->log->count < 8) {
        it->log->order[it->log->count++] = it->id;
    }
}

static int helper_early_return_defer(Defer_Log *log, bool exit_early) {
    Defer_Item i1 = { log, 1 };
    Defer_Item i2 = { log, 2 };
    Defer_Item i3 = { log, 3 };

    CL_DEFER_FN(record_defer, &i1);
    CL_DEFER_FN(record_defer, &i2);
    if (exit_early) {
        return 100;
    }
    CL_DEFER_FN(record_defer, &i3);
    return 200;
}

static void test_tier1_cleanup_lifo_and_early_return(Cl_Test_State *t) {
    Defer_Log log = {0};
    int r1 = helper_early_return_defer(&log, true);
    CL_TEST_EQ_I64(t, r1, 100);
    CL_TEST_EQ_I64(t, log.count, 2);
    CL_TEST_EQ_I64(t, log.order[0], 2);
    CL_TEST_EQ_I64(t, log.order[1], 1);

    CL_ZERO_STRUCT(&log);
    int r2 = helper_early_return_defer(&log, false);
    CL_TEST_EQ_I64(t, r2, 200);
    CL_TEST_EQ_I64(t, log.count, 3);
    CL_TEST_EQ_I64(t, log.order[0], 3);
    CL_TEST_EQ_I64(t, log.order[1], 2);
    CL_TEST_EQ_I64(t, log.order[2], 1);
}

static void test_tier1_resource_defers(Cl_Test_State *t) {
    /* Everything allocated inside this block MUST be auto-freed on exit */
    {
        Cl_Allocator a = cl_ctx_allocator();
        void *raw = cl_alloc(a, 128);
        CL_DEFER_FREE(a, raw, 128);

        Cl_DA_I64 da = {0};
        CL_DEFER_DA(da);
        for (cl_i64 i = 0; i < 32; i++) {
            CL_DA_PUSH(&da, i);
        }

        Cl_Map_Str_I64 m = {0};
        CL_MAP_INIT_STR(&m, a);
        CL_DEFER_MAP(m);
        CL_MAP_PUT(&m, CL_STR("k"), 99);

        Cl_String_Builder sb = {0};
        cl_sb_init(&sb, a);
        CL_DEFER_SB(sb);
        cl_sb_write_cstr(&sb, "hello defer");

        CL_TEST_EQ_I64(t, da.len, 32);
        CL_TEST_EQ_I64(t, CL_MAP_LEN(&m), 1);
        CL_TEST_EQ_STR(t, cl_sb_to_str(&sb), CL_STR("hello defer"));
    }
    /* Outer tracking allocator automatically verifies 0 bytes leaked! */
}

static void test_tier2_and_tier3_pure_c99_defers(Cl_Test_State *t) {
    /* Tier 2: CL_DEFER_LOOP & CL_WITH_TEMP */
    int state = 0;
    CL_DEFER_LOOP(state = 1, state = 2) {
        CL_TEST_EQ_I64(t, state, 1);
        if (state == 1) {
            continue; /* continue executes the post-expression (state = 2) and exits! */
        }
        state = 999; /* unreachable because continue exited early */
    }
    CL_TEST_EQ_I64(t, state, 2);

    cl_u8 buf[1024];
    Cl_Arena arena;
    cl_arena_init_buffer(&arena, buf, (cl_isize)sizeof(buf));
    CL_DEFER_ARENA(arena);

    CL_WITH_TEMP(&arena) {
        void *p = cl_alloc(cl_arena_allocator(&arena), 256);
        CL_TEST_CHECK(t, p != NULL);
        CL_TEST_CHECK(t, cl_arena_used(&arena) >= 256);
    }
    CL_TEST_EQ_I64(t, cl_arena_used(&arena), 0);

    /* Tier 3: Pure C99 Cl_Defer_Stack */
    Defer_Log log = {0};
    Defer_Item a = { &log, 10 };
    Defer_Item b = { &log, 20 };
    Cl_Defer_Stack ds;
    cl_defer_stack_init(&ds);
    CL_TEST_CHECK(t, cl_defer_stack_push(&ds, record_defer, &a));
    CL_TEST_CHECK(t, cl_defer_stack_push(&ds, record_defer, &b));
    cl_defer_stack_run(&ds);
    CL_TEST_EQ_I64(t, log.count, 2);
    CL_TEST_EQ_I64(t, log.order[0], 20);
    CL_TEST_EQ_I64(t, log.order[1], 10);
}

/* Multiple return value helpers */
CL_PAIR_DEFINE(Div_Mod, cl_i64, cl_i64);

static Cl_Res_I64 safe_div(cl_i64 a, cl_i64 b) {
    if (b == 0) {
        return CL_ERR(Cl_Res_I64, CL_ERR_INVALID_ARG);
    }
    return CL_OK(Cl_Res_I64, a / b);
}

static Cl_Res_I64 chained_compute(cl_i64 x, cl_i64 y) {
    cl_i64 q = 0;
    CL_OR_RETURN(q, safe_div(x, y), Cl_Res_I64);
    return CL_OK(Cl_Res_I64, q * 3);
}

static Cl_Opt_I64 parse_port(Cl_Str s) {
    cl_i64 v = 0;
    CL_OPT_OR_RETURN(v, cl_str_parse_i64(s, 10), Cl_Opt_I64);
    if (v < 1 || v > 65535) {
        return CL_NONE(Cl_Opt_I64);
    }
    return CL_SOME(Cl_Opt_I64, v);
}

static Div_Mod divmod_i64(cl_i64 a, cl_i64 b) {
    return (Div_Mod){ a / b, a % b };
}

static void test_multiple_returns_and_propagation(Cl_Test_State *t) {
    Cl_Res_I64 ok = chained_compute(30, 5);
    CL_TEST_EQ_I64(t, ok.err, CL_ERR_NONE);
    CL_TEST_EQ_I64(t, ok.value, 18);

    Cl_Res_I64 bad = chained_compute(30, 0);
    CL_TEST_EQ_I64(t, bad.err, CL_ERR_INVALID_ARG);

    Cl_Opt_I64 p1 = parse_port(CL_STR("8080"));
    CL_TEST_CHECK(t, p1.ok && p1.value == 8080);

    Cl_Opt_I64 p2 = parse_port(CL_STR("99999"));
    CL_TEST_CHECK(t, !p2.ok);

    cl_i64 port = CL_OR_ELSE(parse_port(CL_STR("invalid")), 443);
    CL_TEST_EQ_I64(t, port, 443);

    cl_i64 res_or = CL_RES_OR_ELSE(safe_div(10, 0), -1);
    CL_TEST_EQ_I64(t, res_or, -1);

    Div_Mod dm = divmod_i64(17, 5);
    CL_TEST_EQ_I64(t, dm.first, 3);
    CL_TEST_EQ_I64(t, dm.second, 2);

    /* CL_OPT_OR_BREAK in a split loop */
    Cl_Str rest = CL_STR("10,20,30");
    cl_i64 sum = 0;
    for (;;) {
        Cl_Str tok;
        CL_OPT_OR_BREAK(tok, cl_str_split_iter(&rest, CL_STR(",")));
        sum += CL_OPT_OR_PANIC(cl_str_parse_i64(tok, 10));
    }
    CL_TEST_EQ_I64(t, sum, 60);
}

void suite_defer_result(Cl_Test_State *t) {
    CL_RUN_TEST(t, test_tier1_cleanup_lifo_and_early_return);
    CL_RUN_TEST(t, test_tier1_resource_defers);
    CL_RUN_TEST(t, test_tier2_and_tier3_pure_c99_defers);
    CL_RUN_TEST(t, test_multiple_returns_and_propagation);
}
