/*
 * ============================================================================
 * c_lib_unit_tests - Odin-Inspired Leak-Checked Test Harness
 * File: cl_test.h
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Lightweight C99 unit testing framework modeled after Odin's `core:testing`.
 *   Every test automatically runs inside a scoped `Cl_Context` backed by a
 *   `Cl_Tracking_Allocator` (failing immediately if even 1 byte leaks or any
 *   redzone/bad-free violation occurs) and resets the temp allocator on exit.
 *
 *   Also provides `cl_test_expect_trap(fn)` using Linux `fork()`/`waitpid()`
 *   to verify that bounds checks and assertions genuinely trap in debug mode.
 * ============================================================================
 */

#ifndef CL_TEST_H
#define CL_TEST_H

#include "cl/cl.h"
#include <math.h>
#include <stdio.h>

typedef struct Cl_Test_State {
    const char *current_name;
    cl_isize    total_tests;
    cl_isize    passed_tests;
    cl_isize    failed_tests;
    cl_isize    total_checks;
    cl_isize    current_failures;
} Cl_Test_State;

typedef void (*Cl_Test_Proc)(Cl_Test_State *t);
typedef void (*Cl_Trap_Proc)(void);

/* Run one test case wrapped in an automatic Cl_Tracking_Allocator context */
void cl_test_run(Cl_Test_State *state, const char *name, Cl_Test_Proc fn);

/* Fork a child process and verify that `fn()` terminates via signal (trap/abort) */
bool cl_test_expect_trap(Cl_Trap_Proc fn);

/* Internal failure recorder */
void cl_test_fail_loc(Cl_Test_State *t, Cl_Source_Loc loc, const char *expr, const char *detail);

/* Suite registration entry points */
void suite_types_complex(Cl_Test_State *t);
void suite_alloc_arenas(Cl_Test_State *t);
void suite_tracking_safety(Cl_Test_State *t);
void suite_bounds_assert(Cl_Test_State *t);
void suite_defer_result(Cl_Test_State *t);
void suite_slices_arrays(Cl_Test_State *t);
void suite_hashmap(Cl_Test_State *t);
void suite_strings_utf8(Cl_Test_State *t);
void suite_sb_strbuf(Cl_Test_State *t);
void suite_log_os_time(Cl_Test_State *t);

/* ----------------------------------------------------------------------------
 * Test Assertion Macros
 * ---------------------------------------------------------------------------- */

#define CL_RUN_TEST(state, fn) cl_test_run((state), #fn, (fn))

#define CL_TEST_CHECK(t, cond) do {                                   \
    (t)->total_checks += 1;                                           \
    if (!(cond)) {                                                    \
        cl_test_fail_loc((t), CL_HERE, #cond, NULL);                  \
    }                                                                 \
} while (0)

#define CL_TEST_EQ_I64(t, actual, expected) do {                      \
    (t)->total_checks += 1;                                           \
    cl_i64 _a = (cl_i64)(actual);                                     \
    cl_i64 _e = (cl_i64)(expected);                                   \
    if (_a != _e) {                                                   \
        char _msg[160];                                               \
        snprintf(_msg, sizeof(_msg), "actual=%lld != expected=%lld",  \
                 (long long)_a, (long long)_e);                       \
        cl_test_fail_loc((t), CL_HERE, #actual " == " #expected, _msg); \
    }                                                                 \
} while (0)

#define CL_TEST_EQ_U64(t, actual, expected) do {                      \
    (t)->total_checks += 1;                                           \
    cl_u64 _a = (cl_u64)(actual);                                     \
    cl_u64 _e = (cl_u64)(expected);                                   \
    if (_a != _e) {                                                   \
        char _msg[160];                                               \
        snprintf(_msg, sizeof(_msg), "actual=%llu != expected=%llu",  \
                 (unsigned long long)_a, (unsigned long long)_e);     \
        cl_test_fail_loc((t), CL_HERE, #actual " == " #expected, _msg); \
    }                                                                 \
} while (0)

#define CL_TEST_EQ_STR(t, actual, expected) do {                      \
    (t)->total_checks += 1;                                           \
    Cl_Str _a = (actual);                                             \
    Cl_Str _e = (expected);                                           \
    if (!cl_str_eq(_a, _e)) {                                         \
        char _msg[256];                                               \
        snprintf(_msg, sizeof(_msg),                                  \
                 "actual=\"" CL_STR_FMT "\" != expected=\"" CL_STR_FMT "\"", \
                 CL_STR_ARG(_a), CL_STR_ARG(_e));                     \
        cl_test_fail_loc((t), CL_HERE, #actual " == " #expected, _msg); \
    }                                                                 \
} while (0)

#define CL_TEST_NEAR_F64(t, actual, expected, eps) do {               \
    (t)->total_checks += 1;                                           \
    cl_f64 _a = (cl_f64)(actual);                                     \
    cl_f64 _e = (cl_f64)(expected);                                   \
    if (fabs(_a - _e) > (cl_f64)(eps)) {                              \
        char _msg[160];                                               \
        snprintf(_msg, sizeof(_msg), "actual=%.12g != expected=%.12g (eps=%.3g)", \
                 _a, _e, (cl_f64)(eps));                              \
        cl_test_fail_loc((t), CL_HERE, #actual " ~= " #expected, _msg); \
    }                                                                 \
} while (0)

#define CL_TEST_NEAR_C64(t, actual, expected, eps) do {               \
    (t)->total_checks += 1;                                           \
    cl_c64 _a = (actual);                                             \
    cl_c64 _e = (expected);                                           \
    if (!cl_c64_approx_eq(_a, _e, (eps))) {                           \
        char _msg[160];                                               \
        snprintf(_msg, sizeof(_msg), "actual=(%g,%g) != expected=(%g,%g)", \
                 (double)cl_c64_real(_a), (double)cl_c64_imag(_a),    \
                 (double)cl_c64_real(_e), (double)cl_c64_imag(_e));   \
        cl_test_fail_loc((t), CL_HERE, #actual " ~= " #expected, _msg); \
    }                                                                 \
} while (0)

#define CL_TEST_NEAR_C128(t, actual, expected, eps) do {              \
    (t)->total_checks += 1;                                           \
    cl_c128 _a = (actual);                                            \
    cl_c128 _e = (expected);                                          \
    if (!cl_c128_approx_eq(_a, _e, (eps))) {                          \
        char _msg[160];                                               \
        snprintf(_msg, sizeof(_msg), "actual=(%.12g,%.12g) != expected=(%.12g,%.12g)", \
                 cl_c128_real(_a), cl_c128_imag(_a),                  \
                 cl_c128_real(_e), cl_c128_imag(_e));                 \
        cl_test_fail_loc((t), CL_HERE, #actual " ~= " #expected, _msg); \
    }                                                                 \
} while (0)

#endif /* CL_TEST_H */
