/*
 * ============================================================================
 * c_lib_unit_tests - Suite 4: Toggleable Bounds Checking & Assertions
 * File: test_bounds_assert.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 * ============================================================================
 */

#include "cl_test.h"

#if CL_BOUNDS_CHECK
static void trap_slice_oob_high(void) {
    cl_i32 arr[4] = { 1, 2, 3, 4 };
    Cl_Slice_I32 s = CL_SLICE_FROM_ARRAY(Cl_Slice_I32, arr);
    volatile cl_i32 v = CL_SLICE_AT(s, 4);
    (void)v;
}

static void trap_slice_oob_negative(void) {
    cl_i32 arr[4] = { 1, 2, 3, 4 };
    Cl_Slice_I32 s = CL_SLICE_FROM_ARRAY(Cl_Slice_I32, arr);
    volatile cl_i32 v = CL_SLICE_AT(s, -1);
    (void)v;
}

static void trap_subslice_inverted(void) {
    cl_i32 arr[4] = { 1, 2, 3, 4 };
    Cl_Slice_I32 s = CL_SLICE_FROM_ARRAY(Cl_Slice_I32, arr);
    Cl_Slice_I32 sub = CL_SLICE_SUB(s, 3, 1);
    (void)sub;
}

static void trap_da_pop_empty(void) {
    Cl_DA_I32 da = {0};
    volatile cl_i32 v = CL_DA_POP(&da);
    (void)v;
}

static void trap_str_oob(void) {
    Cl_Str s = CL_STR("abc");
    volatile cl_u8 c = cl_str_at(s, 3);
    (void)c;
}

static void trap_str_slice_oob(void) {
    Cl_Str s = CL_STR("abc");
    Cl_Str sub = cl_str_slice(s, 0, 5);
    (void)sub;
}
#endif

static void trap_ensure_false(void) {
    CL_ENSURE(1 == 2);
}

static void trap_panic_allocator(void) {
    Cl_Allocator p = cl_panic_allocator();
    void *ptr = cl_alloc(p, 16);
    (void)ptr;
}

#if CL_ASAN_ENABLED
CL_NOINLINE static cl_i64 read_i64_noinline(const cl_i64 *p) {
    return *p;
}

static void trap_arena_use_after_rewind_asan(void) {
    cl_u64 backing[128];
    Cl_Arena arena;
    cl_arena_init_buffer(&arena, backing, (cl_isize)sizeof(backing));
    Cl_Arena_Temp tmp = cl_arena_temp_begin(&arena);
    cl_i64 *dangling = cl_new(cl_arena_allocator(&arena), cl_i64);
    *dangling = 42;
    cl_arena_temp_end(tmp);
    /* Reading memory after temp_end MUST trigger ASan use-after-poison! */
    cl_i64 bad_read = read_i64_noinline(dangling);
    CL_UNUSED_VAR(bad_read);
    cl_arena_destroy(&arena);
}
#endif

static void test_bounds_checks_trap_in_dev_mode(Cl_Test_State *t) {
#if CL_BOUNDS_CHECK
    CL_TEST_CHECK(t, cl_test_expect_trap(trap_slice_oob_high));
    CL_TEST_CHECK(t, cl_test_expect_trap(trap_slice_oob_negative));
    CL_TEST_CHECK(t, cl_test_expect_trap(trap_subslice_inverted));
    CL_TEST_CHECK(t, cl_test_expect_trap(trap_da_pop_empty));
    CL_TEST_CHECK(t, cl_test_expect_trap(trap_str_oob));
    CL_TEST_CHECK(t, cl_test_expect_trap(trap_str_slice_oob));
#else
    /* In release mode (CL_BOUNDS_CHECK == 0), valid accesses still compile cleanly */
    cl_i32 arr[3] = { 10, 20, 30 };
    Cl_Slice_I32 s = CL_SLICE_FROM_ARRAY(Cl_Slice_I32, arr);
    CL_TEST_EQ_I64(t, CL_SLICE_AT(s, 2), 30);
#endif
#if CL_ASAN_ENABLED
    /* Verify manual ASan arena poisoning catches use-after-rewind! */
    CL_TEST_CHECK(t, cl_test_expect_trap(trap_arena_use_after_rewind_asan));
#endif
}

static void test_ensure_and_panic_allocator_always_trap(Cl_Test_State *t) {
    CL_TEST_CHECK(t, cl_test_expect_trap(trap_ensure_false));
    CL_TEST_CHECK(t, cl_test_expect_trap(trap_panic_allocator));
}

void suite_bounds_assert(Cl_Test_State *t) {
    CL_RUN_TEST(t, test_bounds_checks_trap_in_dev_mode);
    CL_RUN_TEST(t, test_ensure_and_panic_allocator_always_trap);
}
