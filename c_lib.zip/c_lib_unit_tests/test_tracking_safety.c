/*
 * ============================================================================
 * c_lib_unit_tests - Suite 3: Tracking Allocator (Leaks, Bad Pointers, Redzones)
 * File: test_tracking_safety.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 * ============================================================================
 */

#include "cl_test.h"

static void test_tracking_leak_detection(Cl_Test_State *t) {
    Cl_Tracking_Allocator tr;
    cl_tracking_init(&tr, cl_ctx_allocator());
    CL_DEFER_TRACKING(tr);
    Cl_Allocator a = cl_tracking_allocator(&tr);

    void *p1 = cl_alloc(a, 128);
    void *p2 = cl_alloc(a, 256);
    CL_TEST_CHECK(t, p1 != NULL && p2 != NULL);
    CL_TEST_EQ_I64(t, tr.active_count, 2);
    CL_TEST_EQ_I64(t, tr.current_bytes, 384);
    CL_TEST_EQ_I64(t, tr.peak_bytes, 384);

    cl_free(a, p1, 128);
    /* Intentionally inspect leak state before freeing p2 */
    CL_TEST_CHECK(t, !cl_tracking_is_clean(&tr));
    CL_TEST_EQ_I64(t, tr.active_count, 1);
    CL_TEST_EQ_I64(t, tr.current_bytes, 256);

    /* Now release p2 so underlying heap stays leak-free */
    cl_free(a, p2, 256);
    CL_TEST_CHECK(t, cl_tracking_is_clean(&tr));
    CL_TEST_EQ_I64(t, tr.peak_bytes, 384);
}

static void test_tracking_double_free_and_bad_pointers(Cl_Test_State *t) {
    Cl_Tracking_Allocator tr;
    cl_tracking_init(&tr, cl_ctx_allocator());
    CL_DEFER_TRACKING(tr);
    Cl_Allocator a = cl_tracking_allocator(&tr);

    /* 1. Double free detection */
    cl_u8 *buf = (cl_u8 *)cl_alloc(a, 64);
    cl_u8 *live = (cl_u8 *)cl_alloc(a, 128);
    CL_TEST_CHECK(t, buf != NULL && live != NULL);
    cl_free(a, buf, 64);
    cl_free(a, buf, 64); /* Double free! Safely intercepted without crashing */
    CL_TEST_EQ_I64(t, tr.double_free_count, 1);
    CL_TEST_CHECK(t, tr.error_count >= 1);
    CL_TEST_EQ_I64(t, tr.errors[0].kind, CL_MEM_ERR_DOUBLE_FREE);

    /* 2. Unknown / stack pointer free detection */
    int stack_var = 123;
    cl_free(a, &stack_var, (cl_isize)sizeof(stack_var));
    CL_TEST_EQ_I64(t, tr.bad_free_count, 1);
    CL_TEST_EQ_I64(t, tr.errors[1].kind, CL_MEM_ERR_BAD_FREE_UNKNOWN);

    /* 3. Interior pointer free detection */
    cl_free(a, live + 16, 112); /* Interior pointer! */
    CL_TEST_EQ_I64(t, tr.bad_free_count, 2);
    CL_TEST_EQ_I64(t, tr.errors[2].kind, CL_MEM_ERR_BAD_FREE_INTERIOR);

    /* 4. Live pointer validation API */
    CL_TEST_EQ_I64(t, cl_tracking_validate_ptr(&tr, NULL, 1), CL_PTR_NULL);
    CL_TEST_EQ_I64(t, cl_tracking_validate_ptr(&tr, live, 128), CL_PTR_VALID);
    CL_TEST_EQ_I64(t, cl_tracking_validate_ptr(&tr, live + 64, 64), CL_PTR_VALID);
    CL_TEST_EQ_I64(t, cl_tracking_validate_ptr(&tr, live + 64, 65), CL_PTR_OUT_OF_BOUNDS);
    CL_TEST_EQ_I64(t, cl_tracking_validate_ptr(&tr, buf, 1), CL_PTR_FREED);
    CL_TEST_EQ_I64(t, cl_tracking_validate_ptr(&tr, &stack_var, 4), CL_PTR_UNKNOWN);

    /* Clean up live block */
    cl_free(a, live, 128);
    CL_TEST_EQ_I64(t, tr.active_count, 0);
}

static void test_tracking_redzone_underflow_and_overflow(Cl_Test_State *t) {
    Cl_Tracking_Allocator tr;
    cl_tracking_init(&tr, cl_ctx_allocator());
    CL_DEFER_TRACKING(tr);
    Cl_Allocator a = cl_tracking_allocator(&tr);

    /* Test back redzone overflow detection */
    cl_u8 *p1 = (cl_u8 *)cl_alloc(a, 32);
    CL_TEST_CHECK(t, p1 != NULL);
    p1[32] = 0xAAu; /* Corrupts 1 byte into the 16-byte back redzone */
    CL_TEST_EQ_I64(t, cl_tracking_check_integrity(&tr, CL_HERE), 1);
    CL_TEST_EQ_I64(t, tr.redzone_corruptions, 1);
    CL_TEST_EQ_I64(t, tr.errors[0].kind, CL_MEM_ERR_REDZONE_OVERFLOW);
    /* Restore redzone before free so free doesn't double-count */
    p1[32] = CL_MEM_POISON_REDZONE;
    cl_free(a, p1, 32);

    /* Test front redzone underflow detection */
    cl_u8 *p2 = (cl_u8 *)cl_alloc(a, 32);
    CL_TEST_CHECK(t, p2 != NULL);
    p2[-1] = 0xBBu; /* Corrupts 1 byte into the 16-byte front redzone */
    cl_free(a, p2, 32); /* Detected automatically during free! */
    CL_TEST_EQ_I64(t, tr.redzone_corruptions, 2);
    CL_TEST_EQ_I64(t, tr.errors[1].kind, CL_MEM_ERR_REDZONE_UNDERFLOW);
}

static void test_tracking_size_mismatch_and_non_zeroed_poison(Cl_Test_State *t) {
    Cl_Tracking_Allocator tr;
    cl_tracking_init(&tr, cl_ctx_allocator());
    CL_DEFER_TRACKING(tr);
    Cl_Allocator a = cl_tracking_allocator(&tr);

    /* Non-zeroed allocation should be painted with CL_MEM_POISON_ALLOC_UNINIT (0xCD) */
    cl_u8 *p = (cl_u8 *)cl_alloc_non_zeroed(a, 16);
    CL_TEST_CHECK(t, p != NULL);
    CL_TEST_EQ_U64(t, p[0], CL_MEM_POISON_ALLOC_UNINIT);
    CL_TEST_EQ_U64(t, p[15], CL_MEM_POISON_ALLOC_UNINIT);

    /* Passing wrong old_size on free flags size mismatch cleanly */
    cl_free(a, p, 999);
    CL_TEST_EQ_I64(t, tr.size_mismatch_count, 1);
    CL_TEST_EQ_I64(t, tr.active_count, 0);
}

void suite_tracking_safety(Cl_Test_State *t) {
    CL_RUN_TEST(t, test_tracking_leak_detection);
    CL_RUN_TEST(t, test_tracking_double_free_and_bad_pointers);
    CL_RUN_TEST(t, test_tracking_redzone_underflow_and_overflow);
    CL_RUN_TEST(t, test_tracking_size_mismatch_and_non_zeroed_poison);
}
