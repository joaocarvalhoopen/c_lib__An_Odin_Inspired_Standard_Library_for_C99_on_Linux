/*
 * ============================================================================
 * c_lib_unit_tests - Suite 8: Strings, C-String Interop, UTF-8 & Parsing
 * File: test_strings_utf8.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 * ============================================================================
 */

#include "cl_test.h"
#include <string.h>

static void test_str_cstr_conversions_and_views(Cl_Test_State *t) {
    Cl_Allocator a = cl_ctx_allocator();
    Cl_Str s = CL_STR("Odin-style C99");
    CL_TEST_EQ_I64(t, s.len, 14);
    CL_TEST_EQ_U64(t, cl_str_at(s, 0), 'O');
    CL_TEST_EQ_STR(t, cl_str_slice(s, 0, 4), CL_STR("Odin"));

    /* Allocate NUL-terminated cstring */
    char *cs = cl_str_to_cstr(s, a);
    CL_TEST_CHECK(t, cs != NULL && strcmp(cs, "Odin-style C99") == 0);
    CL_TEST_EQ_STR(t, cl_str_from_cstr(cs), s);
    cl_cstr_free(cs, s.len, a);

    /* Temp allocator cstring (auto-reset at end of test!) */
    char *tcs = cl_str_to_cstr_temp(cl_str_slice(s, 5, 10));
    CL_TEST_CHECK(t, tcs != NULL && strcmp(tcs, "style") == 0);

    /* Fixed buffer conversion (fits & truncated) */
    char small[6];
    Cl_CStr_Buf_Res r1 = cl_str_to_cstr_buf(CL_STR("hello"), small, (cl_isize)sizeof(small));
    CL_TEST_CHECK(t, !r1.truncated && r1.written == 5 && strcmp(small, "hello") == 0);
    Cl_CStr_Buf_Res r2 = cl_str_to_cstr_buf(CL_STR("hello world"), small, (cl_isize)sizeof(small));
    CL_TEST_CHECK(t, r2.truncated && r2.written == 5 && strcmp(small, "hello") == 0);

    /* Embedded NUL bytes work cleanly in Cl_Str */
    const cl_u8 raw[5] = { 'a', 'b', '\0', 'c', 'd' };
    Cl_Str bin = cl_str_from_parts(raw, 5);
    CL_TEST_EQ_I64(t, bin.len, 5);
    CL_TEST_EQ_U64(t, cl_str_at(bin, 2), 0);
    CL_TEST_EQ_U64(t, cl_str_at(bin, 4), 'd');
}

static void test_str_search_trim_cut_and_iterators(Cl_Test_State *t) {
    Cl_Str s = CL_STR("  key = value = extra  ");
    Cl_Str trimmed = cl_str_trim_space(s);
    CL_TEST_EQ_STR(t, trimmed, CL_STR("key = value = extra"));
    CL_TEST_CHECK(t, cl_str_has_prefix(trimmed, CL_STR("key")));
    CL_TEST_CHECK(t, cl_str_has_suffix(trimmed, CL_STR("extra")));
    CL_TEST_CHECK(t, cl_str_contains(trimmed, CL_STR("value")));
    CL_TEST_EQ_I64(t, cl_str_count(trimmed, CL_STR("=")), 2);
    CL_TEST_EQ_I64(t, cl_str_index(trimmed, CL_STR("=")), 4);
    CL_TEST_EQ_I64(t, cl_str_last_index(trimmed, CL_STR("=")), 12);

    /* cl_str_cut */
    Cl_Str_Cut cut = cl_str_cut(trimmed, CL_STR(" = "));
    CL_TEST_CHECK(t, cut.found);
    CL_TEST_EQ_STR(t, cut.before, CL_STR("key"));
    CL_TEST_EQ_STR(t, cut.after, CL_STR("value = extra"));

    /* trim_prefix / trim_suffix / trim_cutset / eq_fold */
    CL_TEST_EQ_STR(t, cl_str_trim_prefix(CL_STR("libfoo.a"), CL_STR("lib")), CL_STR("foo.a"));
    CL_TEST_EQ_STR(t, cl_str_trim_suffix(CL_STR("libfoo.a"), CL_STR(".a")), CL_STR("libfoo"));
    CL_TEST_EQ_STR(t, cl_str_trim_cutset(CL_STR("...hi!!!"), CL_STR(".!")), CL_STR("hi"));
    CL_TEST_CHECK(t, cl_str_eq_fold(CL_STR("HeLLo"), CL_STR("hello")));

    /* Zero-alloc split_iter (including trailing empty piece) */
    Cl_Str rest = CL_STR("a,bb,,ccc");
    Cl_Str expected[4] = { CL_STR("a"), CL_STR("bb"), CL_STR(""), CL_STR("ccc") };
    for (int i = 0; i < 4; i++) {
        Cl_Opt_Str tok = cl_str_split_iter(&rest, CL_STR(","));
        CL_TEST_CHECK(t, tok.ok);
        CL_TEST_EQ_STR(t, tok.value, expected[i]);
    }
    CL_TEST_CHECK(t, !cl_str_split_iter(&rest, CL_STR(",")).ok);

    /* Zero-alloc split_lines_iter (handles CRLF and LF) */
    Cl_Str lines = CL_STR("one\r\ntwo\nthree\n");
    Cl_Str exp_lines[3] = { CL_STR("one"), CL_STR("two"), CL_STR("three") };
    for (int i = 0; i < 3; i++) {
        Cl_Opt_Str l = cl_str_split_lines_iter(&lines);
        CL_TEST_CHECK(t, l.ok);
        CL_TEST_EQ_STR(t, l.value, exp_lines[i]);
    }
    CL_TEST_CHECK(t, !cl_str_split_lines_iter(&lines).ok);

    /* Zero-alloc fields_iter */
    Cl_Str ws = CL_STR("  foo\t\tbar   baz  ");
    CL_TEST_EQ_STR(t, cl_str_fields_iter(&ws).value, CL_STR("foo"));
    CL_TEST_EQ_STR(t, cl_str_fields_iter(&ws).value, CL_STR("bar"));
    CL_TEST_EQ_STR(t, cl_str_fields_iter(&ws).value, CL_STR("baz"));
    CL_TEST_CHECK(t, !cl_str_fields_iter(&ws).ok);
}

static void test_str_allocating_transforms(Cl_Test_State *t) {
    Cl_Allocator a = cl_ctx_allocator();

    Cl_Slice_Str parts = cl_str_split(CL_STR("red:green:blue"), CL_STR(":"), a);
    CL_TEST_EQ_I64(t, parts.len, 3);
    CL_TEST_EQ_STR(t, CL_SLICE_AT(parts, 1), CL_STR("green"));

    Cl_Str joined = cl_str_join(parts, CL_STR(" | "), a);
    CL_TEST_EQ_STR(t, joined, CL_STR("red | green | blue"));
    CL_SLICE_FREE(a, parts);
    cl_str_free(joined, a);

    Cl_Str rep = cl_str_repeat(CL_STR("ab"), 4, a);
    CL_TEST_EQ_STR(t, rep, CL_STR("abababab"));
    cl_str_free(rep, a);

    Cl_Str r1 = cl_str_replace_all(CL_STR("foo bar foo baz foo"), CL_STR("foo"), CL_STR("QUX!"), a);
    CL_TEST_EQ_STR(t, r1, CL_STR("QUX! bar QUX! baz QUX!"));
    cl_str_free(r1, a);

    Cl_Str r2 = cl_str_replace_n(CL_STR("a-a-a-a"), CL_STR("a"), CL_STR("X"), 2, a);
    CL_TEST_EQ_STR(t, r2, CL_STR("X-X-a-a"));
    cl_str_free(r2, a);

    Cl_Str up = cl_str_to_upper(CL_STR("OdinC99!"), a);
    CL_TEST_EQ_STR(t, up, CL_STR("ODINC99!"));
    Cl_Str lo = cl_str_to_lower(up, a);
    CL_TEST_EQ_STR(t, lo, CL_STR("odinc99!"));
    cl_str_free(up, a);
    cl_str_free(lo, a);

    Cl_Str pl = cl_str_pad_left(CL_STR("42"), 5, '0', a);
    CL_TEST_EQ_STR(t, pl, CL_STR("00042"));
    Cl_Str pr = cl_str_pad_right(CL_STR("hi"), 5, '.', a);
    CL_TEST_EQ_STR(t, pr, CL_STR("hi..."));
    cl_str_free(pl, a);
    cl_str_free(pr, a);
}

static void test_utf8_and_reverse(Cl_Test_State *t) {
    /* Mix 1-byte ASCII ('A'), 2-byte ('e' acute U+00E9), 3-byte (Euro U+20AC), 4-byte (U+1F680) */
    const cl_u8 utf8_bytes[] = {
        'A',
        0xC3u, 0xA9u,
        0xE2u, 0x82u, 0xACu,
        0xF0u, 0x9Fu, 0x9Au, 0x80u
    };
    Cl_Str u = cl_str_from_parts(utf8_bytes, (cl_isize)sizeof(utf8_bytes));
    CL_TEST_CHECK(t, cl_utf8_valid(u));
    CL_TEST_EQ_I64(t, cl_utf8_rune_count(u), 4);

    cl_rune expected[4] = { 'A', 0x00E9, 0x20AC, 0x1F680 };
    cl_isize off = 0;
    for (int i = 0; i < 4; i++) {
        Cl_Utf8_Decode d = cl_utf8_next(u, &off);
        CL_TEST_CHECK(t, d.valid);
        CL_TEST_EQ_I64(t, d.codepoint, expected[i]);
    }
    CL_TEST_EQ_I64(t, off, u.len);

    /* Reject overlong & surrogate UTF-8 */
    const cl_u8 overlong[2] = { 0xC0u, 0xAFu };
    CL_TEST_CHECK(t, !cl_utf8_valid(cl_str_from_parts(overlong, 2)));
    const cl_u8 surrogate[3] = { 0xEDu, 0xA0u, 0x80u };
    CL_TEST_CHECK(t, !cl_utf8_valid(cl_str_from_parts(surrogate, 3)));

    /* UTF-8 rune-safe reverse preserves multi-byte code points */
    Cl_Allocator a = cl_ctx_allocator();
    Cl_Str rev = cl_str_reverse_utf8(u, a);
    CL_TEST_CHECK(t, cl_utf8_valid(rev));
    CL_TEST_EQ_I64(t, cl_utf8_rune_count(rev), 4);
    off = 0;
    for (int i = 3; i >= 0; i--) {
        Cl_Utf8_Decode d = cl_utf8_next(rev, &off);
        CL_TEST_EQ_I64(t, d.codepoint, expected[i]);
    }
    cl_str_free(rev, a);
}

static void test_parsing_numbers_and_complex(Cl_Test_State *t) {
    /* Integers (decimal, hex, binary, octal, Odin underscores, INT64_MIN, overflow) */
    CL_TEST_EQ_I64(t, CL_OPT_OR_PANIC(cl_str_parse_i64(CL_STR("-1_000_000"), 10)), -1000000);
    CL_TEST_EQ_I64(t, CL_OPT_OR_PANIC(cl_str_parse_i64(CL_STR("0xFF"), 0)), 255);
    CL_TEST_EQ_I64(t, CL_OPT_OR_PANIC(cl_str_parse_i64(CL_STR("0b1010"), 0)), 10);
    CL_TEST_EQ_I64(t, CL_OPT_OR_PANIC(cl_str_parse_i64(CL_STR("0o77"), 0)), 63);
    CL_TEST_EQ_I64(t, CL_OPT_OR_PANIC(cl_str_parse_i64(CL_STR("-9223372036854775808"), 10)), INT64_MIN);
    CL_TEST_CHECK(t, !cl_str_parse_i64(CL_STR("9223372036854775808"), 10).ok); /* Overflow */
    CL_TEST_CHECK(t, !cl_str_parse_i64(CL_STR("123abc"), 10).ok);              /* Trailing garbage */

    CL_TEST_EQ_U64(t, CL_OPT_OR_PANIC(cl_str_parse_u64(CL_STR("18446744073709551615"), 10)), UINT64_MAX);
    CL_TEST_CHECK(t, !cl_str_parse_u64(CL_STR("-1"), 10).ok);

    /* Float & Bool */
    CL_TEST_NEAR_F64(t, CL_OPT_OR_PANIC(cl_str_parse_f64(CL_STR(" -3.14159 "))), -3.14159, 1e-12);
    CL_TEST_CHECK(t, !cl_str_parse_f64(CL_STR("3.14xyz")).ok);
    CL_TEST_CHECK(t, CL_OPT_OR_PANIC(cl_str_parse_bool(CL_STR("TRUE"))) == true);
    CL_TEST_CHECK(t, CL_OPT_OR_PANIC(cl_str_parse_bool(CL_STR("no"))) == false);

    /* Complex64 & Complex128 parsing */
    CL_TEST_NEAR_C128(t, CL_OPT_OR_PANIC(cl_str_parse_c128(CL_STR("3+4i"))),        cl_c128_make(3.0, 4.0),   1e-12);
    CL_TEST_NEAR_C128(t, CL_OPT_OR_PANIC(cl_str_parse_c128(CL_STR("3.5 - 2.25i"))), cl_c128_make(3.5, -2.25), 1e-12);
    CL_TEST_NEAR_C128(t, CL_OPT_OR_PANIC(cl_str_parse_c128(CL_STR("-i"))),          cl_c128_make(0.0, -1.0),  1e-12);
    CL_TEST_NEAR_C128(t, CL_OPT_OR_PANIC(cl_str_parse_c128(CL_STR("1e-2+2.5e1i"))), cl_c128_make(0.01, 25.0), 1e-12);
    CL_TEST_NEAR_C128(t, CL_OPT_OR_PANIC(cl_str_parse_c128(CL_STR("(-7.5, 8.25)"))), cl_c128_make(-7.5, 8.25), 1e-12);
    CL_TEST_NEAR_C64(t,  CL_OPT_OR_PANIC(cl_str_parse_c64(CL_STR("42"))),           cl_c64_make(42.0f, 0.0f), 1e-6f);
    CL_TEST_CHECK(t, !cl_str_parse_c128(CL_STR("not_complex")).ok);
}

void suite_strings_utf8(Cl_Test_State *t) {
    CL_RUN_TEST(t, test_str_cstr_conversions_and_views);
    CL_RUN_TEST(t, test_str_search_trim_cut_and_iterators);
    CL_RUN_TEST(t, test_str_allocating_transforms);
    CL_RUN_TEST(t, test_utf8_and_reverse);
    CL_RUN_TEST(t, test_parsing_numbers_and_complex);
}
