/*
 * ============================================================================
 * c_lib_unit_tests - Main Test Runner
 * File: test_main.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 *
 * Purpose:
 *   Executes all unit test suites, automatically enforcing zero memory leaks
 *   and zero safety violations per test via Cl_Tracking_Allocator, and
 *   providing fork()-isolated subprocess trap verification for bounds checks.
 * ============================================================================
 */

#define _POSIX_C_SOURCE 200809L

#include "cl_test.h"
#include <fcntl.h>
#include <sys/wait.h>
#include <unistd.h>

void cl_test_fail_loc(Cl_Test_State *t, Cl_Source_Loc loc, const char *expr, const char *detail) {
    t->current_failures += 1;
    fprintf(stderr, "  [FAIL] %s:%d (%s): %s",
            loc.file ? loc.file : "?", (int)loc.line,
            loc.func ? loc.func : "?", expr ? expr : "");
    if (detail != NULL) {
        fprintf(stderr, "  -->  %s", detail);
    }
    fprintf(stderr, "\n");
}

void cl_test_run(Cl_Test_State *state, const char *name, Cl_Test_Proc fn) {
    state->current_name     = name;
    state->current_failures = 0;
    state->total_tests     += 1;

    /* Install fresh tracking allocator + nil logger into scoped context */
    Cl_Tracking_Allocator tracker;
    cl_tracking_init(&tracker, cl_heap_allocator());

    Cl_Context ctx = cl_ctx_default();
    ctx.allocator = cl_tracking_allocator(&tracker);
    ctx.logger    = cl_nil_logger();
    cl_ctx_push(ctx);

    fn(state);

    cl_ctx_temp_reset();
    cl_ctx_pop();

    /* Automatically fail the test if ANY leak or memory safety error occurred! */
    if (!cl_tracking_is_clean(&tracker)) {
        state->current_failures += 1;
        fprintf(stderr, "  [LEAK/MEMORY ERROR] in test '%s':\n", name);
        cl_tracking_print_report(&tracker, stderr);
    }

    cl_tracking_destroy(&tracker);

    if (state->current_failures == 0) {
        state->passed_tests += 1;
        printf("  [PASS] %s\n", name);
    } else {
        state->failed_tests += 1;
        printf("  [FAIL] %s (%lld check failures)\n", name, (long long)state->current_failures);
    }
}

bool cl_test_expect_trap(Cl_Trap_Proc fn) {
    fflush(stdout);
    fflush(stderr);
    pid_t pid = fork();
    if (pid < 0) {
        return false;
    }
    if (pid == 0) {
        /* Silence expected panic/backtrace output in child */
        int devnull = open("/dev/null", O_WRONLY);
        if (devnull >= 0) {
            dup2(devnull, STDERR_FILENO);
            dup2(devnull, STDOUT_FILENO);
            close(devnull);
        }
        fn();
        /* If fn() returned without trapping, exit cleanly with status 0 */
        _exit(0);
    }

    int status = 0;
    if (waitpid(pid, &status, 0) < 0) {
        return false;
    }
    /* Expect termination via signal (SIGTRAP / SIGILL / SIGABRT / SIGSEGV from trap) */
    if (WIFSIGNALED(status)) {
        return true;
    }
    /* Under ASan/UBSan some traps exit non-zero */
    if (WIFEXITED(status) && WEXITSTATUS(status) != 0) {
        return true;
    }
    return false;
}

int main(void) {
    Cl_Stopwatch sw = {0};
    cl_stopwatch_start(&sw);

    Cl_Test_State state = {0};
    printf("================================================================\n");
    printf("c_lib Unit Test Suite (CL_BOUNDS_CHECK=%d, CL_ASAN=%d)\n",
           CL_BOUNDS_CHECK, CL_ASAN_ENABLED);
    printf("================================================================\n");

    printf("\n--- Suite 1: Types, Endian, Complex64/128 & Quaternions ---\n");
    suite_types_complex(&state);

    printf("\n--- Suite 2: Allocators, Arenas, Virtual Arena, Pool & Context ---\n");
    suite_alloc_arenas(&state);

    printf("\n--- Suite 3: Tracking Allocator (Leaks, Bad Pointers, Redzones) ---\n");
    suite_tracking_safety(&state);

    printf("\n--- Suite 4: Toggleable Bounds Checking & Assertions ---\n");
    suite_bounds_assert(&state);

    printf("\n--- Suite 5: Defer Tiers & Multiple Return Values ---\n");
    suite_defer_result(&state);

    printf("\n--- Suite 6: Slices, Dynamic Arrays, Small Array, Queue, BitSet ---\n");
    suite_slices_arrays(&state);

    printf("\n--- Suite 7: HashMap (Dense + Swiss H2 Control Bytes) ---\n");
    suite_hashmap(&state);

    printf("\n--- Suite 8: Strings, C-String Interop, UTF-8 & Parsing ---\n");
    suite_strings_utf8(&state);

    printf("\n--- Suite 9: String Builder & In-Place String Buffer ---\n");
    suite_sb_strbuf(&state);

    printf("\n--- Suite 10: Logging, Linux OS File I/O & Stopwatch ---\n");
    suite_log_os_time(&state);

    cl_stopwatch_stop(&sw);
    cl_ctx_thread_shutdown();

    printf("\n================================================================\n");
    printf("Summary: %lld/%lld tests passed, %lld failed (%lld assertions) in %.2f ms\n",
           (long long)state.passed_tests,
           (long long)state.total_tests,
           (long long)state.failed_tests,
           (long long)state.total_checks,
           cl_stopwatch_elapsed_ms(&sw));
    printf("================================================================\n");

    return (state.failed_tests == 0) ? 0 : 1;
}
