/*
 * ============================================================================
 * c_lib_unit_tests - Suite 6: Slices, Dynamic Arrays, Small Array, Queue, BitSet
 * File: test_slices_arrays.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 * ============================================================================
 */

#include "cl_test.h"

CL_SMALL_ARRAY_DEFINE(Small_I32_4, cl_i32, 4);

static void test_slices_and_algorithms(Cl_Test_State *t) {
    cl_i32 raw[6] = { 50, 10, 40, 20, 60, 30 };
    Cl_Slice_I32 s = CL_SLICE_FROM_ARRAY(Cl_Slice_I32, raw);
    CL_TEST_EQ_I64(t, s.len, 6);
    CL_TEST_EQ_I64(t, CL_SLICE_FIRST(s), 50);
    CL_TEST_EQ_I64(t, CL_SLICE_LAST(s), 30);

    /* Zero-copy sub-slice s[1:4] = { 10, 40, 20 } */
    Cl_Slice_I32 sub = CL_SLICE_SUB(s, 1, 4);
    CL_TEST_EQ_I64(t, sub.len, 3);
    CL_TEST_EQ_I64(t, CL_SLICE_AT(sub, 0), 10);
    CL_TEST_EQ_I64(t, CL_SLICE_AT(sub, 2), 20);

    /* Mutating sub-slice mutates underlying slice */
    CL_SLICE_AT(sub, 1) = 45;
    CL_TEST_EQ_I64(t, CL_SLICE_AT(s, 2), 45);
    CL_SLICE_AT(sub, 1) = 40;

    /* Sort & binary search */
    CL_SLICE_SORT(s, cl_cmp_i32);
    for (cl_isize i = 0; i < 6; i++) {
        CL_TEST_EQ_I64(t, CL_SLICE_AT(s, i), (i + 1) * 10);
    }
    cl_i32 key = 40;
    CL_TEST_EQ_I64(t, CL_SLICE_BSEARCH(s, &key, cl_cmp_i32), 3);
    cl_i32 missing = 99;
    CL_TEST_EQ_I64(t, CL_SLICE_BSEARCH(s, &missing, cl_cmp_i32), -1);

    /* Reverse */
    CL_SLICE_REVERSE(s);
    CL_TEST_EQ_I64(t, CL_SLICE_FIRST(s), 60);
    CL_TEST_EQ_I64(t, CL_SLICE_LAST(s), 10);

    /* Clone, equality, fill, and free */
    Cl_Allocator a = cl_ctx_allocator();
    Cl_Slice_I32 cloned = CL_SLICE_CLONE(Cl_Slice_I32, a, s);
    CL_TEST_CHECK(t, CL_SLICE_EQUAL(s, cloned));
    CL_SLICE_FILL(cloned, 7);
    CL_TEST_CHECK(t, !CL_SLICE_EQUAL(s, cloned));
    CL_TEST_EQ_I64(t, CL_SLICE_AT(cloned, 3), 7);
    CL_SLICE_FREE(a, cloned);
}

static void test_dynamic_array_operations(Cl_Test_State *t) {
    /* Zero-initialized dynamic array uses context allocator automatically */
    Cl_DA_I64 da = {0};
    CL_DEFER_DA(da);

    for (cl_i64 i = 0; i < 100; i++) {
        CL_DA_PUSH(&da, i * 2);
    }
    CL_TEST_EQ_I64(t, da.len, 100);
    CL_TEST_CHECK(t, da.cap >= 100);
    CL_TEST_EQ_I64(t, CL_DA_AT(&da, 0), 0);
    CL_TEST_EQ_I64(t, CL_DA_AT(&da, 99), 198);

    /* Pop */
    CL_TEST_EQ_I64(t, CL_DA_POP(&da), 198);
    CL_TEST_EQ_I64(t, da.len, 99);

    /* Clear and test inject_at / ordered_remove / unordered_remove */
    CL_DA_CLEAR(&da);
    cl_i64 init_vals[3] = { 10, 30, 40 };
    CL_DA_APPEND_MANY(&da, init_vals, 3);
    CL_DA_INJECT_AT(&da, 1, 20); /* { 10, 20, 30, 40 } */
    CL_TEST_EQ_I64(t, da.len, 4);
    CL_TEST_EQ_I64(t, CL_DA_AT(&da, 1), 20);
    CL_TEST_EQ_I64(t, CL_DA_AT(&da, 3), 40);

    CL_DA_ORDERED_REMOVE(&da, 1); /* { 10, 30, 40 } */
    CL_TEST_EQ_I64(t, da.len, 3);
    CL_TEST_EQ_I64(t, CL_DA_AT(&da, 1), 30);

    CL_DA_UNORDERED_REMOVE(&da, 0); /* { 40, 30 } */
    CL_TEST_EQ_I64(t, da.len, 2);
    CL_TEST_EQ_I64(t, CL_DA_AT(&da, 0), 40);
    CL_TEST_EQ_I64(t, CL_DA_AT(&da, 1), 30);

    /* Resize & shrink */
    CL_DA_RESIZE(&da, 5);
    CL_TEST_EQ_I64(t, CL_DA_AT(&da, 4), 0);
    CL_DA_SHRINK(&da);
    CL_TEST_EQ_I64(t, da.cap, 5);

    /* Complex128 dynamic array */
    Cl_DA_C128 cda = {0};
    CL_DEFER_DA(cda);
    CL_DA_PUSH(&cda, cl_c128_make(1.0, 2.0));
    CL_DA_PUSH(&cda, cl_c128_make(3.0, 4.0));
    Cl_Slice_C128 cslice = CL_DA_AS_SLICE(Cl_Slice_C128, &cda);
    CL_TEST_NEAR_C128(t, CL_SLICE_AT(cslice, 1), cl_c128_make(3.0, 4.0), 1e-12);
}

static void test_small_array_queue_and_bitset(Cl_Test_State *t) {
    /* Small array (zero heap alloc) */
    Small_I32_4 sa = {0};
    CL_TEST_CHECK(t, CL_SA_PUSH(&sa, 1));
    CL_TEST_CHECK(t, CL_SA_PUSH(&sa, 2));
    CL_TEST_CHECK(t, CL_SA_PUSH(&sa, 3));
    CL_TEST_CHECK(t, CL_SA_PUSH(&sa, 4));
    CL_TEST_CHECK(t, !CL_SA_PUSH(&sa, 5)); /* Full */
    CL_SA_UNORDERED_REMOVE(&sa, 1); /* { 1, 4, 3 } */
    CL_TEST_EQ_I64(t, sa.len, 3);
    CL_TEST_EQ_I64(t, CL_SA_AT(&sa, 1), 4);

    /* Circular ring queue (deque with wraparound + growth) */
    Cl_Queue_I64 q = {0};
    for (cl_i64 i = 0; i < 6; i++) {
        CL_QUEUE_PUSH_BACK(&q, i);
    }
    cl_i64 out = -1;
    CL_TEST_CHECK(t, CL_QUEUE_POP_FRONT_SAFE(&q, &out) && out == 0);
    CL_TEST_CHECK(t, CL_QUEUE_POP_FRONT_SAFE(&q, &out) && out == 1);
    /* Push enough to wrap around and trigger linearizing growth */
    for (cl_i64 i = 6; i < 20; i++) {
        CL_QUEUE_PUSH_BACK(&q, i);
    }
    CL_QUEUE_PUSH_FRONT(&q, 1);
    CL_TEST_EQ_I64(t, q.len, 19);
    for (cl_i64 expected = 1; expected < 20; expected++) {
        CL_TEST_CHECK(t, CL_QUEUE_POP_FRONT_SAFE(&q, &out) && out == expected);
    }
    CL_TEST_CHECK(t, !CL_QUEUE_POP_FRONT_SAFE(&q, &out));
    CL_QUEUE_FREE(&q);

    /* Dense BitSet */
    Cl_Bit_Set bs1, bs2;
    CL_TEST_CHECK(t, cl_bitset_init(&bs1, 130, cl_ctx_allocator()));
    CL_TEST_CHECK(t, cl_bitset_init(&bs2, 130, cl_ctx_allocator()));
    cl_bitset_set(&bs1, 0);
    cl_bitset_set(&bs1, 64);
    cl_bitset_set(&bs1, 129);
    CL_TEST_CHECK(t, cl_bitset_test(&bs1, 64));
    CL_TEST_CHECK(t, !cl_bitset_test(&bs1, 63));
    CL_TEST_EQ_I64(t, cl_bitset_count_ones(&bs1), 3);

    cl_bitset_set(&bs2, 64);
    cl_bitset_set(&bs2, 100);
    cl_bitset_union_in_place(&bs1, &bs2);
    CL_TEST_EQ_I64(t, cl_bitset_count_ones(&bs1), 4);
    cl_bitset_intersect_in_place(&bs1, &bs2);
    CL_TEST_EQ_I64(t, cl_bitset_count_ones(&bs1), 2);
    cl_bitset_toggle(&bs1, 64);
    CL_TEST_CHECK(t, !cl_bitset_test(&bs1, 64));

    cl_bitset_destroy(&bs1);
    cl_bitset_destroy(&bs2);
}

void suite_slices_arrays(Cl_Test_State *t) {
    CL_RUN_TEST(t, test_slices_and_algorithms);
    CL_RUN_TEST(t, test_dynamic_array_operations);
    CL_RUN_TEST(t, test_small_array_queue_and_bitset);
}
