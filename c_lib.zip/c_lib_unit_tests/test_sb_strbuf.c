/*
 * ============================================================================
 * c_lib_unit_tests - Suite 9: String Builder & In-Place String Buffer
 * File: test_sb_strbuf.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 * ============================================================================
 */

#include "cl_test.h"
#include <string.h>

static void test_string_builder_dynamic_and_complex(Cl_Test_State *t) {
    Cl_String_Builder sb = {0};
    cl_sb_init(&sb, cl_ctx_allocator());
    CL_DEFER_SB(sb);

    cl_sb_write_str(&sb, CL_STR("z = "));
    cl_sb_write_c128(&sb, cl_c128_make(3.5, -2.25), 2);
    cl_sb_write_str(&sb, CL_STR(", n="));
    cl_sb_write_i64(&sb, -42);
    cl_sb_write_str(&sb, CL_STR(", hex="));
    cl_sb_write_hex(&sb, 0xCAFEu, true);
    cl_sb_write_str(&sb, CL_STR(", ok="));
    cl_sb_write_bool(&sb, true);

    Cl_Str expected = CL_STR("z = 3.50 - 2.25i, n=-42, hex=0xCAFE, ok=true");
    CL_TEST_EQ_STR(t, cl_sb_to_str(&sb), expected);

    /* to_cstr adds trailing NUL without changing len */
    cl_isize old_len = sb.len;
    const char *cs = cl_sb_to_cstr(&sb);
    CL_TEST_EQ_I64(t, sb.len, old_len);
    CL_TEST_CHECK(t, strcmp(cs, "z = 3.50 - 2.25i, n=-42, hex=0xCAFE, ok=true") == 0);

    /* Format, pop, truncate, reset */
    cl_sb_reset(&sb);
    cl_sb_write_fmt(&sb, "item[%d] = %.1f", 7, 12.5);
    CL_TEST_EQ_STR(t, cl_sb_to_str(&sb), CL_STR("item[7] = 12.5"));
    cl_u8 popped = 0;
    CL_TEST_CHECK(t, cl_sb_pop_byte(&sb, &popped) && popped == '5');
    cl_sb_truncate(&sb, 7);
    CL_TEST_EQ_STR(t, cl_sb_to_str(&sb), CL_STR("item[7]"));

    /* UTF-8 rune write & repeat */
    cl_sb_reset(&sb);
    cl_sb_write_rune(&sb, 0x20AC); /* Euro sign */
    cl_sb_write_repeat(&sb, CL_STR("!"), 3);
    CL_TEST_EQ_I64(t, cl_utf8_rune_count(cl_sb_to_str(&sb)), 4);

    /* aprintf / tprintf / bprintf */
    Cl_Str a = cl_aprintf(cl_ctx_allocator(), "v=%d", 99);
    CL_TEST_EQ_STR(t, a, CL_STR("v=99"));
    cl_str_free(a, cl_ctx_allocator());

    Cl_Str tmp = cl_tprintf("temp=%s", "ok");
    CL_TEST_EQ_STR(t, tmp, CL_STR("temp=ok"));

    char stack[16];
    Cl_Str b = cl_bprintf(stack, (cl_isize)sizeof(stack), "num=%d", 1234);
    CL_TEST_EQ_STR(t, b, CL_STR("num=1234"));
}

static void test_string_builder_fixed_buffer_truncation(Cl_Test_State *t) {
    char buf[10];
    Cl_String_Builder sb;
    cl_sb_init_buffer(&sb, buf, (cl_isize)sizeof(buf));

    cl_sb_write_cstr(&sb, "hello");
    CL_TEST_CHECK(t, !sb.truncated);
    cl_sb_write_cstr(&sb, "_world_overflow");
    CL_TEST_CHECK(t, sb.truncated);
    CL_TEST_EQ_I64(t, sb.len, 10);
    CL_TEST_EQ_STR(t, cl_sb_to_str(&sb), CL_STR("hello_worl"));

    /* to_cstr clamps cleanly to buf[9] = '\0' */
    const char *cs = cl_sb_to_cstr(&sb);
    CL_TEST_CHECK(t, strcmp(cs, "hello_wor") == 0);
}

static void test_strbuf_inplace_manipulation(Cl_Test_State *t) {
    char raw[64];
    Cl_Str_Buf b = CL_STRBUF_FROM_ARRAY(raw);

    CL_TEST_CHECK(t, cl_strbuf_set(&b, CL_STR("  hello world  ")));
    cl_strbuf_trim_space_in_place(&b);
    CL_TEST_EQ_STR(t, cl_strbuf_as_str(&b), CL_STR("hello world"));

    /* Insert in middle */
    CL_TEST_CHECK(t, cl_strbuf_insert(&b, 5, CL_STR(" Odin")));
    CL_TEST_EQ_STR(t, cl_strbuf_as_str(&b), CL_STR("hello Odin world"));

    /* Erase substring */
    cl_strbuf_erase(&b, 5, 5);
    CL_TEST_EQ_STR(t, cl_strbuf_as_str(&b), CL_STR("hello world"));

    /* In-place find & replace (both growing and shrinking) */
    cl_isize n = cl_strbuf_replace_in_place(&b, CL_STR("l"), CL_STR("LL"));
    CL_TEST_EQ_I64(t, n, 3);
    CL_TEST_EQ_STR(t, cl_strbuf_as_str(&b), CL_STR("heLLLLo worLLd"));

    cl_isize n2 = cl_strbuf_replace_in_place(&b, CL_STR("LL"), CL_STR("l"));
    CL_TEST_EQ_I64(t, n2, 3);
    CL_TEST_EQ_STR(t, cl_strbuf_as_str(&b), CL_STR("hello world"));

    /* Case conversion, reverse, pad, append_fmt */
    cl_strbuf_to_upper_in_place(&b);
    CL_TEST_EQ_STR(t, cl_strbuf_as_str(&b), CL_STR("HELLO WORLD"));
    cl_strbuf_to_lower_in_place(&b);
    CL_TEST_EQ_STR(t, cl_strbuf_as_str(&b), CL_STR("hello world"));
    cl_strbuf_reverse_in_place(&b);
    CL_TEST_EQ_STR(t, cl_strbuf_as_str(&b), CL_STR("dlrow olleh"));

    cl_strbuf_set(&b, CL_STR("42"));
    CL_TEST_CHECK(t, cl_strbuf_pad_left_in_place(&b, 5, '0'));
    CL_TEST_EQ_STR(t, cl_strbuf_as_str(&b), CL_STR("00042"));
    CL_TEST_CHECK(t, cl_strbuf_pad_right_in_place(&b, 8, '_'));
    CL_TEST_EQ_STR(t, cl_strbuf_as_str(&b), CL_STR("00042___"));
    CL_TEST_CHECK(t, cl_strbuf_append_fmt(&b, ":%d", 7));
    CL_TEST_CHECK(t, strcmp(cl_strbuf_as_cstr(&b), "00042___:7") == 0);

    /* Truncation safety on tiny buffer */
    char tiny[6];
    Cl_Str_Buf tb = CL_STRBUF_FROM_ARRAY(tiny);
    CL_TEST_CHECK(t, !cl_strbuf_set(&tb, CL_STR("123456789")));
    CL_TEST_CHECK(t, tb.truncated);
    CL_TEST_CHECK(t, strcmp(cl_strbuf_as_cstr(&tb), "12345") == 0);
}

void suite_sb_strbuf(Cl_Test_State *t) {
    CL_RUN_TEST(t, test_string_builder_dynamic_and_complex);
    CL_RUN_TEST(t, test_string_builder_fixed_buffer_truncation);
    CL_RUN_TEST(t, test_strbuf_inplace_manipulation);
}
