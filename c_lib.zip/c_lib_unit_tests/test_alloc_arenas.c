/*
 * ============================================================================
 * c_lib_unit_tests - Suite 2: Allocators, Arenas, Virtual Arena, Pool & Context
 * File: test_alloc_arenas.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 * ============================================================================
 */

#include "cl_test.h"

static void test_heap_aligned_alloc_and_resize(Cl_Test_State *t) {
    Cl_Allocator a = cl_ctx_allocator();

    /* Standard zeroed allocation */
    cl_i64 *nums = cl_make_array(a, cl_i64, 16);
    CL_TEST_CHECK(t, nums != NULL);
    for (int i = 0; i < 16; i++) {
        CL_TEST_EQ_I64(t, nums[i], 0);
        nums[i] = i * 10;
    }

    /* Resize upward should preserve old bytes and zero new bytes */
    nums = (cl_i64 *)cl_resize(a, nums, 16 * (cl_isize)sizeof(cl_i64), 32 * (cl_isize)sizeof(cl_i64));
    CL_TEST_CHECK(t, nums != NULL);
    for (int i = 0; i < 16; i++) {
        CL_TEST_EQ_I64(t, nums[i], i * 10);
    }
    for (int i = 16; i < 32; i++) {
        CL_TEST_EQ_I64(t, nums[i], 0);
    }
    cl_free(a, nums, 32 * (cl_isize)sizeof(cl_i64));

    /* Over-aligned allocation (64-byte cache line alignment) */
    void *aligned = cl_alloc_aligned(a, 128, 64);
    CL_TEST_CHECK(t, aligned != NULL);
    CL_TEST_EQ_U64(t, ((cl_uintptr)aligned) % 64u, 0u);
    aligned = cl_resize_aligned(a, aligned, 128, 256, 64);
    CL_TEST_CHECK(t, aligned != NULL);
    CL_TEST_EQ_U64(t, ((cl_uintptr)aligned) % 64u, 0u);
    cl_free(a, aligned, 256);
}

static void test_fixed_arena_temp_and_inplace_resize(Cl_Test_State *t) {
    cl_u8 backing[4096];
    Cl_Arena arena;
    cl_arena_init_buffer(&arena, backing, (cl_isize)sizeof(backing));
    CL_DEFER_ARENA(arena);

    Cl_Allocator aa = cl_arena_allocator(&arena);

    cl_i32 *x = cl_new(aa, cl_i32);
    CL_TEST_CHECK(t, x != NULL && *x == 0);
    *x = 777;

    /* In-place top allocation resize should reuse exact same pointer */
    cl_u8 *buf = (cl_u8 *)cl_alloc(aa, 64);
    CL_TEST_CHECK(t, buf != NULL);
    buf[0] = 42;
    buf[63] = 99;
    cl_u8 *grown = (cl_u8 *)cl_resize(aa, buf, 64, 256);
    CL_TEST_CHECK(t, grown == buf);
    CL_TEST_EQ_U64(t, grown[0], 42);
    CL_TEST_EQ_U64(t, grown[63], 99);
    CL_TEST_EQ_U64(t, grown[255], 0);

    /* Checkpoint / rewind */
    cl_isize before = cl_arena_used(&arena);
    Cl_Arena_Temp tmp = cl_arena_temp_begin(&arena);
    void *scratch = cl_alloc(aa, 1024);
    CL_TEST_CHECK(t, scratch != NULL);
    CL_TEST_CHECK(t, cl_arena_used(&arena) >= before + 1024);
    cl_arena_temp_end(tmp);
    CL_TEST_EQ_I64(t, cl_arena_used(&arena), before);
    CL_TEST_EQ_I64(t, *x, 777);

    /* Exhaustion returns NULL cleanly */
    void *too_big = cl_alloc(aa, 8192);
    CL_TEST_CHECK(t, too_big == NULL);

    cl_arena_reset(&arena);
    CL_TEST_EQ_I64(t, cl_arena_used(&arena), 0);
}

static void test_virtual_arena_growth_and_pointer_stability(Cl_Test_State *t) {
    Cl_Virtual_Arena va;
    CL_TEST_CHECK(t, cl_varena_init(&va, CL_MB(16), CL_KB(64)));
    CL_DEFER_VARENA(va);

    Cl_Allocator a = cl_varena_allocator(&va);

    /* Allocate first object in first 64 KiB commit chunk */
    cl_i64 *first = cl_new(a, cl_i64);
    CL_TEST_CHECK(t, first != NULL);
    *first = 123456789LL;
    CL_TEST_EQ_I64(t, va.committed, CL_KB(64));

    /* Grow across multiple commit chunks -> `first` pointer MUST stay valid & unchanged! */
    cl_u8 *big = (cl_u8 *)cl_alloc(a, CL_KB(200));
    CL_TEST_CHECK(t, big != NULL);
    big[0] = 0xAAu;
    big[CL_KB(200) - 1] = 0x55u;
    CL_TEST_CHECK(t, va.committed >= CL_KB(256));
    CL_TEST_EQ_I64(t, *first, 123456789LL);

    /* Temp checkpoint & rewind */
    cl_isize used_before = va.offset;
    Cl_VArena_Temp vt = cl_varena_temp_begin(&va);
    void *tmp_blk = cl_alloc(a, CL_KB(32));
    CL_TEST_CHECK(t, tmp_blk != NULL);
    cl_varena_temp_end(vt);
    CL_TEST_EQ_I64(t, va.offset, used_before);

    /* Reset with physical page decommit and reuse cleanly */
    cl_varena_reset(&va, true);
    CL_TEST_EQ_I64(t, va.offset, 0);
    CL_TEST_EQ_I64(t, va.committed, 0);
    cl_i64 *again = cl_new(a, cl_i64);
    CL_TEST_CHECK(t, again != NULL && *again == 0);
}

static void test_pool_allocator(Cl_Test_State *t) {
    typedef struct Node {
        cl_i64 id;
        cl_f64 weight;
    } Node;

    Cl_Pool pool;
    CL_TEST_CHECK(t, cl_pool_init_alloc(&pool, 8, (cl_isize)sizeof(Node), CL_ALIGNOF(Node), cl_ctx_allocator()));
    CL_DEFER_POOL(pool);

    Cl_Allocator pa = cl_pool_allocator(&pool);
    Node *nodes[8];
    for (int i = 0; i < 8; i++) {
        nodes[i] = cl_new(pa, Node);
        CL_TEST_CHECK(t, nodes[i] != NULL);
        CL_TEST_EQ_I64(t, nodes[i]->id, 0);
        nodes[i]->id = i + 100;
    }

    /* 9th allocation fails cleanly when pool is full */
    CL_TEST_CHECK(t, cl_new(pa, Node) == NULL);

    /* Free slot 3 and reallocate -> should reuse cleanly */
    cl_delete(pa, nodes[3]);
    CL_TEST_EQ_I64(t, pool.used_count, 7);
    Node *reused = cl_new(pa, Node);
    CL_TEST_CHECK(t, reused == nodes[3]);
    CL_TEST_EQ_I64(t, reused->id, 0);

    cl_free_all(pa);
    CL_TEST_EQ_I64(t, pool.used_count, 0);
}

static void test_context_stack_and_dual_scratch(Cl_Test_State *t) {
    Cl_Arena local;
    CL_TEST_CHECK(t, cl_arena_init_alloc(&local, CL_KB(8), cl_ctx_allocator()));
    CL_DEFER_ARENA(local);

    Cl_Allocator orig = cl_ctx_allocator();
    {
        Cl_Context sub = {0};
        sub.allocator = cl_arena_allocator(&local);
        sub.user_index = 42;
        CL_DEFER_CTX_PUSH(sub);

        CL_TEST_CHECK(t, cl_ctx_allocator().data == &local);
        CL_TEST_EQ_I64(t, cl_ctx_current()->user_index, 42);
        int *p = cl_new(cl_ctx_allocator(), int);
        CL_TEST_CHECK(t, p != NULL && cl_arena_used(&local) > 0);
    }
    /* Restored automatically on scope exit */
    CL_TEST_CHECK(t, cl_ctx_allocator().data == orig.data);

    /* Conflict-free dual scratch arenas: second scratch must not alias first */
    Cl_Scratch s1 = cl_scratch_begin(NULL, 0);
    CL_DEFER_SCRATCH(s1);
    Cl_Scratch s2 = cl_scratch_begin(&s1.allocator, 1);
    CL_DEFER_SCRATCH(s2);
    CL_TEST_CHECK(t, s1.allocator.data != s2.allocator.data);

    cl_i64 *a = cl_new(s1.allocator, cl_i64);
    cl_i64 *b = cl_new(s2.allocator, cl_i64);
    *a = 111;
    *b = 222;
    CL_TEST_EQ_I64(t, *a, 111);
    CL_TEST_EQ_I64(t, *b, 222);
}

void suite_alloc_arenas(Cl_Test_State *t) {
    CL_RUN_TEST(t, test_heap_aligned_alloc_and_resize);
    CL_RUN_TEST(t, test_fixed_arena_temp_and_inplace_resize);
    CL_RUN_TEST(t, test_virtual_arena_growth_and_pointer_stability);
    CL_RUN_TEST(t, test_pool_allocator);
    CL_RUN_TEST(t, test_context_stack_and_dual_scratch);
}
