/*
 * ============================================================================
 * c_lib_unit_tests - Suite 10: Logging, Linux OS File I/O & Stopwatch
 * File: test_log_os_time.c
 * License: MIT Open Source License (see LICENSE file)
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Joao Carvalho
 * ============================================================================
 */

#include "cl_test.h"
#include <stdio.h>

static void test_file_and_multi_logger(Cl_Test_State *t) {
    Cl_Str path1 = CL_STR("/tmp/c_lib_test_log1.txt");
    Cl_Str path2 = CL_STR("/tmp/c_lib_test_log2.txt");

    FILE *fp1 = fopen("/tmp/c_lib_test_log1.txt", "w");
    FILE *fp2 = fopen("/tmp/c_lib_test_log2.txt", "w");
    CL_TEST_CHECK(t, fp1 != NULL && fp2 != NULL);

    Cl_Multi_Logger ml;
    cl_multi_logger_init(&ml);
    CL_TEST_CHECK(t, cl_multi_logger_add(&ml, cl_file_logger(fp1, CL_LOG_LEVEL_INFO, CL_LOG_OPT_LEVEL)));
    CL_TEST_CHECK(t, cl_multi_logger_add(&ml, cl_file_logger(fp2, CL_LOG_LEVEL_WARN, CL_LOG_OPT_LEVEL)));

    {
        Cl_Context ctx = {0};
        ctx.logger = cl_multi_logger(&ml, CL_LOG_LEVEL_DEBUG);
        CL_DEFER_CTX_PUSH(ctx);

        CL_LOG_DEBUG("hidden debug");
        CL_LOG_INFO("hello info %d", 1);
        CL_LOG_WARN("hello warn %d", 2);
    }

    fclose(fp1);
    fclose(fp2);

    Cl_Res_Str r1 = cl_os_read_entire_file_str(path1, cl_ctx_allocator());
    Cl_Res_Str r2 = cl_os_read_entire_file_str(path2, cl_ctx_allocator());
    CL_TEST_EQ_I64(t, r1.err, CL_ERR_NONE);
    CL_TEST_EQ_I64(t, r2.err, CL_ERR_NONE);

    /* Sink 1 (>= INFO) received INFO and WARN, not DEBUG */
    CL_TEST_CHECK(t, !cl_str_contains(r1.value, CL_STR("hidden debug")));
    CL_TEST_CHECK(t, cl_str_contains(r1.value, CL_STR("hello info 1")));
    CL_TEST_CHECK(t, cl_str_contains(r1.value, CL_STR("hello warn 2")));

    /* Sink 2 (>= WARN) received only WARN */
    CL_TEST_CHECK(t, !cl_str_contains(r2.value, CL_STR("hello info 1")));
    CL_TEST_CHECK(t, cl_str_contains(r2.value, CL_STR("hello warn 2")));

    cl_str_free(r1.value, cl_ctx_allocator());
    cl_str_free(r2.value, cl_ctx_allocator());
    (void)cl_os_remove_file(path1);
    (void)cl_os_remove_file(path2);
}

static void test_os_file_roundtrip_and_env(Cl_Test_State *t) {
    Cl_Str path = CL_STR("/tmp/c_lib_test_roundtrip.txt");
    Cl_Str payload = CL_STR("Line 1: Odin-inspired C99\nLine 2: 3+4i\n");

    Cl_Error werr = cl_os_write_entire_file_str(path, payload);
    CL_TEST_EQ_I64(t, werr, CL_ERR_NONE);
    CL_TEST_CHECK(t, cl_os_file_exists(path));

    Cl_Res_ISize sz = cl_os_file_size(path);
    CL_TEST_EQ_I64(t, sz.err, CL_ERR_NONE);
    CL_TEST_EQ_I64(t, sz.value, payload.len);

    Cl_Res_Str read = cl_os_read_entire_file_str(path, cl_ctx_allocator());
    CL_TEST_EQ_I64(t, read.err, CL_ERR_NONE);
    CL_TEST_EQ_STR(t, read.value, payload);
    cl_str_free(read.value, cl_ctx_allocator());

    CL_TEST_EQ_I64(t, cl_os_remove_file(path), CL_ERR_NONE);
    CL_TEST_CHECK(t, !cl_os_file_exists(path));

    /* Atomic whole-file write + C-string path overloads */
    Cl_Str atomic_path = CL_STR("/tmp/c_lib_test_atomic.bin");
    cl_u8 bin_payload[6] = { 0xDEu, 0xADu, 0xBEu, 0xEFu, 0x00u, 0x42u };
    Cl_Bytes bin_slice = CL_SLICE_FROM_ARRAY(Cl_Bytes, bin_payload);
    CL_TEST_EQ_I64(t, cl_os_write_entire_file_atomic(atomic_path, bin_slice), CL_ERR_NONE);

    Cl_Res_Bytes read_bin = cl_os_read_entire_file_cstr("/tmp/c_lib_test_atomic.bin", cl_ctx_allocator());
    CL_TEST_EQ_I64(t, read_bin.err, CL_ERR_NONE);
    CL_TEST_CHECK(t, CL_SLICE_EQUAL(read_bin.value, bin_slice));
    CL_SLICE_FREE(cl_ctx_allocator(), read_bin.value);

    /* C-string write overload */
    CL_TEST_EQ_I64(t, cl_os_write_entire_file_cstr("/tmp/c_lib_test_atomic.bin", bin_slice), CL_ERR_NONE);
    CL_TEST_EQ_I64(t, cl_os_remove_file(atomic_path), CL_ERR_NONE);

    /* Linux /proc virtual file (st_size == 0) read_entire_file fallback */
    if (cl_os_file_exists(CL_STR("/proc/version"))) {
        Cl_Res_Str proc_ver = cl_os_read_entire_file_str(CL_STR("/proc/version"), cl_ctx_allocator());
        CL_TEST_EQ_I64(t, proc_ver.err, CL_ERR_NONE);
        CL_TEST_CHECK(t, proc_ver.value.len > 0);
        CL_TEST_CHECK(t, cl_str_contains(proc_ver.value, CL_STR("Linux")));
        cl_str_free(proc_ver.value, cl_ctx_allocator());
    }

    /* Reading missing file returns CL_ERR_NOT_FOUND */
    Cl_Res_Str miss = cl_os_read_entire_file_str(CL_STR("/tmp/c_lib_does_not_exist_99999.txt"), cl_ctx_allocator());
    CL_TEST_EQ_I64(t, miss.err, CL_ERR_NOT_FOUND);

    /* Env variable lookup */
    Cl_Opt_Str path_env = cl_os_env_get(CL_STR("PATH"));
    CL_TEST_CHECK(t, path_env.ok && path_env.value.len > 0);
    CL_TEST_CHECK(t, !cl_os_env_get(CL_STR("CL_NON_EXISTENT_ENV_VAR_XYZ")).ok);
}

static void test_monotonic_stopwatch(Cl_Test_State *t) {
    Cl_Stopwatch sw = {0};
    cl_stopwatch_start(&sw);
    cl_time_sleep_ms(10);
    cl_stopwatch_stop(&sw);

    cl_f64 ms = cl_stopwatch_elapsed_ms(&sw);
    CL_TEST_CHECK(t, ms >= 8.0 && ms < 2000.0);

    cl_stopwatch_reset(&sw);
    CL_TEST_EQ_I64(t, cl_stopwatch_elapsed_ns(&sw), 0);
}

void suite_log_os_time(Cl_Test_State *t) {
    CL_RUN_TEST(t, test_file_and_multi_logger);
    CL_RUN_TEST(t, test_os_file_roundtrip_and_env);
    CL_RUN_TEST(t, test_monotonic_stopwatch);
}
